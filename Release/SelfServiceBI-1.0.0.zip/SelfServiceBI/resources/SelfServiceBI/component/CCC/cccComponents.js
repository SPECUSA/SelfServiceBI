function prepareChartDefination (chartProperties,htmlObj,chartType){

    var options=[];        
    for(var i = 0;i < chartProperties.length;i++)
    {
        if(chartProperties[i][2] == "javascript")
        {
            if(chartProperties[i][3] != undefined && chartProperties[i][3].length > 0)
            {
                
                options[chartProperties[i][0]]= eval("Demo = " +chartProperties[i][3]);
            }
            else
                options[chartProperties[i][0]]= chartProperties[i][3];

        }
        else
            options[chartProperties[i][0]]= chartProperties[i][3];
    }
    options["canvas"] = htmlObj;        
    //console.log(chartType);
    options["width"]  = $("#"+htmlObj ).width();
    if(chartType != 'CCCBullet')
        options["height"]  = $("#"+htmlObj ).height();

    
    console.log(options);

    return options;
            
}

function CCCArea(){};
CCCArea.prototype = new SSBBaseComponent();
CCCArea.prototype = {
    chartType : "CCCarea",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCarea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCarea : postExecution");
    } 
}

function CCCBar(){};
CCCBar.prototype = new SSBBaseComponent();
CCCBar.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}

function CCCBoxplot(){};
CCCBoxplot.prototype = new SSBBaseComponent();
CCCBoxplot.prototype = {
    chartType : "CCCboxplot",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BoxplotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCboxplot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCboxplot : postExecution");
    } 
}

function CCCBullet(){};
CCCBullet.prototype = new SSBBaseComponent();
CCCBullet.prototype = {
    chartType : "CCCbullet",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj,"CCCBullet"),
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BulletChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCbullet : preExecution");
    },
    postExecution: function () {
        //console.log("CCCbullet : postExecution");
    } 
}

function CCCDot(){};
CCCDot.prototype = new SSBBaseComponent();
CCCDot.prototype = {
    chartType : "CCCdot",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.DotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}

function CCCHeatGrid(){};
CCCHeatGrid.prototype = new SSBBaseComponent();
CCCHeatGrid.prototype = {
    chartType : "CCCheat",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.HeatGridChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCheat : preExecution");
    },
    postExecution: function () {
        //console.log("CCCheat : postExecution");
    } 
}

function CCCLine(){};
CCCLine.prototype = new SSBBaseComponent();
CCCLine.prototype = {
    chartType : "CCCline",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.LineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCline : preExecution");
    },
    postExecution: function () {
        //console.log("CCCline : postExecution");
    } 
}

function CCCMetricDot(){};
CCCMetricDot.prototype = new SSBBaseComponent();
CCCMetricDot.prototype = {
    chartType : "CCCmetricDot",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.MetricDotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCmetricDot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCmetricDot : postExecution");
    } 
}

function CCCPie(){};
CCCPie.prototype = new SSBBaseComponent();
CCCPie.prototype = {
    chartType : "CCCpie",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}

function CCCStackedArea(){};
CCCStackedArea.prototype = new SSBBaseComponent();
CCCStackedArea.prototype = {
    chartType : "CCCstackedArea",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}

function CCCStackedLine(){};
CCCStackedLine.prototype = new SSBBaseComponent();
CCCStackedLine.prototype = {
    chartType : "CCCstackedLine",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.StackedLineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedLine : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedLine : postExecution");
    } 
}

function CCCSunburst(){};
CCCSunburst.prototype = new SSBBaseComponent();
CCCSunburst.prototype = {
    chartType : "CCCsunburst",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.SunburstChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCsunburst : preExecution");
    },
    postExecution: function () {
        //console.log("CCCsunburst : postExecution");
    } 
}

function CCCTreemap(){};
CCCTreemap.prototype = new SSBBaseComponent();
CCCTreemap.prototype = {
    chartType : "CCCtreemap",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.TreemapChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCtreemap : preExecution");
    },
    postExecution: function () {
        //console.log("CCCtreemap : postExecution");
    } 
}

function CCCWaterfall(){};
CCCWaterfall.prototype = new SSBBaseComponent();
CCCWaterfall.prototype = {
    chartType : "CCCwaterfall",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.WaterfallChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCwaterfall : preExecution");
    },
    postExecution: function () {
        //console.log("CCCwaterfall : postExecution");
    } 
}

function Table(){};
Table.prototype = new SSBBaseComponent();
Table.prototype = {
    chartType : "CCCTable",

    init : function(chartID,data,htmlObj,chartProperties){
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination = prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render : function(){
        var rows = this.data.queryInfo.totalRows;
        //var totalcols = this.data.metadata.length;
        var cols = this.data.metadata.length;
        var outputCols = [];       
        var data = this.data.resultset;
        var table = '';
        var row = '';
        var col ='';
        //console.log(this.chartDefination['outputCols'].length);

        var len = this.chartDefination['outputCols'].length;

        for(var a=0;a<len;a++)
            if(this.chartDefination['outputCols'][a] <= cols)
                outputCols.push(this.chartDefination['outputCols'][a] -1);
        
        //console.log(outputCols);

        if(cols >= this.chartDefination['noOfColumns'])
            cols = this.chartDefination['noOfColumns'];
        //console.log(cols);

        if(outputCols.length > cols)
            while(outputCols.length>cols)
                outputCols.pop();

        else if(outputCols.length < cols){
            var addEle = true;
            for(var a=0;outputCols.length<cols;a++){

                if(outputCols.length > 0)
                    for(var b=0;b<outputCols.length;b++){
                        addEle = true;
                        //console.log(outputCols[b] +" "+a)
                        if(outputCols[b] == a){
                            //console.log("this is true");
                            addEle = false;
                            break;
                        }
                    }

                if(addEle)
                    outputCols.push(a);
                //console.log(outputCols);
            }
        }     
        outputCols.sort();
        //console.log(outputCols);

        for(var i=0;i<=rows;i++){
            col = '';
            if(i==0)
                row = '<thead>';
            else if(i==1)
                row = row + '<tbody>';
            row = row +'<tr>';
                for(var j=0;j<outputCols.length;j++){
                    if(i==0)
                        col = col+'<th class="tHead">'+this.data.metadata[outputCols[j]].colName+'</th>';                               
                    else
                        col = col + '<td>'+data[i-1][outputCols[j]]+'</td>';
                }
            row = row + col + '</tr>';
            if(i==0)
                row = row +'</thead>';
            else if(i==rows)
                row = row + '</tbody>';
        }

        table = '<div class="pageTitle" style="text-align:'+this.chartDefination["titleAlign"]+'">'+this.chartDefination["title"]+'</div><table id="'+this.htmlObj+'_table" class="table table-bordered table-condensed">'+ row +'</table><div id="'+this.htmlObj+'_page" style="text-align:center"></div>';
        //var navBar = '<div class="pageNav"></div>'

        //var rTable = $(table);
        //$('#'+this.htmlObj+'_table',rTable).append('<div class="pageNav"></div>');
        //$(table).filter('#'+this.htmlObj+'_table').append('<div class="pageNav"></div>');
        /*
        var rowsShown = this.chartDefination['noOfRows'];
        var rowsTotal = rows;
        var noOfPages = rowsTotal/rowsShown;

        for(i=0;i<noOfPages;i++){
            var pageNum = i +1;
            $(table).filter('.pageNav').append('<a href="#" rel="'+i+'">'+pageNum+'</a>');
        }
        $(table).filter('#'+this.htmlObj+'_table tbody tr').hide();
        $(table).filter('#'+this.htmlObj+'_table tbody tr').slice(0,rowsShown).show();
        $(table).filter('.pageNav a:first').addClass('active');
        $(table).filter('.pageNav a').bind('click',function(){
            $(table).filter('.pageNav a').removeClass('active');
                $(this).addClass('active');
                var currPage = $(this).attr('rel');
                var startItem = currPage * rowsShown;
                var endItem = startItem + rowsShown;
                $(table).filter('#'+this.htmlObj+'_table tbody tr').css('opacity','0.0').hide().slice(startItem, endItem).
                        css('display','table-row').animate({opacity:1}, 300);
        })
*/
        //console.log($(rTable).prop('outerHTML'));
        $('#'+this.chartDefination['canvas']).append(table);

        var rowsShown = this.chartDefination['noOfRows'];
        var numPages = rows/rowsShown;
        if(parseInt(numPages)<numPages)
            numPages = parseInt(numPages)+1;

        //console.log(this.chartDefination['noOfRows'])
        //console.log(numPages)
        var self = this;
        $('#'+this.htmlObj+'_page').bootpag({
            total : numPages
        }).on("page",function(event,num){
            //$('#'+this.htmlObj+'_page').html();
            //console.log(num);
            var currPage = num-1;
            var startItem = currPage * rowsShown;
            var endItem = startItem + parseInt(rowsShown);
            //console.log(self.htmlObj +" "+this.htmlObj);
            $('#'+self.htmlObj+'_table tbody tr').hide();
            //$('#'+this.htmlObj+'_table tbody tr').css('opacity','0.0').hide();
            $('#'+self.htmlObj+'_table tbody tr').slice(startItem, endItem).show();

            //$('#'+this.htmlObj+'_table tbody tr').slice(startItem, endItem).
              //      css('display','table-row').animate({opacity:1}, 300);
        })

        $('#'+this.htmlObj+'_table tbody tr').hide();
        $('#'+this.htmlObj+'_table tbody tr').slice(0, rowsShown).show();
        
        //var navBar = '<div id="'+this.htmlObj+'_nav" style="text-align:center">'+pages+'</div>'

        //$('#'+this.htmlObj+'_table').before(navBar);
        
        /*
            var rowsShown = 4;
            var rowsTotal = rows;
            var numPages = rowsTotal/rowsShown;
            for(i = 0;i < numPages;i++) {
                var pageNum = i + 1;
                $('#nav').append('<a href="#" rel="'+i+'">'+pageNum+'</a> ');
            }
            $('#'+this.htmlObj+'_table tbody tr').hide();
            $('#'+this.htmlObj+'_table tbody tr').slice(0, rowsShown).show();
            $('#nav a:first').addClass('active');
            $('#nav a').bind('click', function(){
 
                $('#nav a').removeClass('active');
                $(this).addClass('active');
                var currPage = $(this).attr('rel');
                var startItem = currPage * rowsShown;
                var endItem = startItem + rowsShown;
                $('#'+this.htmlObj+'_table tbody tr').css('opacity','0.0').hide().slice(startItem, endItem).
                        css('display','table-row').animate({opacity:1}, 300);
            });
        */
        //$('#'+this.htmlObj+'_table').append("<div>chudamani</div>")

    },
    preExecution : function(){
        this.render();
    },
    postExecution : function(){
        
    }
}