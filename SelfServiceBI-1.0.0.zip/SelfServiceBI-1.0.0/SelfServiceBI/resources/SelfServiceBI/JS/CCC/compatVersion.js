// Set the default compatibility version to CCC v1.
pvc.defaultCompatVersion(1);