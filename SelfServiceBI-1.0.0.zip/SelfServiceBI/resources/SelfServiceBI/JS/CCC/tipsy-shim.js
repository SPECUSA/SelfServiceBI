
$.tipsy = function() {};
pv.Behavior.tipsy = function() {};
