$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
});


/*$(document).ready(function(){
	$(".btn-filterComponent").hide();
	$(".btn-show-filteroption").on("click", function(e){
		$(".btn-filterComponent").show();
	});
});*/

$(document).ready(function(){
	$winH=$(window).height();
	$winW=$(window).width();  
	//$(".main-navigation").css("height",$winW+70);
	//$("#leftPanel").css("height",$winW+70);
	//$("#mainpage").css("min-height",$winW+70);
	$(".mainpage-singlepin").css("width",$winW);
	$("#mainpage").css("min-height",$winH);
	$(".DisplayGrid").css("width",$winW-330);
	
	$("#clickme").prependTo(".main-navigation");
	$("#clickme").on("click", function(e){
		e.preventDefault();
			var hrefval = $(this).attr("href");
			if(hrefval == "#leftPanel") {
				var distance = $('#mainpage').css('left');
				//alert($w1);
				if(distance == "auto" || distance == "0px") {
					$(this).addClass("open");
						openSidepage();
					} else {
						closeSidepage();
					}
			}
	}); // end click event handler
  
 
//  $("#closebtn").on("click", function(e){
//    e.preventDefault();
//    closeSidepage();
//  }); 

  function openSidepage() {
	$w1=$(window).width();
    $('#mainpage').animate({
      left: '330px'
    }, 400, 'easeOutBack');
	$("#mainpage").removeClass("mainpageW"); 
	$("#mainpage").css("width",$w1-330);
	$(".DisplayGrid").css("width",$w1-330);
	$(".main-navigation a#clickme").addClass("panel-setting-active");
  }
  
  function closeSidepage(){
	$w2=$(window).width();  
    $("#clickme").removeClass("open");
    $('#mainpage').animate({
      left: '0px'
    }, 400, 'easeOutQuint');  
	$("#mainpage").addClass("mainpageW");
	$("#mainpage").css("width",$w2-70);
	$(".DisplayGrid").css("width",$w2-70);	
	$(".main-navigation a#clickme").removeClass("panel-setting-active");
  }
}); 