angular.module('commonUtilModule',[]);

angular.module('commonUtilModule')
.service('commonUtils',['$http','$log','$compile',function($http,$log,$compile){
    this.debugApplication =true;

    this.mode = "pinboard" //pin/pinboard
    this.isPinboard = true;
    this.editor = true;
    this.savedFlag = false;
    this.savedFileFlag = false;
    this.propertiesSaved = false;
    this.isNull = true;
    this.notificationDelay = 4000;
    this.notificationType = "growl";
    this.components = null;
    var self = this;

    this.version = "3.0.0";
    this.buildVersion  = "b-3.0.0-1";

    this.CdaUrl = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery';

    this.getParameterByName = function(name){
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    };
    this.synchronousJsonCall = function (url, method, data) {
        var jsonData;
        jQuery.ajax({
            url:    url,
            data:   data,
            type :  method,
            DataType:'jsonp',
            success:function(result) {
                jsonData = result;
            },
            async:  false
        });

        return jsonData;
    };

    this.readJSONFile = function (url) {
       return JSON.parse(
            $.ajax({
                type: 'GET',
                url: url,
                async: false,
                dataType: 'json',
                data: null,
                done: function(response) {
                    return  response;
                }
            }).responseText)
    };
     this.getHtmlContent = function(url){
        var htmlData;
        jQuery.ajax({
            url : url,
            data: null,
            async : false,
            type : 'GET',
            success : function(result){
                htmlData = result;
            }
        });
        return htmlData;
    }
    filePathValidation = function(path,ext){

        if(path == null || path == undefined || path.length <1)
        {
            //return Messanges.onInvalidFileName;
            return false;
        }
        else
        {
            var tempArray = path.split(".");
            if(tempArray.length <2)
                return false;
            else
            {
                var tempExt=tempArray[tempArray.length-1];

                if(tempExt == ext)
                    return true;
                else
                    return false;
            }
        }
    };

    this.saveDialogBox = function(dialogTitle,ext,onSave,onCancel){
        var selectedFile="";
        var selectedFolder="";
        var data=BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog) {
                var $message = $('<div class="modal-form"><div id="container_id" class="JqueryContainer"></div><div class="cl15"></div><div class="form-group"><div class="col-lg-4 col-md-4 col-sm-4 form-group-left">File Name</div><div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><input type="text" name="fileInput" class="form-control" id="fileInput"  value="" /></div></div>'+
                                '<div class="cl5"></div></div><div class="cl"></div>'+
                                '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                                '<span class="sr-only">Error:</span>'+
                                'Please input valid file name' +'</div>');
                return $message;
            },
            draggable: true,
            closable : false,
            cssClass : 'browse-dialog',
            onshown: function(dialogRef)
            {
                $('#container_id').fileTree({
                    root: '/',
                    script: "../../../plugin/SelfServiceBI/api/explore"+ "?fileExtensions="+ ext+"&access=create",
                    expandSpeed: 1000,
                    collapseSpeed: 1000,
                    multiFolder: false
                }, function(file) {
                    $("#fileInput").val(file);
                    selectedFile = $("#fileInput").val();
                });
                // event listeners
                $('#container_id').on('filetreeexpand', function (e, data)
                {
                    selectedFolder = data.rel;
                    $("#fileInput").val(selectedFolder);
                });
            },
            buttons: [{
                id: 'btn-save',
                label: 'Save',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    //var valid = filePathValidation($("#fileInput").val(),ext);
                    var path = $('#fileInput').val();
                    //$log.log(path);
                    /*
                    function isNotAlphaNumeric(code){
                        $log.log(code);
                        if (!(code > 47 && code < 58) && !(code > 64 && code < 91) && !(code > 96 && code < 123))
                          return true;
                        return false;
                    }
                    */
                    
                    if(path == undefined || path.length < 1 /* || isNotAlphaNumeric(path.charAt(path.length-1)) */){
                        $("#errorMsg").show();
                        return;
                    }
                    var valid = $('#fileInput').val().toLowerCase().search('.'+ext);
                    //$log.log($('#fileInput').val().toLowerCase())
                    //$log.log(valid);

                    if(valid < 0)
                    {
                        dialogItself.close();
                        //$log.log($("#fileInput").val()+'.'+ext);
                        onSave($("#fileInput").val()+'.'+ext);
                    }
                    else
                    {
                        dialogItself.close();
                        onSave($("#fileInput").val());
                    }


                    
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    };

    this.openDialogBox = function(dialogTitle,ext,onSave,onCancel){
        var selectedFile="";
        var selectedFolder="";
        var data=BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog) {
                var $message = $(
                '<div class="modal-form"><div id="container_id" class="JqueryContainer"></div><div class="cl15"></div><div class="form-group"><div class="col-lg-4 col-md-4 col-sm-4 form-group-left">File Name</div><div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><input type="text" name="fileInput" class="form-control" id="fileInput"  value="" /></div></div><div class="cl"></div>'+
                '</div><small class="notification"><strong>*Note:</strong> Specify file extension as '+ ext +' (fileName.'+ ext+'). </small><div class="cl5"></div>'+
                '</div><div class="cl"></div>'+
                '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                    '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                    '<span class="sr-only">Error:</span>'+
                    'Please input valid file name' +'</div>'
                );
                return $message;
            },
            draggable: true,
            closable : false,
            cssClass : 'browse-dialog',
            onshown: function(dialogRef)
            {
                $('#container_id').fileTree({
                    root: '/',
                    script: "../../../plugin/SelfServiceBI/api/explore"+ "?fileExtensions="+ ext+"&access=create",
                    expandSpeed: 1000,
                    collapseSpeed: 1000,
                    multiFolder: false
                }, function(file) {
                    $("#fileInput").val(file);
                    selectedFile = $("#fileInput").val();
                });
                // event listeners
                $('#container_id').on('filetreeexpand', function (e, data)
                {
                    selectedFolder = data.rel;
                    $("#fileInput").val(selectedFolder);
                });
            },
            buttons: [{
                id: 'btn-save',
                label: 'Open',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = filePathValidation($("#fileInput").val(),ext);
                    if(valid)
                    {
                        dialogItself.close();
                        onSave($("#fileInput").val());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    };

    this.BootstrapConfirm = function(msg,userResult){
        BootstrapDialog.confirm(msg, function(result){
            userResult(result);
        });
    };

    this.removeElements = function (text, selector) {
        var wrapped = $("<div>" + text + "</div>");
        wrapped.find(selector).remove();
        return wrapped.html();
    };

     this.btnPinSaikuBrowse = function(title,ext,fileTxtbox,getData){
        var self = this;

        function onOpen(path){
           getData(path);
        }
        function onCancel(dialogItself){}
        this.openDialogBox(title,ext,onOpen,onCancel);
    };

    this.colorDialog = function(dialogTitle,colorArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);

                var template =  '<div class="colorTableWrapper">'+
                                '<div id="colorTable">'+
                                '</div>'+
                                '<div class="form-inline"><div class="label label-add-color">Add Color </div>'+
                                '<input class="form-control" type="text" id="inputColor" ng-model="inputColor" colorpicker="hex">'+
                                '<button class="btn btn-default" id="addColor" ng-click="addColor()"><i class="glyphicon glyphicon-plus"></i></button></div>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'color-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                var length = colorArray.length;
                if(colorArray.length != 0){
                    for(i=0;i<colorArray.length;i++){

                        var temp =  '<div id="row'+i+'" class="form-inline" style="padding-bottom:5px;">'+
                                    '<input colorpicker="hex" colorpicker-with-input="true" class="form-control colorText" type="text" id="colorRow'+i+'"  ng-model="colorRow'+i+'" ng-change="colorChanged('+i+')"/>'+
                                    '<button class="btn btn-sm btn-default glyphicon glyphicon-remove removeColorEvent removeParam" style="margin-left:5px;" ng-click="removeColor('+i+')"></button><div class="showColor" id="showColor'+i+'" style="background-color:{{colorRow'+i+'}}"></div></div>'
                        $('#colorTable').append($compile(temp)(scope));
                        var vari = 'colorRow'+i ;
                        scope[vari] = colorArray[i];
                    };
                }

                scope.addColor = function(){
                    if(scope.inputColor == undefined || scope.inputColor.length <= 0){
                        return
                    }
                    $log.debug("this is add color called");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<div id="row'+l+'" class="form-inline" style="padding-bottom:5px;">'+
                                '<input colorpicker="hex" colorpicker-with-input="true" class="form-control colorText" type="text" id="colorRow'+l+'"  ng-model="colorRow'+l+'" ng-change="colorChanged('+l+')"/>'+
                                '<button class="btn btn-sm btn-default glyphicon glyphicon-remove removeColorEvent removeParam" style="margin-left:5px;" ng-click="removeColor('+l+')"></button><div class="showColor" id="showColor'+l+'" style="background-color:{{colorRow'+l+'}}"></div></div>'
                    $('#colorTable').append($compile(temp)(scope));
                    var vari = 'colorRow'+l ;
                    scope[vari] = scope.inputColor;
                    scope.inputColor = "";
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeColor = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    colorArray = [];
                    $('.colorText').each(function(i, obj) {
                        colorArray.push($(this).val());
                    });
                    dialogItself.close();
                    onOk(colorArray);
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
    }
    
    this.outputOptDialog = function(dialogTitle,indexArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="outputOpt" style="text-align:center;">'+
                                '<tr><td>Index</td><td></td></tr>'+
                                '<tr class="form-inline inputRow indexRow"><td><input class="form-control" type="text" ng-model="inputIndex"></td>'+
                                '<td><button class="btn btn-default btn-xs" id="addIndex" ng-click="addIndex()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table></div>';                                
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                //'</div>';
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'outputopt-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.inputIndex = "";
                var length = indexArray.length;
                if(indexArray.length != 0){
                    //$log.log(indexArray.length);
                    for(i=0;i<indexArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline indexRow"><td><input class="form-control" type="text" ng-model="inputIndex'+i+'"></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeIndex('+i+')"></button></td></tr>'
                        $('.inputRow').before($compile(temp)(scope));
                        var vari = 'inputIndex'+i ;
                        scope[vari] = indexArray[i];
                    };
                }

                scope.addIndex = function(){
                    if(scope.inputIndex == undefined || scope.inputIndex.length <= 0){
                        return
                    }
                    $log.debug("this is add color called");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline indexRow"><td><input class="form-control" type="text" ng-model="inputIndex'+l+'"></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeIndex('+l+')"></button></td></tr>'
                    $('.inputRow').before($compile(temp)(scope));
                    var vari = 'inputIndex'+l ;
                    scope[vari] = scope.inputIndex;
                    scope.inputIndex = "";
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeIndex = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    indexArray = [];
                    $('.indexRow').each(function(i, obj) {
                        var indx = (this.id).charAt(3);
                        //$log.log(indx)
                        if((scope['inputIndex'+indx]).length <1){
                            return;
                        }
                        indexArray.push(scope['inputIndex'+indx]);
                    });
                    dialogItself.close();
                    $log.debug(indexArray);
                    onOk(indexArray);
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
    }

/*
    this.javascriptDialog = function(dialogTitle,currentScrpt,onOk,onCancel){
        var resScript="";
        var editor;
        var data=BootstrapDialog.show({
            title: "Javascript Input",
            message: function(dialog) {
                var $message = $('<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                '<span class="sr-only">Error:</span>'+
                ' ' +"Please input valid script." +'</div>'+
                '<textarea id="codedata" name="codedata">' + currentScrpt + ' </textarea>');
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {

                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: "javascript"
                });

            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        dialogItself.close();
                        $log.log(editor.getValue());
                        onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-danger'
                }]
        });
    };
*/


    this.cdaparamDialog = function(dialogTitle,paramArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);
                

                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Name</td><td>Value</td><td>Type</td><td>Private</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName"  ng-model="paramName" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramVal" ng-model="paramVal" /></td>'+
                                '<td><select class="form-control addParam input-sm" ng-model="paramType" ng-options="n for n in paramTypes"></select></td>'+
                                '<td><input class="form-control paramCheck input-sm" type="checkbox" id="isPrivate" ng-model="isPrivate"/></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: '',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramName = "";
                scope.paramVal = "";
                scope.isPrivate = false;
                scope.paramTypes = ['String','Integer','Numeric','Date','StringArray','IntegerArray','NumericArray','DateArray'];
                scope.paramType = scope.paramTypes[0];
                self.safeApply(scope,function(){});

                var length = paramArray.length;
                if(paramArray.length != 0){
                    for(i=0;i<paramArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'"  ng-model="paramName'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramVal'+i+'" ng-model="paramVal'+i+'" /></td>'+
                                    '<td><select class="form-control input-sm" ng-model="paramType'+i+'" ng-options="n for n in paramTypes"></select></td>'+
                                    '<td><input class="input-sm" type="checkbox" id="isPrivate'+i+'" ng-model="isPrivate'+i+'"/></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramName'+i ;
                        scope[vari] = paramArray[i][0];
                        vari = 'paramVal'+i;
                        scope[vari] = paramArray[i][1];
                        vari = 'paramType'+i;
                        scope[vari] = paramArray[i][2];
                        vari = 'isPrivate'+i;
                        scope[vari] = paramArray[i][3];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramVal == undefined || scope.paramVal.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'"  ng-model="paramName'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramVal'+l+'" ng-model="paramVal'+l+'" /></td>'+
                                '<td><select class="form-control addParam input-sm" ng-model="paramType'+l+'" ng-options="n for n in paramTypes"></select></td>'+
                                '<td><input type="checkbox" class="form-control addParam input-sm" id="isPrivate'+l+'" ng-model="isPrivate'+l+'"/></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    vari = 'paramVal'+l;
                    scope[vari] = scope.paramVal;
                    vari = 'paramType'+l;
                    scope[vari] = scope.paramType;
                    vari = 'isPrivate'+l;
                    scope[vari] = scope.isPrivate;
                    scope.paramName = "";
                    scope.paramVal = "";
                    scope.paramType = "String";
                    scope.isPrivate = false;
                    $('#paramName').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    paramArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramName'+index].length <1 || scope['paramVal'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramName'+index],scope['paramVal'+index],scope['paramType'+index],scope['isPrivate'+index]];
                        paramArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(paramArray);
                    onOk(paramArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    }
    this.columnsDialog = function(dialogTitle,columnsArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Index</td><td>Name</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramIndex"  ng-model="paramIndex" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName" ng-model="paramName" /></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'column-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramIndex = "";
                scope.paramName = "";
                self.safeApply(scope,function(){});

                var length = columnsArray.length;
                if(columnsArray.length != 0){
                    for(i=0;i<columnsArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramIndex'+i+'"  ng-model="paramIndex'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'" ng-model="paramName'+i+'" style="width:90%"/></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramIndex'+i ;
                        scope[vari] = columnsArray[i][0];
                        vari = 'paramName'+i;
                        scope[vari] = columnsArray[i][1];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramIndex == undefined || scope.paramIndex.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramIndex'+l+'"  ng-model="paramIndex'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'" ng-model="paramName'+l+'" /></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramIndex'+l;
                    scope[vari] = scope.paramIndex;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    scope.paramIndex = "";
                    scope.paramName = "";
                    $('#paramIndex').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    columnsArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramIndex'+index].length <1 || scope['paramName'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramIndex'+index],scope['paramName'+index]];
                        columnsArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(columnsArray);
                    onOk(columnsArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    };

    this.calcColumnsDialog = function(dialogTitle,columnsArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Name</td><td>Formula</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName"  ng-model="paramName" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramForm" ng-model="paramForm" /></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'column-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramName = "";
                scope.paramForm = "";
                self.safeApply(scope,function(){});

                var length = columnsArray.length;
                if(columnsArray.length != 0){
                    for(i=0;i<columnsArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'"  ng-model="paramName'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramForm'+i+'" ng-model="paramForm'+i+'" /></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramName'+i ;
                        scope[vari] = columnsArray[i][0];
                        vari = 'paramForm'+i;
                        scope[vari] = columnsArray[i][1];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramForm == undefined || scope.paramForm.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'"  ng-model="paramName'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramForm'+l+'" ng-model="paramForm'+l+'" /></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    vari = 'paramForm'+l;
                    scope[vari] = scope.paramForm;
                    scope.paramName = "";
                    scope.paramForm = "";
                    $('#paramName').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    columnsArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramName'+index].length <1 || scope['paramForm'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramName'+index],scope['paramForm'+index]];
                        columnsArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(columnsArray);
                    onOk(columnsArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    };

    this.datasourceDialog = function(dialogTitle,selectVal,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);

                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<div style="padding-bottom:5px;"> Database Connection'+
                                '</div>'+
                                '<div class="list-group" id="connection" width="100%">'+
                                '</div>'+
                                //'<div class="alignCenter"><a class="blueLink" onclick="window.parent.executeCommand(\'ManageDatasourcesCommand\')"> Make a new Connection here</a></div>'
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'outputopt-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.selection = [];
                var temp = '';
                var param = {
                    'ts' : '1437031684490'
                }

                var jsonData =self.synchronousJsonCall( '../../../plugin/data-access/api/connection/list',"GET",param);
                 //$log.log(jsonData);
                 
                 //$log.log(jsonData.databaseConnections.length)
                for(i=0;i<jsonData.databaseConnections.length;i++){
                    scope.selection.push(jsonData.databaseConnections[i].name);
                    var connection = jsonData.databaseConnections[i].name;
                        temp = temp +'<button type="button" class="col-lg-12 col-md-12 col-sm-12 listGroup list-group-item" id="'+connection+'" ng-click="select(\''+connection+'\')">'+connection+'</button>'  
                }

                scope.select = function(connection){
                    //$log.log("this is clicked");
                    if($('.listGroup').hasClass('active'))
                        $('.listGroup').removeClass('active');

                    $('#'+connection).addClass('active');
                }

                $('#connection').append($compile(temp)(scope));
                $('#'+selectVal).addClass('active');

            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    
                    scope.selectVal =$('#connection .active').attr("id");
                    //$log.log(scope.selectVal);
                    var param = {
                        'name' : scope.selectVal
                    }
                    var jsonData =self.synchronousJsonCall( '../../../plugin/data-access/api/connection/get',"GET",param);
                    //$log.log(jsonData);


                    dialogItself.close();
                    onOk(jsonData);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });   
    }
    

    this.codeMirrorDialog = function(mode,currentScrpt,onOk,onCancel){
        var resScript="";
        var editor;
        var data=BootstrapDialog.show({
            title: mode.charAt(0).toUpperCase()+mode.slice(1)+" Dialog",
            message: function(dialog) {
                var $message = $('<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                '<span class="sr-only">Error:</span>'+
                ' ' +"Please input valid script." +'</div>'+
                '<textarea id="codedata" name="codedata">' + currentScrpt + '</textarea>');
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {
                if(mode=='sql')
                    mode = 'text/x-sql'
                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: mode
                });

            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        dialogItself.close();
                        //$log.log(editor.getValue());
                        onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    }

    this.notification = function (messange, nType, nDelay, icon) {
        if(nType == null || nType == undefined || nType.length <1)
            nType=this.notificationType;
        if(nDelay == null || nDelay == undefined || nDelay.length <1)
            nDelay=this.notificationDelay;

        $.growl({
                message: messange
            }
            ,{
                type: nType,
                allow_dismiss: true,
                placement: {
                    from: "top",
                    align: "right"
                },
                offset: 20,
                spacing: 10,
                z_index: 10031,
                delay: nDelay,
                timer: 1000,
                animate: {
                    enter: 'animated bounceIn',
                    exit: 'animated bounceOut'
                }
            });
    };

    this.safeApply=function (scope, fn){
        (scope.$$phase || scope.$root.$$phase) ? fn() : scope.$apply(fn);
    };


    this.loadjscssfile = function(filename, filetype){

        if (filetype=="js"){ //if filename is a external JavaScript file
            /*
            var message = "";
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = filename;
            
            script.onload = function(){
                message = "loading"
                callback(message);
            }
            
            document.getElementsByTagName("head")[0].appendChild(script);

            */
            var ajaxObj;
            if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
                ajaxObj=new XMLHttpRequest();
            }
            else{// code for IE6, IE5
                ajaxObj=new ActiveXObject("Microsoft.XMLHTTP");
            }
            ajaxObj.onreadystatechange=function(){
                if (ajaxObj.readyState!=4 ) return ;
                eval(ajaxObj.responseText);   
            }
            
            ajaxObj.open("GET",filename,true);
            ajaxObj.send('');

        }
        else if (filetype=="css"){ //if filename is an external CSS file
            var fileref=document.createElement("link")
            fileref.setAttribute("rel", "stylesheet");
            fileref.setAttribute("type", "text/css");
            fileref.setAttribute("href", filename);

            document.getElementsByTagName("head")[0].appendChild(fileref);
            //var css = document.createElement("link");
            //css.rel = "stylesheet";
            //css.type = "text/css"
            //css.href = filename;
        }

        //if (typeof fileref!="undefined")
        //    document.getElementsByTagName("head")[0].appendChild(fileref)
    }
    //currently this function is not using anywhere
    this.loadComponentRes = function()
    {
        var DEFAULT_PATH ="component/";
        var self = this;

        for(var i = 0; i < this.components.selfServiceBI.length; i++) {

            for(var j = 0; j < this.components.selfServiceBI[i].properties.files.css.length; j++) {

                var filePath = this.components.selfServiceBI[i].properties.files.css[j];
                if(filePath.substr(0,2) == ".." ||  filePath.substr(0,3) == "/.." ) // Load Relative path
                {   
                    //this.loadjscssfile(filePath,"css");
                }
                else
                {
                    this.loadjscssfile(DEFAULT_PATH+this.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath,"css")
                    filePath =DEFAULT_PATH+this.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath;
                }


                //$log.debug("\tCSS : " + filePath);
            }
            angular.forEach(this.components.selfServiceBI[i].properties.files.js , function(item,j){

                var filePath = item;
                var reply = undefined;

                if(filePath.substr(0,2) == ".." ||  filePath.substr(0,3) == "/.." ) // Load Relative path
                {
                    //self.loadjscssfile(filePath,"js");

                }
                else
                {
                    self.loadjscssfile(DEFAULT_PATH+self.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath,"js")
                    filePath = DEFAULT_PATH+self.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath;
                }
                //$log.debug("\tjs : " + filePath);
            })
        }
        //$log.log("this is finished");
    }
    
    this.setComponents = function()
    {
        this.components = this.readJSONFile('component/components.json');
        this.loadComponentRes();
    }

    this.getIndex = function(name){
        var properties = {};
        for(i=0;i<this.components.selfServiceBI.length;i++){
            if(name == this.components.selfServiceBI[i].chartName){
                return i;
            };

        }
    }

    this.getChartType = function(input){
        var chartType;
        //$log.log(scope.chartType)
        if(input == "Saiku Analytics")
            chartType = 'Saiku';
        else if(input == "CCC Chart Library")
            chartType = 'CCC';
        else if(input == "Data Tables")
            chartType = 'Table';
        else if(input == "Label")
            chartType = 'Label'
        return chartType
    }
    this.propertiesHTMLComponent= function(pName,caption,dataType,htmlComp,defaultVal,listOfVal,advance,htmlAppend,scope,hidden)
    {
        var cssClass= '';

        //var isHidden = hidden == 0? 'hidden' : '';
        var isHidden = '';
        
        if(advance == 1) // 1 = Advance, 2 = Advance + Primary , 0 = Not implements but we can use as primary only
            cssClass="advance";
        else if(advance == 2)
            cssClass="primary";
        else if(advance == 0)
            isHidden = 'hidden';


        
        var comp = '<div class="form-group '+ cssClass +'" '+isHidden+'><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">'+caption+'</div>';
        //var comp = '<tr '+ cssClass + isHidden+' ><td style="width:40%">'+caption+'</td>'; // this row Tr close within switch case
        //$log.log(comp);
        switch(htmlComp){
            case "textbox":
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></div>';
                //comp = comp + '<td><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></td></tr>';
                $('#'+htmlAppend).append($compile(comp)(scope));
                //$('#'+pName).val(defaultVal);
                scope[pName] = defaultVal;

                break;
            }
            case "combobox" :
            {
                var possible = listOfVal;
                var options = '';
                for(j=0;j<possible.length;j++){
                    if(possible[j] == defaultVal){
                        option = '<option value="'+possible[j]+'">'+possible[j]+'</option>'
                    }
                    else{
                        option = '<option value="'+possible[j]+'">'+possible[j]+'</option>'
                    }

                    options = options.concat(option)
                }
                comp = comp +'<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><select id="'+pName+'" class="form-control input-sm" ng-model="'+pName+'">'+
                options+
                '</div></div>'
                
                $('#'+htmlAppend).append($compile(comp)(scope));

                scope[pName] = defaultVal;
                break;
            }
            case "switch" :
            case "combo" :
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="checkbox" class="form-control" id="'+pName+'" name="my-checkbox" data-size="mini" data-handle-width="42" data-on-text="True" data-off-text="False" data-on-color="success" data-off-color="danger" checked=false /></td>'+
                '</div></div>';

                $('#'+htmlAppend).append($compile(comp)(scope));

                if(defaultVal){
                    $('#'+pName).bootstrapSwitch('state',true);
                }
                else{
                    $('#'+pName).bootstrapSwitch('state',false);
                }
                break;
            }
            case "javascript" :
            case "sql" :
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><div class="input-group form-inline" ng-click="openScriptDialog()"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                '<span class="input-group-addon input-sm" id="'+pName+'button" style="cursor:pointer;" ><i class="glyphicon glyphicon-pencil"></i></button>'+
                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div></div>';
                //$('#'+pName+'text').val(data.substring(0,30));
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = defaultVal;
                    if(defaultVal.length > 20 )
                        scope[pName+'text'] = defaultVal.substring(0,20)+'..(...)';
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openScriptDialog = function(){

                    var onOk = function(data) {
                        scope[pName+'text'] = data;
                        if(data.length >20)
                            scope[pName+'text'] = data.substring(0,20)+'..(...)' ;
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.codeMirrorDialog(htmlComp,currentVal,onOk,function(){});
                };
                break;
            }
            /*
            case "colorDialog" :
            {
                comp = comp +   '<td><div class="input-group form-inline"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" class="form-control input-sm" size="15" />'+
                                '<span class="input-group-addon input-sm" id="'+pName+'button" style="cursor:pointer;" ><i class="glyphicon glyphicon-pencil"></i></button>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></td></tr>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = defaultVal.substring(0,30);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                scope[pName] = defaultVal;
                var currentVal = scope[pName];
                
                $('#'+pName+'button').on('click',function(){
                    $log.debug("color panel selected");

                    var onOk = function(data) {
                        scope[pName+'text'] = data.substring(0,15);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.colorDialog("Select Colors",currentVal,onOk,function(){},scope);
                });

                break;
            }
            */
            case "colorDialog" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><div class="form-group-right input-group form-inline"><input type="text" id="'+pName+'text" ng-click="openColorDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openColorDialog = function(){
                    $log.debug("Color Dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else if(data.length == 0)
                            scope[pName+'text'] = "";
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.colorDialog("Select Colors",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "database" : 
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'_text" ng-click="openDtsrcDialog()" ng-model="'+pName+'_text" class="form-control input-sm readonlybg" style="cursor:text" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'_text'] = defaultVal;
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openDtsrcDialog = function(){
                    $log.debug("Add Datasource Connection dialog");

                    var onOk = function(data) {
                        scope[pName+'_text'] = data.name;
                        scope[pName] = data.name;
                        currentVal = data.name;
                        var connection = self.getDBConnection(data.databaseType.shortName);
                        $log.debug(connection);
                        //$log.log(data.databaseType.extraOptionsHelpUrl.name);
                        //if(data.databaseType.name == 'MySQL')
                        scope.driver = connection[0]
                        scope.username = data.username;
                        scope.password = data.password;
                        scope.url = connection[1]+'://'+data.hostname+':'+data.databasePort+'/'+data.databaseName;
                        self.safeApply(scope,function(){});
                    }
                    self.datasourceDialog("Select Datasource",currentVal,onOk,function(){},scope);
                }
                break;   
            }
            case "cdaparameters" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openParamDialog()" ng-model="'+pName+'text" class=" form-control input-sm readonlybg"  style="cursor:text" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openParamDialog = function(){
                    $log.debug("Add CDA Parameter dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.cdaparamDialog("Add parameters",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "outputOpt" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" ng-click="openOutputDialog()" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openOutputDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.outputOptDialog("Output Options",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "columns" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openColumnDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openColumnDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.columnsDialog("Columns Configuration",currentVal,onOk,function(){},scope);
                }
                break;
            }

            case "calcColumns" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" ng-click="openCalColDialog()" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                var currentVal = scope[pName];

                scope.openCalColDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.calcColumnsDialog("Calculated Columns",currentVal,onOk,function(){},scope);
                }
                break;
            }
        }
    }

    this.getDBConnection = function(dbname){
        var connection = [];
        switch(dbname){
            case 'MYSQL':{
                connection = ['com.mysql.jdbc.Driver','jdbc:mysql'];
                break;
            }   
            case 'ORACLE':{
                connection = ['oracle.jdbc.driver.OracleDriver','jdbc:oracle'];
                break;
            }
            case 'HIVE':{
                connection = ['org.apache.hadoop.hive.jdbc.HiveDriver','jdbc:hive'];
                break;
            }
            case 'HIVE2':{
                connection = ['org.apache.hadoop.hive.jdbc.HiveDriver','jdbc:hive2'];
                break;
            }
            case 'VERTICA5':{
                connection = ['com.vertica.jdbc.Driver','jdbc:vertica'];
                break;
            }
            case 'HYPERSONIC':{
                connection = ['org.hsqldb.jdbcDriver','jdbc:hsqldb:hsql'];
                break;
            }
            case 'POSTGRESQL':{
                connection = ['org.postgresql.Driver','jdbc:postgresql'];
                break;
            }
            case 'MSSQL':{
                connection = ['com.microsoft.sqlserver.jdbc.SQLServerDriver','jdbc:sqlserver'];
                break;   
            }
            case 'MSSQLNative':{
                connection = ['com.microsoft.sqlserver.jdbc.SQLServerDriver','jdbc:sqlserver'];
                break;   
            }
            case 'H2':{
                connection = ['org.h2.Drive','jdbc:h2'];
                break;   
            }
            case 'MONETDB':{
                connection = ['nl.cwi.monetdb.jdbc.MonetDriver','jdbc:monetdb'];
                break;
            }
            case 'IMPALA':{
                connection = ['com.cloudera.impala.jdbc.Driver','jdbc:impala'];
                break;
            }
        }
        return connection;
    }


    this.parsePropertiesDataType = function(value, dataType)
    {
        if(dataType == "boolean")
            value = JSON.parse(value);
        else if (dataType == "array")
        {
            if(value != undefined)
            {
                if(!Array.isArray(value)) {
                    if (value.length > 0)
                    {
                        value = value.split(",");
                    }
                    //$log.debug("property val: "+value);
                }
            }

        }
        return value;
    }
}]);

angular.module('commonUtilModule')
.directive('dropdownMultiselect', ['commonUtils','$compile','$log',function (commonUtils,$compile,$log) {
    return {
        restrict: 'E',
        scope: {
            selectedOptions: '=',
            datasource: '=',
            idd : '='
        },

        link : function($scope,element,attr)
        {
            //$log.log("link");
            $scope.openDropdown = function () {

                $scope.open = !$scope.open;
                if($scope.open)
                {
                    dropDownFixPosition(element.find(".dropdownClicked"),element.find(".dropdown-menu"));
                }

            };

            function dropDownFixPosition(button,dropdown){
                var dropDownTop = button.offset().top + button.outerHeight();
                dropdown.css('top', dropDownTop + "px");
                dropdown.css('left', button.offset().left + "px");
            }


            var html = "<div class='btn-group' ng-class='{open: open}'>" +
                    "<button class='btn btn-sm btn-default dropdown-toggle dropdownClicked' ng-click='openDropdown()' style='width:auto'>{{title}} <b class='caret'></b></button>" +
                    "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                        "<li><a ng-click='selectAll()'><span class='{{idd}}' ng-class='getClass()' aria-hidden='true'></span> Select All</a></li>" +
                        "<li><span class='form-inline'><input type='text' ng-model='search' style='margin-left:5px;margin-right:5px;width:78%'/><i class='glyphicon glyphicon-search'></i></span></li>" +
                        "<li class='divider'></li>"+
                        "<li class='dropdown-data'>"+
                        "<ul style='color:black;list-style-type: none;margin-left: -20px;'><li ng-repeat='option in datasource | filter:search'><div ng-click='toggleSelectItem(option)'><span ng-class='getClassName(option)'aria-hidden='true'></span> {{option}}</div></li>"+
                        "</ul></li></ul>" +
                        "</div>";

            element.html(html);
            $compile(element.contents())($scope);



        },

        controller: function ($scope) {
            //$log.log($scope.idd);
            
            $scope.isSelectAll = true;
            $scope.optionSelect = [];
            angular.forEach($scope.datasource,function(item,index){
                for(i=0;i<$scope.selectedOptions.length;i++){
                    if($scope.selectedOptions[i] == $scope.datasource[index]){
                        $scope.optionSelect.push($scope.selectedOptions[i]);
                    }
                }
            })
            $scope.selectedOptions = $scope.optionSelect; 
            $scope.title = ($scope.selectedOptions.length)+' selected';
            $scope.totalLen = $scope.datasource.length;
            //$scope.selectedLen = $scope.selectedOptions.length;

            $scope.selectAll = function () {
                if($scope.isSelectAll){
                    $scope.selectedOptions = [];
                    angular.forEach($scope.datasource, function (item, index) {
                        $scope.selectedOptions.push(item);
                    });   
                    $scope.isSelectAll = false;
                    $scope.title = 'All Selected'
                }
                else{
                    $scope.selectedOptions = [];    
                    $scope.title = 'None Selected'
                    $scope.isSelectAll = true;
                }
            };

            $scope.getClass = function () {
                if($scope.isSelectAll){
                    return 'glyphicon glyphicon-remove white'
                }
                else{
                    return 'glyphicon glyphicon-ok green'
                }
            };

            $scope.toggleSelectItem = function (option) {
                var intIndex = -1;
                
                angular.forEach($scope.selectedOptions, function (item, index) {
                    if (item == option) {
                        intIndex = index;
                    }
                });
                //$log.log(intIndex);
                if (intIndex >= 0) {
                    $scope.selectedOptions.splice(intIndex, 1);
                    isSelectAll = false;
                    if($scope.selectedOptions.length == 0){
                        $scope.title = 'None Selected';
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                    }
                    else{
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                        $scope.title = ($scope.selectedOptions.length)+' Selected' ;
                    }
                }
                else {
                    $scope.selectedOptions.push(option);
                    if($scope.selectedOptions.length == $scope.totalLen){
                        $scope.title = 'All Selected';
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-remove white');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-ok green');
                        $scope.isSelectAll = true;
                    }
                    else{
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                        $scope.title = ($scope.selectedOptions.length)+' Selected';
                        isSelectAll = false;
                    }
                }
            };
            $scope.getClassName = function (option) {
                var varClassName = 'glyphicon glyphicon-remove white';
                angular.forEach($scope.selectedOptions, function (item, index) {
                    if (item == option) {
                        varClassName = 'glyphicon glyphicon-ok green';
                    }
                });
                return (varClassName);
            };
        }
    }
}]);

angular.module('messagesModule',[])
    .service('Messages',function(){
        // Common
        this.onInvalidFileName = "Please input valid file name";
        this.onSaikuFileNotSelected = "No data source selected";
        this.onPopWindowError = "Please allow popups for this site";
        this.NoDataSourceSelected = "No data source selected.";
        this.onChartRenderError = "Error while rendering chart.";
        //Pin
        this.onNewPinNotification = "New pin created successfully.";
        this.onOpenPinNotification = "Pin opened successfully.";
        this.onSavePinNotification = "Pin saved successfully.";
        this.onAlreadySavedPinNotification = "Pin already saved.";
        this.onSaveAsPinNotification = "Pin save as successfully.";

        this.onDefaultPinNotification = "Pin with default configuration can't saved";

        this.onPinSaveUserRightError = "You don't have rights to modify pin.";
        this.onUnsavePinConfirm = "Would you like to save existing open pin ?";
        this.onPreviewUnsavePinError = "Please save pin before preview.";

        //PinBoard
        this.onNewPinboardNotification =  "New pin Board created successfully.";
        this.onOpenPinboardNotification = "Pin Board opened successfully.";
        this.onSavePinboardNotification = "Pin Board saved successfully.";
        this.onAlreadySavedPinboardNotification = "Pin Board already saved.";
        this.onSaveAsPinboardNotification = "Pin Board save as successfully.";

        this.onNullPinboardNotification = "Pinboard doesn't have any pin to save";

        this.onPinBoardInserRowSuccess = "New row inserted successfully.";
        this.onPinBoardRemoveRowSuccess = "Row removed successfully.";
        this.onRemoveAllNotification = "Pin Board all row(s) removed successfully.";

        this.onPinBoardSaveUserRightError = "You don't have rights to modify Pin Board.";
        this.onUnsavePinBobardConfirm = "Would you like to save existing open pin Board ?";
        this.onPreviewUnsavePinBoardError = "Please save pin Board before preview.";
        this.onRemoveRowConfirm = "Are you sure to delete selected row?";

        this.onInvalidMediumScreenInputError = "Please enter medium screen size values.";
        this.onInvalidLargeScreenInputError = "Please enter leage screen size values.";
        this.onInvalidSmallScreenInputError = "Please enter small  screen size values.";
        this.onInvalidExtraSmallScreenInputError = "Please enter extra small screen size values.";
        this.onInvalidNumberOfColumnInputError = "All your screen size values must have same numbers of columns.";
        this.onFilterNameAlreadyExist = "Filter name already exist. Please try another";

        this.onInvalidPinSizeInput = "Pin size should integer and from 1-12";
        this.onInvalidDateFormat = "Date should be in format YYYY-MM-DD";

        this.onCCCbulletChartSelect = "Please set appropriate height for bullet chart from properties option";
        this.unableLoadData = "Unable to load data, Try again";


        //datasource
        this.onNewDatasourceNotification = "New Data source created successfully";
        this.onOpenDatasourceNotification = "Datasource open successfully";
        this.onNullDatasourceNotification = "Datasource doesn't have any data to save";
        this.onSaveDatasourceNotification = "Datasource saved successfully";
        this.onSaveAsDatasourceNotification = "Datasource saved successfully";
        this.onAlreadySaveDatasourceNotification = "Datasource already saved";
        this.onUnsaveDatasourceConfirm = "Would you like to save existing datasource";

    })

angular.module('pinboard',['commonUtilModule','messagesModule','colorpicker.module']);

angular.module('pinboard')
.config(['$logProvider',function($logProvider){
    $logProvider.debugEnabled(false);
}]);

angular.module('pinboard')
.factory('Pin',['commonUtils','$log','Messages',function (commonUtils,$log,Messages) {
    $log.debug("Pin Factory called");
    var pin = function(){
        this.mode = "";
        this.cIdx =-1; // Column Index
        this.pinId = "newPin" ; //Extension Perpose
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.bootstrapStyle = "panel-blue";
        //this.dataSource = "/home/admin/SelfServiceBI/Test.saiku";
        
        this.height = 200;
        this.width = "100";
        this.htmlObj = "PanelChart";
        this.version = commonUtils.version;
        this.buildVersion= commonUtils.buildVersion;

        this.chartType = "CCC";
        this.chartCaptio
        this.dataSource = "";
        this.visualization = "Bar"; // Chart type
        this.dataAccessId = "";
        this.defaultParamStr = "";
        this.paramStr = "";

        this.listenerFilters = [];
        this.chartProperties = [];
    };
    pin.prototype.init = function(options){

        $log.debug("Pin( "+  this.pinId  +  " ).init : Default values");

        this.pinId = "newPin";
        this.cIdx =-1;
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.bootstrapStyle = "panel-blue";
        
        this.height = 200;
        this.width = "100";
        this.htmlObj = "PanelChart";

        this.chartType = "CCC";
        this.dataSource = "";
        this.visualization = "Bar"; // Chart type
        this.dataAccessId = "";
        this.defaultParamStr = "";
        this.paramStr = "";
        this.listenerFilters = [];
        this.chartProperties = [];
    };

    pin.prototype.isDefault = function(){
        if(this.pinId == "newPin" && this.pinIcon == "glyphicon glyphicon-pushpin" && this.title == "New Pin" && this.minimize && this.isHeader && this.bootstrapStyle == "panel-blue" && this.height == 200 && this.chartType == "CCC" && this.dataSource == "")
            return true;
        else
            return false;
    }


    pin.prototype.getJson = function(){
        $log.debug("pinid : "+this.pinId);
        var json =  "{"+
                    "\"pinId\" : \""+  $.trim(this.pinId)  +  "\" , " +
                    "\"pinIcon\" : \""+  $.trim(this.pinIcon)  +  "\" , " +
                    "\"title\" : \""+  $.trim(this.title)  +  "\" , " +
                    "\"minimize\" : \""+  this.minimize +  "\" , " +
                    "\"isHeader\" : \""+  this.isHeader +  "\" , " +
                    "\"bootstrapStyle\" : \""+  $.trim(this.bootstrapStyle)  +  "\" , " +

                    "\"dataSource\" : \""+  $.trim(this.dataSource)   +  "\" , " +
                    "\"dataAccessId\" : \""+  $.trim(this.dataAccessId)   +  "\" , " +
                    "\"defaultParamStr\" : \""+  $.trim(this.defaultParamStr)   +  "\" , "  +
                    //"\"paramStr\" : \""+  $.trim(this.paramStr)   +  "\" , "  +
                    "\"chartType\" : \""+  $.trim(this.chartType)   +  "\" , " +
                    "\"visualization\" : \""+  $.trim(this.visualization)   +  "\" , "  ;


            if(this.chartProperties != undefined && this.chartProperties.length > 0)
            {

                json = json +  "\"chartProperties\" : " ;
                json = json + "[";

                for(var i=0;i<this.chartProperties.length;i++)
                {

                    if(this.chartProperties[i][2] == "javascript" || this.chartProperties[i][1] == "array") // we use stringify for array and javascript store in json
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" ,"+  JSON.stringify($.trim(this.chartProperties[i][3]))   +  ", " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;

                        //$log.debug(this.chartProperties[i][0] + " - "  + this.chartProperties[i][3]);
                    }
                    else
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][3])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                    }

                    if(i == this.chartProperties.length-1)
                    {
                        json = json + "]";
                    }
                    else{
                        json = json + "],";
                    }

                }
                json = json + "],";
            }
            else
            {
                json = json + "\"chartProperties\" : [] , " ;
            }

        $log.debug("listenerFilters "+this.listenerFilters);
        json = json + "\"listenerFilters\" : ";
        json = json + "[";
        len = this.listenerFilters.length;
        if(this.listenerFilters.length >0){
            for(var i=0;i<len;i++){
                json = json + "[";
                json = json  + "\"" +$.trim(this.listenerFilters[i][0])+"\" ,";
                json = json  + "\"" +$.trim(this.listenerFilters[i][1])+"\" ";
                if(i == len-1){
                    json = json + "]";    
                }
                else{
                    json = json + "],";   
                }
                
            }
        }
        json = json +   "],";
        json = json +   "\"height\" : \""+  $.trim(this.height)   +  "\" , " +
                        "\"width\" : \""+  $.trim(this.width)   +  "\" , " +
                        "\"htmlObj\" : \""+  $.trim(this.htmlObj)+  "\" , " +
                        "\"version\" : \""+  $.trim(this.version)+  "\" , " +
                        "\"buildVersion\" : \""+  $.trim(this.buildVersion)+  "\" " +
                        "}";

        /* if(Config.debug)
         $log.debug("Pin("+  this.pinId  +  " ).getJson() : " + json);
         */
        return json;
    };

    pin.prototype.render = function(param){
        $log.debug("chart rendering start || chartType : "+this.chartType);

        $("#" + this.htmlObj).empty();
        $("#" + this.htmlObj).html('<div id="'+ this.htmlObj+'_chart" style="width:'+ this.width+'%; height:'+ this.height+'px;"></div>' );
        try {
            if (this.dataSource == undefined || this.dataSource.length < 1) {
                $("#" + this.htmlObj+ "_chart").html("<div style=\"text-align: center;\">" + Messages.NoDataSourceSelected + "</div>");
            }
            else if (this.chartType == "Saiku") {
                var saikuClientRenderer = new SaikuClient(
                    {
                        server: "/pentaho/plugin/saiku",
                        path: "/cde-component"
                    });

                if ((this.visualization).toLowerCase() != "table") {
                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: "#" + this.htmlObj,
                        render: "chart",
                        mode: (this.visualization).substring(0,1).toLowerCase()+(this.visualization).substring(1),
                        zoom: true
                    });
                }
                else {
                    $("#" + this.htmlObj).addClass('workspace_results');
                    var t = $("<div></div>");
                    $("#" + this.htmlObj).html(t);
                    htmlId = t;

                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: htmlId,
                        render: "table",
                        mode: "sparkline",
                        zoom: true
                    });
                }
                $log.debug("Rendering configuration");
                $log.debug("Pin( " + this.pinId + " ).render : htmlID : " + this.htmlObj);
                $log.debug("Pin( " + this.pinId + " ).render : dataSource : " + this.dataSource);
                $log.debug("Pin( " + this.pinId + " ).render : chart : " + this.visualization);
                $log.debug("Pin( " + this.pinId + " ).render : Ended");

            }
            else if (this.chartType == "CCC") {

                var chartType = window["CCC"+ this.visualization];
                var visualization = new chartType();
                $log.debug(this.chartType + " " + this.visualization);
                if (param == undefined) {
                    param = "";
                }
                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);

                visualization.init(this.pinId, data, this.htmlObj+"_chart", this.chartProperties);
            }
            else{
                //$log.log(this.chartType+this.visualization);
                var chartType = window[this.visualization];
                //$log.log(chartType);
                var visualization = new chartType();
                if (param == undefined) {
                    param = "";
                }
                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);
                
                visualization.init(this.pinId,data,this.htmlObj+"_chart",this.chartProperties);
            }
        }
        catch(error)
        {
            if(error == "Error: [pvChart ERROR]: Invalid operation. Chart type requires unassigned role 'y'."){
                //alert(Messages.onChartRenderError + "\nError : Inproper dataset : Please give dataset with one category and two measures and change one property called cross tab mode to false " );
                $("#" + this.htmlObj+ "_chart").html("<div style=\"text-align: center;text-decoration:underline;color:red;\">Error <br /> Inproper dataset </div><div style='text-align:center;'><h6><u>Tip</u><br/> Please provide dataset with one category and two measures.<br /> Also change one property called CrossTabMode to false </h6></div>");
            }
            else
            {
                alert(Messages.onChartRenderError + "\nError : " + error);    
                $log.error(error);
            }
        }
    };
    pin.prototype.saveConfigToFile = function(){
        $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : Started");
        var param = {
            "file"  :  this.pinFile ,
            "content"  : this.getJson()
        };
        $log.debug(this.getJson());
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);
        if(jsonData.result =="Success."){
            $log.debug("Pin( "+  this.pinId  +  " ).saveConfigToFile : ended : SuccessFully");
            return true;
        }
        else{
            $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : ended : Error : " + jsonData.result );
            return false;
        }
    };

    pin.prototype.getConfigFromFile = function() {
        $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : Started" );

        if(this.pinFile == undefined || this.pinFile.length <1)
        {

            this.title = "Existing Pin is not Configured";
            this.bootstrapStyle = "panel-blue";
            this.dataSource = "";
            this.height = 200;
            this.width = "100";

        }
        else
        {
            var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ this.pinFile,"GET",null).result);
            $log.debug(jsonData);
            try
            {
                this.pinId = jsonData.pinId;
                this.pinIcon = jsonData.pinIcon;
                this.title = jsonData.title;
                this.minimize = jsonData.minimize=="true"?true :false;
                this.isHeader = jsonData.isHeader=="true"?true :false;
                this.bootstrapStyle = jsonData.bootstrapStyle;
                this.dataSource = jsonData.dataSource;
                this.dataAccessId = jsonData.dataAccessId;
                this.defaultParamStr = jsonData.defaultParamStr;
                this.paramStr =  jsonData.defaultParamStr;
                this.chartType = jsonData.chartType;
                this.visualization = jsonData.visualization;

                if(jsonData.chartProperties != undefined && jsonData.chartProperties.length > 0)
                {
                    //var chartType = commonUtils.getChartType(this.chartType);
                    this.chartProperties = commonUtils.readJSONFile('component/'+this.chartType+'/'+this.chartType+'.'+this.visualization+'.properties.json');
                    for(var i=0;i< this.chartProperties.length ;i++)
                    {
                        if(this.chartProperties[i][0] == jsonData.chartProperties[i][0])
                        {

                            this.chartProperties[i][3] = commonUtils.parsePropertiesDataType(jsonData.chartProperties[i][1],jsonData.chartProperties[i][2]);
                        }
                    }
                }
                else
                {
                    this.chartProperties = [];
                }
                this.htmlObj = jsonData.htmlObj;
                this.height = jsonData.height;
                this.width = jsonData.width;
                this.version =jsonData.version;
                this.buildVersion=jsonData.buildVersion;
            }
            catch(err)
            {
                $log.error("Pin( "+  this.pinId  +  " ).getConfigFromFile : Error : " + err.message);
                $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ServerError :  \n" + jsonData);
            }
            $log.debug("pin json data : ");
            $log.debug(this.getJson());
        }

        $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ended : getJson : \n" + this.getJson());
    };
    return pin ;
}]);

angular.module('pinboard')
.factory('PinRow',['commonUtils','$log',function (commonUtils,$log) {
    $log.debug("PinRow Factory called");
    var PinRow = function () {
        this.pins = [];
        this.pinType = []; /* 0 - self 1 - existing*/
        this.isSimpleLayout = false;
        this.mdLayout = [];
        this.smLayout = [];
        this.esLayout = [];
        this.lgLayout = [];
        this.cols = 0;
        this.rIdx =-1; // Row Index
    };

    PinRow.prototype.getJson= function() {
        var temp = "{" ;
        var len = this.pins.length -1 ;
        temp = temp  + "\"pins\" : [";
        $.each( this.pins, function( index, pin ){

            if(index < len)
                temp = temp  + pin.getJson() + ",";
            else
                temp = temp  + pin.getJson() ;
        });
        temp = temp  + "],";

        len = this.pinType.length -1 ;
        temp = temp  + "\"pinType\" : [";
        $.each( this.pinType, function( index, value ){

            if(index < len)
                temp = temp  + value+ ",";
            else
                temp = temp  + value+ "";

        });
        temp = temp  + "],";

        len = this.mdLayout.length -1 ;
        temp = temp  + "\"mdLayout\" : [";
        $.each( this.mdLayout, function( index, value ){

            if(index < len)
                temp = temp  + value+ ",";
            else
                temp = temp  + value;


        });
        temp = temp  + "],";

        len = this.smLayout.length -1 ;
        temp = temp  + "\"smLayout\" : [";
        $.each( this.smLayout, function( index, value ){

            if(index < len)
                temp = temp  + value+ ",";
            else
                temp = temp  + value;


        });
        temp = temp  + "],";

        len = this.esLayout.length -1 ;
        temp = temp  + "\"esLayout\" : [";
        $.each( this.esLayout, function( index, value ){

            if(index < len)
                temp = temp  + value+ ",";
            else
                temp = temp  + value;


        });
        temp = temp  + "],";

        len = this.lgLayout.length -1 ;
        temp = temp  + "\"lgLayout\" : [";
        $.each( this.lgLayout, function( index, value ){

            if(index < len)
                temp = temp  + value+ ",";
            else
                temp = temp  + value;


        });
        temp = temp  + "],";

        temp = temp  + "\"cols\" : \""+  $.trim(this.cols)  +  "\" , " ;
        temp = temp  + "\"isSimpleLayout\" : \""+  $.trim(this.isSimpleLayout)  +  "\"  ";


        temp = temp  +"}";

        return temp;
    };

    return PinRow ;
}]);

angular.module('pinboard')
.service('pinboard', ['commonUtils','filterPanel','filter','PinRow','Pin','$log','$compile',function (commonUtils,filterPanel,filter,PinRow,Pin,$log,$compile){
    $log.debug("Pinboard service called");
    this.pinboardscope = this;
    this.PinBoardID = "NewPinBoard";
    //this.PinboardName = ""
    this.pinLists = [];
    this.PinBoardFile = "";
    this.title = "Title";
    this.rowsCount = 0;
    this.uniquePinIdCnt = 1;
    this.filterPanel = Object();
    this.htmlObj = "pinboard";
    this.version = commonUtils.version;
    this.buildVersion = commonUtils.buildVersion;
    this.pinListenerArray = []; 
        
    this.init= function(options) {
        $log.debug("pinboard init is called");
        this.PinBoardID = "NewPinBoard";
        this.pinLists = [];
        this.PinBoardFile = "";
        this.title = "Title";
        this.rowsCount = 0;
        this.uniquePinIdCnt = 1;
        this.htmlObj = "pinboard";
        this.version = commonUtils.version;
        this.buildVersion = commonUtils.buildVersion;
        this.filterPanel = new filterPanel();
        this.filterPanel.init();
        $log.debug("Pinboard.init: " + this.getJson());
    };

    this.getJson= function() {
        var temp = "{"+
            "\"PinBoardID\" : \""+  $.trim(this.PinBoardID)  +  "\" , " +
            "\"PinBoardFile\" : \""+  $.trim(this.PinBoardFile)  +  "\" , " +
            "\"title\" : \""+  $.trim(this.title)  +  "\" , " +
            "\"rowsCount\" : \""+  this.rowsCount +  "\" , " +
            "\"uniquePinIdCnt\" : \""+  this.uniquePinIdCnt +  "\" , " +
            "\"htmlObj\" : \""+  $.trim(this.htmlObj)  +  "\" , " +
            "\"version\" : \""+  $.trim(this.version)+  "\" , " +
            "\"buildVersion\" : \""+  $.trim(this.buildVersion)+  "\" , " +
            "\"filterPanel\" : "+  this.filterPanel.getJson()+  " , " +
            "\"pinLists\" : [";

        var len = this.pinLists.length -1 ;
        $.each( this.pinLists, function( index, value ){
            if(index < len)
                temp = temp  + value.getJson()+ ",";
            else
                temp = temp  + value.getJson();
        });
        temp = temp  +"]";
        temp = temp  +"}";
        return temp;
    };

    this.saveConfigToFile = function() {
        $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Starterd");
        var param = { "file"  :  this.PinBoardFile ,
            "content"  : this.getJson() };
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);

        if(jsonData.result =="Success.")
        {
            $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Ended : Successfully");
            return true;
        }
        else
        {
            $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Ended : Error : " + jsonData.result );
            return false;
        }
    };

    this.getConfigFromFile = function() {
        $log.debug("Pinboard( "+  this.pinId  +  " ).getConfigToFile(" +  this.pinFile  + ") :   Started");
        var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ this.PinBoardFile,"GET",null).result);
        $log.debug(jsonData);
        this.removeAll();

        this.PinBoardID = jsonData.PinBoardID;
        this.pinLists =jsonData.pinLists;
        var pinList = [];

        $.each( this.pinLists, function( index, pinRowData ){
            var pinrow = new PinRow();
            var pindata = pinRowData.pins;


            $.each( pindata, function( pindataIdx, pin ){
                pinrow.pins[pindataIdx] = new Pin();
                pinrow.pins[pindataIdx].pinId   =pin.pinId;
                pinrow.pins[pindataIdx].pinIcon =pin.pinIcon;
                pinrow.pins[pindataIdx].title   =pin.title;
                pinrow.pins[pindataIdx].cIdx =pindataIdx;
                if(pin.minimize == "true")
                    pinrow.pins[pindataIdx].minimize    = true;
                else
                    pinrow.pins[pindataIdx].minimize    = false;

                if(pin.isHeader == "true")
                    pinrow.pins[pindataIdx].isHeader    = true;
                else
                    pinrow.pins[pindataIdx].isHeader    = false;

                pinrow.pins[pindataIdx].bootstrapStyle  =pin.bootstrapStyle;
                pinrow.pins[pindataIdx].dataSource  =pin.dataSource;
                pinrow.pins[pindataIdx].dataAccessId = pin.dataAccessId;
                pinrow.pins[pindataIdx].defaultParamStr = pin.defaultParamStr;
                pinrow.pins[pindataIdx].chartType = pin.chartType;
                pinrow.pins[pindataIdx].visualization   =pin.visualization;
                pinrow.pins[pindataIdx].height  =pin.height;
                pinrow.pins[pindataIdx].width   =pin.width;
                pinrow.pins[pindataIdx].htmlObj =pin.htmlObj;
                //$log.debug("pin.listenerFilters "+pin.listenerFilters);
                pinrow.pins[pindataIdx].listenerFilters =pin.listenerFilters;
                //$log.debug("pinrow.pins[pindataIdx].listenerFilters "+pinrow.pins[pindataIdx].listenerFilters);
                
                 if(pin.chartProperties != undefined && pin.chartProperties.length > 0)
                {
                    //var chartType = commonUtils.getChartType(pinrow.pins[pindataIdx].chartType);
                    pinrow.pins[pindataIdx].chartProperties = commonUtils.readJSONFile('component/'+pinrow.pins[pindataIdx].chartType+'/'+pinrow.pins[pindataIdx].chartType+'.'+pinrow.pins[pindataIdx].visualization+'.properties.json');
                    for(var i=0;i< pinrow.pins[pindataIdx].chartProperties.length ;i++)
                    {
                        $log.debug(pin.chartProperties[i]);
                        $log.debug(pinrow.pins[pindataIdx].chartProperties[i]);
                        if(pinrow.pins[pindataIdx].chartProperties[i][0] == pin.chartProperties[i][0])
                        {
                            pinrow.pins[pindataIdx].chartProperties[i][3] = commonUtils.parsePropertiesDataType(pin.chartProperties[i][1],pin.chartProperties[i][2]);

                        }
                    }
                }
                else
                {
                    pinrow.pins[pindataIdx].chartProperties = [];
                }

            });

            pinrow.pinType = pinRowData.pinType;
            pinrow.mdLayout = pinRowData.mdLayout;
            pinrow.smLayout = pinRowData.smLayout;
            pinrow.esLayout = pinRowData.esLayout;
            pinrow.lgLayout = pinRowData.lgLayout;

            if(pinRowData.isSimpleLayout == "true")
                pinrow.isSimpleLayout = true;
            else
                pinrow.isSimpleLayout = false;
            pinrow.cols = parseInt(pinRowData.cols);
            pinrow.rIdx =index;

            pinList[index]=pinrow;

        });

        this.pinLists = pinList;

        //get config of filterPanel
        this.filterPanel = new filterPanel();
        this.filterPanel.filterPanelId = jsonData.filterPanel.filterPanelId;
        this.filterPanel.filterPanelTitle = jsonData.filterPanel.filterPanelTitle;
        this.filterPanel.filterPanelIcon = jsonData.filterPanel.filterPanelIcon;
        this.filterPanel.filterPanelColor = jsonData.filterPanel.filterPanelColor;
        this.filterPanel.filterPanelHeight = jsonData.filterPanel.filterPanelHeight;
        this.filterPanel.filterPanelShow = jsonData.filterPanel.filterPanelShow=="true"?true :false;
        
        //this.filterPanel.filterArray = jsonData.filterPanel.filterArray;
        var filterListArray = [];
        $.each(jsonData.filterPanel.filterArray, function( index, filterVal ){
            filterListArray[index] = new filter();
            filterListArray[index].filterId = filterVal.filterId;
            filterListArray[index].filterName = filterVal.filterName;
            filterListArray[index].filterCaption = filterVal.filterCaption;
            filterListArray[index].defaultVal = filterVal.defaultVal;
            filterListArray[index].filterVal = filterVal.filterVal;
            filterListArray[index].filterType = filterVal.filterType;
            filterListArray[index].htmlComponent = filterVal.htmlComponent;
            filterListArray[index].dataSource = filterVal.dataSource;
            filterListArray[index].dataAccessId = filterVal.dataAccessId;
            filterListArray[index].position = filterVal.position;
            filterListArray[index].filterWidth = filterVal.filterWidth;

            var datasourceArray = filterVal.datasourceArray;
            $.each( datasourceArray, function( datasourceIdx, datasource ){
                filterListArray[index].datasourceArray.push(datasource);
            });

            if(filterVal.filterType == 'multiSelect'){
                var defaultVal = filterVal.defaultVal;
                $.each( defaultVal, function( defaultValIdx, defaultValue ){
                    filterListArray[index].defaultVal = [];
                    filterListArray[index].defaultVal.push(defaultValue);

                }); 
                //$log.debug("filterListArray"+filterListArray[index].defaultVal);
                //$log.debug(filterListArray[index].datasourceArray);               
            }
            else{
                filterListArray[index].defaultVal = filterVal.defaultVal;
            }

            var listenerPins = filterVal.listenerPins;
            $.each( listenerPins, function( listenerIdx, listener ){
                //$log.debug(listener);
                filterListArray[index].listenerPins[listenerIdx] = new Object();
                filterListArray[index].listenerPins[listenerIdx].pinId = listener.pinId;
                filterListArray[index].listenerPins[listenerIdx].rowIdx = listener.rowIdx;
                filterListArray[index].listenerPins[listenerIdx].colIdx = listener.colIdx;
            });
        });
        this.filterPanel.filterArray = [];
        this.filterPanel.filterArray = filterListArray ;

        this.PinBoardFile = jsonData.PinBoardFile;
        this.title =jsonData.title;
        this.rowsCount = parseInt(jsonData.rowsCount);
        this.uniquePinIdCnt = parseInt(jsonData.uniquePinIdCnt);
        this.htmlObj = jsonData.htmlObj;
        this.version =jsonData.version;
        this.buildVersion=jsonData.buildVersion;

        $log.debug("Pinboard( "+  this.pinId  +  " ).getConfigFromFile : ended : getJson : \n" )
        $log.debug(this.getJson());
    };
    /* pinData = pinList Object */
    this.addRow= function(pinData) {
        //if(Config.debug)
        $log.debug("New row added");
        pinData.rIdx = this.rowsCount;
        this.pinLists[this.rowsCount] = pinData;
        this.rowsCount = this.rowsCount + 1;
    };
    this.removeAll= function(pinData) {
        while(this.pinLists.length > 0) {
            this.pinLists.pop();
        }
        
        //this.filterPanel.filterPanelShow = true;
        this.rowsCount = 0;
    };
    
    this.getPinRow = function(index) {
        var pinRow;
        pinRow = this.pinLists[index-1];
        //if(Config.debug)
            $log.debug("getPinRow.getJson() : " + pinRow.getJson());
        return pinRow;
    };

    this.removeAt = function(index) {
        $log.debug("Row remove at index :"+ (index+1));
        //$log.debug("Before remove row" + this.getJson());
        this.removeListenerFilter(index);
        this.pinLists.splice(index,1);
        this.rowsCount = this.rowsCount -1;
        while(index <this.rowsCount)
        {
            this.pinLists[index].rIdx = this.pinLists[index].rIdx -1 ;
            index = index +1;
        }
        $log.debug(this.rowsCount);
        $log.debug("After remove row : " + this.getJson());
        if(this.rowsCount == 0)
            return true;
        else
            return false;
    };
    
    this.removeListenerFilter = function(index){
        $log.debug("Remove Filter Called");
        for(i=0;i<this.filterPanel.filterArray.length;i++){
            j=0;
            while(j<this.filterPanel.filterArray[i].listenerPins.length){
                

                if(this.filterPanel.filterArray[i].listenerPins[j].rowIdx == index){
                    $log.debug("removed entry from filterArray: ");
                    $log.debug(this.filterPanel.filterArray[i].listenerPins[j]);
                    this.filterPanel.filterArray[i].listenerPins.splice(j,1);
                }
                else{
                    if(this.filterPanel.filterArray[i].listenerPins[j].rowIdx > index){
                        this.filterPanel.filterArray[i].listenerPins[j].rowIdx -= 1;    
                    }
                    j++;
                }
            }
            $log.debug("Listener Pins "+this.filterPanel.filterArray[i].listenerPins);
        }
    };
        
    this.addRowAfter = function(index,insertPinRow) {
        //if(Config.debug)
        $log.debug(" Add row after (" +index + ") : Started : getJson : \n" +  this.getJson() );
        this.addRowAfterFilters(index);
        index = index +1;
        //pull down elements
        for(var i =this.rowsCount; i>index;i--)
        {
            this.pinLists[i] = this.pinLists[i-1];
            this.pinLists[i].rIdx = i;

        }
        this.pinLists[index]=insertPinRow;
        this.pinLists[index].rIdx = index;

        this.rowsCount = this.rowsCount + 1;

        //if(Config.debug)
            $log.debug(" addRowAfter(" +index + " ) : ended : getJson : \n" +  this.getJson() );
    };

    this.addRowAfterFilters = function(index){
        for(i=0;i<this.filterPanel.filterArray.length;i++){
            j=0;
            while(j<this.filterPanel.filterArray[i].listenerPins.length){
                if(this.filterPanel.filterArray[i].listenerPins[j].rowIdx > index){
                    this.filterPanel.filterArray[i].listenerPins[j].rowIdx = parseInt(this.filterPanel.filterArray[i].listenerPins[j].rowIdx) + 1;
                }
                j++;
                
            }
        }
        $log.debug("Filter Array : "+this.filterPanel.filterArray);
    }

    this.addRowBefore = function(index,insertPinRow) {
        $log.debug("Add row before (" +index + ") : Started : getJson : \n" +  this.getJson() );

        $log.debug("Row Count " + this.rowsCount);
        this.addRowBeforeFilters(index);
        //pull down elements
        for(var i =this.rowsCount; i>index;i--)
        {
            this.pinLists[i] = this.pinLists[i-1]; // copy pull down row
            this.pinLists[i].rIdx = i;

        }
        this.pinLists[index]=insertPinRow;
        this.pinLists[index].rIdx= index;

        this.rowsCount = this.rowsCount + 1;

        //if(Config.debug)
            $log.debug(" Add remove before(" +index + ") : ended : getJson : \n" +  this.getJson() );
    };

    this.addRowBeforeFilters = function(index){
        for(i=0;i<this.filterPanel.filterArray.length;i++){
            j=0;
            while(j<this.filterPanel.filterArray[i].listenerPins.length){
                if(this.filterPanel.filterArray[i].listenerPins[j].rowIdx >= index){
                    this.filterPanel.filterArray[i].listenerPins[j].rowIdx = parseInt(this.filterPanel.filterArray[i].listenerPins[j].rowIdx) + 1;    
                }
                j++;
            }
        }
        $log.debug("Filter Array : "+this.filterPanel.filterArray);
    };
    this.resizeChart = function (){
        $log.debug("Resize Called.");
        for(var i =0; i<this.rowsCount;i++)
            for(j=0;j<this.pinLists[i].pins.length;j++)
                    this.pinLists[i].pins[j].render(this.pinLists[i].pins[j].paramStr);

    }
}]);

angular.module('pinboard')
.factory('filter',['commonUtils','$log',function(commonUtils,$log){
    var filter = function(){
        this.filterId = "";
        this.filterName = "";
        this.filterCaption = "";
        this.defaultVal = "";
        this.filterVal = "";
        this.filterType = "";
        this.htmlComponent = "";
        this.dataSource = "";
        this.dataAccessId = "";
        this.datasourceArray = [];
        this.listenerPins = [];
        this.position = "";
        this.filterWidth = "120";
    };


    filter.prototype.getJson = function(){
        //$log.debug("getjson of filter called");
        var self = this;
        var json = "{"+
            "\"filterId\" : \""+  $.trim(this.filterId)  +  "\" , " +
            "\"filterName\" : \""+  $.trim(this.filterName)  +  "\" , " +
            "\"filterCaption\" : \""+  $.trim(this.filterCaption)  +  "\" , " +
            "\"filterType\" : \""+ $.trim(this.filterType)+  "\" , " +
            "\"htmlComponent\" : "+  JSON.stringify($.trim(this.htmlComponent))  +  " , " +
            "\"dataSource\" : \""+  $.trim(this.dataSource)   +  "\" , " +
            "\"dataAccessId\" : \""+  $.trim(this.dataAccessId)   +  "\" , ";

            if(this.datasourceArray != undefined && this.datasourceArray.length > 0)
            {
                len = this.datasourceArray.length -1 ;
                json = json  + "\"datasourceArray\" : [";
                $.each( this.datasourceArray, function( index, value ){

                    if(index < len)
                        json = json  + "\"" +value+"\",";
                    else
                        json = json  + "\"" +value+"\"";

                });
                json = json  + "],";
                
            }
            else
            {
                json = json + "\"datasourceArray\" : [] , " ;
            }

            if(this.filterType == 'multiSelect'){
                len = this.defaultVal.length -1 ;
                json = json  + "\"defaultVal\" : [";
                $.each( this.defaultVal, function( index, value ){

                    if(index < len)
                        json = json  + "\"" +value+"\",";
                    else
                        json = json  + "\"" +value+"\"";

                });
                json = json  + "],";

                len = this.filterVal.length -1 ;
                json = json  + "\"filterVal\" : [";
                $.each( this.filterVal, function( index, value ){

                    if(index < len)
                        json = json  + "\"" +value+"\",";
                    else
                        json = json  + "\"" +value+"\"";

                });
                json = json  + "],";

            }
            else{
                json = json +  "\"defaultVal\" : \""+  $.trim(this.defaultVal)  +  "\" , " +
                               "\"filterVal\" : \""+ $.trim(this.filterVal)+  "\" , " ;
            }
        
            json = json + "\"listenerPins\" : ";
            json = json + "[";
            len = this.listenerPins.length;
            if(this.listenerPins.length >0){
                
                //$log.debug(this.listenerPins);

                for(var i=0;i<len;i++){
                    json = json + "{";
                    json = json +  "\"pinId\" : " ;
                    json = json  + "\"" +self.listenerPins[i].pinId+"\",";
                    json = json +  "\"rowIdx\" : " ;
                    json = json  + "\"" +self.listenerPins[i].rowIdx+"\",";
                    json = json +  "\"colIdx\" : " ;
                    json = json  + "\"" +self.listenerPins[i].colIdx+"\"";
                    if(i == len-1){
                        json = json + "}";    
                    }
                    else{
                        json = json + "},";   
                    }
                    
                }
            }
            json = json + "],";
            

            json = json + "\"position\" : \""+  $.trim(this.position)   +  "\" , " +
            "\"filterWidth\" : \""+  $.trim(this.filterWidth)   +  "\"  "+
            
            "}"; 
        return json;
    }
    return filter;
}]);

angular.module('pinboard')
.factory('filterPanel',['commonUtils','$log',function(commonUtils,$log){
    var filterPanel = function(){
        this.filterArray = [];
        this.filterPanelId = '';
        this.filterPanelTitle = 'Filter Panel 1';
        this.filterPanelIcon = 'glyphicon glyphicon-filter';
        this.filterPanelColor = 'panel-blue';
        this.filterPanelHeight = '100';
        this.filterPanelShow = false;
    };

    filterPanel.prototype.init = function(){
        this.filterArray = [];
        this.filterPanelId = '';
        this.filterPanelTitle = 'Filter Panel';
        this.filterPanelIcon = 'glyphicon glyphicon-filter';
        this.filterPanelColor = 'panel-blue';
        this.filterPanelHeight = '100';
        this.filterPanelShow = false;
    }

    filterPanel.prototype.getJson = function(){
        var json = "{"+
            "\"filterPanelId\" : \""+  $.trim(this.filterPanelId)  +  "\" , " + // currently not using for anything
            "\"filterPanelTitle\" : \""+  $.trim(this.filterPanelTitle)  +  "\" , " +
            "\"filterPanelIcon\" : \""+  $.trim(this.filterPanelIcon)  +  "\" , " +
            "\"filterPanelColor\" : \""+  $.trim(this.filterPanelColor)  +  "\" , " +
            "\"filterPanelHeight\" : \""+  this.filterPanelHeight +  "\" , " +
            "\"filterArray\" : [";

        
        var len = this.filterArray.length ;
        $.each( this.filterArray, function( index, value ){

            if(index < len-1)
                json = json  + value.getJson()+ ",";
            else
                json = json  + value.getJson();
        });

        json = json  +"] ,";
        json = json  +"\"filterPanelShow\" : \""+  this.filterPanelShow +  "\"" ;
        json = json  +"}";
        return json;
        
    }
    return filterPanel;
}]);

angular.module('pinboard')
.directive("filterpanel",['pinboard','$log','$compile','commonUtils','$timeout',function(pinboard,$log,$compile,commonUtils,$timeout){
    return{
        restrict : 'E',
        scope : {
            'filterPanel' : '='
        },
        transclude: true,
        bindtoController:true,
        controllerAs :'filterpanelctrl',
        controller : ['$scope', '$attrs','$element', function (scope, attrs,element) {
            $log.debug("This is filterPanel controller");
            var vm  = this;
            vm.filterPanel = pinboard.filterPanel;
            vm.filterArray = pinboard.filterPanel.filterArray; 
            $log.debug("filterPanel : "+pinboard.filterPanel);
            scope.settingVisible = commonUtils.editor;
            scope.filterPanelMinimize = false;

            scope.submitFilter = function(){
                $log.debug("this is submit filter method");
                var len = scope.filterPanel.filterArray.length;
                pinboard.pinListenerArray = [];
                $log.debug("Filter Array : "+scope.filterPanel.filterArray);
                for(i=0;i<len;i++){
                    if((k=scope.filterPanel.filterArray[i].listenerPins.length)!= 0){
                        for(j=0;j<k;j++){
                            var arrayLen = [];
                            var cdaParam = "";

                            var rowIdx = parseInt(scope.filterPanel.filterArray[i].listenerPins[j].rowIdx);
                            var colIdx = parseInt(scope.filterPanel.filterArray[i].listenerPins[j].colIdx);
                            arrayLen = pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters.length;
                            $log.debug("listenerFilters "+pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters)

                            for(var m=0;m<arrayLen;m++){
                                if(pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters[m][0] == scope.filterPanel.filterArray[i].filterId){
                                    cdaParam = pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters[m][1];
                                    break;
                                }
                            }
                            var paramval = scope.filterPanel.filterArray[i].filterVal;
                            $log.debug("paramval : "+paramval + " "+cdaParam);

                            var param='';
                            if(scope.filterPanel.filterArray[i].filterType == 'multiSelect'){
                                for(a=0;a<paramval.length;a++)
                                    param = param +'&param'+cdaParam+'='+paramval[a]+'';    
                            }
                            else{
                                param = '&param'+cdaParam+'='+paramval;
                            }
                            

                            var l = pinboard.pinListenerArray.length;
                            var isNewEntry = true;
                            if(l == 0){
                                pinboard.pinListenerArray[0] = new Object();
                                pinboard.pinListenerArray[0].rowIdx = parseInt(scope.filterPanel.filterArray[i].listenerPins[j].rowIdx);
                                pinboard.pinListenerArray[0].colIdx = parseInt(scope.filterPanel.filterArray[i].listenerPins[j].colIdx);
                                pinboard.pinListenerArray[0].param = param;
                            }
                            else{
                                for(b=0;b<l;b++){
                                    if(pinboard.pinListenerArray[b].rowIdx == scope.filterPanel.filterArray[i].listenerPins[j].rowIdx && pinboard.pinListenerArray[b].colIdx == scope.filterPanel.filterArray[i].listenerPins[j].colIdx ){
                                        pinboard.pinListenerArray[b].param = pinboard.pinListenerArray[b].param + param; 
                                        isNewEntry = false;
                                        break;
                                    }
                                }
                                if(isNewEntry){
                                    pinboard.pinListenerArray[l] = new Object();
                                    pinboard.pinListenerArray[l].rowIdx = parseInt(scope.filterPanel.filterArray[i].listenerPins[j].rowIdx);
                                    pinboard.pinListenerArray[l].colIdx = parseInt(scope.filterPanel.filterArray[i].listenerPins[j].colIdx);
                                    pinboard.pinListenerArray[l].param = param;   
                                }
                            }
                            
                            $log.debug("pinlistenerArray ");
                            $log.debug(pinboard.pinListenerArray);
                        }
                    }    
                };

                $timeout(function(){
                    for(x=0;x<pinboard.pinListenerArray.length;x++){
                        pinboard.pinLists[pinboard.pinListenerArray[x].rowIdx].pins[pinboard.pinListenerArray[x].colIdx].paramStr = pinboard.pinListenerArray[x].param;
                        pinboard.pinLists[pinboard.pinListenerArray[x].rowIdx].pins[pinboard.pinListenerArray[x].colIdx].render(pinboard.pinListenerArray[x].param);
                    }
                },0)
                commonUtils.savedFlag = false;
                $log.debug("Pinboard Json data : ");
                $log.debug(pinboard.getJson());
                
            };
            scope.resetFilters = function(){
 
                for(i=0;i<scope.filterPanel.filterArray.length;i++){
                    if(scope.filterPanel.filterArray[i].filterType == "multiSelect"){
                        var temp = [];
                        temp= scope.filterPanel.filterArray[i].defaultVal;
                        scope.filterPanel.filterArray[i].filterVal = [];
                        for(j=0;j<temp.length;j++){
                            scope.filterPanel.filterArray[i].filterVal.push(temp[j]);    
                        }
                    }
                    else{
                        scope.filterPanel.filterArray[i].filterVal = scope.filterPanel.filterArray[i].defaultVal;
                    }
                    
                }
                
                $log.debug(scope.filterPanel.filterArray);
                $log.debug("Filter Panel reseted");
            }

            scope.filterPanelSetting = function(){
                $log.debug("this is filter panel setting");
                BootstrapDialog.show({
                            title : 'Filter Panel Setting',
                            message : function(dialog) {
                                var $message = $('<div></div>');
                                var template = commonUtils.getHtmlContent('angular/files/filterPanelSetting.html');
                                
                                $message.append($compile(template)(scope));
                                return $message;
                            },
                            closable : false,
                            draggable : true,
                            cssClass : 'setting-dialog',
                            onshown : function(dialogRef) {
                                $('#filterpanel').collapse('show');
                                scope.filterPanelTitle = scope.filterPanel.filterPanelTitle;
                                scope.filterPanelIcon = scope.filterPanel.filterPanelIcon;
                                scope.filterPanelColor = scope.filterPanel.filterPanelColor;
                                scope.filterPanelHeight = scope.filterPanel.filterPanelHeight;
                                commonUtils.safeApply(scope,function(){});
                            },
                            buttons : [{
                                label : 'Apply',
                                cssClass : 'btn-primary',
                                action : function(dialogItself) {
                                    scope.filterPanel.filterPanelTitle = scope.filterPanelTitle; 
                                    scope.filterPanel.filterPanelIcon = scope.filterPanelIcon;
                                    scope.filterPanel.filterPanelColor = scope.filterPanelColor;
                                    scope.filterPanel.filterPanelHeight = scope.filterPanelHeight;
                                    commonUtils.safeApply(scope,function(){});
                                    commonUtils.savedFlag = false;
                                    dialogItself.close();
                                },
                                cssClass : 'btn-default btn-lg btn-primary'
                            },{
                                label : 'Close',
                                action : function(dialogItself) {
                                    dialogItself.close();
                                },
                                cssClass : 'btn-default btn-lg btn-danger'
                            }]
                        });
            }

            scope.minimizeFilterPnael = function(){
                //$log.log(scope.filterPanelMinimize);
                if($('#filterpanel').hasClass('collapse') && $('#filterpanel').hasClass('in') )
                    scope.filterPanelMinimize = true;                    
                else
                    scope.filterPanelMinimize = false;   
                
            }

            scope.init = function(){
                //$log.log($('#filterpanel').height());
                if(!$('#filterpanel').hasClass('collapse') && !$('#filterpanel').hasClass('in'))
                    scope.filterPanelMinimize = true;
            }
            scope.init();
        }], 
        template:   '<div class="filterpanelWrapper"><div id="filterpanelHeader" class="panel panel-filter" >' +
                        '<div class="panel-heading clearfix fontWhite {{filterPanel.filterPanelColor}}">' +
                            '<h4 id="filterpanelTitle" class="panel-title panel-filterpanel-main pull-left">'+
                                '<i id="filterPanIcon" class="{{filterPanel.filterPanelIcon}}"></i> ' +
                                ' {{filterPanel.filterPanelTitle}}' +
                            '</h4>' +
                            '<div class="pull-right">' +
                                '<button class="btn btn-default btn-xs btn-xs-last" ng-click="minimizeFilterPnael()" data-toggle="collapse" data-target="#filterpanel">'+
                                '<i class="glyphicon glyphicon-minus"></i></button>' +
                                '<button class="btn btn-default btn-xs" ng-show=settingVisible ng-click="filterPanelSetting()">'+
                                '<i class="glyphicon glyphicon-cog"></i></button>' +                                
                                '<button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()" ng-hide=filterPanelMinimize>Reset</button>'+
                                '<button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()" ng-hide=filterPanelMinimize>Submit</button>'+
                            '</div>' +
                        '</div>' +
                        '<div id="filterpanel" class="panel-body panel-filter-body collapse filterpanel" style="height:{{filterPanel.filterPanelHeight}}px;">'+
                           // '<div  class="filterPanelBody col-md-12  col-sm-12  column " style="height:{{filterPanel.filterPanelHeight}}px;" > '+
                            '<div  class="filterPanelBody col-md-12  col-sm-12  column " > '+
                                "<filtercomponent ng-repeat='filter in filterPanel.filterArray' filterconfig=filter ></filtercomponent>" +
                            '</div>' +
                        '</div>'+
                    '</div></div>'
    }
}]);

angular.module('pinboard')
.directive("filtercomponent",['commonUtils','pinboard','$log','$compile','$timeout',function(commonUtils,pinboard,$log,$compile,$timeout){
    return{
        restrict: 'E',
        scope : {
            filterconfig : "="
        },
        bindtoController:true,
        controllerAs : 'filterComponentCtrl',
        controller : ['$scope','$attrs','$element',function(scope,attrs,element){
            scope.setComponentWidth = function(){
                $log.debug("Set component Width");
                BootstrapDialog.show({
                    title : 'Filter Component Width',
                    message : function(dialog) {
                        var $message = $('<div></div>');
                        var template =  '<div >'+
                                        '<div class="modal-form">'+
                                        '<div class="form-group">'+
                                        '<div class="col-lg-4 col-md-4 col-sm-4 form-group-left">Width</div>'+
                                        '<div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><div class="form-inline"><input type="text" class="form-control col-md-8" id="setComponentWidth" ng-model="componentWidth" value="{{filterconfig.filterWidth}}"><span class="text1">(Maximum width 220)</span></div></div>'+
                                            //'<td><button id="setwidth" ng-click="clickme();">I will call scope function</td></tr>'+
                                        '</div>'+
                                        '</div>'+
                                        '<div class="cl"></div>';                                       ;
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    
                    closable : false,
                    draggable : true,
                    onshown : function(dialogRef) {
                    },
                    buttons : [{
                        label : 'Apply',
                        cssClass : 'btn-primary',
                        action : function(dialogItself) {
                            scope.filterconfig.filterWidth = scope.componentWidth;
                            commonUtils.safeApply(scope,function(){});
                            dialogItself.close();
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : 'Close',
                        action : function(dialogItself) {
                            dialogItself.close();
                        },
                        cssClass : 'btn-lg btn-danger'
                    }]
                });
            }

            scope.removeFilterComponent = function(filterId){
                $log.debug("remove filter is"+ filterId);
                var indx,temp;
                for(i=0;i<pinboard.filterPanel.filterArray.length;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                
                for(var j=0;j<pinboard.filterPanel.filterArray[indx].listenerPins.length;j++){
                    rowIdx = pinboard.filterPanel.filterArray[indx].listenerPins[j].rowIdx;
                    colIdx = pinboard.filterPanel.filterArray[indx].listenerPins[j].colIdx;

                    for(var k=0;k<pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters.length;k++){
                        if(filterId == pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters[k][0])
                            temp = k;
                    }
                    pinboard.pinLists[rowIdx].pins[colIdx].listenerFilters.splice(temp,1);
                }
                
                pinboard.filterPanel.filterArray.splice(indx,1);
                if(pinboard.filterPanel.filterArray.length == 0){
                    pinboard.filterPanel.filterPanelShow = false;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }
            scope.slideFilterLeft = function(filterId){
                var indx;
                for(i=0;i<pinboard.filterPanel.filterArray.length;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                //$log.debug("slide filter component of index :"+indx+" to new index :"+indx-1);
                if(indx!=0){
                    var temp = pinboard.filterPanel.filterArray[indx];
                    pinboard.filterPanel.filterArray[indx] =  pinboard.filterPanel.filterArray[indx-1];
                    pinboard.filterPanel.filterArray[indx-1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }

            scope.slideFilterRight = function(filterId){
                var indx;
                var len=pinboard.filterPanel.filterArray.length;
                for(i=0;i<len;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                //$log.debug("slide filter component of index :"+indx+" to new index :"+indx+1);
                if(indx < len-1 ){
                    var temp = pinboard.filterPanel.filterArray[indx];
                    pinboard.filterPanel.filterArray[indx] =  pinboard.filterPanel.filterArray[indx+1];
                    pinboard.filterPanel.filterArray[indx+1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }

            scope.showOption = function(){  
                //$log.log("this is clicked"+ scope.filterconfig.filterId);
                $('.'+scope.filterconfig.filterId+'-show').hide();
                $('.'+scope.filterconfig.filterId+'-hide').show();
                $('.'+scope.filterconfig.filterId+'-buttons').show('fast');   
                //$('.btn-filterComponent .'+scope.filterconfig.filterId).show('fast');
            }

            scope.hideOption = function(){
                $('.'+scope.filterconfig.filterId+'-hide').hide();
                $('.'+scope.filterconfig.filterId+'-show').show();
                $('.'+scope.filterconfig.filterId+'-buttons').hide('fast');   
            }
        }],

        link: function(scope,element,attrs){
            //pinboard.filterScope = scope;
            if(commonUtils.editor)
            {
                var html ="<div class='filterComponentOuter'>"+
                    "<div class='filterComponent btn-filterComponent form-inline pull-right {{filterconfig.filterId}}-buttons' >" +
                    "<button class='btn  btn-xs filterButton' title='remove' ng-click='removeFilterComponent(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-remove'></i></button>" +
                    "<button class='btn  btn-xs filterButton' title='slide-left' ng-click='slideFilterLeft(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-arrow-left'></i></button>" +
                    "<button class='btn  btn-xs filterButton' title='slide-right' ng-click='slideFilterRight(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-arrow-right'></i></button>" +
                    "<button tabindex='0' title='width' ng-click='setComponentWidth()' class='btn btn-xs filterButton filterPopover glyphicon glyphicon-resize-horizontal'"+
                    "></button>"+
                    "</div>"+
                    "<div class='btn-show-filteroption {{filterconfig.filterId}}-show' ng-click='showOption()'><i class='fa fa-plus-square'></i></div><div class='btn-hide-filteroption {{filterconfig.filterId}}-hide' ng-click='hideOption()'><i class='fa fa-minus-square'></i></div>" ;
            }
            else
                var html = "<div class='filterComponentOuter'>";

            html = html+scope.filterconfig.htmlComponent+"</div>";
            element.html(html);
            $compile(element.contents())(scope);

            $timeout(function(){
                if(scope.filterconfig.filterType == 'datePicker'){
                    $('#'+scope.filterconfig.filterId).daterangepicker(
                        { 
                            singleDatePicker: true,
                            format :'YYYY-MM-DD',
                            startDate : scope.filterconfig.filterVal
                        },
                        function(start, end, label) {
                        $log.debug("date into ISOstring: "+start.toISOString());
                    });
                }
            },0)
        }   
    }
}])

angular.module('pinboard')
.directive("dashboard",['pinboard','$log',function(pinboard,$log){
    return {
        restrict : 'E',
        scope : {
            'editor' : '@'
        },
        bindtoController:true,
        controllerAs :'databoard',
        template :  "<filterpanel filter-panel='databoard.pinboard.filterPanel' ng-show=databoard.pinboard.filterPanel.filterPanelShow></filterpanel>"+
                    "<pinrow ng-repeat='pinrow in databoard.pinboard.pinLists' idd={{pinrow.rIdx}}  is-Simple-Layout='{{pinrow.isSimpleLayout}}'  row=pinrow class='row clearfix' >" +
                    "</pinrow>",


        controller : ['$scope','$attrs','$element', function (scope,attrs,element) {
            $log.debug("This is Dashboard directive");
            var vm  = this;
            vm.pinboard = pinboard;
        }]
    }

}])

angular.module('pinboard')
.directive("pinrow",['pinboard','$compile','commonUtils','$log',function(pinboard,$compile,commonUtils,$log){
    return {
        restrict :'E',
        scope : {
            'row'  : '=',
            'idd' : '@',
            'isSimpleLayout' :'@'
        },
        transclude: true,
        bindtoController:true,
        controllerAs :'pinrow',
        controller : ['$scope', '$attrs','$element', function (scope, attrs,element) {
            $log.debug("This is Pinrow directive");
            var vm  = this;
            vm.row = pinboard.pinLists[scope.idd];
        }],
        link : function (scope,element,attrs ){
            $log.debug("Pinboard editor flag : "+commonUtils.editor);
            if(commonUtils.editor)
            {
                var html ="<div class='RowOptionsOuter'  >"+
                    "<div class='RowOptions'>" +
                    "<button class='btn  btn-xs btn-default rowOptionInsertBefore' ng-click='$parent.$parent.$parent.insertRowBefore(idd)' title='Insert Row Before'><i class='glyphicon glyphicon-arrow-up'></i></button>" +
                    "<button class='btn  btn-xs btn-default rowOptionInsertAfter' ng-click='$parent.$parent.$parent.insertRowAfter(idd)' title='Insert Row After'><i class='glyphicon glyphicon-arrow-down'></i></button>" +
                    "<button class='btn  btn-xs btn-danger rowOptionRemove' ng-click='$parent.$parent.$parent.removeRow(idd)' title='Remove Row'><i class='glyphicon glyphicon-remove'></i></button>" +
                    "</div>" +
                    "</div>" ;
            }
            else
                var html ="";
            if(attrs.isSimpleLayout=="true")
                html = html+ "<pin ng-repeat='pin in pinrow.row.pins' idd='{{idd}}_{{pin.cIdx}}' pinboardrow ='{{idd}}' pinboardcol='{{pin.cIdx}}' editor={{$parent.$parent.$parent.editor}} pintype=pinrow.row.pinType[pin.cIdx] pinobj=pin class='col-md-{{pinrow.row.mdLayout[pin.cIdx]}} column'></pin>";
            else
                html = html+"<pin ng-repeat='pin in pinrow.row.pins' idd='{{idd}}_{{pin.cIdx}}' pinboardrow ='{{idd}}' pinboardcol='{{pin.cIdx}}'  editor={{$parent.$parent.$parent.editor}} pintype=pinrow.row.pinType[pin.cIdx] pinobj=pin class='col-xs-{{pinrow.row.esLayout[pin.cIdx]}} col-sm-{{pinrow.row.smLayout[pin.cIdx]}} col-md-{{pinrow.row.mdLayout[pin.cIdx]}} col-lg-{{pinrow.row.lgLayout[pin.cIdx]}} column'></pin>";

            element.html(html);
            $compile(element.contents())(scope);
        }
    }
}]);

angular.module('pinboard')
.directive("pin",['pinboard','Pin','$timeout','commonUtils','$log','$http','$compile','Messages',function(pinboard,Pin,$timeout,commonUtils,$log,$http,$compile,Messages){
    return {
        restrict :'E',
        scope : {
            'pinobj'  : '=',
            'pinboardrow' : '@',
            'pinboardcol' : '@',
            'pintype' : '=',
            'idd' : '@'
        },
        link : function (scope,element,attrs ){
            
            $log.debug("This is Pin directive");
            $log.debug("PinType  : " + scope.pintype);
            scope.editor=commonUtils.editor;
            scope.preview = !commonUtils.editor;

            

            if(scope.preview && scope.pinobj.chartType != 'Saiku'){
                scope.showExport = true;    
            }
            else
                scope.showExport = false;

            scope.listParameters = [];

            $timeout(function(){
                if(scope.pinobj.chartType == 'CCC'){
                    $log.debug("paramStr "+scope.pinobj.defaultParamStr);
                    scope.pinobj.paramStr = scope.pinobj.defaultParamStr;
                    scope.pinobj.render(scope.pinobj.defaultParamStr);    
                }
                else{
                    scope.pinobj.render();    
                }
            }, 0);

            if(commonUtils.mode == "pin")
                scope.pageToLoad = 'angular/files/PinProperties.html';
            else
                scope.pageToLoad = 'angular/files/PinBoardProperties.html';


            //initialization method of the chart properties
            scope.initChartProperties = function(){
                scope.isPinboard = false;
                scope.chartTypes = [];
                scope.filterParameters = [];
                scope.filterShow = false;
                for(var i=0; i<commonUtils.components.selfServiceBI.length; i++) {
                    scope.chartTypes.push(commonUtils.components.selfServiceBI[i].chartCaption);
                };
                scope.chartType = scope.chartTypes[0];

                if(commonUtils.mode == 'pinboard'){
                    scope.isPinboard = true;
                    scope.filterBinder = [];
                    scope.showFilterParam;
                    scope.filterListenerVal = [];    
                    for(var i=0; i<pinboard.filterPanel.filterArray.length; i++) {
                        scope.filterParameters.push(pinboard.filterPanel.filterArray[i].filterId);
                    };
                    scope.filterShow = false;
                }
                
                if(scope.chartType == 'Saiku'){
                    scope.isCCCchart = false;
                }
                    
                else{
                    scope.isCCCchart = true;
                }
            }  

             scope.chartProperties = function(){
                $log.debug("chart properties called");
                scope.initChartProperties();

                BootstrapDialog.show({
                    title: 'Chart Properties of '+scope.pinobj.title+'',
                    message: function(dialog){
                        var $message = $('<div></div>');
                        //var pageToLoad = dialog.getData('pageToLoad');
                        //$message.load(pageToLoad);
                        var template = commonUtils.getHtmlContent('chartsProperties.html');
                        $message.append($compile(template)(scope));
                        return $message;

                    },
                    closable : false,
                    draggable : true,
                    cssClass : 'chart-properties-dialog',
                    onshown : function(dialogRef){
                        var cdaParams = [];
                        var getDataAccessId = [];
                        $log.debug(scope.pinobj.pinId);
                        scope.pinId = scope.pinobj.pinId;
                        scope.properties = scope.pinobj.chartProperties;
                        scope.chartType = scope.pinobj.chartType;
                        scope.dataSource = scope.pinobj.dataSource ;
                        scope.visualization = scope.pinobj.visualization ;
                        scope.dataAccessId = scope.pinobj.dataAccessId ;
                        scope.cdaParameter = '';
                        scope.defaultVal = '';
                        scope.filterBinder = scope.pinobj.listenerFilters;

                        if(scope.pinobj.listenerFilters.length != 0){
                            for(i=0;i<scope.filterBinder.length;i++){
                                scope.filterBinder[i][2] = 'table-row';
                            }
                        }            

                        var loadVisualization = function(indx,isNew){
                            scope.visualizations = [];
                            var charts = commonUtils.components.selfServiceBI[indx].properties.files.charts;
                            //$log.debug(charts);
                            scope.browseExt = commonUtils.components.selfServiceBI[indx].properties.datasourceExt;
                            for(i = 0; i < charts.length; i++) {
                                scope.visualizations.push(commonUtils.components.selfServiceBI[indx].properties.files.charts[i]);
                            }
                            if(isNew){
                                scope.visualization = scope.visualizations[0];        
                            }
                            else{
                                scope.visualization = scope.pinobj.visualization;        
                            }
                        }                        
                        
                        var loadProperties = function(){
                            $("#primaryProperties").html("");
                            //var chartType = commonUtils.getChartType(scope.chartType);
                            /*
                            $log.log(scope.chartType)
                            if(scope.chartType == "Saiku Analytics")
                                chartType = 'Saiku';
                            else if(scope.chartType == "CCC Chart Library")
                                chartType = 'CCC';
                            else if(scope.chartType == "Data Tables")
                                chartType = 'Table';
                            else if(scope.chartType == "Labels")
                                chartType = 'Label'
                            */
                            scope.properties = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');
                            if(scope.pinobj.visualization == scope.visualization && scope.pinobj.chartProperties.length > 0){
                                scope.properties = scope.pinobj.chartProperties;
                            }

                            //$log.log(scope.properties)
                            /*
                            var l = scope.properties.length;
                            //$log.log(l);
                            for(i=0;i<l;i++){
                                if(typeof scope.pinobj.chartProperties  != 'undefined' &&  scope.pinobj.chartProperties.length >0 && scope.pinobj.visualization == scope.visualization && scope.pinobj.chartProperties[i][0] == scope.properties[i][0])
                                    commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.pinobj.chartProperties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties",scope);    
                                else
                                    commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties",scope);
                            }
                            */
                        }
                        


                        scope.loadProperties = function(){
                            BootstrapDialog.show({
                                title: ''+scope.visualization+' Properties',
                                message: function(dialog){
                                    var template =  '<div id="propertiesPanel" class="panel propertiesPanel" style="margin-bottom:0px;" >'+
                                                        '<div class="panel-heading" style="text-align:center">'+
                                                            '<input class="form-control input-sm" type="checkbox" id="switchProperties" data-size="small" data-handle-width="75" data-on-text="Primary" data-off-text="Advance" data-on-color="primary" data-off-color="danger"  checked />'+
                                                        '</div>'+
                                                        '<div class="panel" style="overflow:auto;max-height:340px;border:1px solid #DCDCDC">'+
                                                            '<div class="modal-form" id="primaryProperties1">'+
                                                            '</div>'+
                                                        '</div>'+
                                                    '</div>';

                                    var $message = $('<div></div>');
                                    $message.append($compile(template)(scope));
                                    return $message;
                                },
                                closable : false,
                                draggable : true,
                                cssClass : 'chart-properties-dialog',
                                onshown : function(dialogRef){
                                    //$log.debug(scope.filterBinder);
                                    $("#primaryProperties1").html("");

                                    var changeProperties = function(indx){
                                        if(indx == 0 ){
                                            $(".advance").hide();
                                        }
                                        else{
                                            $(".advance").show();
                                        }  
                                    }

                                    $('#switchProperties').bootstrapSwitch('state',true,true);
                                    $('#switchProperties').on('switchChange.bootstrapSwitch', function(event, state){
                                        if(!state)
                                            changeProperties(1);
                                        else
                                            changeProperties(0);
                                    });

                                    /*
                                    scope.properties = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');
                                    */
                                    var l = scope.properties.length;
                                    //$log.log(scope.properties);
                                    for(i=0;i<l;i++){
                                        //$log.log(scope.pinobj.chartProperties[i][0] +" == "+ scope.properties[i][0] +" "+scope.pinobj.visualization+" == "+scope.visualization)

                                        if(typeof scope.pinobj.chartProperties  != 'undefined' &&  scope.pinobj.chartProperties.length >0 && scope.pinobj.visualization == scope.visualization && scope.pinobj.chartProperties[i][0] == scope.properties[i][0]){
                                            commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.pinobj.chartProperties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                        }
                                            
                                        else{
                                            //$log.log(scope.pinobj.visualization+" == "+scope.visualization);
                                            commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                        }
                                            
                                    }
                                                                        
                                    changeProperties(0);
                                },
                                buttons : [{
                                    label : 'Ok',
                                    cssClass : 'btn-primary',
                                    action : function(dialogItself) {
                                        //$log.log(scope.properties);

                                        
                                        var l = scope.properties.length;
                                        //$log.log(scope.properties);
                                        for(var i=0;i<l;i++){
                                            //$log.log(scope.properties[i][2]);
                                            if(scope.properties[i][2] == 'switch' || scope.properties[i][2] == 'combo'){
                                                temp = $('#'+scope.properties[i][0]).bootstrapSwitch('state');
                                                scope[scope.properties[i][0]] = temp;
                                            }
                                            //scope.pinobj.chartProperties[i] = scope.properties[i];
                                            scope.properties[i][3] = commonUtils.parsePropertiesDataType(scope[scope.properties[i][0]],scope.properties[i][1]);
                                            //$log.debug(scope.pinobj.chartProperties[i]);
                                        }
                                        //scope.pinobj.visualization = scope.visualization;
                                        //$log.log(scope.properties);                                        
                                        dialogItself.close();
                                    },
                                    cssClass: 'btn-default btn-lg btn-primary'
                                },{
                                    label : 'Close',
                                    action : function(dialogItself) {
                                        dialogItself.close();
                                        
                                    },
                                    cssClass: 'btn-default btn-lg btn-danger'
                                }]
                            })
                        }

                        var changeProperties = function(indx){
                            if(indx == 0 ){
                                $(".advance").hide();
                            }
                            else{
                                $(".advance").show();
                            }  
                        }
                        
                        scope.getParams = function(dataAccessId){
                            var listParams = [];
                            cdaParams = [];
                            scope.listParameters = [];
                            //alert(listParams);
                            uri = encodeURIComponent(scope.dataSource);
                            url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+dataAccessId ;
                            listParams = commonUtils.readJSONFile(url);
                            scope.listParameters = listParams;

                            if(listParams.resultset.length <= 0 && commonUtils.mode == 'pinboard'){
                                scope.filterShow = false;
                                scope.cdaParameters = [];
                                scope.cdaParameter = "";
                                return;
                            }
                            else if(commonUtils.mode == 'pinboard'){
                                scope.filterShow = true;
                            }
                            
                            scope.cdaParameters = [];
                            for(i=0,l=listParams.resultset.length;i<l;i++)
                                cdaParams.push(listParams.resultset[i][0]);

                            for(var i = 0; i < cdaParams.length; i++) {
                                scope.cdaParameters.push(cdaParams[i]);
                            }

                            scope.cdaParameter = scope.cdaParameters[0];
                        }

                        scope.getParamString = function(){
                            var param = '';
                            var  l = scope.listParameters.resultset.length;
                            for(var i=0;i<l;i++){
                                var cdaParam = scope.listParameters.resultset[i][0];
                                if(scope.listParameters.resultset[i][1].search("Array") >= 0){
                                    var valArray = [];
                                    valArray = JSON.parse(scope.listParameters.resultset[i][2])
                                    for(var j=0;j<(len=valArray.length);j++)
                                        param = param + '&param'+cdaParam+'='+valArray[j];
                                    
                                    return param;
                                }
                                else{
                                    param = param + '&param'+cdaParam+'='+scope.listParameters.resultset[i][2];
                                    return param;
                                }
                            }
                        }

                        $timeout(function(){
                            scope.chartTypeChanged();  
                        },0);

                        
                        scope.chartTypeChanged = function(){
                            var temp;
                            //$log.log("charttype changed");
                            scope.dataSource = "";
                            scope.isNew = true;
                            var index = commonUtils.getIndex(scope.chartType);

                            scope.browseExt = commonUtils.components.selfServiceBI[index].properties.datasourceExt;

                            if(scope.chartType == 'Table' || scope.chartType == 'Label'){
                                //$log.log("this is happend")
                                $('.chartType').hide();
                                $('.dataProperties').show();
                            }
                            else{
                                $('.dataProperties').hide(); 
                                $('.chartType').show();
                            }

                            if(scope.pinobj.chartType == scope.chartType){
                                scope.dataSource = scope.pinobj.dataSource;
                                scope.isNew = false;           
                            }

                            loadVisualization(index,scope.isNew);
                            $('#propertiesPanel').collapse('hide');
                            //commonUtils.components.selfServiceBI[index].properties.files.chartProperties=="true"?true:false;
                            //$log.log(commonUtils.components.selfServiceBI[index].properties.files.chartProperties);
                            if(commonUtils.components.selfServiceBI[index].properties.files.chartProperties=="true"?true:false){
                                //$log.log("this is inside");
                                $('.cccProperties').show();
                                loadProperties();
                                changeProperties(0);
                                $('#switchProperties').bootstrapSwitch('state',true,true);
                            }
                            
                            else   
                                $('.cccProperties').hide();

                            if(commonUtils.components.selfServiceBI[index].properties.parameters){
                                if(scope.filterParameters.length == 0){
                                        $('.filterParam').hide();
                                    }
                                    else{
                                        $('.filterParam').show();
                                    }
                            }
                        }
                        
/*
                        scope.chartTypeChanged = function(){
                            var  temp;
                            $log.debug("chartyype changed");
                            scope.dataSource = '';    
                            switch(scope.chartType){
                                case 'Saiku':{
                                    scope.isCCCchart = false;
                                    scope.browseExt = 'saiku';
                                    scope.isNew = true;
                                    if(scope.pinobj.chartType == scope.chartType){
                                        scope.dataSource = scope.pinobj.dataSource;
                                        scope.isNew = false;           
                                    }
                                    $('#propertiesPanel').collapse('hide');
                                    $('.cccProperties').hide();
                                    loadVisualization(0,scope.isNew);
                                    break;
                                }
                                case 'CCC':{
                                    scope.browseExt = 'cda'
                                    scope.isCCCchart = true;
                                    scope.isNew = true;
                                    if(scope.pinobj.chartType == scope.chartType){
                                        scope.isNew = false;
                                        scope.dataSource = scope.pinobj.dataSource;
                                        //scope.browseFileChanged();
                                        //scope.dataAccessId = scope.pinobj.dataAccessId;
                                    }

                                    $('#propertiesPanel').collapse('hide');
                                    $('.cccProperties').show();

                                    if(scope.filterParameters.length == 0){
                                        $('.filterParam').hide();
                                    }
                                    else{
                                        $('.filterParam').show();
                                    }

                                    loadVisualization(1,scope.isNew);
                                    loadProperties();
                                    changeProperties(0);
                                    $('#switchProperties').bootstrapSwitch('state',true,true);
                                    break;
                                }
                            }
                        }
                        */

                        scope.visualChanged = function(){
                            if(scope.chartType != 'Saiku'){
                                $log.debug("visualization changed");
                                if(scope.visualization == 'Bullet'){
                                    commonUtils.notification(Messages.onCCCbulletChartSelect);
                                }
                                loadProperties();
                                changeProperties(0);
                                $('#switchProperties').bootstrapSwitch('state',true,true);    
                            }
                        }
                        
                        scope.dataAccessIdChanged = function(){
                            $log.debug(scope.dataAccessId);
                            if(scope.dataAccessId != null || scope.dataAccessId != undefined){
                                scope.getParams(scope.dataAccessId);
                                if(commonUtils.mode == "pinboard"){

                                    scope.cdaParamChanged();    
                                }
                                
                            }
                        }

                        scope.cdaParamChanged = function(){
                            $log.debug("cda parameter changed");
                            var param = '';

                            var  l = scope.listParameters.resultset.length;
                            var showMultiSelect = false;
                            if(l == 0){
                                scope.defaultVal = "";
                            }
                            else{
                                for(var i=0;i<l;i++){
                                    if(scope.listParameters.resultset[i][0] == scope.cdaParameter){
                                        
                                        if(scope.listParameters.resultset[i][1].search("Array") >= 0){
                                            var valArray = [];

                                            valArray = JSON.parse(scope.listParameters.resultset[i][2])
                                            for(var j=0;j<(len=valArray.length);j++){
                                                if(j< len-1)
                                                    param = param + valArray[j]+','
                                                else
                                                    param = param + valArray[j] ;
                                            }
                                            scope.defaultVal = param;
                                            showMultiSelect = true;

                                        }
                                        else{
                                            scope.defaultVal = scope.listParameters.resultset[i][2];
                                            showMultiSelect = false;
                                        }
                                    }
                                }
                                if(showMultiSelect){
                                    scope.filterParameters = [];
                                    for(var a=0; a<pinboard.filterPanel.filterArray.length; a++){
                                            scope.filterParameters.push(pinboard.filterPanel.filterArray[a].filterId);
                                    };
                                    scope.filterParameter = scope.filterParameters[0];    
                                }
                                else{
                                    scope.filterParameters = [];
                                    for(var a=0; a<pinboard.filterPanel.filterArray.length; a++) {
                                        if(pinboard.filterPanel.filterArray[a].filterType != 'multiSelect')
                                            scope.filterParameters.push(pinboard.filterPanel.filterArray[a].filterId);
                                    };
                                    scope.filterParameter = scope.filterParameters[0];    
                                }
                            }
                        }

                        scope.browseFile = function(){
                            $log.debug("browseExt : "+scope.browseExt)
                            var getData = function(path){
                                $timeout(function(){
                                    $log.debug("isCCCchart : "+scope.isCCCchart);
                                    scope.dataSource = path;
                                },0)
                            }
                            commonUtils.btnPinSaikuBrowse("Browse Data Source",scope.browseExt,"dataSource",getData);

                        };

                        scope.$watch('dataSource',function(newval,oldval){
                            $log.debug("browseExt : "+scope.browseExt)
                            if(scope.browseExt == 'cda'){
                                //  scope.dataAccessId = "";
                                scope.dataAccessIds = [];
                                scope.cdaParameters = [];
                                scope.defaultVal = '';
                                var getDataAccessId = [];

                                if(scope.dataSource.length > 0){
                                    uri = encodeURIComponent(scope.dataSource);
                                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listQueries?path=/'+uri ;
                                    //alert(url); 
                                    var queryData = commonUtils.synchronousJsonCall(url,'GET',null);
                                    if(queryData != "ERROR"){
                                        for(i=0,l=queryData.resultset.length;i<l;i++)
                                            getDataAccessId.push(queryData.resultset[i][0]);

                                        $log.debug("dataAccessId : "+getDataAccessId);

                                        for(var i = 0; i < getDataAccessId.length; i++) {
                                                scope.dataAccessIds.push(getDataAccessId[i]);
                                            }

                                        if(scope.dataAccessId == undefined || scope.dataAccessId.length <= 0 || scope.dataSource != scope.pinobj.dataSource){
                                            scope.dataAccessId = getDataAccessId[0];    
                                        }
                                        else{
                                            scope.dataAccessId = scope.pinobj.dataAccessId;
                                        }
                                        
                                        $log.debug("scope.dataAccessId : "+scope.dataAccessId);
                                        scope.getParams(scope.dataAccessId);
                                        if(commonUtils.mode == "pinboard"){
                                            scope.cdaParamChanged();
                                        }
                                        
                                    }    
                                }                                
                            }  
                        })
                        
                        scope.bindFilter = function(){
                            var  l = scope.filterBinder.length;
                            var alreadyExist = false;
                            var hasSameFilter = false;
                            var temp;

                            if(l==0){
                                $log.debug(scope.filterParameter+ " "+scope.cdaParameter );
                                scope.filterBinder.push([scope.filterParameter,scope.cdaParameter,'table-row']);
                            }
                            else{
                                for(var i=0;i<l;i++){
                                    if(scope.filterBinder[i][1] == scope.cdaParameter && scope.filterBinder[i][2] == 'table-row'){
                                        alert("\""+scope.cdaParameter+ "\" has already been binded with Filter \""+ scope.filterBinder[i][0]+"\"");
                                        alreadyExist = true;
                                        break;
                                    }
                                    else if(scope.filterBinder[i][1] == scope.cdaParameter && scope.filterBinder[i][2] == 'none'){
                                        if(scope.filterBinder[i][0] == scope.filterParameter){
                                            temp = i;
                                            alreadyExist = false;
                                            hasSameFilter = true;
                                            continue;
                                        }
                                        else{
                                            alreadyExist = false;
                                            continue;
                                        }
                                    }    
                                }
                                if(!alreadyExist){
                                    if(hasSameFilter){
                                        scope.filterBinder[temp][2] = 'table-row';
                                    }
                                    else{
                                        scope.filterBinder.push([scope.filterParameter,scope.cdaParameter,'table-row']);
                                    }
                                }
                            }
                            $log.debug("filterBinder"+scope.filterBinder);

                        }

                        scope.showListener = function(){
                            BootstrapDialog.show({
                                title: 'Listener To Filters',
                                message: function(dialog){
                                    var template = '<div>'+
                                                    '<table class="table table-hover table-condensed" id="filterListenerTable">'+
                                                    '<tr><td>Filter Parameter</td>'+
                                                    '<td>Cda Parameter</td>'+
                                                    '<td>Delete</td></tr>'+
                                                    '</table>'
                                                    '</div>';

                                    var $message = $('<div></div>');
                                    $message.append($compile(template)(scope));
                                    return $message;
                                },
                                closable : false,
                                draggable : true,
                                cssClass : 'column-dialog',
                                onshown : function(dialogRef){
                                    //$log.debug(scope.filterBinder);
                                    scope.filterListenerVal = [];
                                    for(i=0;i<scope.filterBinder.length;i++){
                                        var temp ='<tr id="row'+i+'" class="listenerEntry" style="display:'+scope.filterBinder[i][2]+'">'+
                                                '<td class="filterParam">'+scope.filterBinder[i][0]+'</td>'+
                                                '<td class="cdaParam">'+scope.filterBinder[i][1]+'</td>'+
                                                '<td><button id="delete'+i+'" class="btn btn-xs danger glyphicon glyphicon-remove removeParam" ng-click="removeEntry('+i+')"></button></td></tr>';
                                        $('#filterListenerTable').append($compile(temp)(scope));
                                    }

                                    scope.removeEntry = function(indx){
                                        $('#row'+indx).css("display","none");
                                    }
                                },
                                buttons : [{
                                    label : 'Apply',
                                    cssClass : 'btn-primary',
                                    action : function(dialogItself) {

                                        $('#filterListenerTable tr').each(function() {
                                            if($(this).hasClass('listenerEntry')){
                                                var arrayVal = [$(this).find(".filterParam").html(),$(this).find(".cdaParam").html(),$(this).css("display")];
                                                scope.filterListenerVal.push(arrayVal);
                                            }
                                        });

                                        $log.debug("filterListenerVal "+ scope.filterListenerVal)
                                        scope.filterBinder = [];
                                        scope.filterBinder = scope.filterListenerVal ;
                                        //$log.debug("FilterBinder "+ scope.filterBinder); 
                                        scope.filterListenerVal = [];

                                        dialogItself.close();
                                    },
                                    cssClass: 'btn-default btn-lg btn-primary'
                                },{
                                    label : 'Close',
                                    action : function(dialogItself) {
                                        dialogItself.close();
                                        
                                    },
                                    cssClass: 'btn-default btn-lg btn-danger'
                                }]
                            })
                        }
                                                
                        //initiate properties switch and method when state change
                        $('#switchProperties').bootstrapSwitch('state',true,true);

                        $('#switchProperties').on('switchChange.bootstrapSwitch', function(event, state){
                            if(!state)
                                changeProperties(1);
                            else
                                changeProperties(0);
                        });
                        
                        $('#propertiesPanel').collapse({toggle: false});
                    },
                    buttons : [{
                        label : 'Apply',
                        cssClass : 'btn-primary',
                        action : function(dialogItself) {

                            if(scope.dataSource == undefined || scope.dataSource.length <= 0){
                                $("#chartErrorMsg").show();
                                return;
                            }
                            var temp;
                            var param = '';
                            scope.pinobj.chartType = scope.chartType;
                            scope.pinobj.dataSource= scope.dataSource;
                            scope.pinobj.visualization = scope.visualization;
                            scope.pinobj.listenerFilters = [];

                            //$log.debug("commonUtils.mode : "+commonUtils.mode )
                            if(commonUtils.mode == 'pinboard' && (scope.chartType != 'Saiku')){
                                for(var a=0;a<pinboard.filterPanel.filterArray.length;a++){
                                    for(var b=0;b<scope.filterBinder.length;b++){
                                        //$log.debug(pinboard.filterPanel.filterArray[a].filterId +" == "+ scope.filterBinder[b][0])
                                        if(pinboard.filterPanel.filterArray[a].filterId == scope.filterBinder[b][0] && scope.filterBinder[b][2] == 'table-row'){
                                            //$log.debug("match found");
                                            var len =pinboard.filterPanel.filterArray[a].listenerPins.length;
                                            var newEntry = true;
                                            //$log.log(scope.pinobj.pinId);
                                            if(len==0){
                                                pinboard.filterPanel.filterArray[a].listenerPins[len] = new Object();
                                                pinboard.filterPanel.filterArray[a].listenerPins[len].pinId = scope.pinobj.pinId;
                                                pinboard.filterPanel.filterArray[a].listenerPins[len].rowIdx = parseInt(scope.pinboardrow);
                                                pinboard.filterPanel.filterArray[a].listenerPins[len].colIdx = parseInt(scope.pinboardcol);
                                            }
                                            else{
                                                for(var x=0;x<len;x++){
                                                    
                                                    if(pinboard.filterPanel.filterArray[a].listenerPins[x].pinId == scope.pinobj.pinId){
                                                        newEntry = false;
                                                        break;
                                                    }
                                                }
                                                if(newEntry){
                                                    pinboard.filterPanel.filterArray[a].listenerPins[len] = new Object();        
                                                    pinboard.filterPanel.filterArray[a].listenerPins[len].pinId = scope.pinobj.pinId;
                                                    pinboard.filterPanel.filterArray[a].listenerPins[len].rowIdx = parseInt(scope.pinboardrow);
                                                    pinboard.filterPanel.filterArray[a].listenerPins[len].colIdx = parseInt(scope.pinboardcol);
                                                }
                                            }
                                            
                                        }
                                        else if(pinboard.filterPanel.filterArray[a].filterId == scope.filterBinder[b][0] && scope.filterBinder[b][2] == 'none'){
                                            var len =pinboard.filterPanel.filterArray[a].listenerPins.length;
                                            if(len != 0){
                                                var m= 0;
                                                while(m<pinboard.filterPanel.filterArray[a].listenerPins.length){
                                                    if(pinboard.filterPanel.filterArray[a].listenerPins[m].pinId == scope.pinobj.pinId){
                                                        pinboard.filterPanel.filterArray[a].listenerPins.splice(m,1);
                                                    }
                                                    else{
                                                        m++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                for(var i=0;i<scope.filterBinder.length;i++){
                                    if(scope.filterBinder[i][2] != 'none'){
                                        scope.pinobj.listenerFilters.push([scope.filterBinder[i][0],scope.filterBinder[i][1]]);
                                    }    
                                }
                                $log.debug("listenerFilters ");$log.debug(scope.pinobj.listenerFilters);
                            }

                            if(scope.pinobj.chartType == 'Saiku'){
                                scope.pinobj.dataAccessId = "";
                                scope.pinobj.defaultParamStr = "";
                                scope.pinobj.paramStr = "";
                                commonUtils.savedFlag = false;
                                commonUtils.safeApply(scope,function(){});
                                scope.pinobj.render(scope.pinobj.defaultParamStr);
                            }

                            else if(scope.pinobj.chartType == 'CCC' || scope.pinobj.chartType == 'Table' || scope.pinobj.chartType == "Label"){
                                //$log.log("chart type : "+ scope.pinobj.chartType);
                                //var l = scope.properties.length;
                                scope.pinobj.dataAccessId = scope.dataAccessId;    
                                scope.pinobj.defaultParamStr = scope.getParamString();
                                scope.pinobj.visualization = scope.visualization;
                                scope.pinobj.chartProperties = scope.properties;                                

                                /*
                                for(var i=0;i<l;i++){
                                    if(scope.properties[i][2] == 'switch' || scope.properties[i][2] == 'combo'){
                                        temp = $('#'+scope.properties[i][0]).bootstrapSwitch('state');
                                        scope[scope.properties[i][0]] = temp;
                                    }
                                    scope.pinobj.chartProperties[i] = scope.properties[i];
                                    scope.pinobj.chartProperties[i][3] = commonUtils.parsePropertiesDataType(scope[scope.properties[i][0]],scope.pinobj.chartProperties[i][1]);
                                    //$log.debug(scope.pinobj.chartProperties[i]);
                                }
                                */
                                //$log.debug(scope.pinobj.defaultParamStr);
                                //$log.log(scope.pinobj.chartProperties);
                                scope.pinobj.paramStr = scope.getParamString();

                                if(scope.pinobj.chartType == "Label"){
                                    var param = scope.pinobj.paramStr
                                    if (param == undefined) {
                                        param = "";
                                    }
                                    
                                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + param + '&outputIndexId=1';
                                    var data = commonUtils.readJSONFile(url);   
                                    if(data.resultset.length > 1){
                                        alert("Datasource should be single valued. It has multiple value");
                                        return
                                    }
                                        
                                }   

                                $log.debug("scope.pinobj.defaultParamStr "+scope.pinobj.defaultParamStr);       
                                $log.debug("scope.pinobj.listenerFilters "+scope.pinobj.listenerFilters);
                                commonUtils.savedFlag = false;
                                commonUtils.safeApply(scope,function(){});
                                //$log.log(pinboard.filterPanel.filterArray);
                                scope.pinobj.render(scope.pinobj.defaultParamStr);
                            }

                            scope.pinobj.getJson();
                            dialogItself.close();
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : 'Close',
                        action : function(dialogItself) {
                            dialogItself.close();
                        },
                        cssClass : 'btn-default btn-lg btn-danger'
                    }]
                })
            }

            scope.setting= function (){
                BootstrapDialog.show({
                    title : 'Pin Properties',
                    message : function(dialog) {
                        var $message = $('<div></div>');
                        var pageToLoad = scope.pageToLoad;
                        var template = commonUtils.getHtmlContent(pageToLoad);
                        $message.append($compile(template)(scope));
                        $('.existingPin').hide();
                        $('.selfConfigPin').hide();
                        return $message;
                    },
                    closable : false,
                    cssClass : 'setting-dialog', 
                    draggable : true,
                    onshown : function(dialogRef){
                        scope.pinIcon = scope.pinobj.pinIcon;
                        scope.pinProTitle = scope.pinobj.title;
                        scope.pinMinimize = scope.pinobj.minimize;
                        scope.pinHeader = scope.pinobj.isHeader;
                        scope.pinColor = scope.pinobj.bootstrapStyle;
                        scope.pinHeight = scope.pinobj.height;
                        scope.pinWidth = scope.pinobj.width;

                        scope.browsePin = function(){
                            var getData = function(path){
                                $timeout(function(){
                                   //$("#pinConfigBrowseFile").val(path);
                                   scope.pinDatasource = path;
                                   commonUtils.safeApply(scope,function(){});
                                },0)
                            }
                            commonUtils.btnPinSaikuBrowse("Browse Existing Pin","pin","pinConfigBrowseFile",getData);
                        }

                        scope.pinIconChanged = function(){
                            $("#pinIconImg").attr("class",scope.pinIcon);
                        }

                        function existingPinChk()
                        {
                            if(scope.existingPin)
                            {
                                $('.existingPin').show();
                                $('.selfConfigPin').hide();
                            }
                            else
                            {
                                $('.existingPin').hide();
                                $('.selfConfigPin').show();
                            }
                        }
                        //$log.log(scope.pintype)
                        if(scope.pintype == 0 )
                            scope.existingPin = false;
                            //$('#existingPin').attr("checked",false);
                        else if(scope.pintype == undefined)
                            scope.existingPin = false;
                        else
                        {
                            scope.existingPin = true;
                            //$('#existingPin').attr("checked",true);
                            scope.pinDatasource = scope.pinobj.pinFile;
                            //$("#pinConfigBrowseFile").val(scope.pinobj.pinFile);
                        }


                        existingPinChk();
                        scope.pinTypeChanged = function(){
                            existingPinChk();
                        }
                        //$("#existingPin").change(function() {});
                        

                        //$("#pinIcon").val(scope.pinobj.pinIcon);
                        //$("#pinIconImg").attr("class", scope.pinobj.pinIcon);
                        //$("#pinProTitle").val(scope.pinobj.title);
                        //$('#pinMinimize').attr('checked', scope.pinobj.minimize);
                        //$('#pinColor').val(scope.pinobj.bootstrapStyle);                        
                        //$('#pinHeight').val(scope.pinobj.height);
                        //$('#pinWidth').val(scope.pinobj.width);
                        commonUtils.safeApply(scope,function(){});
                    },
                    buttons : [{
                        label : 'Apply',
                        cssClass : 'btn-primary',
                        action : function(dialogItself) {
                            //$log.log(scope.existingPin);

                            if(scope.existingPin)
                            {
                                scope.pintype = 1;
                                //$log.log(scope.pinobj.htmlObj)
                                var htmlObj = scope.pinobj.htmlObj;
                                scope.pinobj.pinFile = scope.pinDatasource;
                                scope.pinobj.getConfigFromFile();
                                scope.pinobj.htmlObj = htmlObj;
                                $timeout(function(){
                                    scope.pinobj.render(scope.pinobj.defaultParamStr);
                                },0)
                                
                            }
                            else
                            {
                                scope.pintype = 0;

                                scope.pinobj.pinIcon = scope.pinIcon;
                                scope.pinobj.title = scope.pinProTitle;
                                scope.pinobj.minimize = scope.pinMinimize;
                                scope.pinobj.isHeader = scope.pinHeader;
                                scope.pinobj.bootstrapStyle = scope.pinColor;
                                scope.pinobj.height = scope.pinHeight;
                                scope.pinobj.width = scope.pinWidth;

                                //scope.pinobj.pinIcon = $("#pinIcon").val();
                                //scope.pinobj.title = $("#pinProTitle").val();
                                //scope.pinobj.minimize = $('#pinMinimize').is(":checked");
                                //scope.pinobj.bootstrapStyle = $('#pinColor').val();
                                //scope.pinobj.height = $('#pinHeight').val();
                                //scope.pinobj.width = $('#pinWidth').val();
                            }

                            commonUtils.savedFlag = false;
                            commonUtils.safeApply(scope,function(){});
                            scope.pinobj.render(scope.pinobj.defaultParamStr);
                            dialogItself.close();
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : 'Close',
                        action : function(dialogItself) {
                            dialogItself.close();
                        },
                        cssClass : 'btn-lg btn-danger'
                    }]
                });
            };


            
            
            function JSONToCSVConvertor(JSONData, ReportTitle, ShowLabel,extension) {
                //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
                var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;
                $log.debug(arrData);
                var CSV = '';   
                //Set Report title in first row or line
                CSV += ReportTitle + '\r\n\n';

                //This condition will generate the Label/Header
                if (ShowLabel) {
                    var row = "";
                    //This loop will extract the label from 1st index of on array
                    for (var index in arrData[0]) {
                        //Now convert each value to string and comma-seprated
                        row += index + ',';
                    }
                    row = row.slice(0, -1);
                    //append Label row with line break
                    CSV += row + '\r\n';
                }
                //1st loop is to extract each row
                for (var i = 0; i < arrData.length; i++) {
                    var row = "";
                    //2nd loop will extract each column and convert it in string comma-seprated
                    for (var index in arrData[i]) {
                        row += '"' + arrData[i][index] + '",';
                    }
                    row.slice(0, row.length - 1);
                    //add a line break after each row
                    CSV += row + '\r\n';
                }

                if (CSV == '') {        
                    alert("Invalid data");
                    return;
                }   
                
                //Generate a file name
                var fileName = "Report_";
                //this will remove the blank-spaces from the title and replace it with an underscore
                fileName += ReportTitle.replace(/ /g,"_");   
                
                //Initialize file format you want csv or xls
                var uri = 'data:text/csv;charset=utf-8,' + encodeURI(CSV);
                
                // Now the little tricky part.
                // you can use either>> window.open(uri);
                // but this will not work in some browsers
                // or you will not get the correct file extension    
                
                //this trick will generate a temp <a /> tag
                var link = document.createElement("a");    
                link.href = uri;
                
                //set the visibility hidden so it will not effect on your web-layout
                link.style = "visibility:hidden";
                link.download = fileName + "."+extension;
                
                //this part will append the anchor tag and remove it after automatic click
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }


            function jsonToHtmlTable(jsonData,title){
                //$log.log(jsonData);
                var rows = jsonData.queryInfo.totalRows;
                var cols = jsonData.metadata.length;
                var data = jsonData.resultset;
                var table = '';
                var row = '';
                var col ='';
                for(var i=0;i<=rows;i++){
                    col = '';
                    if(i==0)
                        row = '<thead>';
                    else if(i==1)
                        row = row + '<tbody>';
                    row = row +'<tr>';
                        for(var j=0;j<cols;j++){
                            if(i==0)
                                col = col+'<th>'+jsonData.metadata[j].colName+'</th>';                               
                            else
                                col = col + '<td>'+data[i-1][j]+'</td>';
                        }
                    row = row + col + '</tr>';
                    if(i==0)
                        row = row +'</thead>';
                    else if(i==rows)
                        row = row + '</tbody>';
                }

                table = '<table id="mytable" class="table table-bordered table-condensed table-striped">'+ row +'</table>';
                $('#mydiv').append(table);

                $('#customers').tableExport({data:table,fileName:title,type :'csv',escape:'false'});    
                
            }

            scope.export = function(extension){
                
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + scope.pinobj.paramStr + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);
                //$log.log(data);
                JSONToCSVConvertor(data.resultset, scope.pinobj.title, false,extension);

                $('#exportToggle').collapse(true);
                               
            };
        
            var html = '<div class="panel">';

            if(commonUtils.editor){
                html = html+'<div class="panel-heading clearfix fontWhite {{pinobj.bootstrapStyle}}" >';
            }
                

            else if(scope.preview)
                html = html+'<div class="panel-heading clearfix fontWhite {{pinobj.bootstrapStyle}}" ng-show={{pinobj.isHeader}}>';

                html = html+'<div >'+
                            '<h3 id="pinTitle" class="panel-title pull-left" style="padding-top: 3px;padding-bottom:3px;">'+
                                '<i class="{{pinobj.pinIcon}}"></i>' +
                                '&nbsp;{{pinobj.title}}' +
                            '</h3></div>' +
                            '<div class="btn-group pull-right">' +
                                '<button id="Panel_Properties"  ng-if=editor class="btn btn-xs btn-default" ng-click="chartProperties()" title="Chart Properties"><i class="glyphicon glyphicon-edit"></i></button>' +
                                '<button id="Panel_Setting" ng-if=editor class="btn btn-xs btn-default panelSettingEvent" ng-click="setting()" title="Pin Properties"><i class="glyphicon glyphicon-cog"></i></button>' +
                                '<button id="Panel_Minimize" ng-if="pinobj.minimize"  class="btn btn-xs btn-default" data-target="#{{idd}}" data-toggle="collapse" title="Minimize"><i class="glyphicon glyphicon-minus"></i></button>' +
                                //'<button id="Panel_Export" ng-if="pinobj.minimize"  class="btn btn-xs btn-default" data-target="#{{idd}}" data-toggle="collapse" title="Export as..."><i class="glyphicon glyphicon-share-alt"></i></button>' +
                                //'<div>test</div>' +
                                '<div class="dropdown dropdown-export" ng-show= {{showExport}} ><button id="dLabel" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-xs btn-default">'+
                                    '<i class="glyphicon glyphicon-export"></i></button></button>'+
                                    '<ul class="dropdown-menu" aria-labelledby="dLabel">'+
                                    '<li ng-click="export(\'csv\')"><a href="#">.csv</a></li><li ng-click="export(\'xls\')"><a href="#">.xls</a></li>'+
                                    //'<li class="last"><a href="#">.pdf</a></li>'+
                                '</ul></div>' +
                            '</div>' +
                        '</div>'+
                        '<div id="{{idd}}" class="panel-body collapse in" style="overflow:auto;"> '+
                            '<div id="{{pinobj.htmlObj}}" style="width:{{pinobj.width}}%; height:{{pinobj.height}}px;">'+
                                '<div id="{{pinobj.htmlObj}}_chart" style="width:{{pinobj.width}}%; height:{{pinobj.height}}px;"></div>' +
                            '</div>' +
                        '</div>' +
                    '</div>' 

            element.html(html);
            $compile(element.contents())(scope);
        }
    }

}]);

angular.module('pinboard')
.controller('pinboardEditorCtr',['$scope','pinboard','Pin' ,'PinRow','filter','filterPanel','commonUtils','Messages','$log','$timeout','$compile','$window',function($scope,pinboard,Pin,PinRow,filter,filterPanel,commonUtils,Messages,$log,$timeout,$compile,$window){
    $log.debug("Pinboard Editor Controller called");
    commonUtils.setComponents();

    $scope.myecho = [[1],[2],[4],[5],[6],[7],[8],[9],[10],[21]];
    $scope.myechoval = [1,5];
    $scope.mdcols ="4 4 4";
    $scope.lgcols ="4 4 4";
    $scope.smcols ="6 6 12";
    $scope.escols ="12 12 12";
    // $scope.numCols= 1; remove because of we use uniquePinIcx counter
    $scope.mode =  commonUtils.getParameterByName("mode");
    commonUtils.editor = true;
    commonUtils.mode = "pinboard";

    var fullJson = [];
    $scope.filterType = '';
    $scope.filterTypes = [];
    $scope.pinbCtrl = {};
    $scope.pinbCtrl.filterDatasource = '';
    $scope.pinbCtrl.filterDatasources = [];
    $scope.disableAppend = false;
    $scope.disableNew = false;
    $scope.disableSave = false;
    $scope.disableSaveAs = false;
    $scope.disablePreview = false;
    $scope.disableSubmit = false;
    pinboard.init();

    var winH = $(window).height();
    var winW = $(window).width();
    var leftW = $('#leftPanel').width();
    var leftpanelW = leftW+55;

//$(".mainpage-singlepin").css("width",winW);
    $("#mainpage").css("width",winW-55);
    $("#mainpage").css("left",55);  
    $("#mainpage").css("min-height",winH);

//    $("#LayoutMaker_container").css("top",$("#topButton").height()+10);
    $scope.PinBoardFile = pinboard.PinBoardFile;

    var w = angular.element($window);
    w.bind('resize', function () {
        pinboard.resizeChart();
    });

    $scope.filterTypeChanged = function(){
        if($scope.filterType == 'datePicker'){
            $scope.dateFormat = "( YYYY-MM-DD )";
            $scope.showDataSource = false;
            //$('#filterDatasourcePanel').hide();
        }
        else if($scope.filterType == "combobox" || $scope.filterType == "multiSelect"){
            $scope.showDataSource = true;
            //$('#filterDatasourcePanel').show();
            $scope.dateFormat = "";
        }
        else{
            $scope.showDataSource = false;
            $scope.dateFormat = "";
            //$('#filterDatasourcePanel').hide();
        }
    };

    $('#setting-panel .btn').on('click', function() {
        $('#setting-panel .btn').removeClass('active');
        $(this).addClass('active');
    });
    $scope.layoutSetting = function(){
        $('#LayoutRowDefiner').show();
        $('#addFilterPanel').hide();
    }
    $scope.filterSetting = function(){
        $('#addFilterPanel').show();
        $('#LayoutRowDefiner').hide();
    }

    $scope.setCaption = function(){
        $scope.filterCaption = $scope.filterName;
    }    
    
    var init = function(){
        //available component for filtering
        fullJson = commonUtils.readJSONFile('component/filter/filterComponent.json');
        for(i=0;i<fullJson.filterComponent.length;i++)
            $scope.filterTypes.push(fullJson.filterComponent[i].componentName);
        $scope.showDataSource = false;
        //$('#filterDatasourcePanel').hide();
        //$("#filterpanel").collapse("show");
        $scope.layoutSetting();
    }
    init();

    $scope.browseFile = function(){
        $scope.pinbCtrl.filterDatasources = [];
        function getData(path){
            $timeout(function(){
                $scope.pinbCtrl.dataSource = path;
                $scope.loadDataAccessId();
             },0)
        }
        commonUtils.btnPinSaikuBrowse("Browse Data Source",'cda',"browseFile",getData);
    }

    $scope.loadDataAccessId = function(){
            var getDataAccessId = [];
            $scope.pinbCtrl.filterDatasources = [];
            uri = encodeURIComponent($scope.pinbCtrl.dataSource);
            url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listQueries?path=/'+uri ;

            var queryData = commonUtils.synchronousJsonCall(url,'GET',null);
            if(queryData == undefined || queryData.length <= 0){
                return;
            }

            for(i=0,l=queryData.resultset.length;i<l;i++)
                getDataAccessId.push(queryData.resultset[i][0]);

            $log.debug("getDataAccessId : "+getDataAccessId);

            
            for(var i = 0; i < getDataAccessId.length; i++) {
                    $scope.pinbCtrl.filterDatasources.push(getDataAccessId[i]);
                }
            $scope.pinbCtrl.filterDatasource = getDataAccessId[0];
    }

    $scope.addFilter = function(){
        $log.debug("add filter called");
        
        if($scope.filter.$valid){
            if($scope.filterType=="multiSelect" || $scope.filterType=="combobox"){
                if($scope.pinbCtrl.dataSource == undefined || $scope.pinbCtrl.dataSource.length <= 0){
                    return;
                }
            }
            else if($scope.filterType=="datePicker"){
                if(!$scope.filterVal.match(/^[0-9]{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])/)){
                    commonUtils.notification(Messages.onInvalidDateFormat,"danger");
                    $scope.filterVal = "";
                    $("#filterVal").focus();
                    return;
                }
            }
            $("#filterpanel").collapse("show");
            var len = pinboard.filterPanel.filterArray.length;

            var checkId = function(indx){
                for(a=0;a<indx;a++){
                    if($scope.filterName == pinboard.filterPanel.filterArray[a].filterName){
                        $scope.disableSubmit = true;
                        commonUtils.notification(Messages.onFilterNameAlreadyExist,"danger");
                        $timeout(function(){
                            $scope.disableSubmit = false;
                        },3000);
                        return false;                       
                    }
                }
                return true;
            }
            
            var status = checkId(len);
            if(status){
                pinboard.filterPanel.filterArray[len] = new filter();
                pinboard.filterPanel.filterArray[len].filterId  = $scope.filterName.replace(/\s+/g, '');
                pinboard.filterPanel.filterArray[len].filterType = $.trim($scope.filterType);
                pinboard.filterPanel.filterArray[len].filterName = $scope.filterName.replace(/\s+/g, '');
                pinboard.filterPanel.filterArray[len].filterCaption = $.trim($scope.filterCaption);
                //pinboard.filterPanel.filterArray[len].filterWidth = "120";

                var filterVal = $scope.filterVal.split(",");
                if($scope.filterType == 'multiSelect'){
                    pinboard.filterPanel.filterArray[len].filterVal = [];
                    pinboard.filterPanel.filterArray[len].defaultVal = [];
                    for(i=0;i<filterVal.length;i++){
                        pinboard.filterPanel.filterArray[len].filterVal.push(filterVal[i]);
                        pinboard.filterPanel.filterArray[len].defaultVal.push(filterVal[i]);    
                    }
                    pinboard.filterPanel.filterArray[len].dataSource = $.trim($scope.pinbCtrl.dataSource);
                    pinboard.filterPanel.filterArray[len].dataAccessId = $scope.pinbCtrl.filterDatasource;
                    pinboard.filterPanel.filterArray[len].datasourceArray = getDatasource($scope.pinbCtrl.dataSource,$scope.pinbCtrl.filterDatasource);
                }
                else if($scope.filterType == 'combobox'){
                    pinboard.filterPanel.filterArray[len].filterVal = filterVal[0];    
                    pinboard.filterPanel.filterArray[len].defaultVal = filterVal[0];
                    pinboard.filterPanel.filterArray[len].dataSource = $scope.pinbCtrl.dataSource;
                    pinboard.filterPanel.filterArray[len].dataAccessId = $scope.pinbCtrl.filterDatasource;
                    pinboard.filterPanel.filterArray[len].datasourceArray = getDatasource($scope.pinbCtrl.dataSource,$scope.pinbCtrl.filterDatasource);
                }
                else{
                    pinboard.filterPanel.filterArray[len].filterVal = filterVal[0];    
                    pinboard.filterPanel.filterArray[len].defaultVal = filterVal[0];
                    pinboard.filterPanel.filterArray[len].dataSource = "";
                    pinboard.filterPanel.filterArray[len].dataAccessId = "";
                    pinboard.filterPanel.filterArray[len].datasourceArray = "";
                }
                
                var filterType = window[$scope.filterType];
                var addHtmlComponent = new filterType();
                pinboard.filterPanel.filterArray[len].htmlComponent = addHtmlComponent.init(pinboard.filterPanel.filterArray[len].datasourceArray);
                pinboard.filterPanel.filterArray[len].listenerPins = [];
                pinboard.filterPanel.filterPanelShow = true; 
                $log.debug(pinboard.filterPanel.filterArray);
                
                $timeout(function(){
                   //$(".btn-hide-filteroption").hide();
                   $scope.filterName = "";
                   $scope.filterCaption = "";
                   $scope.filterType = "textbox";
                   $scope.showDataSource = false;
                   $scope.filterVal = "";
                   $scope.pinbCtrl.dataSource = "";
                   $scope.pinbCtrl.filterDatasource = "";
                   $scope.dateFormat = "";
                   $log.debug("filterPanelShow "+pinboard.filterPanel.filterPanelShow);
                   commonUtils.savedFlag = false;
                   //pinboard.filterPanel.filterArray[len].getJson();
                },0)
            }
            $("#filterName").focus();
        }
    };
 
    
    var getDatasource = function(dataSource,dataAccessId){
        uri = encodeURIComponent(dataSource);
        url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+dataAccessId ;
        //var datasourceVal = commonUtils.readJSONFile(url);
        var listParams = commonUtils.readJSONFile(url);
        var param = '';

        var  l = listParams.resultset.length;
        for(var i=0;i<l;i++){
            var cdaParam = listParams.resultset[i][0];
            if(listParams.resultset[i][1].search("Array") >= 0){
                var valArray = [];
                valArray = JSON.parse(listParams.resultset[i][2])
                for(var j=0;j<(len=valArray.length);j++)
                    param = param + '&param'+cdaParam+'='+valArray[j];
            }
            else{
                param = param + '&param'+cdaParam+'='+listParams.resultset[i][2];
            }
        }

        url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/'+uri+'&dataAccessId='+dataAccessId+param+'&outputIndexId=1';
        var datasourceVal = commonUtils.readJSONFile(url);
        var datasourceValArray = [];
        for(var a=0;a<datasourceVal.resultset.length;a++){
            datasourceValArray.push(datasourceVal.resultset[a][0]);
        }
        return datasourceValArray;
    }   

    if($scope.mode == "edit")
    {
        $scope.showEditorOption = false ;
        pinboard.PinBoardFile = commonUtils.getParameterByName("solutionFile");
        $('#filterpanel').collapse('show');
        pinboard.getConfigFromFile();
        $scope.PinBoardFile = pinboard.PinBoardFile;
        commonUtils.savedFlag = true;
        commonUtils.isNull = false;
        commonUtils.savedFileFlag = true;
    }
    else
    {
        commonUtils.savedFlag = false;
        commonUtils.savedFileFlag = false;
        $scope.PinBoardFile = pinboard.PinBoardFile;
        $scope.showEditorOption = true;
    }

    function removeAllRowsPinboard()
    {
        pinboard.removeAll();
        commonUtils.safeApply($scope,function(){});
        commonUtils.isNull = true;
    }

    function savePinboard()
    {
        if(!pinboard.saveConfigToFile())
        {
            commonUtils.notification(Messages.onPinBoardSaveUserRightError,"danger");
            commonUtils.savedFileFlag=false;
            commonUtils.savedFlag = false;
            return false;
        }
        else
        {
            commonUtils.savedFileFlag=true;
            commonUtils.savedFlag = true;
            return true;
        }
        
    }

    validateAndParseLayoutInput = function (mdcols,escols,smcols,lgcols,isSimpleLayout)
    {
        var result =[]; //0=valid/invalid 1=message , medium screen,extra small, small screen and large screen array

        if(isSimpleLayout)
        {
            mdcols=mdcols.trim().replace( /\s\s+/g, ' ' );

            if( mdcols.length < 1 )
            {
                $log.debug(Messages.onInvalidMediumScreenInputError);
                result[0]=false;
                result[1]=Messages.onInvalidMediumScreenInputError;
                $("#mdcols").focus();
                return result;
            }

            
            result[2]=mdcols.split(" ");
            var pinSizeValidate =  validatePinSize(result[2]);
            if(pinSizeValidate){
                result[0]=true;
                result[1]="";    
            }
            else{
                result[0]=false;
                result[1]=Messages.onInvalidPinSizeInput;
                $("#mdcols").focus();
                return result;       
            }
            
            result[3]=[];
            result[4]=[];
            result[5]=[];
            return result;
        }
        else
        {
            escols=escols.trim().replace( /\s\s+/g, ' ' );
            smcols=smcols.trim().replace( /\s\s+/g, ' ' );
            mdcols=mdcols.trim().replace( /\s\s+/g, ' ' );
            lgcols=lgcols.trim().replace( /\s\s+/g, ' ' );

            /* Validation -Start*/
            if ( mdcols.length < 1 )
            {
                $log.debug(Messages.onInvalidMediumScreenInputError);
                result[0]=false;
                result[1]=Messages.onInvalidMediumScreenInputError;
                $("#mdcols").focus();
                return result;
            }
            else if(lgcols.length < 1)
            {
                $log.debug(Messages.onInvalidLargeScreenInputError);
                result[0]=false;
                result[1]=Messages.onInvalidLargeScreenInputError;
                $("#lgcols").focus();
                return result;

            }
            else if (smcols.length < 1 )
            {
                $log.debug(Messages.onInvalidSmallScreenInputError);
                result[0]=false;
                result[1]=Messages.onInvalidSmallScreenInputError;
                $("#smcols").focus();
                return result;

            }
            else if(escols.length <1 )
            {
                $log.debug(Messages.onInvalidExtraSmallScreenInputError);
                result[0]=false;
                result[1]=Messages.onInvalidExtraSmallScreenInputError;
                $("#escols").focus();
                return result;
            }

            
            var mdcolsArr=mdcols.split(" ");
            var mdcolsValid = validatePinSize(mdcolsArr);
            var lgcolsArr=lgcols.split(" ");
            var lgcolsValid = validatePinSize(lgcolsArr);
            var smcolsArr=smcols.split(" ");
            var smcolsValid = validatePinSize(smcolsArr);
            var escolsArr=escols.split(" ");
            var escolsValid = validatePinSize(escolsArr);
            
            if(!escolsValid || !smcolsValid || !mdcolsValid || !lgcolsValid){
                result[0]=false;
                result[1]=Messages.onInvalidPinSizeInput;
                if(!mdcolsValid)
                    $("#mdcols").focus();
                else if(!lgcolsValid)
                    $("#lgcols").focus();
                else if(!smcolsValid)
                    $("#smcols").focus();
                else if(!escolsValid)
                    $("#escols").focus();
                return result;  
            }
            if(!(escolsArr.length == smcolsArr.length && mdcolsArr.length == smcolsArr.length && lgcolsArr.length == smcolsArr.length))
            {
                $log.debug(Messages.onInvalidNumberOfColumnInputError);
                result[0]=false;
                result[1]=Messages.onInvalidNumberOfColumnInputError;
                return result;
            }
            result[0]=true;
            result[1]="";
            result[2]=mdcols.split(" ");
            result[3]=escols.split(" ");
            result[4]=smcols.split(" ");
            result[5]=lgcols.split(" ");
            return result;
        }
    }

    validatePinSize = function(pinSizeArray){
        for(var i=0;i<pinSizeArray.length;i++){
            if(isNaN(pinSizeArray[i])){
                return false;
            }
            else if(pinSizeArray[i] > 12 || pinSizeArray[i] < 1){
                return false;
            }
        }
        return true;
    }

    pinrowInsert = function (mdcols,escols,smcols,lgcols,isSimpleLayout)
    {
        var pinrow = new PinRow();
        pinrow.mdLayout = mdcols;
        pinrow.cols =  pinrow.mdLayout.length;

        if(!isSimpleLayout)
        {
            pinrow.esLayout = escols;
            pinrow.smLayout = smcols;
            pinrow.lgLayout = lgcols;
            pinrow.isSimpleLayout = false;
        }
        else
        {
            pinrow.esLayout = [];
            pinrow.smLayout = [];
            pinrow.lgLayout = [];
            pinrow.isSimpleLayout = true;
        }

        for(var i=0;i< pinrow.mdLayout.length;i++)
        {
            pinrow.pins[i] = new Pin();
            pinrow.pinType[i] = 0; /* 0 - self 1 - existing*/
            pinrow.pins[i].init();

            pinrow.pins[i].pinId = "Pin"+pinboard.uniquePinIdCnt;
            pinrow.pins[i].cIdx = i;
            pinrow.pins[i].title = "Pin "  + pinboard.uniquePinIdCnt ;
            pinboard.uniquePinIdCnt++;
            //pinrow.pins[i].htmlObj = "panelAreaC_" + (insertRowIndex) +"_" + i  ;
            pinrow.pins[i].htmlObj = pinrow.pins[i].pinId  ; // chart genrate unique ID
        }
        return pinrow;
    }

    $scope.appendClick = function ()
    {
        
        var result=validateAndParseLayoutInput($scope.mdcols,$scope.escols,$scope.smcols,$scope.lgcols,!$scope.advanceSettingChk);

        if(!result[0])
        {
            $scope.disableAppend = true;
            commonUtils.notification(result[1],"danger");
            $timeout(function(){
                $scope.disableAppend = false;
            },3000)
            return;
        }
        else
        {
            var pinrow = pinrowInsert(result[2],result[3],result[4],result[5],!$scope.advanceSettingChk);
            pinboard.addRow(pinrow);
            
            $log.debug(pinboard.getJson());
            commonUtils.savedFlag = false;
            commonUtils.notification(Messages.onPinBoardInserRowSuccess);

            $timeout(function(){
                $('.mytooltip').tooltip();
            },0)
            //$scope.$apply();
        }
        commonUtils.isNull = false;
    }

    $scope.clearClick = function ()
    {
        BootstrapDialog.confirm(Messages.onRemoveRowConfirm, function(result){
            if(result) {
                removeAllRowsPinboard();
                commonUtils.notification(Messages.onPinBoardRemoveRowSuccess);
                commonUtils.savedFlag =false;
            }
        });
    }

    $scope.newPinboardClick = function ()
    {
        if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            commonUtils.BootstrapConfirm(Messages.onUnsavePinBobardConfirm,function(r){
                if (r)
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(savePinboard())
                            createNewPinBoard();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            pinboard.PinBoardFile = path;
                            if(savePinboard())
                                createNewPinBoard();
                        }
                        function onCancel()
                        {
                            //createNewPinBoard();
                        }
                        commonUtils.saveDialogBox("Save Pin Board","pinb",onSave,onCancel);
                    }
                }
                else
                {
                    createNewPinBoard();
                }
            });
        }
        else
        {
            createNewPinBoard();
        }
        function createNewPinBoard()
        {
            pinboard.init();
            $scope.PinBoardFile = pinboard.PinBoardFile;
            removeAllRowsPinboard();
            commonUtils.isNull = true;
            commonUtils.savedFileFlag =false;
            commonUtils.savedFlag =false;
            $scope.disableNew = true;
            commonUtils.notification(Messages.onNewPinboardNotification);
            $timeout(function(){
                $scope.disableNew = false;
            },4000);
            $log.debug("New Pinboard Created");
        }
    }

    $scope.openPinboardClick = function ()
    {
        if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            commonUtils.BootstrapConfirm(Messages.onUnsavePinBobardConfirm,function(r){
                if (r)
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(savePinboard())
                            openPinBoard();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            pinboard.PinBoardFile = path;
                            $scope.PinBoardFile = pinboard.PinBoardFile;
                            commonUtils.safeApply($scope,function(){});
                            if(savePinboard())
                                openPinBoard();
                        }
                        function onCancel()
                        {
                            openPinBoard();
                        }
                        commonUtils.saveDialogBox("Save Exiting Pin Board","pinb",onSave,onCancel);
                    }
                }
                else
                {
                    openPinBoard();
                }
            });
        }
        else
        {
            openPinBoard();
        }

        function openPinBoard()
        {
            function onOpen(path)
            {
                pinboard.PinBoardFile = path;
                $scope.PinBoardFile = pinboard.PinBoardFile;
                pinboard.getConfigFromFile();
                commonUtils.safeApply($scope,function(){});
                commonUtils.isNull = false;
                commonUtils.savedFlag =true;
                commonUtils.savedFileFlag=true;
                commonUtils.notification(Messages.onOpenPinboardNotification);
            }
            function onCancel()
            {
                $log.debug("Open file option canceled");
            }
            commonUtils.openDialogBox("Open Pin Board","pinb",onOpen,onCancel);
        }
    }
    $scope.savePinboardClick = function ()
    {    
        if(commonUtils.isNull){
            $scope.disableSave = true;
            commonUtils.notification(Messages.onNullPinboardNotification,"danger");
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }
        else if(!commonUtils.savedFlag)
        {
            if(commonUtils.savedFileFlag)
            {
                if(savePinboard())
                    commonUtils.notification(Messages.onSavePinboardNotification);
            }
            else
            {
                function onSave(path)
                {
                    pinboard.PinBoardFile = path;
                    $scope.PinBoardFile = pinboard.PinBoardFile;
                    commonUtils.safeApply($scope,function(){});
                    if(savePinboard())
                        commonUtils.notification(Messages.onSavePinboardNotification);
                }
                function onCancel()
                {
                    $log.debug("Save file option canceled");
                }
                commonUtils.saveDialogBox("Save Pin Board","pinb",onSave,onCancel);
            }
        }
        else
        {
            commonUtils.notification(Messages.onAlreadySavedPinboardNotification);
        }
    }

    $scope.saveAsPinboardClick = function ()
    {   
        
        if(commonUtils.isNull){
            $scope.disableSaveAs = true;
            commonUtils.notification(Messages.onNullPinboardNotification,"danger");
            $timeout(function(){
                $scope.disableSaveAs = false;
            },4000)
        }
        else{
            function onSave(path)
            {
                pinboard.PinBoardFile = path;
                $scope.PinBoardFile = pinboard.PinBoardFile;
                commonUtils.safeApply($scope,function(){});
                if(savePinboard())
                    commonUtils.notification(Messages.onSaveAsPinboardNotification);

            }
            function onCancel()
            {
                $log.debug("Save file option canceled");
            }
            commonUtils.saveDialogBox("Save As Pin Board","pinb",onSave,onCancel);    
        }
        
    }

    $scope.previewPinboardClick = function ()
    {
        
        if(!commonUtils.savedFlag){
            $scope.disablePreview = true;
            commonUtils.notification(Messages.onPreviewUnsavePinBoardError,"danger");
            $timeout(function(){
                $scope.disablePreview = false;
            },4000)
        }
        else
        {
            $log.debug("Pinboard preview selected");
            var win = window.open('PinBoardIndex.html?mode=generatedContent&solutionFile='+pinboard.PinBoardFile, '_blank');
            if(win){
                win.focus();
            }
            else{
                commonUtils.notification(Messanges.OnPopWindowError,"danger");

            }
        }
    }
    $scope.removeRow  = function (removeRow)
    {
        $log.debug("Remove Row : " + removeRow);
        commonUtils.BootstrapConfirm(Messages.onRemoveRowConfirm, function(result){
            if(result) {
                removeRow= parseInt(removeRow);
                var nullPinboard = pinboard.removeAt(removeRow);
                commonUtils.notification(Messages.onPinBoardRemoveRowSuccess);
                if(nullPinboard)
                    commonUtils.isNull = true;
                else
                    commonUtils.isNull = false;
                commonUtils.safeApply($scope,function(){});
                commonUtils.savedFlag =false; //to-do set flag to root or commonutil
            }
        });
    }

    $scope.insertRowAfter = function (insertIndex)
    {
        var result=validateAndParseLayoutInput($scope.mdcols,$scope.escols,$scope.smcols,$scope.lgcols,!$scope.advanceSettingChk);
        if(!result[0])
        {
            commonUtils.notification(result[1],"danger");
            return;
        }
        else
        {
            insertIndex= parseInt(insertIndex);
            var pinrow = pinrowInsert(result[2],result[3],result[4],result[5],!$scope.advanceSettingChk);
            pinboard.addRowAfter(insertIndex,pinrow)
            $log.debug(pinboard.getJson());
            commonUtils.savedFlag = false;
            commonUtils.safeApply($scope,function(){});
            commonUtils.notification(Messages.onPinBoardInserRowSuccess);
        }
    }

    $scope.insertRowBefore = function (insertIndex)
    {
        var result=validateAndParseLayoutInput($scope.mdcols,$scope.escols,$scope.smcols,$scope.lgcols,!$scope.advanceSettingChk);
        if(!result[0])
        {
            commonUtils.notification(result[1],"danger");
            return;
        }
        else
        {
            var pinrow = pinrowInsert(result[2],result[3],result[4],result[5],!$scope.advanceSettingChk);
            insertIndex= parseInt(insertIndex);
            pinboard.addRowBefore(insertIndex,pinrow)
            commonUtils.savedFlag = false;
            commonUtils.safeApply($scope,function(){});
            commonUtils.notification(Messages.onPinBoardInserRowSuccess);
        }
    }

    function openSidepage() {
        $('#mainpage').animate({
          left: leftpanelW
        }, 400, 'easeOutBack');
        $("#mainpage").removeClass("mainpageW"); 
        $("#mainpage").css("width",winW-leftpanelW);
        $(".DisplayGrid").css("width",winW-leftpanelW);
        $(".main-navigation a#clickme").addClass("panel-setting-active");
    }

    function closeSidepage(){
        $("#clickme").removeClass("open");
        $('#mainpage').animate({
        left: '0px'
        }, 400, 'easeOutQuint');  
        $("#mainpage").addClass("mainpageW");
        $("#mainpage").css("width",winW-55);
        $(".DisplayGrid").css("width",winW-55);    
        $(".main-navigation a#clickme").removeClass("panel-setting-active");
    }

    $scope.setting = function(){
        
        //var hrefval = $(this).attr("href");
        
        var distance = $('#mainpage').css('left');
        //$log.log(distance); 
        if(distance == "auto" || distance == "0px" || distance == "55px" ) {
            $(this).addClass("open");
                openSidepage();
        }
        else
            closeSidepage();    

        pinboard.resizeChart();
        commonUtils.safeApply($scope,function(){});
        
    
    }
    /*
    $scope.xmlEdit = "";
    $scope.openXmlEdit = function(){
        var resScript="";
        var editor;
        var data=BootstrapDialog.show({
            title: "SQL Input",
            message: function(dialog) {
                var $message = $('<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                '<span class="sr-only">Error:</span>'+
                ' ' +"Please input valid script." +'</div>'+
                '<textarea id="codedata" name="codedata">' + $scope.xmlEdit + ' </textarea>');
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {   
                $log.log($scope.xmlEdit);
                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: "text/x-sql"
                });

            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        $scope.xmlEdit = editor.getValue();
                        commonUtils.safeApply($scope,function(){});
                        dialogItself.close();
                        $log.log(editor.getValue());
                        //onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        //onCancel();
                    },
                    cssClass: 'btn-danger'
                }]
        });
    }

    $scope.saveXml = function(){
        var xml = $scope.xmlEdit;
        var param = {
            "file"  :  'public/CDE demo/demoCda.cda' ,
            "content"  : xml
        };
        $log.log(xml);
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);
    }

    $scope.getXml = function(){
        var xml = (commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path=public/CDE demo/demoCda.cda',"GET",null).result);
        //$log.log(xml)
        //$scope.xmlEdit = $.parseXML(xml);

        var xml = $.parseXML(xml),
        $xml = $( xml ),
        $test = $xml.find('test');
        $scope.xmlEdit = $test.text();
        $log.log($xml);
        $log.log($test);
    }
    */

/*
    $scope.getDb = function(){
        var param = {
            'ts' : '1437031684490'
        }
         var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/data-access/api/connection/list',"GET",param);
         //$log.log(jsonData);
         
         $log.log(jsonData.databaseConnections.length)
         for(i=0;i<jsonData.databaseConnections.length;i++){
            $log.log(jsonData.databaseConnections[i].databaseName);
         }
    }
  */  
}]);

angular.module('pinboard')
.controller('pinboardViewerCtr',['$scope','pinboard','Pin' ,'PinRow','filter','filterPanel','commonUtils','Messages','$window','$log',function($scope,pinboard,Pin,PinRow,filter,filterPanel,commonUtils,Messages,$window,$log){
    $log.debug("This is Pinboard View Controller");
    commonUtils.mode = "pinboard";
    var mode=commonUtils.getParameterByName("mode").split("?")[0] ;
    if(mode == "editor")
        $window.location.href ="../../../content/SelfServiceBI-res/SelfServiceBI/LayoutDesign.html?mode=edit&solutionFile=" +  commonUtils.getParameterByName("solutionFile");

    else
    {
        pinboard.PinBoardFile = commonUtils.getParameterByName("solutionFile");
        //$log.log(pinboard.PinBoardFile);
        commonUtils.editor=false;
        pinboard.getConfigFromFile();

        var w = angular.element($window);
        w.bind('resize', function () {
            pinboard.resizeChart();
        });
        $("#filterpanel").collapse("show");      
    }
     //$('.dropdown-toggle').dropdown()
}]);

angular.module('pinboard')
.controller('pinEditorCtr',['$scope','Pin','commonUtils','Messages','$log','$window','$timeout',function($scope,Pin,commonUtils,Messages,$log,$window,$timeout){
    $log.debug("This is Pin Editor Controller");
    commonUtils.mode = "pin";
    commonUtils.savedFlag = false;
    commonUtils.savedFileFlag = false;
    commonUtils.editor = true;
    $scope.pin  = new Pin();
    $scope.pintype = undefined;
    $scope.mode =  commonUtils.getParameterByName("mode");
    commonUtils.setComponents();
    $log.debug($scope.pin.getJson());
    var w = angular.element($window);
    w.bind('resize', function () {
        $scope.pin.render($scope.pin.defaultParamStr);
    });
    $scope.disableNew = false;
    $scope.disableSave = false;
    $scope.disableSaveAs = false;
    $scope.disablePreview = false;

    $scope.pinFile = $scope.pin.pinFile;

    if($scope.mode  == "edit")
    {
        $scope.showEditorOption = false ;
        $scope.pin.pinFile = commonUtils.getParameterByName("solutionFile");
        $scope.pin.getConfigFromFile();
        $scope.pinFile = $scope.pin.pinFile;
        //$scope.pin.render($scope.pin.defaultParamStr);
        commonUtils.savedFlag = true;
        commonUtils.savedFileFlag = true;
    }
    else
    {
        $scope.showEditorOption = true;
        $scope.pinFile = $scope.pin.pinFile;
        $log.debug($scope.pin.pinFile);
        commonUtils.savedFlag = false;
        commonUtils.savedFileFlag = false;
    }


    function savePin()
    {
        if(!$scope.pin.saveConfigToFile())
        {
            commonUtils.notification(Messages.onPinSaveUserRightError,"danger");
            commonUtils.savedFileFlag=false;
            commonUtils.savedFlag = false;
            return false;
        }
        else
        {
            commonUtils.savedFileFlag=true;
            commonUtils.savedFlag = true;
            return true;
        }
    };

    $scope.newPinClick = function ()
    {
        var isDefault = $scope.pin.isDefault();
        if(!isDefault && !commonUtils.savedFlag)
        {
            commonUtils.BootstrapConfirm(Messages.onUnsavePinConfirm,function(r){
                if (r)  
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(savePin())
                            createNewPin();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            $scope.pin.pinFile = path;
                            commonUtils.safeApply($scope,function(){});
                            if(savePin())
                                createNewPin();
                        }
                        function onCancel()
                        {
                            //createNewPin();
                        }
                        commonUtils.saveDialogBox("Save Pin","pin",onSave,onCancel);
                    }
                }
                else
                {
                    createNewPin();
                }
            });
        }
        else
        {
            createNewPin();
        }
        function createNewPin()
        {
            $log.debug("new pin click");
            $("#demoPin").html("");
            $scope.pin = new Pin();
            $scope.pin.init();
            $scope.pinFile = $scope.pin.pinFile;
            $scope.pin.htmlObj = $scope.pin.htmlObj;
            //$scope.pin.getConfigFromFile();
            commonUtils.safeApply($scope,function(){});
            $scope.pin.render($scope.pin.defaultParamStr);
            commonUtils.savedFileFlag =false;
            commonUtils.savedFlag =false;
            $scope.disableNew = true;
            commonUtils.notification(Messages.onNewPinNotification);
            $timeout(function(){
                $scope.disableNew = false;
            },4000);
            $log.debug("New Pin created");

        }
    };

    $scope.openPinClick = function ()
    {
        var isDefault = $scope.pin.isDefault();
        if(!isDefault && !commonUtils.savedFlag)
        {
            commonUtils.BootstrapConfirm(Messages.onUnsavePinConfirm,function(r){
                if (r)
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(savePin())
                            openPin();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            $scope.pin.pinFile = path;
                            $scope.pinFile = $scope.pin.pinFile;
                            commonUtils.safeApply($scope,function(){});
                            if(savePin())
                                openPin();
                        }
                        function onCancel()
                        {
                            openPin();
                        }
                        commonUtils.saveDialogBox("Save Exiting Pin","pin",onSave,onCancel);
                    }
                }
                else
                {
                    openPin();
                }
            });
        }
        else
        {
            openPin();
        }

        function openPin()
        {
            function onOpen(path)
            {
                $scope.pin = new Pin();
                $scope.pin.init();
                $scope.pin.pinFile = path;
                $scope.pinFile = $scope.pin.pinFile;
                $scope.pin.getConfigFromFile();
                commonUtils.safeApply($scope,function(){});
                $scope.pin.render($scope.pin.defaultParamStr);
                commonUtils.savedFlag =true;
                commonUtils.savedFileFlag=true;
                commonUtils.notification(Messages.onOpenPinNotification);
            }
            function onCancel()
            {
                $log.debug("Open file option canceled");
            }
            commonUtils.openDialogBox("Open Pin","pin",onOpen,onCancel);
        }
    };
    $scope.savePinClick = function ()
    {
        if($scope.pin.isDefault()){
            $scope.disableSave = true;
            commonUtils.notification(Messages.onDefaultPinNotification,"danger");   
            $timeout(function(){
                $scope.disableSave = false;
            },4000)
        }
        else if(!commonUtils.savedFlag)
        {
            if(commonUtils.savedFileFlag)
            {
                if(savePin())
                    commonUtils.notification(Messages.onSavePinNotification);
            }
            else
            {
                function onSave(path)
                {
                    $scope.pin.pinFile = path;
                    $scope.pinFile = $scope.pin.pinFile;
                    commonUtils.safeApply($scope,function(){});
                    if(savePin())
                        commonUtils.notification(Messages.onSavePinNotification);
                }
                function onCancel()
                {
                    $log.debug("Save file option canceled");
                }
                commonUtils.saveDialogBox("Save Pin","pin",onSave,onCancel);
            }
        }
        else
        {
            commonUtils.notification(Messages.onAlreadySavedPinNotification);
        }
    };

    $scope.saveAsPinClick = function ()
    {   
        if($scope.pin.isDefault()){
            $scope.disableSaveAs = true;
            commonUtils.notification(Messages.onDefaultPinNotification,"danger");   
            $timeout(function(){
                $scope.disableSaveAs = false;
            },4000)
        }
        else{
            function onSave(path)
            {
                $scope.pin.pinFile = path;
                $scope.pinFile = $scope.pin.pinFile;
                commonUtils.safeApply($scope,function(){});
                if(savePin())
                    commonUtils.notification(Messages.onSaveAsPinNotification);
            }
            function onCancel(){}
            commonUtils.saveDialogBox("Save As Pin","pin",onSave,onCancel);    
        }
        
    };

    $scope.previewPinClick = function ()
    {
        if(!commonUtils.savedFlag){
            $scope.disablePreview = true;
            commonUtils.notification(Messages.onPreviewUnsavePinError,"danger");
            $timeout(function(){
                $scope.disablePreview = false;
            },4000)
        }
        else
        {
            $log.debug("Pin preview called");
            var win = window.open('PinIndex.html?mode=generatedContent&solutionFile='+$scope.pin.pinFile, '_blank');
            if(win){
                win.focus();
            }else{
                commonUtils.notification(Messanges.OnPopWindowError,"danger");
            }
        }
    };

}]);

angular.module('pinboard')
.controller('pinViewerCtr',['$scope','Pin' ,'commonUtils','Messages','$window','$log',function($scope,Pin,commonUtils,Messages,$window,$log){
    $log.debug("This is Pin View Controller");
    commonUtils.mode = "pin";
    $scope.pintype = undefined;
    var mode=commonUtils.getParameterByName("mode").split("?")[0] ;

    if(mode == "editor")
        $window.location.href ="../../../content/SelfServiceBI-res/SelfServiceBI/PinLayoutDesign.html?mode=edit&solutionFile=" +  commonUtils.getParameterByName("solutionFile");
    else
    {
        $scope.pin  = new Pin();
        $scope.pin.pinFile = commonUtils.getParameterByName("solutionFile");
        $scope.pin.getConfigFromFile();
        //$scope.pin.render($scope.pin.defaultParamStr)
        commonUtils.editor = false;
        //commonUtils.preview = true;
        var w = angular.element($window);
        w.bind('resize', function () {
            $scope.pin.render(this.defaultParamStr);
        });
    }
}]);