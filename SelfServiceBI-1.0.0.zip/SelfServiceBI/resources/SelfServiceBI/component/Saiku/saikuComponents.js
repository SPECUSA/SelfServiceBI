function Saikubar(){};
Saikubar.prototype = new SSBBaseComponent();
Saikubar.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikubar : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'bar',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikubar : preExecution");
    },
    postExecution: function () {
        console.log("Saikubar : postExecution");
    }
}

function SaikustackedBar(){};
SaikustackedBar.prototype = new SSBBaseComponent();
SaikustackedBar.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("SaikustackedBar : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("SaikustackedBar : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'stackedBar',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("SaikustackedBar : preExecution");
    },
    postExecution: function () {
        console.log("SaikustackedBar : postExecution");
    }
}

function SaikustackedBar100(){};
SaikustackedBar100.prototype = new SSBBaseComponent();
SaikustackedBar100.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("SaikustackedBar100 : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("SaikustackedBar100 : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'stackedBar100',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("SaikustackedBar100 : preExecution");
    },
    postExecution: function () {
        console.log("SaikustackedBar100 : postExecution");
    }
}

function Saikumultiplebar(){};
Saikumultiplebar.prototype = new SSBBaseComponent();
Saikumultiplebar.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikumultiplebar : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikumultiplebar : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'multiplebar',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikumultiplebar : preExecution");
    },
    postExecution: function () {
        console.log("Saikumultiplebar : postExecution");
    }
}

function Saikuline(){};
Saikuline.prototype = new SSBBaseComponent();
Saikuline.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikuline : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikuline : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'line',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikuline : preExecution");
    },
    postExecution: function () {
        console.log("Saikuline : postExecution");
    }
}

function Saikuarea(){};
Saikuarea.prototype = new SSBBaseComponent();
Saikuarea.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikuarea : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikuarea : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'area',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikuarea : preExecution");
    },
    postExecution: function () {
        console.log("Saikuarea : postExecution");
    }
}

function Saikupie(){};
Saikupie.prototype = new SSBBaseComponent();
Saikupie.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikupie : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikupie : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'pie',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikupie : preExecution");
    },
    postExecution: function () {
        console.log("Saikupie : postExecution");
    }
}

function Saikutreemap(){};
Saikutreemap.prototype = new SSBBaseComponent();
Saikutreemap.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikutreemap : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikutreemap : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'treemap',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikutreemap : preExecution");
        
    },
    postExecution: function () {
        console.log("Saikutreemap : postExecution");
    }
}

function Saikusunburst(){};
Saikusunburst.prototype = new SSBBaseComponent();
Saikusunburst.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikusunburst : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikusunburst : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'sunburst',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikusunburst : preExecution");
    },
    postExecution: function () {
        console.log("Saikusunburst : postExecution");
    }
}

function Saikudot(){};
Saikudot.prototype = new SSBBaseComponent();
Saikudot.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikudot : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikudot : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'dot',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }

    },
    preExecution: function () {
        console.log("Saikudot : preExecution");
    },
    postExecution: function () {
        console.log("Saikudot : postExecution");
    }
}

function Saikuwaterfall(){};
Saikuwaterfall.prototype = new SSBBaseComponent();
Saikuwaterfall.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("Saikuwaterfall : execute");
    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("Saikuwaterfall : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'waterfall',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("Saikuwaterfall : preExecution");
    },
    postExecution: function () {
        console.log("Saikuwaterfall : postExecution");
    }
}

function SaikuMetricDotChart(){};
SaikuMetricDotChart.prototype = new SSBBaseComponent();
SaikuMetricDotChart.prototype = {
    name : "",
    dataSource : "",
    htmlObj : "",
    execute : function(){
        console.log("SaikuMetricDotChart : execute");

    },
    init: function () {
        this.preExecution();
        this.render();
        this.postExecution();
    },
    render: function () {
        console.log("SaikuMetricDotChart : render");
        $("#"+this.htmlObj).html("");
        var saikuClientRenderer =  new SaikuClient(
            {
                server: "/pentaho/plugin/saiku",
                path: "/cde-component"
            });
        //console.log(dataSource);
        if(this.dataSource != undefined && this.dataSource.length > 0)
        {
                saikuClientRenderer.execute({
                    file:this.dataSource,
                    htmlObject: "#"+this.htmlObj,
                    render: "chart",
                    mode:'MetricDotChart',
                    zoom: true
                });
        }
        else
        {
            $("#"+this.htmlObj).html("<div style=\"text-align: center;\">"+"No data source selected."+"</div>");
            //$log.debug("else  error");
        }
    },
    preExecution: function () {
        console.log("SaikuMetricDotChart : preExecution");
    },
    postExecution: function () {
        console.log("SaikuMetricDotChart : postExecution");
    }
}