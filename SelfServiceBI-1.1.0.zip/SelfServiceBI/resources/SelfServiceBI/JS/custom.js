$(document).ready(function(){
	$('[data-toggle="tooltip"]').tooltip();
	//$('[data-toggle="tooltip"]').tooltip({trigger: 'manual'}).tooltip('show');
});


/*$(document).ready(function(){
	$(".btn-filterComponent").hide();
	$(".btn-show-filteroption").on("click", function(e){
		$(".btn-filterComponent").show();
	});
});

var winH = $(window).height();
var winW = $(window).width();
var leftW = $('#leftPanel').width();
var leftpanelW = leftW+55;

$(".mainpage-singlepin").css("width",winW);
$("#mainpage").css("width",winW-55);
$("#mainpage").css("left",55);	
$("#mainpage").css("min-height",winH);
$(".DisplayGrid").css("width",winW-leftpanelW);
$(".DisplayGrid").css("left",leftpanelW);

$("#clickme").prependTo(".main-navigation");
*/

$(document).ready(function(){
	$winH=$(window).height();
	$winW=$(window).width();  
	$leftW=$('#leftPanel').width();
	$leftpanelW=$leftW+55;
	//$(".main-navigation").css("height",$winW+70);
	//$("#leftPanel").css("height",$winW+70);
	//$("#mainpage").css("min-height",$winW+70);
/*
	$(".mainpage-singlepin").css("width",$winW);
	$("#mainpage").css("width",$winW-55);
	$("#mainpage").css("left",55);	
	$("#mainpage").css("min-height",$winH);
*/	
	$(".DisplayGrid").css("width",$winW-$leftpanelW);
	$(".DisplayGrid").css("left",$leftpanelW);
	//$("#clickme").prependTo(".main-navigation");
/*	
	$("#clickme").prependTo(".main-navigation");
	$("#clickme").on("click", function(e){
		e.preventDefault();
			var hrefval = $(this).attr("href");
			if(hrefval == "#leftPanel") {
				var distance = $('#mainpage').css('left');
				//alert($w1);
				if(distance == "auto" || distance == "0px") {
					$(this).addClass("open");
						openSidepage();
					} else {
						closeSidepage();
					}
			}
	}); // end click event handler
  
 
//  $("#closebtn").on("click", function(e){
//    e.preventDefault();
//    closeSidepage();
//  }); 

  function openSidepage() {
    $('#mainpage').animate({
      left: $leftpanelW
    }, 400, 'easeOutBack');
	$("#mainpage").removeClass("mainpageW"); 
	$("#mainpage").css("width",$winW-$leftpanelW);
	$(".DisplayGrid").css("width",$winW-$leftpanelW);
	$(".main-navigation a#clickme").addClass("panel-setting-active");
  }
  
  function closeSidepage(){
    $("#clickme").removeClass("open");
    $('#mainpage').animate({
      left: '0px'
    }, 400, 'easeOutQuint');  
	$("#mainpage").addClass("mainpageW");
	$("#mainpage").css("width",$winW-55);
	$(".DisplayGrid").css("width",$winW-55);	
	$(".main-navigation a#clickme").removeClass("panel-setting-active");
  }
  */
}); 


$(window).scroll(function(){
	if($(window).scrollTop() > 80){
		  $('.pinboard-header').addClass("pinboard-header-border");
	} else {
		  $('.pinboard-header').removeClass("pinboard-header-border");
	}    
});


$(document).ready(function(){    
    var $active = $('#datasourceMenu .panel-collapse.in').prev().addClass('active');
    $active.find('a').prepend('<i class="glyphicon glyphicon-minus"></i>');
    $('#datasourceMenu .panel-heading').not($active).find('a').prepend('<i class="glyphicon glyphicon-plus"></i>');
    $('#datasourceMenu').on('show.bs.collapse', function (e) {
        $('#datasourceMenu .panel-heading.active').removeClass('active').find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
        $(e.target).prev().addClass('active').find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
    });
	$('#datasourceMenu').on('hide.bs.collapse', function (e){
		$(e.target).prev().removeClass('active').find('.glyphicon').removeClass('glyphicon-minus').addClass('glyphicon-plus');
	});	
});
/*
$(document).ready(function(){    
    
    $('#datasourceContent').on('show.bs.collapse', function (e) {
        $('#datasourceContent .panel-heading.active').removeClass('active').find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
        $(e.target).prev().addClass('active').find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
    });
	$('#datasourceContent').on('hide.bs.collapse', function (e){
		$(e.target).prev().removeClass('active').find('.glyphicon').removeClass('glyphicon-minus').addClass('glyphicon-plus');
	});	

});


$(document).ready(function(){  
	$(".row-datasource:even").css( "background-color", "#f7f7f7" );
});

*/