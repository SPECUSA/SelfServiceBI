function prepareChartDefination (chartProperties,htmlObj,chartType){

    var options={};        
    for(var i = 0;i < chartProperties.length;i++)
    {
        if(chartProperties[i][2] == "javascript")
        {
            if(chartProperties[i][3] != undefined && chartProperties[i][3].length > 0)
            {
                options[chartProperties[i][0]]= eval("Demo = " +chartProperties[i][3]);
            }
            else
                options[chartProperties[i][0]]= chartProperties[i][3];

        }
        else
            options[chartProperties[i][0]]= chartProperties[i][3];
    }
    options["canvas"] = htmlObj;        
    //console.log(chartType);
    options["width"]  = $("#"+htmlObj).width();
    if(chartType != 'CCCBullet')
        options["height"]  = $("#"+htmlObj).height();

    
    //console.log(options);

    return options;
            
}


function CCCArea(){};
CCCArea.prototype = new SSBBaseComponent();
CCCArea.prototype = {
    chartType : "CCCarea",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCarea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCarea : postExecution");
    } 
}



function CCCBar(){};
CCCBar.prototype = new SSBBaseComponent();
CCCBar.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();

        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}
function CCCStackedBar(){};
CCCStackedBar.prototype = new SSBBaseComponent();
CCCStackedBar.prototype = {
    chartType : "CCCStackedBar",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}
function CCCStackedBar100(){};
CCCStackedBar100.prototype = new SSBBaseComponent();
CCCStackedBar100.prototype = {
    chartType : "CCCStackedBar100",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}
function CCCBar_with_Line(){};
CCCBar_with_Line.prototype = new SSBBaseComponent();
CCCBar_with_Line.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();

        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    }
}

function CCCBoxplot(){};
CCCBoxplot.prototype = new SSBBaseComponent();
CCCBoxplot.prototype = {
    chartType : "CCCboxplot",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BoxplotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCboxplot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCboxplot : postExecution");
    } 
}

function CCCBullet(){};
CCCBullet.prototype = new SSBBaseComponent();
CCCBullet.prototype = {
    chartType : "CCCbullet",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj,"CCCBullet"),
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BulletChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCbullet : preExecution");
    },
    postExecution: function () {
        //console.log("CCCbullet : postExecution");
    } 
}

function CCCDot(){};
CCCDot.prototype = new SSBBaseComponent();
CCCDot.prototype = {
    chartType : "CCCdot",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.DotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}

function CCCHeatGrid(){};
CCCHeatGrid.prototype = new SSBBaseComponent();
CCCHeatGrid.prototype = {
    chartType : "CCCheat",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.HeatGridChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCheat : preExecution");
    },
    postExecution: function () {
        //console.log("CCCheat : postExecution");
    } 
}

function CCCLine(){};
CCCLine.prototype = new SSBBaseComponent();
CCCLine.prototype = {
    chartType : "CCCline",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.LineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCline : preExecution");
    },
    postExecution: function () {
        //console.log("CCCline : postExecution");
    } 
}

function CCCMetricDot(){};
CCCMetricDot.prototype = new SSBBaseComponent();
CCCMetricDot.prototype = {
    chartType : "CCCmetricDot",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.MetricDotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCmetricDot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCmetricDot : postExecution");
    } 
}

function CCCPie(){};
CCCPie.prototype = new SSBBaseComponent();
CCCPie.prototype = {
    chartType : "CCCpie",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}
function CCCDonut(){};
CCCDonut.prototype = new SSBBaseComponent();
CCCDonut.prototype = {
    chartType : "CCCDonut",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}

function CCCStackedArea(){};
CCCStackedArea.prototype = new SSBBaseComponent();
CCCStackedArea.prototype = {
    chartType : "CCCstackedArea",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}

function CCCStackedLine(){};
CCCStackedLine.prototype = new SSBBaseComponent();
CCCStackedLine.prototype = {
    chartType : "CCCstackedLine",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.StackedLineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedLine : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedLine : postExecution");
    } 
}

function CCCSunburst(){};
CCCSunburst.prototype = new SSBBaseComponent();
CCCSunburst.prototype = {
    chartType : "CCCsunburst",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.SunburstChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCsunburst : preExecution");
    },
    postExecution: function () {
        //console.log("CCCsunburst : postExecution");
    } 
}

function CCCTreemap(){};
CCCTreemap.prototype = new SSBBaseComponent();
CCCTreemap.prototype = {
    chartType : "CCCtreemap",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.TreemapChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCtreemap : preExecution");
    },
    postExecution: function () {
        //console.log("CCCtreemap : postExecution");
    } 
}

function CCCWaterfall(){};
CCCWaterfall.prototype = new SSBBaseComponent();
CCCWaterfall.prototype = {
    chartType : "CCCwaterfall",
    
    init: function (chartID,data,htmlObj,chartProperties) {
            
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.WaterfallChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCwaterfall : preExecution");
    },
    postExecution: function () {
        //console.log("CCCwaterfall : postExecution");
    } 
}

function Table(){};
Table.prototype = new SSBBaseComponent();
Table.prototype = {
    chartType : "CCCTable",

    init : function(chartID,data,htmlObj,chartProperties,conditions){
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination = prepareChartDefination(chartProperties,htmlObj);
        this.conditions = conditions;
        this.preExecution();
    },
    render : function(){

        //console.log(this.conditions)
        var table = "<table class='table table1' width='100%'></table>";

        //console.log(this.data)
        $('#'+this.chartDefination['canvas']).append(table);


        var outputCols = [];
        var len = this.chartDefination['outputCols'].length;
        var cols = this.data.metadata.length;

        for(var a=0;a<len;a++)
            if(this.chartDefination['outputCols'][a] <= cols)
                outputCols.push(this.chartDefination['outputCols'][a] -1);
        
        //console.log(outputCols);

        if(cols >= this.chartDefination['noOfColumns'])
            cols = this.chartDefination['noOfColumns'];
        //console.log(cols);

        if(outputCols.length > cols)
            while(outputCols.length>cols)
                outputCols.pop();

        else if(outputCols.length < cols){
            var addEle = true;
            for(var a=0;outputCols.length<cols;a++){

                if(outputCols.length > 0)
                    for(var b=0;b<outputCols.length;b++){
                        addEle = true;
                        //console.log(outputCols[b] +" "+a)
                        if(outputCols[b] == a){
                            //console.log("this is true");
                            addEle = false;
                            break;
                        }
                    }

                if(addEle)
                    outputCols.push(a);
                //console.log(outputCols);
            }
        }     
        outputCols.sort(function(a, b){return a-b});

        //console.log(outputCols);

        if(outputCols.length==0){
            var p = this.data.metadata.length;
            var i=0;
            while(i<p){
                outputCols.push(i);
                i++;
            }
        }


        var columns = [];
        var colIdx = {}
        for(var i=0;i<this.data.metadata.length;i++){
            for(var j=0;j<outputCols.length;j++){
                if(outputCols[j]==i){
                    colIdx[this.data.metadata[i].colName] = j;
                    columns.push({title:this.data.metadata[i].colName})
                }
            }
        }
        var dataSet = [];
        for(var i=0;i<this.data.resultset.length;i++){
            dataSet[i] = [];
            for(var j=0;j<outputCols.length;j++){
                dataSet[i].push(this.data.resultset[i][outputCols[j]]);
            }

        }
        // console.log(columns);
        // console.log(dataSet);


        // for(var i=0;i<this.data.metadata.length;i++){
        //     //var tempObj = {}; 
        //     colIdx[this.data.metadata[i].colName] = i;
        //     columns.push({title:this.data.metadata[i].colName});
        // }
        //var dataSet = this.data.resultset;
        var dataSet1 = [
            [ "Tiger Nixon", "System Architect", "Edinburgh", "5421", "2011/04/25", "$320,800" ],
            [ "Garrett Winters", "Accountant", "Tokyo", "8422", "2011/07/25", "$170,750" ],
            [ "Ashton Cox", "Junior Technical Author", "San Francisco", "1562", "2009/01/12", "$86,000" ],
            [ "Cedric Kelly", "Senior Javascript Developer", "Edinburgh", "6224", "2012/03/29", "$433,060" ],
            [ "Airi Satou", "Accountant", "Tokyo", "5407", "2008/11/28", "$162,700" ],
            [ "Brielle Williamson", "Integration Specialist", "New York", "4804", "2012/12/02", "$372,000" ],
            [ "Herrod Chandler", "Sales Assistant", "San Francisco", "9608", "2012/08/06", "$137,500" ],
            [ "Rhona Davidson", "Integration Specialist", "Tokyo", "6200", "2010/10/14", "$327,900" ]
        ]

        //console.log(colIdx);

        var self = this;
        $('#'+this.chartDefination['canvas']+' .table1').DataTable( {
            data: dataSet,
            columns: columns,
            // [
            //     {title:"1"},
            //     {title:"2"},
            //     {title:"3"},
            //     {title:"4"},
            //     {title:"5"},
            //     {title:"6"}
            // ],
            //"bLengthChange": false
             "iDisplayLength": 10,
             rowCallback: function(row, data, index) {
                //console.log(self.conditions);

                for(var i=0;i<self.conditions.length;i++){
                    //console.log(colIdx[self.conditions[i].column]);
                    if(self.conditions[i].cond=="><"){
                        if(eval(data[colIdx[self.conditions[i].column]]+">="+self.conditions[i].val1) && eval(data[colIdx[self.conditions[i].column]]+"<="+self.conditions[i].val2)){
                            //console.log("here")
                            $(row).find('td:eq('+colIdx[self.conditions[i].column]+')').addClass('color'+self.conditions[i].color)
                        }
                    }
                    else{
                        if(eval(data[colIdx[self.conditions[i].column]]+self.conditions[i].cond+self.conditions[i].val1)){
                            //console.log("here")
                            $(row).find('td:eq('+colIdx[self.conditions[i].column]+')').addClass('color'+self.conditions[i].color)
                        }    
                    }
                    
                }
                // if (data[2]=='Edinburgh' && data[3]=='5421') {
                //   $(row).find('td:eq(3)').addClass('color')
                // } 
                // else{
                //   $(row).find('td:eq(3)').addClass('greencolor')  
                // } 
              }

        });
    },
    preExecution : function(){
        this.render();
    },
    postExecution : function(){
        
    }
}


// function Table(){};
// Table.prototype = new SSBBaseComponent();
// Table.prototype = {
//     chartType : "CCCTable",

//     init : function(chartID,data,htmlObj,chartProperties){
//         this.chartID = chartID;
//         this.data = data;
//         this.htmlObj = htmlObj;
//         this.chartDefination = prepareChartDefination(chartProperties,htmlObj);
//         this.preExecution();
//     },
//     render : function(){
//         var rows = this.data.queryInfo.totalRows;
//         //var totalcols = this.data.metadata.length;
//         var cols = this.data.metadata.length;

//         var bodyHead = [];
//         for(var i=0;i<this.data.metadata.length;i++){
//             if(this.data.metadata[i].colType=="String")
//                 bodyHead.push(i);
//         }
//         var outputCols = [];       
//         var data = this.data.resultset;
//         var table = '';
//         var row = '';
//         var col ='';
//         //console.log(this.chartDefination['outputCols'].length);

//         var len = this.chartDefination['outputCols'].length;

//         for(var a=0;a<len;a++)
//             if(this.chartDefination['outputCols'][a] <= cols)
//                 outputCols.push(this.chartDefination['outputCols'][a] -1);
        
//         //console.log(outputCols);

//         if(cols >= this.chartDefination['noOfColumns'])
//             cols = this.chartDefination['noOfColumns'];
//         //console.log(cols);

//         if(outputCols.length > cols)
//             while(outputCols.length>cols)
//                 outputCols.pop();

//         else if(outputCols.length < cols){
//             var addEle = true;
//             for(var a=0;outputCols.length<cols;a++){

//                 if(outputCols.length > 0)
//                     for(var b=0;b<outputCols.length;b++){
//                         addEle = true;
//                         //console.log(outputCols[b] +" "+a)
//                         if(outputCols[b] == a){
//                             //console.log("this is true");
//                             addEle = false;
//                             break;
//                         }
//                     }

//                 if(addEle)
//                     outputCols.push(a);
//                 //console.log(outputCols);
//             }
//         }     
//         outputCols.sort(function(a, b){return a-b});


//         console.log(data)
//         console.log(outputCols);

//         for(var i=0;i<=rows;i++){
//             col = '';
//             if(i==0)
//                 row = '<thead>';
//             else if(i==1)
//                 row = row + '<tbody>';
//             row = row +'<tr>';
//                 for(var j=0;j<outputCols.length;j++){
//                     if(i==0)
//                         col = col+'<th class="tHead">'+this.data.metadata[outputCols[j]].colName+'</th>';                               
//                     else
//                         col = col + '<td>'+data[i-1][outputCols[j]]+'</td>';
//                 }
//             row = row + col + '</tr>';
//             if(i==0)
//                 row = row +'</thead>';
//             else if(i==rows)
//                 row = row + '</tbody>';
//         }

//         table = '<div class="pageTitle" style="text-align:'+this.chartDefination["titleAlign"]+'">'+this.chartDefination["title"]+'</div><table id="'+this.htmlObj+'_table" class="table table-bordered table-condensed">'+ row +'</table><div id="'+this.htmlObj+'_page" style="text-align:center"></div>';
//         //var navBar = '<div class="pageNav"></div>'

//         //var rTable = $(table);
//         //$('#'+this.htmlObj+'_table',rTable).append('<div class="pageNav"></div>');
//         //$(table).filter('#'+this.htmlObj+'_table').append('<div class="pageNav"></div>');
        
//         var rowsShown = this.chartDefination['noOfRows'];
//         var rowsTotal = rows;
//         var noOfPages = rowsTotal/rowsShown;

//         for(i=0;i<noOfPages;i++){
//             var pageNum = i +1;
//             $(table).filter('.pageNav').append('<a href="#" rel="'+i+'">'+pageNum+'</a>');
//         }
//         $(table).filter('#'+this.htmlObj+'_table tbody tr').hide();
//         $(table).filter('#'+this.htmlObj+'_table tbody tr').slice(0,rowsShown).show();
//         $(table).filter('.pageNav a:first').addClass('active');
//         $(table).filter('.pageNav a').bind('click',function(){
//             $(table).filter('.pageNav a').removeClass('active');
//                 $(this).addClass('active');
//                 var currPage = $(this).attr('rel');
//                 var startItem = currPage * rowsShown;
//                 var endItem = startItem + rowsShown;
//                 $(table).filter('#'+this.htmlObj+'_table tbody tr').css('opacity','0.0').hide().slice(startItem, endItem).
//                         css('display','table-row').animate({opacity:1}, 300);
//         })

//         //console.log($(rTable).prop('outerHTML'));
//         $('#'+this.chartDefination['canvas']).append(table);

//         var rowsShown = this.chartDefination['noOfRows'];
//         var numPages = rows/rowsShown;
//         if(parseInt(numPages)<numPages)
//             numPages = parseInt(numPages)+1;

//         //console.log(this.chartDefination['noOfRows'])
//         //console.log(numPages)
//         var self = this;
//         $('#'+this.htmlObj+'_page').bootpag({
//             total : numPages
//         }).on("page",function(event,num){
//             //$('#'+this.htmlObj+'_page').html();
//             //console.log(num);
//             var currPage = num-1;
//             var startItem = currPage * rowsShown;
//             var endItem = startItem + parseInt(rowsShown);
//             //console.log(self.htmlObj +" "+this.htmlObj);
//             $('#'+self.htmlObj+'_table tbody tr').hide();
//             //$('#'+this.htmlObj+'_table tbody tr').css('opacity','0.0').hide();
//             $('#'+self.htmlObj+'_table tbody tr').slice(startItem, endItem).show();

//             //$('#'+this.htmlObj+'_table tbody tr').slice(startItem, endItem).
//               //      css('display','table-row').animate({opacity:1}, 300);
//         })

//         $('#'+this.htmlObj+'_table tbody tr').hide();
//         $('#'+this.htmlObj+'_table tbody tr').slice(0, rowsShown).show();
        
//         //var navBar = '<div id="'+this.htmlObj+'_nav" style="text-align:center">'+pages+'</div>'

//         //$('#'+this.htmlObj+'_table').before(navBar);
        
//         /*
//             var rowsShown = 4;
//             var rowsTotal = rows;
//             var numPages = rowsTotal/rowsShown;
//             for(i = 0;i < numPages;i++) {
//                 var pageNum = i + 1;
//                 $('#nav').append('<a href="#" rel="'+i+'">'+pageNum+'</a> ');
//             }
//             $('#'+this.htmlObj+'_table tbody tr').hide();
//             $('#'+this.htmlObj+'_table tbody tr').slice(0, rowsShown).show();
//             $('#nav a:first').addClass('active');
//             $('#nav a').bind('click', function(){
 
//                 $('#nav a').removeClass('active');
//                 $(this).addClass('active');
//                 var currPage = $(this).attr('rel');
//                 var startItem = currPage * rowsShown;
//                 var endItem = startItem + rowsShown;
//                 $('#'+this.htmlObj+'_table tbody tr').css('opacity','0.0').hide().slice(startItem, endItem).
//                         css('display','table-row').animate({opacity:1}, 300);
//             });
//         */
//         //$('#'+this.htmlObj+'_table').append("<div>chudamani</div>")

//     },
//     preExecution : function(){
//         this.render();
//     },
//     postExecution : function(){
        
//     }
// }


function fusionChart(){};
fusionChart.prototype = new SSBBaseComponent();
fusionChart.prototype = {
    init : function(chartId,data,htmlObj){

        var fusiondata =[];

        for(var i=0;i<data.resultset.length;i++){
            //if(data.resultset.length > i+1)
                //fusiondata = '{ "label":"'+data.resultset[i][0]+'", "value":"'+data.resultset[i][0]+'},'
            //else
                fusiondata.push({"label": data.resultset[i][0], "value":data.resultset[i][1]}) 
        }

        FusionCharts.ready(function () {
            var revenueChart = new FusionCharts({
                type: 'column2d',
                renderAt: htmlObj,
                width: '100%',
                height: '100%',
                dataFormat: 'json',
                dataSource: {
                    "chart": {
                        "caption": "Monthly revenue for last year",
                        "subCaption": "Harry's SuperMart",
                        "xAxisName": "Month",
                        "yAxisName": "Revenues (In USD)",
                        "numberPrefix": "$",
                        "exportEnabled":"1",
                        "theme": "fint"
                    },

                    "data": fusiondata
                }
            });
            revenueChart.render();
        });
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCarea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCarea : postExecution");
    } 
}

