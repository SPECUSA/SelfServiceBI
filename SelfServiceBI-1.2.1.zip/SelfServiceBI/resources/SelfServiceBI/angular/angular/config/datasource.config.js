angular.module('dataSourceModule',['commonUtilModule','messagesModule']);

angular.module('dataSourceModule')
.config(['$logProvider',function($logProvider){
    $logProvider.debugEnabled(false);
}]);