angular.module('pinboard',['commonUtilModule','messagesModule','colorpicker.module','ui.bootstrap','gridstack-angular','ui.checkbox']);

angular.module('pinboard')
.config(['$logProvider',function($logProvider){
    $logProvider.debugEnabled(false);
}]);


function fireChange(param){
    console.log(param);

    for(var i=0;i<param.length;i++){
        angular.element($("#"+param[i].pinId)).scope().fireChange(param[i].param,param[i].value);
    }

}