angular.module('dataSourceModule').
controller('datasourceCtrl',['$scope','$log','$compile','commonUtils','Messages','dataSource','datasrc','$timeout','commonUtils','datasrcOuter',function($scope,$log,$compile,commonUtils,Messages,dataSource,datasrc,$timeout,commonUtils,datasrcOuter){

    commonUtils.isNull = true;
    commonUtils.savedFlag = false;
    commonUtils.savedFileFlag = false;
    commonUtils.propertiesSaved = false;

    $scope.datasourceFile = "";
    $scope.disableNew = false;
    $scope.disableSave = false;
    $scope.disableSaveAs = false;
    //$scope.PinBoardFile = pinboard.PinBoardFile;
    //$scope.showEditorOption = true;

    $('#propertiesPanel').change(function(){
        commonUtils.savedFlag = false;
        commonUtils.propertiesSaved = false;
        commonUtils.safeApply($scope,function(){});     
    })

    $scope.dblist = [];

    var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/data-access/api/connection/list',"GET",{'ts' : '1437031684490'});

    for(i=0;i<jsonData.databaseConnections.length;i++){
        $scope.dblist.push(jsonData.databaseConnections[i].name);
    }


    $scope.sqlJndi = function(){
        
        $scope.ds_name="";
        $scope.dbcon = $scope.dblist[0];
        $scope.dbcon_pass = "";

        BootstrapDialog.show({
            title: "Create Datasource",
            message: function(dialog) {

                var template = '<div class="modal-form">'+

                               '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Name</div>'+
                               '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right">'+
                               '<input type="text" id="ds_name" class="form-control input-sm" ng-model="ds_name"></div>'+
                               '</div>'+

                               '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Datasource Connection</div>'+
                               '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right">'+
                               '<select id="dbcon" class="form-control input-sm" ng-model="dbcon" ng-options="n for n in dblist" ng-change="dbChange()"></select></div>'+
                               '</div>'+



                               '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Password</div>'+
                               '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right">'+
                               '<input type="password" id="dbcon_pass" class="form-control input-sm" ng-model="dbcon_pass"></div>'+
                               '</div>'+  
                               
                               '</div>'+
                               '<div class="cl"></div>'
                var $message = $('<div></div>');
                $message.append($compile(template)($scope))
                return $message;
            },
            draggable: true,
            closable : true,
            //cssClass : 'browse-dialog',
            onshown: function(dialogRef){
                
                //console.log($scope.dblist);
                var data,dbtype,dbuser,dbhost,dbport,dbname;
                $scope.dbChange = function(){
                    data = commonUtils.synchronousJsonCall( '../../../plugin/data-access/api/connection/get',"GET",{name:$scope.dbcon});
                    dbtype = data.databaseType.shortName;
                    dbuser = data.username;
                    dbhost = data.hostname;
                    dbport = data.databasePort;
                    dbname = data.databaseName;
                }

                $scope.checkpassword = function(){
                    var tableName = commonUtils.getTableName(dbtype,dbuser,$scope.dbcon_pass,dbhost,dbport,dbname);
                    if(tableName==null)
                        return false;
                    else
                        return true;
                }

                /*
                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = defaultVal;
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openDtsrcDialog = function(){
                    $log.debug("Add Datasource Connection dialog");

                    var onOk = function(data) {
                        scope[pName+'text'] = data.name;
                        scope[pName] = data.name;
                        currentVal = data.name;
                        //var connection = self.getDBConnection(data.databaseType.shortName);
                        $log.debug(connection);
                        //$log.log(data.databaseType.extraOptionsHelpUrl.name);e10
                        //if(data.databaseType.name == 'MySQL')
                        //scope.driver = connection[0]
                        scope.dbtype = data.databaseType.shortName;
                        scope.dbuser = data.username;
                        scope.dbhost = data.hostname;
                        scope.dbport = data.databasePort;
                        scope.dbname = data.databaseName;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        //scope.url = connection[1]+'://'+data.hostname+':'+data.databasePort+'/'+data.databaseName;
                        self.safeApply(scope,function(){});
                    }
                    self.datasourceDialog("Select Datasource",currentVal,onOk,function(){},scope);
                }

                */


            },
            buttons: [{
                id: 'btn-save',
                label: 'Save',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var regexp = /^[a-zA-Z0-9-_\.]+$/;
                    if($scope.ds_name.search(regexp) == -1 && $scope.ds_name != undefined && $scope.ds_name.length > 0){
                        alert("Invalid datasource name. It only contain Alphanumeric character and special _ and . characters.");
                        return;
                    }
                    if($scope.checkpassword()){
                        //$('.row-datasource').removeClass('select');
                        $scope.addDatasource('sql.jndi',$scope.ds_name,$scope.dbcon,$scope.dbcon_pass);
                        dialogItself.close();
                        commonUtils.safeApply($scope,function(){});
                    }
                    else{
                        //alert("Wrong password");
                        $scope.addDatasource('sql.jndi',$scope.ds_name,$scope.dbcon,"");
                        dialogItself.close();
                        commonUtils.safeApply($scope,function(){});
                    }
                    
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
            {
                label: 'Cancel',
                action: function(dialogItself){
                    dialogItself.close();
                    
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });






    }
    $scope.addDatasource = function(type,titleName,dbcon,dbcon_pass){
        //$log.log(dataSource.count)
        var len = dataSource.datasources.length;
        /*
        if(len!=0){
            for(var i=0;i<dataSource.datasources.length;i++){
                if(dataSource.datasources[i].type.substr(0, dataSource.datasources[i].type.indexOf('.')) == type.substr(0, type.indexOf('.'))){
                    dataSource.newDtsrcType = false;
                }
            }
        }
        */
        var temp = '';
        dataSource.newDtsrcType = true;

        if(len!=0){
            for(var i=0;i<dataSource.datasources.length;i++){
                //$log.log(dataSource.datasources[i].datasrcName+' '+type.substr(0, type.indexOf('.')))
                if(dataSource.datasources[i].datasrcName == type.substr(0, type.indexOf('.'))){
                    //$log.log("im here")
                    dataSource.newDtsrcType = false;
                    temp = i;
                }    
            }
        }


        if(dataSource.newDtsrcType){
            dataSource.datasources[len] = new datasrcOuter();
            dataSource.datasources[len].datasrcName = type.substr(0, type.indexOf('.'));
            dataSource.datasources[len].datasrcEntry = [];
            dataSource.datasources[len].position = len;
            makeDtsrcEntry(len,0);
        }
        else{
            var arryLen = dataSource.datasources[temp].datasrcEntry.length;
            makeDtsrcEntry(temp,arryLen);      
        }


        function makeDtsrcEntry(len,index){
            dataSource.datasources[len].datasrcEntry[index] = new datasrc();
            dataSource.datasources[len].datasrcEntry[index].id = "dtsrc"+dataSource.count;
            dataSource.datasources[len].datasrcEntry[index].name = titleName;
            dataSource.datasources[len].datasrcEntry[index].type = type;
            dataSource.datasources[len].datasrcEntry[index].properties = commonUtils.readJSONFile('component/datasource/'+type+'.properties.json');
            dataSource.datasources[len].datasrcEntry[index].properties[0][3] = dbcon;
            dataSource.datasources[len].datasrcEntry[index].properties[1][3] = dbcon_pass;

            console.log(dataSource);
            dataSource.currentCda = dataSource.datasources[len].datasrcEntry[index].id;
            console.log(dataSource.currentCda);
        }

/*
        dataSource.datasources[len] = new datasrc();
        dataSource.datasources[len].id = "dtsrc"+dataSource.count;
        dataSource.datasources[len].name = titleName;
        dataSource.datasources[len].type = type;
        
        dataSource.datasources[len].base = type.substr(0, type.indexOf('.'));
        if(dataSource.newDtsrcType)
            dataSource.datasources[len].isFirst = true;
        else
            dataSource.datasources[len].isFirst = false;
        */
        
        $log.debug(dataSource.datasources);

        dataSource.count++;
        commonUtils.isNull = false;
    }


    function saveProperties(){
        $log.debug(dataSource.nullPropertyPanel);
        $log.log(dataSource.datasources);
        if(!dataSource.nullPropertyPanel){
            /*
            for(var a=0;a<dataSource.datasources.length;a++){
                for(var b=0;b<dataSource.datasources[a].datasrcEntry.length;b++){
                    if(dataSource.datasources[a].datasrcEntry[b].id == dataSource.currentCda){
                        var temp1 = a;
                        var temp2 = b;
                        break;
                    }    
                }   
            }
            
            var regexp = /^[a-zA-Z0-9-_\.]+$/;
            if($('#name').val().search(regexp) == -1 && $('#name').val() != undefined && $('#name').val().length > 0){
                alert("Invalid datasource name. It only contain Alphanumeric character and special _ and . characters.");
                $('#name').focus();
                return false;
            }


            dataSource.datasources[temp1].datasrcEntry[temp2].name = $('#name').val();
            //$log.log(dataSource.datasources[temp]);
            for(var i=0;i<dataSource.datasources[temp1].datasrcEntry[temp2].properties.length;i++){
                //$log.log(dataSource.datasources[temp].properties[i][0]);
                if(dataSource.datasources[temp1].datasrcEntry[temp2].properties[i][2] == 'switch' || dataSource.datasources[temp1].datasrcEntry[temp2].properties[i][2] == 'combo'){
                    value = $('#'+dataSource.datasources[temp1].datasrcEntry[temp2].properties[i][0]).bootstrapSwitch('state');
                    $('#'+dataSource.datasources[temp1].datasrcEntry[temp2].properties[i][0]).val(value);
                    //$log.log(dataSource.datasources[temp].properties[i][3]);
                    //dataSource.datasources[temp].properties[i][3] = value;
                }
                var compName = dataSource.datasources[temp1].datasrcEntry[temp2].properties[i][0];
                dataSource.datasources[temp1].datasrcEntry[temp2].properties[i][3] = $('#'+compName).val();
                
                //scope[scope.obj.properties[i][0]];
            }
            //$log.log(dataSource.datasources);
            commonUtils.savedFlag = false;
            commonUtils.propertiesSaved = true;
            commonUtils.safeApply($scope,function(){});
            //$log.log(dataSource.datasources[temp].properties);
        }
        return true;
        */
        }
    }

    function saveDatasource()
    {   
        console.log(commonUtils.propertiesSaved);
        console.log(commonUtils.isNull)


        if(!dataSource.saveConfigToFile())
        {
            //commonUtils.notification(Messages.onPinBoardSaveUserRightError,"danger");
            commonUtils.savedFileFlag=false;
            commonUtils.savedFlag = false;
            return false;
        }
        else
        {
            commonUtils.savedFileFlag=true;
            commonUtils.savedFlag = true;
            return true;
        }
    }
    $scope.newFile = function ()
    {
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            
            commonUtils.savedFlag =false;
        }

        if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            var r = commonUtils.BootstrapConfirm(Messages.onUnsaveDatasourceConfirm,function(r){
                if (r)
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(saveDatasource())
                            newDatasource();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            dataSource.fileName = path;
                            if(saveDatasource())
                                newDatasource();
                        }
                        function onCancel()
                        {
                            //createNewPinBoard();
                        }
                        commonUtils.saveDialogBox("Save Datasource File","cda",onSave,onCancel);
                    }
                }
                else
                {
                    newDatasource();
                }
            });
        }
        else
        {
            newDatasource();
        }
        function newDatasource()
        {
            dataSource.init();
            //$scope.PinBoardFile = pinboard.PinBoardFile;
            //removeAllRowsPinboard();
            commonUtils.isNull = true;
            commonUtils.savedFileFlag =false;
            commonUtils.savedFlag =false;
            dataSource.newDtsrcType = true;
            $scope.datasourceFile = ""
            $scope.disableNew = true;
            commonUtils.notification(Messages.onNewDatasourceNotification);
            $timeout(function(){
                $scope.disableNew = false;
            },4000);
            dataSource.blankPropertiesPanel();
            commonUtils.safeApply($scope,function(){}); 
            $log.debug("New Datasource Created");
        }
    }

    $scope.openFile = function(){
        /*
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            if(!saveProperties())
                return;
        }
        */



        if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            var r = commonUtils.BootstrapConfirm(Messages.onUnsaveDatasourceConfirm,function(r){
                if (r)
                {   
                    if(!commonUtils.propertiesSaved && !commonUtils.isNull){
                        //if(!saveProperties())
                        //    return;
                        console.log(Messages.saveDatasourceProperties);
                        if(!dataSource.nullPropertyPanel){
                            commonUtils.notification(Messages.saveDatasourceProperties,"danger");
                        }
                    }
                    else if(commonUtils.savedFileFlag)
                    {
                        if(saveDatasource())
                            openDatasource();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            dataSource.fileName = path;
                            commonUtils.safeApply($scope,function(){});
                            if(saveDatasource())
                                openDatasource();
                        }
                        function onCancel()
                        {
                            openDatasource();
                        }
                        commonUtils.saveDialogBox("Save Exiting Pin Board","pinb",onSave,onCancel);
                    }
                }
                else
                {
                    openDatasource();
                }
            });
        }
        else
        {
            openDatasource();
        }

        function openDatasource()
        {
            function onOpen(path)
            {
                dataSource.fileName = path;
                $scope.datasourceFile = dataSource.fileName;
                //$scope.PinBoardFile = pinboard.PinBoardFile;
                dataSource.getConfigFromFile();
                commonUtils.safeApply($scope,function(){});
                commonUtils.isNull = false;
                commonUtils.savedFlag =true;
                commonUtils.savedFileFlag=true;
                commonUtils.notification(Messages.onOpenDatasourceNotification);
            }
            function onCancel()
            {
                $log.debug("Open datasource option canceled");
            }
            commonUtils.openDialogBox("Open Datasource","cda",onOpen,onCancel);
        }
    };

    $scope.saveFile = function(){
        //$log.log(commonUtils.propertiesSaved +" "+commonUtils.isNull)
        /*
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            //$log.log("Im here")
            if(!saveProperties())
                return;
        }
    */

        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            //if(!saveProperties())
            //    return;
            console.log(Messages.saveDatasourceProperties);
            if(!dataSource.nullPropertyPanel){
                commonUtils.notification(Messages.saveDatasourceProperties,"danger");
                return
            }
        }
        if(commonUtils.isNull){
            $scope.disableSave = true;
            commonUtils.notification(Messages.onNullDatasourceNotification,"danger");
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }

        else if(!commonUtils.savedFlag)
        {
            if(commonUtils.savedFileFlag)
            {
                if(saveDatasource())
                    commonUtils.notification(Messages.onSaveDatasourceNotification);
            }
            else
            {
                function onSave(path)
                {
                    dataSource.fileName = path;
                    $scope.datasourceFile = dataSource.fileName;
                    //$scope.PinBoardFile = pinboard.PinBoardFile;
                    commonUtils.safeApply($scope,function(){});
                    if(saveDatasource())
                        commonUtils.notification(Messages.onSaveDatasourceNotification);
                }
                function onCancel()
                {
                    $log.debug("Save datasrouce option canceled");
                }
                commonUtils.saveDialogBox("Save CDA data source ","cda",onSave,onCancel);
            }
        }
        else
        {
            $scope.disableSave = true;
            commonUtils.notification(Messages.onAlreadySaveDatasourceNotification);
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }
    }

    $scope.saveFileAs = function(){
        /*
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            if(!saveProperties())
                return;
        }
        */
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            //if(!saveProperties())
            //    return;
            console.log(Messages.saveDatasourceProperties);
            if(!dataSource.nullPropertyPanel){
                commonUtils.notification(Messages.saveDatasourceProperties,"danger");
                return
            }
        }

        if(commonUtils.isNull){
            $scope.disableSaveAs = true;
            commonUtils.notification(Messages.onNullDatasourceNotification,"danger");
            $timeout(function(){
                $scope.disableSaveAs = false;
            },4000)
        }
        else{
            function onSave(path)
            {
                dataSource.fileName = path;
                $scope.datasourceFile = dataSource.fileName;
                //$scope.PinBoardFile = pinboard.PinBoardFile;
                commonUtils.safeApply($scope,function(){});
                if(saveDatasource())
                    commonUtils.notification(Messages.onSaveAsDatasourceNotification);

            }
            function onCancel()
            {
                $log.debug("Save datasource option canceled");
            }
            commonUtils.saveDialogBox("Save As CDA datasource","cda",onSave,onCancel);    
        }
    }
/*
    $scope.saveFile = function(){
        function onSave(path)
        {
            dataSource.fileName = path;
            //$scope.PinBoardFile = dataSource.fileName;
            commonUtils.safeApply($scope,function(){});
            if(saveDatasource())
                $log.debug("Saved");
                //commonUtils.notification(Messages.onSaveAsPinboardNotification);

        }
        function onCancel()
        {
            $log.debug("Save file option canceled");
        }
        commonUtils.saveDialogBox("Save as CDA file","cda",onSave,onCancel);    
    }
*/
    
}]);