angular.module('pinboard')
.controller('pinboardViewerCtr',['$scope','pinboard','Pin' ,'filter','filterPanel','commonUtils','Messages','$window','$log','$compile','$timeout',function($scope,pinboard,Pin,filter,filterPanel,commonUtils,Messages,$window,$log,$compile,$timeout){
    $log.debug("This is Pinboard View Controller");
    commonUtils.mode = "pinboard";
    var mode=commonUtils.getParameterByName("mode").split("?")[0] ;
    if(mode == "editor")
        $window.location.href ="../../../content/SelfServiceBI-res/SelfServiceBI/pinboardEdit.html?mode=edit&solutionFile=" +  commonUtils.getParameterByName("solutionFile");

    else
    {
        pinboard.PinBoardFile = commonUtils.getParameterByName("solutionFile");
        //$log.log(pinboard.PinBoardFile);
        commonUtils.editor=false;

        pinboard.options.disableDrag = true;
        pinboard.options.disableResize = true;


        console.log(pinboard.options)
        pinboard.getConfigFromFile();

        console.log("after get config")
        $scope.pinboardName = pinboard.PinboardName;
        $scope.usercomments = pinboard.userComments;
        $scope.commentsCount = pinboard.commentsCount;


        $scope.bgcolor = pinboard.bgcolor;
        $scope.webfont = pinboard.fonts;
        $scope.transTheme = pinboard.transTheme;
        var w = angular.element($window);
        w.bind('resize', function () {

            pinboard.resizeChart();
            
            //$('body').height($('html').height());
        });
        $("#filterpanel").collapse("show");

        $scope.fileComments = function(){
            commonUtils.comments($scope,$scope.pinboardName,$scope.usercomments,$scope.commentsCount);
        }

        $scope.$watchCollection('usercomments',function(){
            var len = $scope.usercomments.length;

            if(len == undefined || len < 0 )
                $scope.commentsCount='';
            else if(len > 0 && len <10)
                $scope.commentsCount= len;
            else if(len > 10)
                $scope.commentsCount = '10+'; 

            pinboard.saveConfigToFile();
        })
        
        $scope.changeTrans = function(){
            console.log($scope.transTheme)
            if($scope.transTheme)
                $('body').addClass('transTheme');
            else
                $('body').removeClass('transTheme');
        }

        $scope.changeTrans();

        $scope.$watch('bgcolor',function(newval,oldval){
            if(oldval!= undefined){
                $('body').removeClass('bg-'+oldval.toLowerCase());
                $('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
                //$('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
            }
            if(newval!=undefined){
                $('body').addClass('bg-'+newval.toLowerCase());
                $('#LayoutMaker_container').addClass('bg-'+newval.toLowerCase());
                //$('.bootstrap-dialog.type-primary .modal-header').css('background-color','#333');
                //$scope.setFont(newval);
            }

            if(newval!=undefined && newval=='Transparent'){
                $('pin').addClass('transTheme');
            }
            else{
                $('pin').removeClass('transTheme');   
            }
            commonUtils.safeApply($scope,function(){});

        });


        $(function(){
            console.log($('.pinboard-preview-div').html())
            $compile($('.pinboard-preview-div').html('<dashboard></dashboard>'))
            $('body').css('min-height',$('html').height()-50);
        })

    }
     //$('.dropdown-toggle').dropdown()
}]);