angular.module('dataSourceModule').
directive('datasource',['dataSource','$log',function(dataSource,$log){
	return{
		restrict : 'E',
		scope : {},
		transclude : true,
		bindtoController:true,
        controllerAs :'datasourceCtrl',
		template : '<datasource-outer ng-repeat="datasourceCmp in datasourceCtrl.dataSource.datasources" pos={{datasourceCmp.position}} datasrcobj=datasourceCmp></datasource-outer>',
		controller : function($scope,$element,$attrs){
			var vm = this;
			vm.dataSource = dataSource;
			$log.debug("This is datasource directive")
		},
		link : function(scope){
			$log.debug(dataSource.datasources);
		}
	}
}])