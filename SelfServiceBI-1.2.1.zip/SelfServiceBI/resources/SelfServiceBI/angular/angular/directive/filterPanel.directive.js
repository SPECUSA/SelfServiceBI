angular.module('pinboard')
.directive("filterpanel",['pinboard','$log','$compile','commonUtils','$timeout',function(pinboard,$log,$compile,commonUtils,$timeout){
    return{
        restrict : 'E',
        scope : {
            'filterPanel' : '='
        },
        //transclude: true,
        //bindtoController:true,
        //controllerAs :'filterpanelctrl',
        controller : ['$scope', '$attrs','$element', function (scope, attrs,element) {
            $log.debug("This is filterPanel controller");

            $log.debug("filterPanel : "+pinboard.filterPanel);
            scope.settingVisible = commonUtils.editor;
            scope.filterPanelMinimize = false;

            scope.filterPanel.filterPanelHeight = scope.filterPanel.filterPanelHeight >99 ? scope.filterPanel.filterPanelHeight :100;
            //console.log(scope.filterPanel.filterPanelHeight);

            scope.submitFilter = function(){
                console.log("loading......................");
                $log.debug("this is submit filter method");
                var len = scope.filterPanel.filterArray.length;
                pinboard.pinListenerArray = [];
                $log.log("Filter Array : ");
                //console.log(scope.filterPanel.filterArray); 
                //console.log(pinboard.pinLists[0]);

                var pinListeners = {};

                for(var i=0;i<len;i++){
                    p=scope.filterPanel.filterArray[i].listenerPins.length;
                    if(p>0){
                        for(var j=0;j<p;j++){
                            var pinId = scope.filterPanel.filterArray[i].listenerPins[j].pinId;
                            var cdaParam = scope.filterPanel.filterArray[i].listenerPins[j].param
                            var paramval = scope.filterPanel.filterArray[i].filterVal;

                            if(cdaParam!=undefined){
                                if(pinListeners[pinId]==void 0){
                                    pinListeners[pinId] = {};
                                } 
                                pinListeners[pinId][cdaParam] = paramval;    
                            }
                            

                            
                            //console.log(pinListeners)
                        }
                    }
                }


                for(var key in pinListeners){
                    for(var m=0;m<pinboard.pinLists.length;m++){
                        if(key==pinboard.pinLists[m].pin[0].pinId){
                            pinboard.pinLists[m].pin[0].paramStr = pinListeners[key] ;    
                            pinboard.pinLists[m].pin[0].render(pinListeners[key]);
                        }
                    }
                }

                commonUtils.savedFlag = false;
                $log.debug("Pinboard Json data : ");
                $log.debug(pinboard.getJson());

                $log.log(pinboard.pinListenerArray);
                console.log("completed loading......................")
            };
            scope.resetFilters = function(){
 
                for(i=0;i<scope.filterPanel.filterArray.length;i++){
                    if(scope.filterPanel.filterArray[i].filterType == "multiSelect"){
                        var temp = [];
                        temp= scope.filterPanel.filterArray[i].defaultVal;
                        scope.filterPanel.filterArray[i].filterVal = [];
                        for(j=0;j<temp.length;j++){
                            scope.filterPanel.filterArray[i].filterVal.push(temp[j]);    
                        }
                    }
                    else{
                        scope.filterPanel.filterArray[i].filterVal = scope.filterPanel.filterArray[i].defaultVal;
                    }
                    
                }
                
                $log.debug(scope.filterPanel.filterArray);
                $log.debug("Filter Panel reseted");
            }

            scope.filterPanelSetting = function(){
                $log.debug("this is filter panel setting");
                BootstrapDialog.show({
                            title : 'Filter Panel Setting',
                            message : function(dialog) {
                                var $message = $('<div></div>');
                                //var pageToLoad = dialog.getData('pageToLoad');
                                var template = commonUtils.getHtmlContent('component/templates/filter/filterPanelSetting.html');
                                
                                $message.append($compile(template)(scope));
                                return $message;
                            },
                            // data : {
                            //         'pageToLoad' : 'component/templates/filter/filterPanelSetting.html'
                            // },
                            closable : false,
                            draggable : true,
                            cssClass : 'setting-dialog',
                            onshown : function(dialogRef) {
                                $('#filterpanel').collapse('show');
                                scope.filterPanelTitle = scope.filterPanel.filterPanelTitle;
                                scope.filterPanelIcon = scope.filterPanel.filterPanelIcon;
                                scope.filterPanelColor = scope.filterPanel.filterPanelColor;
                                $log.log("this is working");
                                scope.filterPanelHeight = scope.filterPanel.filterPanelHeight >99 ? scope.filterPanel.filterPanelHeight : 100;
                                commonUtils.safeApply(scope,function(){});
                            },
                            buttons : [{
                                label : 'Apply',
                                cssClass : 'btn-primary',
                                action : function(dialogItself) {
                                    scope.filterPanel.filterPanelTitle = scope.filterPanelTitle; 
                                    scope.filterPanel.filterPanelIcon = scope.filterPanelIcon;
                                    scope.filterPanel.filterPanelColor = scope.filterPanelColor;
                                    if(scope.filterPanelHeight < 100 || scope.filterPanelHeight >300){
                                        scope.filterPanelHeight = 100;
                                    }
                                    scope.filterPanel.filterPanelHeight = scope.filterPanelHeight;
                                    commonUtils.safeApply(scope,function(){});
                                    commonUtils.savedFlag = false;
                                    dialogItself.close();
                                },
                                cssClass : 'btn-default btn-lg btn-primary'
                            },{
                                label : 'Close',
                                action : function(dialogItself) {
                                    dialogItself.close();
                                },
                                cssClass : 'btn-default btn-lg btn-danger'
                            }]
                        });
            }

            scope.minimizeFilterPanel = function(){
                //$log.log(scope.filterPanelMinimize);
                if($('#filterpanel').hasClass('collapse') && $('#filterpanel').hasClass('in') )
                    scope.filterPanelMinimize = true;                    
                else
                    scope.filterPanelMinimize = false;   
                
            }


            scope.filterPanelColor = function(){
                console.log("filter panel color")
                BootstrapDialog.show({
                    title:'Set Filter Header Color',
                    message: function(dialog) {
                        var $message = $('<div></div>');
                        var template = commonUtils.getHtmlContent('component/templates/chart/setHeaderColor.html');
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    cssClass:'width542',
                    onshown:function(dialogRef){
                        /*
                        $('.colorPallete').on('click',function(){
                            $log.log(this.id);
                            $('.colorPreview').addClass('panel-'+this.id);
                        })
                        */
                        var colorname = 'red1'
                        //$log.log(scope.colorNames['panel-'+colorname]);
                        //$log.log(scope.pinobj.pinHeaderColor)
                        scope.previewColor = scope.filterPanel.filterPanelColor;
                        scope.colorLabel = commonUtils.colorNames[scope.filterPanel.filterPanelColor];

                        scope.setPreview = function(color){
                            scope.previewColor = 'panel-'+color;
                            scope.colorLabel = commonUtils.colorNames['panel-'+color];
                        }

                        scope.setColor = function(){
                            dialogRef.close();
                            //scope.pinobj.pinHeaderColor = scope.previewColor;
                            scope.filterPanel.filterPanelColor = scope.previewColor;
                        }

                        commonUtils.safeApply(scope,function(){});
                    }
                });
            }


        }],
        link : function(scope,element,attrs){
            scope.init = function(){
                //$log.log($('#filterpanel').height());
                if(!$('#filterpanel').hasClass('collapse') && !$('#filterpanel').hasClass('in'))
                    scope.filterPanelMinimize = false;
            }
            scope.init();

            if(scope.filterPanel.filterPanelShow && scope.filterPanel.filterArray.length > 0){
                $log.log(scope.filterPanel.filterPanelShow);
                $log.log(scope.filterPanel.filterArray)
                $('#filterpanel').collapse('show');
            }
            var html = '<div class="filterpanelWrapper font{{filterPanel.filterPanelFontColor}}"><div id="filterpanelHeader" class="panel panel-filter" >' +
                        '<div class="panel-heading clearfix {{filterPanel.filterPanelColor}}">' +
                            '<h4 id="filterpanelTitle" class="panel-title panel-filterpanel-main pull-left">'+
                                //'<i id="filterPanIcon" class="{{filterPanel.filterPanelIcon}}"></i> ' +
                                ' {{filterPanel.filterPanelTitle}}' +
                            '</h4>' +
                            '<div class="pull-right">' +
                                '<button class="btn btn-default btn-xs btn-xs-last" ng-click="minimizeFilterPanel()" ng-hide=settingVisible data-toggle="collapse" data-target="#filterpanel">'+
                                '<i class="glyphicon glyphicon-minus"></i></button>' +
                                '<button class="btn btn-default btn-xs" ng-show=settingVisible ng-click="filterPanelSetting()">'+
                                '<i class="glyphicon glyphicon-cog"></i></button>'+
                                '<button class="btn btn-default btn-xs" ng-show=settingVisible ng-click="filterPanelColor()">'+
                                '<i class="fa fa-paint-brush"></i></button>';
                                
                if(commonUtils.editor)
                    html = html +'<button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()">Reset</button><button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()">Submit</button>';
                else
                    html = html +'<button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()" ng-hide=filterPanelMinimize>Reset</button><button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()" ng-hide=filterPanelMinimize>Submit</button>';

                html = html +'</div>' +
                        '</div>' +
                        '<div id="filterpanel" class="panel-body panel-filter-body collapse in filterpanel" style="height:{{filterPanel.filterPanelHeight}}px;">'+
                           // '<div  class="filterPanelBody col-md-12  col-sm-12  column " style="height:{{filterPanel.filterPanelHeight}}px;" > '+
                            '<div  class="filterPanelBody col-md-12  col-sm-12  column " > '+
                                "<filtercomponent ng-repeat='filter in filterPanel.filterArray' filterconfig=filter ></filtercomponent>" +
                            '</div>' +
                        '</div>'+
                    '</div></div>';


            element.html(html);
            $compile(element.contents())(scope);
        }
    }
}]);