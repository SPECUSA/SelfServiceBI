angular.module('commonUtilModule')
.directive('dropdownMultiselect', ['commonUtils','$compile','$log',function (commonUtils,$compile,$log) {
    return {
        restrict: 'E',
        scope: {
            selectedOptions: '=',
            datasource: '=',
            idd : '='
        },

        link : function($scope,element,attr)
        {
            //$log.log("link");
            $scope.openDropdown = function () {

                $scope.open = !$scope.open;
                if($scope.open)
                {
                    dropDownFixPosition(element.find(".dropdownClicked"),element.find(".dropdown-menu"));
                }

            };

            function dropDownFixPosition(button,dropdown){
                var dropDownTop = button.offset().top + button.outerHeight();
                dropdown.css('top', dropDownTop + "px");
                dropdown.css('left', button.offset().left + "px");
            }


            var html = "<div class='btn-group' ng-class='{open: open}'>" +
                    "<button class='btn btn-sm btn-default dropdown-toggle dropdownClicked' ng-click='openDropdown()' style='width:auto'>{{title}} <b class='caret'></b></button>" +
                    "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                        "<li><a ng-click='selectAll()'><span class='{{idd}}' ng-class='getClass()' aria-hidden='true'></span> Select All</a></li>" +
                        "<li><span class='form-inline'><input type='text' ng-model='search' style='margin-left:5px;margin-right:5px;width:78%'/><i class='glyphicon glyphicon-search'></i></span></li>" +
                        "<li class='divider'></li>"+
                        "<li class='dropdown-data'>"+
                        "<ul style='color:black;list-style-type: none;margin-left: -20px;'><li ng-repeat='option in datasource | filter:search'><div ng-click='toggleSelectItem(option)'><span ng-class='getClassName(option)'aria-hidden='true'></span> {{option}}</div></li>"+
                        "</ul></li></ul>" +
                        "</div>";

            element.html(html);
            $compile(element.contents())($scope);



        },

        controller: function ($scope) {
            //$log.log($scope.idd);
            
            $scope.isSelectAll = true;
            $scope.optionSelect = [];
            angular.forEach($scope.datasource,function(item,index){
                for(i=0;i<$scope.selectedOptions.length;i++){
                    if($scope.selectedOptions[i] == $scope.datasource[index]){
                        $scope.optionSelect.push($scope.selectedOptions[i]);
                    }
                }
            })
            $scope.selectedOptions = $scope.optionSelect; 
            $scope.title = ($scope.selectedOptions.length)+' selected';
            $scope.totalLen = $scope.datasource.length;
            //$scope.selectedLen = $scope.selectedOptions.length;

            $scope.selectAll = function () {
                if($scope.isSelectAll){
                    $scope.selectedOptions = [];
                    angular.forEach($scope.datasource, function (item, index) {
                        $scope.selectedOptions.push(item);
                    });   
                    $scope.isSelectAll = false;
                    $scope.title = 'All Selected'
                }
                else{
                    $scope.selectedOptions = [];    
                    $scope.title = 'None Selected'
                    $scope.isSelectAll = true;
                }
            };

            $scope.getClass = function () {
                if($scope.isSelectAll){
                    return 'glyphicon glyphicon-remove white'
                }
                else{
                    return 'glyphicon glyphicon-ok green'
                }
            };

            $scope.toggleSelectItem = function (option) {
                var intIndex = -1;
                
                angular.forEach($scope.selectedOptions, function (item, index) {
                    if (item == option) {
                        intIndex = index;
                    }
                });
                //$log.log(intIndex);
                if (intIndex >= 0) {
                    $scope.selectedOptions.splice(intIndex, 1);
                    isSelectAll = false;
                    if($scope.selectedOptions.length == 0){
                        $scope.title = 'None Selected';
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                    }
                    else{
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                        $scope.title = ($scope.selectedOptions.length)+' Selected' ;
                    }
                }
                else {
                    $scope.selectedOptions.push(option);
                    if($scope.selectedOptions.length == $scope.totalLen){
                        $scope.title = 'All Selected';
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-remove white');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-ok green');
                        $scope.isSelectAll = true;
                    }
                    else{
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                        $scope.title = ($scope.selectedOptions.length)+' Selected';
                        isSelectAll = false;
                    }
                }
            };
            $scope.getClassName = function (option) {
                var varClassName = 'glyphicon glyphicon-remove white';
                angular.forEach($scope.selectedOptions, function (item, index) {
                    if (item == option) {
                        varClassName = 'glyphicon glyphicon-ok green';
                    }
                });
                return (varClassName);
            };
        }
    }
}]);