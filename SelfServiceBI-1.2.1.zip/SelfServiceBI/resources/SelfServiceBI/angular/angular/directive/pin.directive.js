angular.module('pinboard')
.directive("pin",['pinboard','Pin','$timeout','commonUtils','$log','$http','$compile','Messages',function(pinboard,Pin,$timeout,commonUtils,$log,$http,$compile,Messages){
    return {
        restrict :'E',
        scope : {
            'pinobj'  : '=',
            'pinboardrow' : '@',
            'pinboardcol' : '@',
            'pintype' : '=',
            'idd' : '@'
        },
        link : function (scope,element,attrs ){

            $log.debug("This is Pin directive");
            $log.debug("PinType  : " + scope.pintype);
            
            console.log(scope.pinobj);

            scope.editor=commonUtils.editor;
            scope.preview = !commonUtils.editor;

            scope.dataSources = [];


            if(pinboard.datasourceList.indexOf(scope.pinobj.dataSource)<0 && scope.pinobj.dataSource.length>0){
                pinboard.datasourceList.push(scope.pinobj.dataSource);
                //console.log(scope.pinobj.dataSource.indexOf(".cda"))
                scope.pinobj.dataSource.indexOf(".cda")>0?pinboard.addDAelement(pinboard.datasourceList.length-1):console.log("saiku");
            }
            //console.log(pinboard.datasourceList)
            //console.log("datasource :"+scope.pinobj.dataSource)

            if(scope.pinobj.commentsCount==undefined && (scope.pinobj.comments.length>0 && scope.pinobj.comments.length<11))
                scope.pinobj.commentsCount = scope.pinobj.comments.length;
            else if(scope.pinobj.commentsCount==undefined && scope.pinobj.comments.length>10)
                scope.pinobj.commentsCount = '10+'
            else if(scope.pinobj.commentsCount==undefined && scope.pinobj.comments.length==0)
                scope.pinobj.commentsCount = '';   
            

            if(scope.preview && scope.pinobj.chartType != 'Saiku')
                scope.showExport = true;    
            else
                scope.showExport = false;

            scope.listParameters = [];



            var getDefaultParams = function(){
                scope.listParameters = [];
                            //alert(listParams);
                uri = encodeURIComponent(scope.pinobj.dataSource);

                var listParams = commonUtils.getDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,"parameter");

                if(!listParams){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+scope.pinobj.dataAccessId ;
                    listParams = commonUtils.synchronousJsonCall(url);

                    commonUtils.setDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,listParams,"parameter");
                }
                //scope.listParameters = listParams;

                console.log(listParams);

                var param = {};
                var  l = listParams.resultset.length;
                //console.log(scope.listParameters);

                for(var i=0;i<l;i++){
                    paramObj = listParams.resultset[i];
                    param[paramObj[0]] = paramObj[2];
                }
                scope.pinobj.defaultParamStr = param;

                //console.log(param);
                for(var x=0;x<scope.pinobj.listenerFilters.length;x++){
                    //console.log("asd")
                    for(var i=0;i<pinboard.filterPanel.filterArray.length;i++){
                        if(pinboard.filterPanel.filterArray[i].filterId==scope.pinobj.listenerFilters[x][0]){
                            $.each(pinboard.filterPanel.filterArray[i].listenerPins,function(j,v){
                                if(v.pinId == scope.pinobj.pinId){
                                    pinboard.filterPanel.filterArray[i].listenerPins[j].param = scope.pinobj.listenerFilters[x][1];
                                }
                            })
                        }
                            
                    }
                        
                }


                var paramStr = commonUtils.parseParams(angular.copy(scope.pinobj.defaultParamStr));

                //console.log(paramStr)
                var data = commonUtils.getDatasourceData(scope.dataSource,scope.dataAccessId,"data");

                if(!data){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + paramStr + '&outputIndexId=1';
                    data = commonUtils.synchronousJsonCall(url);

                    commonUtils.setDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,data,"data");
                }
            }

            $timeout(function(){
                if(scope.pinobj.dataAccessId.length>0)
                    getDefaultParams();
                console.log("paramStr "+scope.pinobj.defaultParamStr)
                if(scope.pinobj.chartType == 'CCC' || scope.pinobj.chartType == 'Label'){
                    $log.log("paramStr "+scope.pinobj.defaultParamStr);
                    scope.pinobj.paramStr = scope.pinobj.defaultParamStr;
                    scope.pinobj.render(scope.pinobj.defaultParamStr);    
                }
                else{
                    //console.log(scope.pinobj)
                    scope.pinobj.render();    
                }
            }, 0);

            if(commonUtils.mode == "pin")
                scope.pinMode = true
            else
                scope.pinMode = false;

            var populateDatasrc = function(filext){
                console.log(filext)
                scope.dataSources = [];
                var flagCda = false;
                for(i=0;i<pinboard.datasourceList.length;i++){
                    if(pinboard.datasourceList[i].indexOf('.cda')>0)
                        flagCda = true;
                    if(pinboard.datasourceList[i].indexOf('.'+filext)>0)
                        scope.dataSources.push(pinboard.datasourceList[i]);
                }

                console.log(scope.dataSources)

                console.log(scope.dataSource);
                if(scope.dataSource == undefined || scope.dataSource.length <= 0 || scope.dataSources.indexOf(scope.dataSource)<0){
                    scope.dataSource = scope.dataSources[0];
                }
                else if(scope.pinobj.dataSource==scope.dataSource)
                    scope.dataSource = scope.pinobj.dataSource;
                

                console.log(filext)
                if(flagCda && filext=='cda'){
                    scope.populateDAId();
                }
            }

            scope.populateDAId = function(){
                console.log(pinboard.dataAccessList)
                scope.dataAccessIds = [];
                for(var i=0;i<pinboard.dataAccessList.length;i++){
                    if(pinboard.dataAccessList[i].dbsrc==scope.dataSource)
                        scope.dataAccessIds = angular.copy(pinboard.dataAccessList[i].daIds)
                }

                //scope.dataAccessId = scope.dataAccessIds[0];

                if(scope.dataAccessId == undefined || scope.dataAccessId.length <= 0 || scope.dataSource != scope.pinobj.dataSource){
                    scope.dataAccessId = scope.dataAccessIds[0];    
                }
                else{
                    scope.dataAccessId = scope.pinobj.dataAccessId;
                }

                scope.dataAccessIdChanged();
            }

            //initialization method of the chart properties
            scope.initChartProperties = function(){
                scope.isPinboard = false;
                scope.chartTypes = [];

                for(var i=0; i<commonUtils.components.selfServiceBI.length; i++) {
                    scope.chartTypes.push(commonUtils.components.selfServiceBI[i].chartCaption);
                };
                scope.chartType = scope.chartTypes[0];

                if(commonUtils.mode == 'pinboard'){
                    //scope.getChartClass = 'chart_table_body';
                    scope.isPinboard = true;

                }

                    

                if(scope.chartType=="Saiku")
                    scope.isCCCchart = false;
                else
                    scope.isCCCchart = true;

                // init - pinlistener

                if(scope.pinobj.listenerPins == undefined){
                    scope.pinobj.listenerPins = [];
                }

                scope.totalPins = [];
                $.each(pinboard.pinLists,function(i,v){
                    if(v.pin[0].pinId != scope.pinobj.pinId)
                        for(a in v.pin[0].defaultParamStr){
                            scope.totalPins.push({pinId:v.pin[0].pinId,title:v.pin[0].title,param:a});
                        }
                })

                scope.bindPins = [];
                scope.bindPins = angular.copy(scope.pinobj.listenerPins);

                var i=0;
                while(i<scope.totalPins.length){
                    var hasEntry = false;
                    for(var j=0;j<scope.bindPins.length;j++){
                        if(scope.bindPins[j].pinId==scope.totalPins[i].pinId && scope.bindPins[j].param==scope.totalPins[i].param){
                            scope.bindPins[j].title = scope.totalPins[i].title;
                            hasEntry = true;
                            console.log(j)
                            break; 
                        }
                    }
                    if(hasEntry)
                        scope.totalPins.splice(i,1);
                    else
                        i++;
                }

                scope.cccChart = false;
            }

            

            scope.fireChange = function(param,value){
                console.log(param)
                scope.pinobj.paramStr[param] = value;
                scope.pinobj.render(scope.pinobj.paramStr);
            }

            scope.chartProperties = function(){
                $log.debug("chart properties called");
                scope.initChartProperties();
                $log.log(commonUtils.mode)
                BootstrapDialog.show({
                    title: 'Settings of '+scope.pinobj.title+'',
                    message: function(dialog){
                        var $message = $('<div></div>');
                        //var pageToLoad = dialog.getData('pageToLoad');
                        //$message.load(pageToLoad);
                        var template = commonUtils.getHtmlContent('component/templates/chart/chartsProperties.html');
                        $message.append($compile(template)(scope));
                        $('.existingPin').hide();
                        return $message;

                    },
                    closable : false,
                    draggable : true,
                    cssClass : 'chart-properties-dialog',
                    onshown : function(dialogRef){

                        var cdaParams = [];
                        var getDataAccessId = [];
                        //$log.log(scope.pinobj.pinId);


                        scope.pinId = scope.pinobj.pinId;
                        scope.properties = scope.pinobj.chartProperties;
                        //console.log(scope.properties);
                        scope.chartType = scope.pinobj.chartType;
                        scope.dataSource = scope.pinobj.dataSource;

                        scope.visualization = scope.pinobj.visualization ;
                        scope.dataAccessId = scope.pinobj.dataAccessId ;
                        //console.log(scope.pinobj.dataAccessId)
                                               

                        scope.addListenerPin = function(indx){
                            console.log(indx);
                            scope.bindPins.push(scope.totalPins[indx])
                            scope.totalPins.splice(indx,1)
                            //updateCss();
                            //commonUtils.safeApply(scope,function(){})
                        }
                        scope.removeListenerPin = function(indx){
                            scope.totalPins.push(scope.bindPins[indx]);
                            scope.bindPins.splice(indx,1);
                        }

                        var loadVisualization = function(indx,isNew){
                            $log.log("load visualizations");
                            scope.visualizations = [];
                            var charts = commonUtils.components.selfServiceBI[indx].properties.files.charts;
                            //$log.debug(charts);
                            scope.browseExt = commonUtils.components.selfServiceBI[indx].properties.datasourceExt;

                            for(i = 0; i < charts.length; i++) {
                                scope.visualizations.push(charts[i]);
                            }
                            if(isNew){
                                scope.visualization = scope.visualizations[0];        
                            }
                            else{
                                scope.visualization = scope.pinobj.visualization;        
                            }

                        }                        
                        
                        var loadProperties = function(){
                            $log.log("load properties");
                            $("#primaryProperties").html("");
                            scope.properties = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');

                            console.log(scope.properties)
                            // if(scope.pinobj.visualization == scope.visualization && scope.pinobj.chartProperties.length > 0){
                            //     scope.properties = scope.pinobj.chartProperties;
                            // }
                        }
                        scope.loadProperties = function(){
                            $log.log("load properties called");
                            BootstrapDialog.show({
                                title: ''+scope.visualization+' Properties',
                                message: function(dialog){
                                    var template =  '<div id="propertiesPanel" class="panel propertiesPanel" style="margin-bottom:0px;" >'+
                                                        '<div class="panel-heading" style="text-align:center">'+
                                                            '<input class="form-control input-sm" type="checkbox" id="switchProperties" data-size="small" data-handle-width="75" data-on-text="Primary" data-off-text="Advance" data-on-color="primary" data-off-color="danger"  checked />'+
                                                        '</div>'+
                                                        '<div class="panel" style="overflow:auto;max-height:340px;border:1px solid #DCDCDC">'+
                                                            '<div class="modal-form" id="primaryProperties1">'+
                                                            '</div>'+
                                                        '</div>'+
                                                    '</div>';

                                    var $message = $('<div></div>');
                                    $message.append($compile(template)(scope));
                                    return $message;
                                },
                                closable : false,
                                draggable : true,
                                cssClass : 'width500',
                                onshown : function(dialogRef){
                                    
                                    $("#primaryProperties1").html("");

                                    var changeProperties = function(indx){
                                        if(indx == 0 ){
                                            $(".advance").hide();
                                        }
                                        else{
                                            $(".advance").show();
                                        }  
                                    }

                                    $('#switchProperties').bootstrapSwitch('state',true,true);
                                    $('#switchProperties').on('switchChange.bootstrapSwitch', function(event, state){
                                        if(!state)
                                            changeProperties(1);
                                        else
                                            changeProperties(0);
                                    });

                                    
                                    //scope.properties = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');
                                    
                                    var l = scope.properties.length;
                                    console.log(scope.properties);
                                    //$log.log(scope.properties);
                                    for(i=0;i<l;i++){
                                        //$log.log(scope.pinobj.chartProperties[i][0] +" == "+ scope.properties[i][0] +" "+scope.pinobj.visualization+" == "+scope.visualization)

                                        if(typeof scope.pinobj.chartProperties  != 'undefined' &&  scope.pinobj.chartProperties.length >0 && scope.pinobj.visualization == scope.visualization && scope.pinobj.chartProperties[i][0] == scope.properties[i][0]){
                                            commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.pinobj.chartProperties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                        }
                                            
                                        else{
                                            //$log.log(scope.pinobj.visualization+" == "+scope.visualization);
                                            commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                        }
                                            
                                    }
                                    console.log(scope.chartType)

                                    if(scope.chartType){
                                        console.log($('#newMeasure').bootstrapSwitch('state'));
                                        $('#newMeasure').on('switchChange.bootstrapSwitch',function(event,state){
                                            console.log("asdasdasd");
                                            console.log($())
                                            if(state)
                                                $('#measure').prop('disabled',true);
                                            else
                                                $('#measure').prop('disabled',false);
                                        })


                                    }

                                    changeProperties(0);
                                },
                                buttons : [{
                                    label : 'Ok',
                                    cssClass : 'btn-primary',
                                    action : function(dialogItself) {
                                        //$log.log(scope.properties);

                                        
                                        var l = scope.properties.length;
                                        //$log.log(scope.properties);
                                        for(var i=0;i<l;i++){
                                            //$log.log(scope.properties[i][2]);
                                            if(scope.properties[i][2] == 'switch' || scope.properties[i][2] == 'combo'){
                                                temp = $('#'+scope.properties[i][0]).bootstrapSwitch('state');
                                                scope[scope.properties[i][0]] = temp;
                                            }
                                            //scope.pinobj.chartProperties[i] = scope.properties[i];
                                            scope.properties[i][3] = commonUtils.parsePropertiesDataType(scope[scope.properties[i][0]],scope.properties[i][1]);
                                            //$log.debug(scope.pinobj.chartProperties[i]);
                                        }
                                        //scope.pinobj.visualization = scope.visualization;
                                        //$log.log(scope.properties);                                        
                                        dialogItself.close();
                                    },
                                    cssClass: 'btn-default btn-lg btn-primary'
                                },{
                                    label : 'Close',
                                    action : function(dialogItself) {
                                        dialogItself.close();
                                        
                                    },
                                    cssClass: 'btn-default btn-lg btn-danger'
                                }]
                            })
                        }

                        scope.getParams = function(dataAccessId){
                            $log.log("get params");
                            var listParams = [];
                            //cdaParams = [];
                            scope.listParameters = [];
                            //alert(listParams);


                            uri = encodeURIComponent(scope.dataSource);

                            listParams = commonUtils.getDatasourceData(scope.dataSource,dataAccessId,"parameter");

                            if(!listParams){
                                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+dataAccessId ;
                                listParams = commonUtils.synchronousJsonCall(url);

                                commonUtils.setDatasourceData(scope.dataSource,dataAccessId,listParams,"parameter");
                            }
                            scope.listParameters = listParams;

                        }

                        scope.getParamString = function(){
                            $log.log("get param string");
                            var param = {};
                            var  l = scope.listParameters.resultset.length;
                            console.log(scope.listParameters);

                            for(var i=0;i<l;i++){
                                paramObj = scope.listParameters.resultset[i];
                                param[paramObj[0]] = paramObj[2];
                            }

                            return param;
                        }

                        scope.chartTypeChanged = function(){
                            var temp;
                            console.log(scope.chartType)
                            //scope.dataSource = "";
                            scope.isNew = true;
                            var index = commonUtils.getIndex(scope.chartType);
                            //$log.log(index);
                            //scope.browseExt = commonUtils.components.selfServiceBI[index].properties.datasourceExt;

                            if(scope.chartType == 'Table' || scope.chartType == 'Label'){
                                //$log.log("this is happend")
                                $('.cccProperties').show();
                                $('.chartType').hide();
                                $('.dataProperties').show();
                                scope.cccChart = false;
                            }
                            else if(scope.chartType == 'Saiku'){
                                $('.dataProperties').hide();
                                $('.chartType').show();
                                $('.cccProperties').hide();
                                scope.cccChart = true;
                            }
                            else{
                                $('.cccProperties').show();
                                $('.dataProperties').hide();
                                $('.chartType').show();
                                scope.cccChart = true;
                            }

                            if(scope.pinobj.chartType == scope.chartType){
                                scope.dataSource = scope.pinobj.dataSource;
                                scope.isNew = false;          
                            }

                            loadVisualization(index,scope.isNew);
                            console.log(pinboard.datasourceList)

                            if(pinboard.datasourceList.length>0)
                                populateDatasrc(scope.browseExt);
                            
                            if(commonUtils.components.selfServiceBI[index].properties.files.chartProperties=="true"?true:false){
                                console.log("load properties")
                                loadProperties();
                            }
                            
                            //scope.datasourceChanged();
                        }

                        scope.visualChanged = function(){
                            $log.log("visual changed");
                            if(scope.chartType != 'Fusion' ){
                                $log.debug("visualization changed");
                                if(scope.visualization == 'Bullet'){
                                    commonUtils.notification(Messages.onCCCbulletChartSelect);
                                }
                                loadProperties(); 
                            }
                        }
                        
                        scope.dataAccessIdChanged = function(){
                            $log.log("data access Id");
                            $log.log(scope.dataAccessId);

                            if(scope.dataAccessId != undefined && scope.dataAccessId != null &&  scope.dataAccessId.length >0){
                                scope.getParams(scope.dataAccessId);

                                var param = scope.getParamString();
                                console.log(param);

                                var paramStr = commonUtils.parseParams(angular.copy(param));

                                console.log(paramStr)
                                var data = commonUtils.getDatasourceData(scope.dataSource,scope.dataAccessId,"data");

                                if(!data){
                                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.dataSource + '&dataAccessId=' + scope.dataAccessId + paramStr + '&outputIndexId=1';
                                    data = commonUtils.synchronousJsonCall(url);

                                    commonUtils.setDatasourceData(scope.dataSource,scope.dataAccessId,data,"data");
                                }


                                // url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.dataSource + '&dataAccessId=' + scope.dataAccessId + param + '&outputIndexId=1';
                                // data = commonUtils.synchronousJsonCall(url);
                                if(data==void 0)
                                    return false;


                                var len = data.metadata.length;

                                $log.debug(data.metadata);
                                
                                scope.listenerColumns = [];
                                for(var i=0;i<len;i++){
                                    scope.listenerColumns.push(data.metadata[i].colName);
                                }
                                scope.listenerColumn = scope.listenerColumns[0];
                            }
                            

                        }

                        scope.removePin = function(){
                            commonUtils.BootstrapConfirm(Messages.onRemoveRowConfirm, function(result){
                                if(result) {
                                    var temp;
                                    for(var i=0;i<pinboard.pinLists.length;i++){
                                        if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                                            temp = i;
                                    }

                                    //pinboard.pinLists.splice(temp,1);

                                    //removeRow= parseInt(removeRow);
                                    var nullPinboard = pinboard.removeAt(temp);
                                    //commonUtils.notification(Messages.onPinBoardRemoveRowSuccess);
                                    if(nullPinboard)
                                        commonUtils.isNull = true;
                                    else
                                        commonUtils.isNull = false;

                                    dialogRef.close();
                                    commonUtils.safeApply(scope,function(){});
                                    commonUtils.savedFlag =false; //to-do set flag to root or commonutil
                                }
                            });
                            $("#mainpage").height(document.getElementById("mainpage").scrollHeight)
                        }


                        $timeout(function(){
                            scope.chartTypeChanged();                           
                        },0)                            
                        
                    },
                    buttons : [{
                        label : 'Apply',
                        cssClass : 'btn-primary',
                        action : function(dialogItself) {

                            if(scope.dataSource != undefined && scope.dataSource.length > 0){
                                var temp;
                                var param = '';
                                scope.pinobj.chartType = scope.chartType;
                                scope.pinobj.dataSource= scope.dataSource;
                                scope.pinobj.visualization = scope.visualization;
                                
                                

                                if(scope.bindPins.length>0){
                                    // var strArry1 =[];
                                    // angular.forEach(scope.bindPins,function(v,i){
                                    //     strArry1.push({pinId:v.pinId,param:v.param,value:"clickVal"}) 
                                    // })
                                    //console.log(JSON.stringify(strArry1));
                                    var strArry = "["
                                    angular.forEach(scope.bindPins,function(v,i){
                                        //strArry.push({pinId:v.pinId,param:v.param,value:"clickVal"}) 
                                        if(i!=0)
                                            strArry1 +=",";
                                        strArry += '{"pinId":"'+v.pinId+'","param":"'+v.param+'","value":clickVal}'
                                    })
                                    strArry+="]"
                                    

                                    console.log(scope.properties);


                                    for(var i=0;i<scope.properties.length;i++){
                                        if(scope.properties[i][0]=='clickable'){
                                            scope.properties[i][3] = true;
                                        }

                                        if(scope.properties[i][0]=='clickAction'){
                                            var fun = "function(scene){\n\t\tvar arryListener=[],clickVal='';\n\t\tconsole.log(scene);"+
                                                        "\n\t\tif(scene.vars.category.value!= null){\n\t\t\tclickVal=scene.vars.category.value}\n\t\telse{\n\t\t\tclickVal=scene.vars.category.value\n\t\t}"+
                                                        "\n\t\tarryListener="+strArry+";\n\t\tfireChange(arryListener);\n}";
                                            $log.log(fun);
                                            scope.properties[i][3] = fun;
                                        }
                                    }




                                }
                                else{
                                    for(var i=0;i<scope.properties.length;i++){
                                        if(scope.properties[i][0]=='clickable'){
                                            scope.properties[i][3] = false;
                                        }

                                        if(scope.properties[i][0]=='clickAction'){
                                            scope.properties[i][3] = "";
                                        }
                                    }
                                }

                                scope.pinobj.listenerPins = angular.copy(scope.bindPins);
                                for(var i=0;i<pinboard.pinLists.length;i++){
                                    if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                                        scope.pinobj.height = pinboard.pinLists[i].height * 70 - 10 -38;
                                }
                                if(scope.pinobj.chartType == 'Saiku'){


                                    url = location.protocol +"//"+location.host+"/pentaho/plugin/saiku/api/cde-component/export/saiku/json?formatter=flattened&file="+scope.dataSource;
                                    var data = commonUtils.readJSONFile(url)
                                    console.log(data)
                                    scope.pinobj.dataAccessId = "";
                                    scope.pinobj.paramStr = {};
                                    scope.pinobj.paramStr = data.query.parameters;
                                    scope.pinobj.defaultParamStr = data.query.parameters;
                                    commonUtils.savedFlag = false;
                                    commonUtils.safeApply(scope,function(){});
                                    scope.pinobj.chartProperties = scope.properties;
                                    scope.pinobj.currentSaiku = scope.pinobj.visualization;  
                                    scope.pinobj.render(scope.pinobj.paramStr);
                                }
                            
                                else{
                                //else if(scope.pinobj.chartType == 'CCC' || scope.pinobj.chartType == 'Fusion' || scope.pinobj.chartType == 'Table' || scope.pinobj.chartType == "Label"){
                                    //var arryListener = [];

                                    //$log.log("chart type : "+ scope.pinobj.chartType);
                                    //var l = scope.properties.length;
                                    scope.pinobj.dataAccessId = scope.dataAccessId;    
                                    scope.pinobj.defaultParamStr = scope.getParamString();
                                    scope.pinobj.visualization = scope.visualization;
                                    scope.pinobj.chartProperties = scope.properties;                                

                                    /*
                                    for(var i=0;i<l;i++){
                                        if(scope.properties[i][2] == 'switch' || scope.properties[i][2] == 'combo'){
                                            temp = $('#'+scope.properties[i][0]).bootstrapSwitch('state');
                                            scope[scope.properties[i][0]] = temp;
                                        }
                                        scope.pinobj.chartProperties[i] = scope.properties[i];
                                        scope.pinobj.chartProperties[i][3] = commonUtils.parsePropertiesDataType(scope[scope.properties[i][0]],scope.pinobj.chartProperties[i][1]);
                                        //$log.debug(scope.pinobj.chartProperties[i]);
                                    }
                                    */
                                    //$log.debug(scope.pinobj.defaultParamStr);
                                    //$log.log(scope.pinobj.chartProperties);
                                    scope.pinobj.paramStr = scope.getParamString();

                                    if(scope.pinobj.chartType == "Label"){
                                        //var param = scope.pinobj.paramStr
                                        // if (param == undefined) {
                                        //     param = "";
                                        // }


                                        var paramStr = commonUtils.parseParams(angular.copy(scope.pinobj.paramStr));

                                        url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + paramStr + '&outputIndexId=1';
                                        var data = commonUtils.readJSONFile(url); 
                                        if(data.resultset.length > 1){
                                            alert("Datasource should be single valued. It has multiple value");
                                            return
                                        }
                                            
                                    }
                                    if(scope.pinobj.chartType=="Table"){
                                        scope.isTable = true;
                                    }
                                    else{
                                        scope.isTable = false;
                                    }   

                                    $log.debug("scope.pinobj.defaultParamStr "+scope.pinobj.defaultParamStr);
                                    scope.pinobj.render(scope.pinobj.defaultParamStr);
                                }
                            }   

                            commonUtils.savedFlag = false;
                            commonUtils.safeApply(scope,function(){});
                            //scope.pinobj.getJson();
                            dialogItself.close();
                            
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : 'Close',
                        action : function(dialogItself) {
                            dialogItself.close();
                            
                            //console.log(commonUtils.datasourceData)
                        },
                        cssClass : 'btn-default btn-lg btn-danger'
                    }]
                })
            }

 
            scope.pinComments = function(){
                scope.username = commonUtils.username;
                //$log.log(scope.pinobj.comments);
                BootstrapDialog.show({
                    title : 'Comments - '+scope.pinobj.title,
                    message : function(dialog) {
                        var $message = $('<div style="overflow:auto;"></div>');
                        //var pageToLoad = scope.pageToLoad;
                        var template =  '<div class="modal-form"><div id="comment-area" class="form-control comment-display"></div><div class="form-group comment-input">'+
                                        '<div class="col-lg-11 col-md-11 col-sm-11 comment-input-left">'+
                                            '<textarea id="comment" class="form-control textarea comment-textarea" ng-model="comment" style="height:68px"/></div>'+
                                        '<div class="col-md-1 col-lg-1 col-sm-1" style="padding-left:0px;">'+
                                            '<button class="btn btn-md btn-blue comment-send" title="Make comment" ng-click="makeComment()"><i class="glyphicon glyphicon-send"></i></button>'+
                                        '</div></div>';

                        //'<div class="modal-form"><div class="col-md-12 comment-search"><div class="c-search c-seach-icon col-md-1"><i class="glyphicon glyphicon-search"></i></div><div class="c-search col-md-11"><input type="text" class="form-control c-search-input" /></div></div>'+
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    closable : true,
                    cssClass : 'width500',
                    onshown : function(dialogRef){

                        scope.addComment = function(username,comment,date,time,repeat,sameDate,owner){
                            var addNewComment = '';
                            //$log.log(sameDate);

                            if(!sameDate){
                                addNewComment +='<div class="comment-date">'+date+'</div>';
                            }


                            if(owner){
                                if(!repeat)
                                    addNewComment = addNewComment+'<div class="comment-user">You</div>';
                                
                                addNewComment = addNewComment+ '<div class="comment-comment"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                            }
                            else{
                                if(!repeat)
                                    addNewComment = addNewComment+'<div class="comment-user-v">'+username+'</div>'
                                addNewComment = addNewComment + '<div class="comment-comment-v"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                            }
                            $('#comment-area').append(addNewComment);

                        }

                        scope.makeComment = function(){
                            
                            if(scope.comment == undefined || scope.comment.length < 1){
                                return;
                            }


                            var d = new Date();
                            var day = d.getDate();
                            var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                            var month = months[d.getMonth()];
                            var year = d.getFullYear();
                            var hour = d.getHours();
                            var format = "am"
                            var mins = d.getMinutes();
                            if(mins.toString().length == 1){
                                mins = '0'+mins;
                            }

                            if(hour>12){
                                hour-=12;
                                format = 'pm';
                            }
                            var date = month+' '+day+','+year;
                            var time = hour+':'+mins+' '+format;

                            var repeat = false;
                            var sameDate = false;
                            var owner = true;
                            var username = scope.username;
                            var comment = $.trim(scope.comment);
                            //$log.log(comment);

                            scope.pinobj.comments.push([scope.username,comment,date,time]);
                            var len = scope.pinobj.comments.length;

                            if(len>1 && (scope.pinobj.comments[len-1][2]== scope.pinobj.comments[len-2][2])){
                                sameDate = true;
                            }

                            if(sameDate && len>1 && (scope.pinobj.comments[len-1][0]== scope.pinobj.comments[len-2][0])){
                                repeat = true;
                            }
                            
                            scope.addComment(scope.username,comment,date,time,repeat,sameDate,owner);


                            if(scope.pinobj.commentsCount=='')
                                scope.pinobj.commentsCount=1;
                            else if(isNaN(scope.pinobj.commentsCount) || scope.pinobj.commentsCount==10)
                                scope.pinobj.commentsCount='10+';
                            else
                                scope.pinobj.commentsCount++;
                            
                            //var addNewComment = '<div class="comment-user">'+username+'</div><div class="comment-comment"><pre>'+comment+'</pre></div>';
                            //$('#comment-area').append(addNewComment);
                            
                            scope.comment = "";
                            $('#comment').focus();
                            commonUtils.savedFlag = false;

                            var mode = commonUtils.getParameterByName("mode").split("?")[0];
                            //$log.log(commonUtils.getParameterByName("mode").split("?")[0]);

                            if("generatedContent"==mode && commonUtils.mode == 'pinboard'){
                                pinboard.saveConfigToFile();
                            }
                            else if("generatedContent"==mode && commonUtils.mode == 'pin'){
                                scope.pinobj.saveConfigToFile();   
                            }
                            commonUtils.safeApply(scope,function(){});

                            $log.log(scope.pinobj.comments);
                        }


                        $('#comment').focus();
                        for(var i=0;i<scope.pinobj.comments.length;i++){
                            var repeat = false;
                            var sameDate = false;
                            var owner = false;


                            if(i>0 && (scope.pinobj.comments[i][2]== scope.pinobj.comments[i-1][2])){
                                //$log.log(scope.pinobj.comments[len-1][2]+" "+scope.pinobj.comments[len-2][2])   
                                sameDate = true;
                            }
                            

                            if(sameDate && i>0 && (scope.pinobj.comments[i][0]== scope.pinobj.comments[i-1][0]))
                                repeat = true;
                            
                            if(scope.pinobj.comments[i][0]==scope.username)
                                owner = true;

                            scope.addComment(scope.pinobj.comments[i][0],scope.pinobj.comments[i][1],scope.pinobj.comments[i][2],scope.pinobj.comments[i][3],repeat,sameDate,owner);

                            //var addOldComments = '<div class="comment-user-v">'+scope.pinobj.comments[i][0]+'</div><div class="comment-comment-v"><pre>'+scope.pinobj.comments[i][1]+'</pre></div>';
                            //$('#comment-area').append(addOldComments);
                        }                       
                    }
                });
            }
            scope.colorNames = {'panel-red1':'Wine Red','panel-red2':'Cherry Red','panel-red3':'Imperial Red','panel-red4':'Pure Red','panel-red5':'Orange Red','panel-orange1':'Orange','panel-orange2':'Spanish Orange','panel-orange3':'Amber','panel-orange4':'Peachy Orange','panel-orange5':'Apricot',
                                'panel-yellow1':'Sunglow','panel-yellow2':'Gold','panel-yellow3':'Honey','panel-yellow4':'Marigold','panel-yellow5':'Lemon Yellow','panel-green1':'Winter Teal','panel-green2':'Sea Green','panel-green3':'Frost Green','panel-green4':'Fresh Grass','panel-green5':'Lemon Green',
                                'panel-blue1':'Navy Blue','panel-blue2':'Spanish Blue','panel-blue3':'Royal Blue','panel-blue4':'Azure','panel-blue5':'Sky Blue','panel-violet1':'Russian Violet','panel-violet2':'Spanish Violet','panel-violet3':'Purple','panel-violet4':'Lavender Purple','panel-violet5':'Orchid',
                                'panel-grey1':'Charcoal','panel-grey2':'Arsenic','panel-grey3':'Grey','panel-grey4':'Pastel Grey','panel-grey5':'Silver'
                                };

            scope.setHeaderColor = function(){
                BootstrapDialog.show({
                    title:'Set Header Color',
                    message: function(dialog) {
                        var $message = $('<div></div>');
                        var template = commonUtils.getHtmlContent('component/templates/chart/setHeaderColor.html');
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    cssClass:'width542',
                    onshown:function(dialogRef){
                        /*
                        $('.colorPallete').on('click',function(){
                            $log.log(this.id);
                            $('.colorPreview').addClass('panel-'+this.id);
                        })
                        */
                        var colorname = 'red1'
                        //$log.log(scope.colorNames['panel-'+colorname]);
                        $log.log(scope.pinobj.pinHeaderColor)
                        scope.previewColor = scope.pinobj.pinHeaderColor;
                        scope.colorLabel = scope.colorNames[scope.pinobj.pinHeaderColor];

                        scope.setPreview = function(color){
                            scope.previewColor = 'panel-'+color;
                            scope.colorLabel = scope.colorNames['panel-'+color];
                            scope.pinobj.pinHeaderColor = scope.previewColor;
                        }

                        scope.setColor = function(){
                            dialogRef.close();
                            scope.pinobj.pinHeaderColor = scope.previewColor;
                        }
                        commonUtils.savedFlag = false;
                        commonUtils.safeApply(scope,function(){});
                    }
                });
                
            }

            scope.exportPng = function(){
                //$log.log(scope.pinobj)
                //alert(scope.pinobj.htmlObj);

                var width = $('#'+scope.pinobj.htmlObj+'_chart').width();
                if(width < 450 ){
                    widthclass= 'width450';
                }
                else if(width>449 && width <700){
                    widthclass= 'width700';
                }
                else if(width >699 && width <1000){
                    widthclass= 'width1000';
                }
                else if(width >999 && width < 1400){
                    widthclass= 'width1400';
                }
                else{
                   widthclass= 'width1600'; 
                }

                $('#'+scope.pinobj.htmlObj+'_chart div').remove();
                var xml = $('#'+scope.pinobj.htmlObj+'_chart').html();
                //$log.log($('#'+scope.pinobj.pinId+'_chart svg').length)
                

                if($('#'+scope.pinobj.htmlObj+'_chart svg').length){
                    BootstrapDialog.show({
                        title:'Png Export',
                        message: function(dialog) {
                            var $message = $('<div align="center"></div>');
                            var template = '<div><canvas id="chart_png"></canvas></div><button class="btn btn-default" ng-click="getPng()">Export</button><!--<button class="btn" ng-click="setWidth()">width</button>--><div class="cl">&nbsp;</div>'
                            //$message.load(pageToLoad);
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        cssClass : widthclass,
                        onshown:function(dialogRef){
                            /*
                            $('.colorPallete').on('click',function(){
                                $log.log(this.id);
                                $('.colorPreview').addClass('panel-'+this.id);
                            })
                            */
                            $log.log(xml)
                            canvg(document.getElementById('chart_png'), xml);
                            // var test = document.getElementById('pinbPreview')
                            // console.log(test);
                            // html2canvas( test, {
                            //   onrendered: function(canvas) {
                            //     document.body.appendChild(canvas);
                            //     $('#chart_png').after(canvas);
                            //   }
                            // });


                            //commonUtils.safeApply(scope,function(){});



                            scope.setWidth = function(){
                                //var c = document.getElementById('chart_png');
                                //c.width= 500;
                                $('#chart_png').css('width','500px');
                            }
                            scope.getPng = function(){

                                var  canvas = document.getElementById('chart_png');
                                var a = document.createElement('a');
                                a.download = "image.png";
                                a.href = canvas.toDataURL('image/png');
                                document.body.appendChild(a);
                                dialogRef.close();

                                a.click();
                                a.remove();

                            }


                            //var canvas = document.getElementById('chart_png');
                            //$log.log(canvas.toDataURL('image/png'));
                            

                        }
                    });
                }                
            }

            //scope.commentCount = 2;

            scope.export = function(extension){
                var paramStr = commonUtils.parseParams(angular.copy(scope.pinobj.paramStr));

                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + paramStr + '&outputIndexId=1&outputType='+extension;

                window.open(url);
                // var data = commonUtils.readJSONFile(url);
                // //$log.log(data);
                // JSONToCSVConvertor(data.metadata,data.resultset, scope.pinobj.title+scope.pinobj.paramValStr, false,extension);
                 $('#exportToggle').collapse(true);
                               
            };


            scope.minimize = false;
            scope.minimizeClick = function(){
                $log.log(scope.idd);
                if($('#'+scope.idd).hasClass("collapse in"))
                    scope.minimize = true;

                else{
                    scope.pinobj.render(scope.pinobj.defaultParamStr);
                    scope.minimize = false;
                }
            }

            scope.zoom = function(){
                var width = $(window).width();
                var height = $(window).height();


                width = width - 50;
                height = height - 200;      
                //console.log(width);

                BootstrapDialog.show({
                    title: this.pinobj.title,
                    message: function(dialog) {
                        var $message = $('<div align="center"></div>');
                        var template = '<div id="open_modal" style="overflow:auto;"></div><div class="cl">&nbsp;</div>'
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    onshown:function(dialogRef){
                        // var propIdx,rowVal;
                        // console.log(scope.pinobj.chartType)
                        // if(scope.pinobj.chartType=="Table"){
                        //     for(var i=0;i<scope.pinobj.chartProperties.length;i++){
                        //         if(scope.pinobj.chartProperties[i][0]=="noOfRows"){
                        //             propIdx = i;
                        //             rowVal = scope.pinobj.chartProperties[i][3];

                        //             scope.pinobj.chartProperties[i][3] = "150";
                        //         }
                        //     }
                        // }
                        $(".modal-dialog").css("width",width+"px");
                        $("#open_modal").css("height",height+"px");
                        //$("#open_modal").css("overflow","auto");
                        scope.pinobj.render(scope.pinobj.paramStr,"open_modal",true);
                        commonUtils.safeApply(scope,function(){});

                        // if(scope.pinobj.chartType=="Table"){
                        //     scope.pinobj.chartProperties[propIdx][3] = rowVal;
                        // }

                    }
                });
            }
            
            var currentSaiku;
            scope.showSaiku = false;

            if(scope.pinobj.chartType=="Saiku"){
                scope.showSaiku = scope.preview ? true : false; 
                currentSaiku = scope.pinobj.visualization;
                scope.pinobj.currentSaiku = scope.pinobj.visualization;
            }
            
            scope.swapData = function(){
                console.log(currentSaiku);
                if(scope.pinobj.currentSaiku != "table"){
                    scope.pinobj.currentSaiku = 'table';
                    scope.pinobj.render(scope.pinobj.defaultParamStr,scope.pinobj.htmlObj);
                }
                else{
                    scope.pinobj.currentSaiku = scope.pinobj.visualization;
                    scope.pinobj.render(scope.pinobj.defaultParamStr);   
                }
            }

            scope.refreshPin = function(){
                //console.log("refresh pin")
                for(var i=0;i<pinboard.pinLists.length;i++){
                    if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                        scope.pinobj.height = pinboard.pinLists[i].height * 70 - 10 - 38;
                }
                //console.log(scope.pinobj.height)
                //console.log(pinboard.pinLists[0]);
                scope.pinobj.render(scope.pinobj.paramStr);
                commonUtils.savedFlag = false;
            }

            
            
            scope.condFomrat = function(){
                
                scope.dataHeaders = [];
                var temp = commonUtils.getDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,"data").metadata;

                angular.forEach(temp,function(v,i){
                    if(v.colType=="Numeric" ||v.colType=="Integer")
                        scope.dataHeaders.push(v.colName);
                })
                console.log(scope.dataHeaders);

                if(scope.pinobj.conditions.length==0){
                    scope.conditions = [{
                                        "column":scope.dataHeaders[0],
                                        "cond":"<",
                                        "val1":"1000",
                                        "val2":"2000",
                                        "color":"red",
                                        "isBetween":false
                                    }];
                }
                else{
                    scope.conditions = angular.copy(scope.pinobj.conditions);
                }
                

                var mydata =BootstrapDialog.show({
                    title: "Conditional Formatting",
                    message: function(dialog) {
                        var $message = $('<div align=center></div>');

                        var template = commonUtils.getHtmlContent('component/templates/chart/conditionalFormat.html')
                        
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    draggable: true,
                    closable : false,
                    cssClass : 'width700',
                    onshown: function(dialogRef){
                        console.log(scope.conditions)
                        scope.addCondition = function(){
                            var temp = {
                                        "column":scope.dataHeaders[0],
                                        "cond":"<",
                                        "val1":"1000",
                                        "val2":"2000",
                                        "color":"red",
                                        "isBetween":false
                                    }
                            scope.conditions.push(temp);
                        }

                        scope.removeCond = function(i){
                            scope.conditions.splice(i,1)
                        }

                        scope.condChange = function(a,b){
                            console.log(a);
                            if(a.cond=="><")
                                a.isBetween = true;
                            else
                                a.isBetween = false;
                            
                        }

                        commonUtils.safeApply(scope,function(){});
                    },

                    buttons: [{
                        label: 'Apply',
                        cssClass: 'btn-primary',
                        action: function(dialogItself){
                            scope.pinobj.conditions = angular.copy(scope.conditions)
                            console.log(scope.pinobj.conditions)
                            dialogItself.close();
                            scope.pinobj.render(scope.pinobj.defaultParamStr);
                            commonUtils.savedFlag = false;
                        },
                            
                    },
                    {
                        label: 'Cancel',
                        action: function(dialogItself){
                            dialogItself.close();
                            //onCancel();
                        },
                        cssClass: 'btn-danger'
                    }]
                });
            }

            scope.showExpOpt = false;
            scope.exportOver = function(){
                scope.showExpOpt = true;
            }
            scope.exportLeave = function(){
                scope.showExpOpt = false;   
            }

            scope.iconPreview = scope.preview;
            if(!scope.pinobj.dataSource){
                scope.iconPreview = false;
                scope.showExport = false;
            }

            //scope.pngExpEnable = false;
            scope.iscccChart = false;
            scope.isLabel = false;
            scope.isTable = false;
            if(scope.pinobj.chartType=="CCC"){
                //scope.pngExpEnable = true;
                scope.iscccChart = true;
            }
            else if(scope.pinobj.chartType=="Label"){
                scope.isLabel = true;
            }
            else if(scope.pinobj.chartType=="Table"){
                scope.isTable = true;
            }

            
            scope.editTitle = function(){
                scope.editOn = true;
                //$(".pin-header").focus();
            }

            scope.hideEditTitle = function(){
                scope.editOn=false;
            }


            $log.debug(scope.pinobj.pinHeaderColor);
            var html = '<div class="panel pin font{{pinobj.pinFontColor}}">';   

            if(commonUtils.editor){
                html = html+'<div class="panel-heading clearfix {{pinobj.pinHeaderColor}}" >';
            }
                

            else if(scope.preview)
                html = html+'<div class="panel-heading clearfix  {{pinobj.pinHeaderColor}}" ng-show={{pinobj.isHeader}}>';

                html = html+'<div class="col-md-7 panel-title" style="padding-left:0px;">';
                            //'<div class="col-md-2 col-sm-2 col-xs-2 pin-icon"><i class="{{pinobj.pinIcon}}" ng-click="setPinIcon()"></i></div>';
                            //'<div class="col-md-2 col-sm-2 col-xs-2 pin-icon"></div>';

            if(commonUtils.editor)
                
                html = html +'<div class="col-md-9 col-sm-7 col-xs-6"><a class="pinTitle" ng-hide="editOn">{{pinobj.title}}</a><i class="editTitleIcon fa fa-pencil" ng-hide="editOn" ng-click="editTitle()"></i><input type="text" class="pin-header form-control" ng-model="pinobj.title" ng-if="editOn" ng-blur="hideEditTitle()"/> </div>';
            else if(scope.preview)
                html = html +'<div class="col-md-9 col-sm-7 col-xs-6 pin-header">{{pinobj.title}}</div>';

            //    html = html +'<h3 id="pinTitle" class="panel-title pull-left" style="padding-top: 3px;padding-bottom:3px;">'+
              //                  '<i class="{{pinobj.pinIcon}}" ng-click="setPinIcon()"></i>'+
                //                '&nbsp;{{pinobj.title}}</h3>';

                html = html +'</div>' +
                            '<div class="btn-group pull-right">' +
                                //'<button id="export_png"  ng-if=editor class="btn btn-xs btn-default" ng-click="exportPng()" title="Png" ng-hide="minimize"><i class="fa fa-minus"></i></button>' +
                                '<button id="panel_color"  ng-if=editor class="btn btn-xs btn-default" ng-click="setHeaderColor()" title="Set Color" ng-hide="minimize"><i class="fa fa-paint-brush"></i></button>' +
                                '<button id="panel_refresh"  ng-if=editor class="btn btn-xs btn-default" ng-click="refreshPin()" title="Refresh" ng-hide="minimize"><i class="fa fa-refresh" aria-hidden="true"></i></button>' +
                                '<button id="panel_condFormat"  ng-if=editor class="btn btn-xs btn-default" ng-click="condFomrat()" title="Conditional Formatting" ng-show=isTable ><i class="fa fa-table" aria-hidden="true"></i></button>' +
                                '<button id="Panel_Properties"  ng-if=editor class="btn btn-xs btn-default" ng-click="chartProperties()" title="Pin Settings" ng-hide="minimize"><i class="glyphicon glyphicon-cog"></i></button>' +
                                '<button id="panel_zoom" class="btn btn-xs btn-default" ng-click="zoom()" title="Zoom" ng-show=iconPreview ng-if=!'+scope.isLabel+'><i class="fa fa-arrows-alt"></i></button>' +
                                '<button id="Panel_Comment" class="btn btn-xs btn-default" ng-click="pinComments()" title="Comments" ng-show=iconPreview><i class="glyphicon glyphicon-comment"></i><div class="comment-count">{{pinobj.commentsCount}}</div></button>' +
                                //'<button id="Panel_Minimize" ng-if="pinobj.minimize" class="btn btn-xs btn-default" data-target="#{{idd}}" data-toggle="collapse" title="Minimize" ng-click="minimizeClick()" ng-show=iconPreview><i class="glyphicon glyphicon-minus"></i></button>' +
                                '<div class="dropdown dropdown-setting" ng-show=iconPreview ng-if=!'+scope.isLabel+'>'+
                                    '<button id="dLabel1" type="button" title="settings" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-xs btn-default">'+
                                        '<i class="fa fa-cog"></i></button>'+
                                    '<ul class="dropdown-menu" aria-labelledby="dLabel1">'+
                                        //'<li ng-click="zoom()" ng-show=iconPreview><a href="#">Zoom</a></li>'+
                                        '<li ng-click="swapData()" ng-show=showSaiku><a href="#">Swap to Data</a></li>'+
                                        '<li ng-show=showExport ng-mouseover="exportOver()" ng-mouseleave="exportLeave()"><a href="#">Export ></a>'+
                                            '<ul ng-show="showExpOpt">'+
                                                '<li ng-click="export(\'csv\')">CSV</li>'+
                                                '<li ng-click="export(\'xls\')">XLS</li>'+
                                                '<li ng-click="exportPng()" ng-show="iscccChart">PNG</li>'+
                                            '</ul>'+                                       
                                        '</li>'+
                                        //'<li ng-if="pinobj.minimize" data-target="#{{idd}}" data-toggle="collapse" ng-click="minimizeClick()" ng-show=iconPreview><a href="#">Minimize</a></li>'+
                                    //'<li class="last"><a href="#">.pdf</a></li>'+
                                    '</ul></div>' +
                            '</div>' +
                        '</div>'+
                        '<div id="{{idd}}" class="panel-body collapse in" style="padding:0;"> '+
                            '<div id="{{pinobj.htmlObj}}" class="pin_body" style="width:100%; height:{{pinobj.height}}px;">'+
                                // '<div id="{{pinobj.htmlObj}}_chart" style="width:{{pinobj.width}}%; height:{{pinobj.height}}px;"></div>' +
                                // '<canvas id="{{pinobj.htmlObj}}_canvas" style="width:{{pinobj.width}}%; height:{{pinobj.height}}px;display:none;"></canvas>'
                            '</div>' +
                        '</div>' +
                    '</div>' 

            element.html(html);
            $compile(element.contents())(scope);
        }
    }
}]);