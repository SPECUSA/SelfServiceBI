angular.module('commonUtilModule',[]);

angular.module('commonUtilModule')
.service('commonUtils',['$http','$log','$compile',function($http,$log,$compile){
    this.debugApplication =true;

    this.mode = "pinboard" //pin/pinboard
    this.isPinboard = true;
    this.editor = true;
    this.savedFlag = false;
    this.savedFileFlag = false;
    this.propertiesSaved = false;
    this.isNull = true;
    this.notificationDelay = 4000;
    this.notificationType = "growl";
    this.components = null;
    var self = this;

    this.version = 3.1;
    this.buildVersion  = 3.1;

    this.CdaUrl = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery';


    this.colorNames = {'panel-red1':'Wine Red','panel-red2':'Cherry Red','panel-red3':'Imperial Red','panel-red4':'Pure Red','panel-red5':'Orange Red','panel-orange1':'Orange','panel-orange2':'Spanish Orange','panel-orange3':'Amber','panel-orange4':'Peachy Orange','panel-orange5':'Apricot',
                    'panel-yellow1':'Sunglow','panel-yellow2':'Gold','panel-yellow3':'Honey','panel-yellow4':'Marigold','panel-yellow5':'Lemon Yellow','panel-green1':'Winter Teal','panel-green2':'Sea Green','panel-green3':'Frost Green','panel-green4':'Fresh Grass','panel-green5':'Lemon Green',
                    'panel-blue1':'Navy Blue','panel-blue2':'Spanish Blue','panel-blue3':'Royal Blue','panel-blue4':'Azure','panel-blue5':'Sky Blue','panel-violet1':'Russian Violet','panel-violet2':'Spanish Violet','panel-violet3':'Purple','panel-violet4':'Lavender Purple','panel-violet5':'Orchid',
                    'panel-grey1':'Charcoal','panel-grey2':'Arsenic','panel-grey3':'Grey','panel-grey4':'Pastel Grey','panel-grey5':'Silver'
                    };



    this.parseParams = function(param){
        console.log(param);
        var paramStr = "";
        for(key in param){
            if(typeof param[key]=="object")
                var values = param[key];
            else
                var values = param[key].split(",");

            //if(values.length>1)
            for(var p=0;p<values.length;p++){
                //values[p] = "\""+values[p]+"\""
                paramStr += '&param'+key+'='+values[p];
            }

            //param[key] = values.join();
            //paramStr += '&param'+key+"="+param[key];

        }
        return paramStr;
    }

    this.datasourceData = [];

    this.getPinsParameter = function(dataSource,dataAccessId){

        var tempParamData = self.getDatasourceData(dataSource,dataAccessId,"parameter");

        console.log(tempParamData)
        if(tempParamData.resultset != void 0){
            tempParamData = tempParamData.resultset;

            var params = [];
            for(var i=0;i<tempParamData.length;i++){
                params.push(tempParamData[i][0])
            }

            console.log(params);
            return params;
        }
        else{
            return [];
        }
            


    }


    this.getDatasourceData = function(dataSource,dataAccessId,selection){
        // for(var i=0;i<pinboard.datasourceData.length;i++){
        //     if(pinboard.datasourceData[i].datasourceFile==dataSource){
        //         for(var j=0;j<pinboard.datasourceData[i].dataAccess.length;j++){
        //             pinboard.datasourceData[i].dataAccess
        //         }
        //     }
                
        // }

        console.log(dataSource);
        console.log(dataAccessId);
        console.log(selection)
        console.log(self.datasourceData);

        var data = null;
        var flag1 = false;
        $.each(self.datasourceData,function(i1,v1){
            if(v1.datasourceFile==dataSource){
                console.log("level 1 passed;")

                $.each(v1.dataAccess,function(i2,v2){
                    console.log(v2)
                    console.log(v2.dataAccessId+"=="+dataAccessId+"--")
                    if(v2.dataAccessId==dataAccessId && v2[selection]!=null){
                        console.log("level 2 passed;")
                        flag1 = true;
                        data = v2[selection];
                        return false;
                    }
                })

                if(flag1)
                    return false;
            }
        })

        if(flag1)
            return data;
        return false;
    }

    this.setDatasourceData = function(dataSource,dataAccessId,data,selection){
        var flag1 = false;
        var flag2 = false;
        var idx1 = null;
        var idx2 = null;

        
        $.each(self.datasourceData,function(i1,v1){
            idx1 = i1;
            if(v1.datasourceFile==dataSource){
                flag1 = true;
                $.each(v1.dataAccess,function(i2,v2){
                    console.log("asd : "+i2)
                    idx2 = i2;
                    if(v2.dataAccessId==dataAccessId){
                        flag2 = true;
                        console.log(i2)
                        return false;
                    }
                    else{
                        idx1 = i1;
                        flag2 = false;
                    }
                })
                if(flag2)
                    return false;
            }
            else{
                flag1 = false;
            }
        });

        if(!flag1){
            var temp = {
                "datasourceFile": dataSource,
                dataAccess : [
                    {
                        "dataAccessId" : dataAccessId,
                        "parameter" : "",
                        "data" : ""
                    }
                ]

            }
            temp.dataAccess[0][selection] = data;

            self.datasourceData.push(temp)
        }
        else if(flag1 && !flag2){
            var temp = {
                "dataAccessId" : dataAccessId,
                "parameter" : "",
                "data" : ""
            }
        
            temp[selection] = data;
            self.datasourceData[idx1].dataAccess.push(temp)
        }
        else if(flag1 && flag2){
            console.log("--")
            console.log(self.datasourceData[idx1].dataAccess[idx2])
            self.datasourceData[idx1].dataAccess[idx2][selection] = data;   
        }

        console.log("flag1 ::"+flag1)
        console.log("flag2 ::"+flag2)

        console.log(self.datasourceData);

    }

    this.getParameterByName = function(name){
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
            results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    };
    this.synchronousJsonCall = function (url, method, data) {
        var jsonData;
        jQuery.ajax({
            url:    url,
            data:   data,
            type :  method,
            DataType:'jsonp',
            success:function(result) {
                jsonData = result;
            },
            async:  false
        });

        return jsonData;
    };

    this.readJSONFile = function (url) {
        var jsonData;
        $.ajax({
            type: 'GET',
            url: url,
            async: false,
            dataType: 'json',
            data: null,
            success:function(response){
                jsonData = response;
            },
            error:function(response){
                jsonData = "";
            }
        })
        console.log(jsonData);
        return jsonData;
    };
    this.getHtmlContent = function(url){
        var htmlData;
        jQuery.ajax({
            url : url,
            data: null,
            async : false,
            type : 'GET',
            success : function(result){
                htmlData = result;
            }
        });
        return htmlData;
    }
    this.getUserName = function(){
        var username;
        jQuery.ajax({
            url:"../../../plugin/SelfServiceBI/api/getUsername",
            type :"GET",
            async:false,
            success:function(result) {
                username = result;
            },
            complete: function (obj,textStatus) {
            //console.log("response::"+obj.responseText);
            }
        });            
        return username;    
    }
    this.username = self.getUserName();
    var saikuSession = self.synchronousJsonCall("../../../plugin/saiku/api/session?_=1460976493562",'GET',null);
    saikuSession = self.synchronousJsonCall("../../../plugin/saiku/api/admin/discover?_=1460370515397",'GET',null);
    //$log.log(self.getUserRole().replace("[","").replace("]","").split(","))
    //$log.log(this.username);

    // function loadjscssfile(filename, filetype){
    //     console.log("ASdsa");
    //     if (filetype=="js"){ //if filename is a external JavaScript file
    //         var fileref=document.createElement('script')
    //         fileref.setAttribute("type","text/javascript")
    //         fileref.setAttribute("src", filename)
    //     }
    //     else if (filetype=="css"){ //if filename is an external CSS file
    //         var fileref=document.createElement("link")
    //         fileref.setAttribute("rel", "stylesheet")
    //         fileref.setAttribute("type", "text/css")
    //         fileref.setAttribute("href", filename)
    //     }
    //     if (typeof fileref!="undefined")
    //         document.getElementsByTagName("head")[0].appendChild(fileref)
    // }
    // var saikuJsFiles = ["../../saiku-ui/js/jquery/jquery.blockUI.js","../../saiku-ui/js/backbone/underscore.js","../../saiku-ui/js/backbone/json2.js","../../saiku-ui/js/backbone/backbone.js","../../saiku-ui/js/saiku/render/SaikuRenderer.js","../../saiku-ui/js/saiku/render/SaikuTableRenderer.js","../../saiku-ui/js/saiku/render/SaikuChartRenderer.js","js/saiku/SaikuEmbed.js"]
    // var saikuCssFiles = ["../../saiku-ui/css/saiku/src/saiku.table.css","../../saiku-ui/embed/saiku.css"];
        

    // if(saikuSession!=undefined){
    //     $.each(saikuJsFiles,function(i,v){
    //         loadjscssfile(v, "js");
    //     })
    //     $.each(saikuCssFiles,function(i,v){
    //         loadjscssfile(v,"css");
    //     })
    // }

    


    


    this.getJson = function(obj){
        return JSON.stringify(obj)
    }
/*
    this.getTableName = function(){
        var tableData;
        $.ajax({
            type: "POST",
            url:"../../../plugin/SelfServiceBI/api/getTableData",
            data:JSON.stringify({
                   "dbType":"MYSQL",
                    "dbUser":"pentaho",
                    "dbPassword":"pentaho",
                    "dbHost":"10.37.55.192",
                    "dbName":"pentahosalesdashboard",
                    "dbPort":"3306" 
             }),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(result,status,xhr) {
                console.log(result);
                tableData = result
                //console.log(result.status);
                //console.log(result.xhr);
            },
            error: function (request, status, errorThrown) {
                alert("Error");
            },
            complete: function (obj,textStatus) {
                //console.log(obj.responseText);
            },
            async : false
            
        });

        return tableData;
    }

    */

    this.getTableName = function(dbtype,dbuser,dbpass,dbhost,dbport,dbname) {
        $log.log(dbtype,dbuser,dbpass);
        var tableName;
            $.ajax({
                type: "POST",
                url:"../../../plugin/SelfServiceBI/api/getTableData",
                data:JSON.stringify({
                    "dbType":dbtype,
                    "dbUser":dbuser,
                    "dbPassword":dbpass,
                    "dbHost":dbhost,
                    "dbPort":dbport,
                    "dbName":dbname
                    
                 }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async : false,
                success: function(result,status,xhr) {
                    tableName = result;
                    //console.log(result );
                    //console.log(result.status);
                    //console.log(result.xhr);
                },

                complete: function (obj,textStatus) {
                    //console.log("response::"+obj.responseText);
                }
            });

        return tableName;
     }       
            
            
    this.getFieldName = function(dbtype,dbuser,dbpass,dbhost,dbport,dbname,schemaName,tableName)
    {
        var param = {
            "dbType":dbtype,
            "dbUser":dbuser,
            "dbPassword":dbpass,
            "dbHost":dbhost,
            "dbPort":dbport,
            "dbName":dbname,
            "tableName":tableName,
            "schemaName":schemaName
        }; 

        var fieldName;
        jQuery.ajax({
            url:"../../../plugin/SelfServiceBI/api/getTableField",
            data:param,
            type :"POST",
            DataType:'json',
            async : false,
            success:function(result) {
                //console.log("result "+result);
                fieldName = result;
            },
            complete: function (obj,textStatus) {
                //console.log("response::"+obj.responseText);
            }
         });
         return fieldName; 
    }

    filePathValidation = function(path,ext){

        if(path == null || path == undefined || path.length <1)
        {
            //return Messanges.onInvalidFileName;
            return false;
        }
        else
        {
            var tempArray = path.split(".");
            if(tempArray.length <2)
                return false;
            else
            {
                var tempExt=tempArray[tempArray.length-1];

                if(tempExt == ext)
                    return true;
                else
                    return false;
            }
        }
    };

    this.saveDialogBox = function(dialogTitle,ext,onSave,onCancel){
        var selectedFile="";
        var selectedFolder="";
        var data=BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog) {
                var $message = $('<div class="modal-form"><div id="container_id" class="JqueryContainer"></div><div class="cl15"></div><div class="form-group"><div class="col-lg-4 col-md-4 col-sm-4 form-group-left">File Name</div><div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><input type="text" name="fileInput" class="form-control" id="fileInput"  value="" /></div></div>'+
                                '<div class="cl5"></div></div><div class="cl"></div>'+
                                '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                                '<span class="sr-only">Error:</span>'+
                                'Please input valid file name' +'</div>');
                return $message;
            },
            draggable: true,
            closable : false,
            cssClass : 'browse-dialog',
            onshown: function(dialogRef)
            {
                $('#container_id').fileTree({
                    root: '/',
                    script: "../../../plugin/SelfServiceBI/api/explore"+ "?fileExtensions="+ ext+"&access=create",
                    expandSpeed: 1000,
                    collapseSpeed: 1000,
                    multiFolder: false
                }, function(file) {
                    $("#fileInput").val(file);
                    selectedFile = $("#fileInput").val();
                });
                // event listeners
                $('#container_id').on('filetreeexpand', function (e, data)
                {
                    selectedFolder = data.rel;
                    $("#fileInput").val(selectedFolder);
                });
            },
            buttons: [{
                id: 'btn-save',
                label: 'Save',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    //var valid = filePathValidation($("#fileInput").val(),ext);
                    var path = $('#fileInput').val();
                    //$log.log(path);
                    /*
                    function isNotAlphaNumeric(code){
                        $log.log(code);
                        if (!(code > 47 && code < 58) && !(code > 64 && code < 91) && !(code > 96 && code < 123))
                          return true;
                        return false;
                    }
                    */
                    var len = path.length;
                    if(path == undefined || path.length < 1 || path.charAt(len-1) == '/'/* || isNotAlphaNumeric(path.charAt(path.length-1)) */){
                        $("#errorMsg").show();
                        return;
                    }
                    var valid = $('#fileInput').val().toLowerCase().search('.'+ext);
                    //$log.log($('#fileInput').val().toLowerCase())
                    //$log.log(valid);

                    if(valid < 0)
                    {
                        dialogItself.close();
                        //$log.log($("#fileInput").val()+'.'+ext);
                        onSave($("#fileInput").val()+'.'+ext);
                    }
                    else
                    {
                        dialogItself.close();
                        onSave($("#fileInput").val());
                    }


                    
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    };

    this.openDialogBox = function(dialogTitle,ext,onSave,onCancel){
        var selectedFile="";
        var selectedFolder="";
        var data=BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog) {
                var $message = $(
                '<div class="modal-form"><div id="container_id" class="JqueryContainer"></div><div class="cl15"></div><div class="form-group"><div class="col-lg-4 col-md-4 col-sm-4 form-group-left">File Name</div><div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><input type="text" name="fileInput" class="form-control" id="fileInput"  value="" /></div></div><div class="cl"></div>'+
                '</div><div class="cl5"></div>'+
                '</div><div class="cl"></div>'+
                '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                    '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                    '<span class="sr-only">Error:</span>'+
                    'Please input valid file name' +'</div>'
                );
                return $message;
            },
            draggable: true,
            closable : false,
            cssClass : 'browse-dialog',
            onshown: function(dialogRef)
            {
                $('#container_id').fileTree({
                    root: '/',
                    script: "../../../plugin/SelfServiceBI/api/explore"+ "?fileExtensions="+ ext+"&access=create",
                    expandSpeed: 1000,
                    collapseSpeed: 1000,
                    multiFolder: false
                }, function(file) {
                    $("#fileInput").val(file);
                    selectedFile = $("#fileInput").val();
                });
                // event listeners
                $('#container_id').on('filetreeexpand', function (e, data)
                {
                    selectedFolder = data.rel;
                    $("#fileInput").val(selectedFolder);
                });
            },
            buttons: [{
                id: 'btn-save',
                label: 'Open',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = filePathValidation($("#fileInput").val(),ext);
                    if(valid)
                    {
                        dialogItself.close();
                        onSave($("#fileInput").val());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    };


    this.comments = function(scope,title,usercomments,commentCount){
        scope.username = self.username;
        //var username = self.username;
        //$log.log(username);
        scope.usercomments = usercomments;
        scope.commentCount = commentCount;
        //$log.log(scope.pinobj.comments);
        BootstrapDialog.show({
            title : 'Comments - '+title,
            message : function(dialog) {
                var $message = $('<div style="overflow:auto;"></div>');
                //var pageToLoad = scope.pageToLoad;
                var template =  '<div class="modal-form"><div id="comment-area" class="form-control comment-display"></div><div class="form-group comment-input">'+
                                '<div class="col-lg-11 col-md-11 col-sm-11 comment-input-left">'+
                                    '<textarea id="comment" class="form-control textarea" ng-model="comment" style="height:68px"/></div>'+
                                '<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1" style="padding-left:0px;">'+
                                    '<button class="btn btn-md btn-blue comment-send" title="Make comment" ng-click="makeComment()"><i class="glyphicon glyphicon-send"></i></button>'+
                                '</div></div>';

                //'<div class="modal-form"><div class="col-md-12 comment-search"><div class="c-search c-seach-icon col-md-1"><i class="glyphicon glyphicon-search"></i></div><div class="c-search col-md-11"><input type="text" class="form-control c-search-input" /></div></div>'+
                $message.append($compile(template)(scope));
                return $message;
            },
            closable : true,
            cssClass : 'width500',
            onshown : function(dialogRef){

                scope.addComment = function(username,comment,date,time,repeat,sameDate,owner){
                    var addNewComment = '';
                    //$log.log(sameDate);

                    if(!sameDate){
                        addNewComment +='<div class="comment-date">'+date+'</div>';
                    }


                    if(owner){
                        if(!repeat)
                            addNewComment = addNewComment+'<div class="comment-user">You</div>';
                        
                        addNewComment = addNewComment+ '<div class="comment-comment"><pre>'+comment+'</pre><span class="comment-time">'+time+'</span></div>';
                    }
                    else{
                        if(!repeat)
                            addNewComment = addNewComment+'<div class="comment-user-v">'+username+'</div>'
                        addNewComment = addNewComment + '<div class="comment-comment-v"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                    }
                    $('#comment-area').append(addNewComment);

                }

                scope.makeComment = function(){
                    if(scope.comment == undefined || scope.comment.length < 1){
                        return;
                    }


                    var d = new Date();
                    var day = d.getDate();
                    var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                    var month = months[d.getMonth()];
                    var year = d.getFullYear();
                    var hour = d.getHours();
                    var format = "am"
                    var mins = d.getMinutes();
                    if(mins.toString().length == 1){
                        mins = '0'+mins;
                    }

                    if(hour>12){
                        hour-=12;
                        format = 'pm';
                    }
                    var date = month+' '+day+','+year;
                    var time = hour+':'+mins+' '+format;

                    var repeat = false;
                    var sameDate = false;
                    var owner = true;
                    var username = scope.username;
                    var comment = $.trim(scope.comment);
                    //$log.log(comment);

                    scope.usercomments.push([scope.username,comment,date,time]);
                    var len = scope.usercomments.length;

                    if(len>1 && (scope.usercomments[len-1][2]== scope.usercomments[len-2][2])){
                        sameDate = true;
                    }

                    if(sameDate && len>1 && (scope.usercomments[len-1][0] == scope.usercomments[len-2][0])){
                        repeat = true;
                    }
                    
                    scope.addComment(scope.username,comment,date,time,repeat,sameDate,owner);

                    if(scope.commentCount == undefined)
                        scope.commentCount = scope.usercomments.length;

                    if(scope.commentCount=='')
                        scope.commentCount=1;
                    else if((isNaN(scope.commentCount) && scope.usercomments.length >10) || scope.commentCount>=10)
                        scope.commentCount='10+';
                    else if(isNaN(scope.commentCount) && scope.usercomments.length <11)
                        scope.commentCount = scope.usercomments.length;                        
                    else
                        scope.commentCount++;
                    /*
                    var addNewComment = '<div class="comment-user">'+username+'</div><div class="comment-comment"><pre>'+comment+'</pre></div>';
                    $('#comment-area').append(addNewComment);
                    */
                    scope.comment = "";
                    $('#comment').focus();
                    self.savedFlag = false;
                    //$log.log(scope.commentCount)

                    //var mode = self.getParameterByName("mode").split("?")[0];
                    //$log.log(commonUtils.getParameterByName("mode").split("?")[0]);


                    self.safeApply(scope,function(){});

                    //$log.log("make comment");
                }


                $('#comment').focus();
                for(var i=0;i<scope.usercomments.length;i++){
                    var repeat = false;
                    var sameDate = false;
                    var owner = false;


                    if(i>0 && (scope.usercomments[i][2]== scope.usercomments[i-1][2])){
                        //$log.log(scope.pinobj.comments[len-1][2]+" "+scope.pinobj.comments[len-2][2])   
                        sameDate = true;
                    }
                    

                    if(sameDate && i>0 && (scope.usercomments[i][0]== scope.usercomments[i-1][0]))
                        repeat = true;
                    
                    if(scope.usercomments[i][0]==scope.username)
                        owner = true;

                    scope.addComment(scope.usercomments[i][0],scope.usercomments[i][1],scope.usercomments[i][2],scope.usercomments[i][3],repeat,sameDate,owner);

                    //var addOldComments = '<div class="comment-user-v">'+scope.pinobj.comments[i][0]+'</div><div class="comment-comment-v"><pre>'+scope.pinobj.comments[i][1]+'</pre></div>';
                    //$('#comment-area').append(addOldComments);
                }                       
            }
        });
    }


    this.BootstrapConfirm = function(msg,userResult){
        //$log.log(msg);
        //$log.log("hey there")
        BootstrapDialog.confirm({
            title: 'Confirmation',
            message: msg,
            closable: true, // <-- Default value is false
            btnCancelClass: 'btn-defaul btn-lg btn-danger', // <-- If you didn't specify it, dialog type will be used,
            callback: function(result) {
                userResult(result);
            }
        });
    };

    this.removeElements = function (text, selector) {
        var wrapped = $("<div>" + text + "</div>");
        wrapped.find(selector).remove();
        return wrapped.html();
    };

     this.btnPinSaikuBrowse = function(title,ext,fileTxtbox,getData){
        var self = this;

        function onOpen(path){
           getData(path);
        }
        function onCancel(dialogItself){}
        this.openDialogBox(title,ext,onOpen,onCancel);
    };

    this.colorDialog = function(dialogTitle,colorArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);

                var template =  '<div class="colorTableWrapper">'+
                                '<div id="colorTable">'+
                                '</div>'+
                                '<div class="form-inline"><div class="label label-add-color">Add Color </div>'+
                                '<input class="form-control" type="text" id="inputColor" ng-model="inputColor" colorpicker="hex">'+
                                '<button class="btn btn-default" id="addColor" ng-click="addColor()"><i class="glyphicon glyphicon-plus"></i></button></div>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'color-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                var length = colorArray.length;
                if(colorArray.length != 0){
                    for(i=0;i<colorArray.length;i++){

                        var temp =  '<div id="row'+i+'" class="form-inline" style="padding-bottom:5px;">'+
                                    '<input colorpicker="hex" colorpicker-with-input="true" class="form-control colorText" type="text" id="colorRow'+i+'"  ng-model="colorRow'+i+'" ng-change="colorChanged('+i+')"/>'+
                                    '<button class="btn btn-sm btn-default glyphicon glyphicon-remove removeColorEvent removeParam" style="margin-left:5px;" ng-click="removeColor('+i+')"></button><div class="showColor" id="showColor'+i+'" style="background-color:{{colorRow'+i+'}}"></div></div>'
                        $('#colorTable').append($compile(temp)(scope));
                        var vari = 'colorRow'+i ;
                        scope[vari] = colorArray[i];
                    };
                }

                scope.addColor = function(){
                    if(scope.inputColor == undefined || scope.inputColor.length <= 0){
                        return
                    }
                    $log.debug("this is add color called");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<div id="row'+l+'" class="form-inline" style="padding-bottom:5px;">'+
                                '<input colorpicker="hex" colorpicker-with-input="true" class="form-control colorText" type="text" id="colorRow'+l+'"  ng-model="colorRow'+l+'" ng-change="colorChanged('+l+')"/>'+
                                '<button class="btn btn-sm btn-default glyphicon glyphicon-remove removeColorEvent removeParam" style="margin-left:5px;" ng-click="removeColor('+l+')"></button><div class="showColor" id="showColor'+l+'" style="background-color:{{colorRow'+l+'}}"></div></div>'
                    $('#colorTable').append($compile(temp)(scope));
                    var vari = 'colorRow'+l ;
                    scope[vari] = scope.inputColor;
                    scope.inputColor = "";
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeColor = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    colorArray = [];
                    $('.colorText').each(function(i, obj) {
                        colorArray.push($(this).val());
                    });
                    dialogItself.close();
                    onOk(colorArray);
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
    }
    
    this.outputOptDialog = function(dialogTitle,indexArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="outputOpt" style="text-align:center;">'+
                                '<tr><td>Index</td><td></td></tr>'+
                                '<tr class="form-inline inputRow indexRow"><td><input class="form-control" type="text" ng-model="inputIndex"></td>'+
                                '<td><button class="btn btn-default btn-xs" id="addIndex" ng-click="addIndex()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table></div>';                                
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                //'</div>';
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'outputopt-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.inputIndex = "";
                var length = indexArray.length;
                if(indexArray.length != 0){
                    //$log.log(indexArray.length);
                    for(i=0;i<indexArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline indexRow"><td><input class="form-control" type="text" ng-model="inputIndex'+i+'"></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeIndex('+i+')"></button></td></tr>'
                        $('.inputRow').before($compile(temp)(scope));
                        var vari = 'inputIndex'+i ;
                        scope[vari] = indexArray[i];
                    };
                }

                scope.addIndex = function(){
                    if(scope.inputIndex == undefined || scope.inputIndex.length <= 0){
                        return
                    }
                    $log.debug("this is add color called");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline indexRow"><td><input class="form-control" type="text" ng-model="inputIndex'+l+'"></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeIndex('+l+')"></button></td></tr>'
                    $('.inputRow').before($compile(temp)(scope));
                    var vari = 'inputIndex'+l ;
                    scope[vari] = scope.inputIndex;
                    scope.inputIndex = "";
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeIndex = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    indexArray = [];
                    $('.indexRow').each(function(i, obj) {
                        var indx = (this.id).charAt(3);
                        //$log.log(indx)
                        if((scope['inputIndex'+indx]).length <1){
                            return;
                        }
                        indexArray.push(scope['inputIndex'+indx]);
                    });
                    dialogItself.close();
                    $log.debug(indexArray);
                    onOk(indexArray);
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
    }

/*
    this.javascriptDialog = function(dialogTitle,currentScrpt,onOk,onCancel){
        var resScript="";
        var editor;
        var data=BootstrapDialog.show({
            title: "Javascript Input",
            message: function(dialog) {
                var $message = $('<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                '<span class="sr-only">Error:</span>'+
                ' ' +"Please input valid script." +'</div>'+
                '<textarea id="codedata" name="codedata">' + currentScrpt + ' </textarea>');
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {

                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: "javascript"
                });

            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        dialogItself.close();
                        $log.log(editor.getValue());
                        onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-danger'
                }]
        });
    };
*/


    this.cdaparamDialog = function(dialogTitle,paramArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);
                

                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Name</td><td>Value</td><td>Type</td><td>Private</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName"  ng-model="paramName" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramVal" ng-model="paramVal" /></td>'+
                                '<td><select class="form-control addParam input-sm" ng-model="paramType" ng-options="n for n in paramTypes"></select></td>'+
                                '<td><input class="form-control paramCheck input-sm" type="checkbox" id="isPrivate" ng-model="isPrivate" style="height:13px"/></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: '',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramName = "";
                scope.paramVal = "";
                scope.isPrivate = false;
                scope.paramTypes = ['String','Integer','Numeric','Date','StringArray','IntegerArray','NumericArray','DateArray'];
                scope.paramType = scope.paramTypes[0];
                self.safeApply(scope,function(){});

                var length = paramArray.length;
                if(paramArray.length != 0){
                    for(i=0;i<paramArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'"  ng-model="paramName'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramVal'+i+'" ng-model="paramVal'+i+'" /></td>'+
                                    '<td><select class="form-control input-sm" ng-model="paramType'+i+'" ng-options="n for n in paramTypes"></select></td>'+
                                    '<td><input class="input-sm" type="checkbox" id="isPrivate'+i+'" ng-model="isPrivate'+i+'" style="height:13px"/></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramName'+i ;
                        scope[vari] = paramArray[i][0];
                        vari = 'paramVal'+i;
                        scope[vari] = paramArray[i][1];
                        vari = 'paramType'+i;
                        scope[vari] = paramArray[i][2];
                        vari = 'isPrivate'+i;
                        scope[vari] = paramArray[i][3];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramVal == undefined || scope.paramVal.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'"  ng-model="paramName'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramVal'+l+'" ng-model="paramVal'+l+'" /></td>'+
                                '<td><select class="form-control addParam input-sm" ng-model="paramType'+l+'" ng-options="n for n in paramTypes"></select></td>'+
                                '<td><input type="checkbox" class="form-control addParam input-sm" id="isPrivate'+l+'" ng-model="isPrivate'+l+'" style="height:13px"/></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    vari = 'paramVal'+l;
                    scope[vari] = scope.paramVal;
                    vari = 'paramType'+l;
                    scope[vari] = scope.paramType;
                    vari = 'isPrivate'+l;
                    scope[vari] = scope.isPrivate;
                    scope.paramName = "";
                    scope.paramVal = "";
                    scope.paramType = "String";
                    scope.isPrivate = false;
                    $('#paramName').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    paramArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramName'+index].length <1 || scope['paramVal'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramName'+index],scope['paramVal'+index],scope['paramType'+index],scope['isPrivate'+index]];
                        paramArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(paramArray);
                    onOk(paramArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    }
    this.columnsDialog = function(dialogTitle,columnsArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Index</td><td>Name</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramIndex"  ng-model="paramIndex" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName" ng-model="paramName" /></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'column-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramIndex = "";
                scope.paramName = "";
                self.safeApply(scope,function(){});

                var length = columnsArray.length;
                if(columnsArray.length != 0){
                    for(i=0;i<columnsArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramIndex'+i+'"  ng-model="paramIndex'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'" ng-model="paramName'+i+'" style="width:90%"/></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramIndex'+i ;
                        scope[vari] = columnsArray[i][0];
                        vari = 'paramName'+i;
                        scope[vari] = columnsArray[i][1];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramIndex == undefined || scope.paramIndex.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramIndex'+l+'"  ng-model="paramIndex'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'" ng-model="paramName'+l+'" /></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramIndex'+l;
                    scope[vari] = scope.paramIndex;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    scope.paramIndex = "";
                    scope.paramName = "";
                    $('#paramIndex').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    columnsArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramIndex'+index].length <1 || scope['paramName'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramIndex'+index],scope['paramName'+index]];
                        columnsArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(columnsArray);
                    onOk(columnsArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    };

    this.calcColumnsDialog = function(dialogTitle,columnsArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Name</td><td>Formula</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName"  ng-model="paramName" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramForm" ng-model="paramForm" /></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'column-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramName = "";
                scope.paramForm = "";
                self.safeApply(scope,function(){});

                var length = columnsArray.length;
                if(columnsArray.length != 0){
                    for(i=0;i<columnsArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'"  ng-model="paramName'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramForm'+i+'" ng-model="paramForm'+i+'" /></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramName'+i ;
                        scope[vari] = columnsArray[i][0];
                        vari = 'paramForm'+i;
                        scope[vari] = columnsArray[i][1];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramForm == undefined || scope.paramForm.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'"  ng-model="paramName'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramForm'+l+'" ng-model="paramForm'+l+'" /></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    vari = 'paramForm'+l;
                    scope[vari] = scope.paramForm;
                    scope.paramName = "";
                    scope.paramForm = "";
                    $('#paramName').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    columnsArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramName'+index].length <1 || scope['paramForm'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramName'+index],scope['paramForm'+index]];
                        columnsArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(columnsArray);
                    onOk(columnsArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    };

    this.datasourceDialog = function(dialogTitle,selectVal,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);

                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<div style="padding-bottom:5px;"> Database Connection'+
                                '</div>'+
                                '<div class="list-group" id="connection" width="100%">'+
                                '</div>'+
                                //'<div class="alignCenter"><a class="blueLink" onclick="window.parent.executeCommand(\'ManageDatasourcesCommand\')"> Make a new Connection here</a></div>'
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'outputopt-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.selection = [];
                var temp = '';
                var param = {
                    'ts' : '1437031684490'
                }

                var jsonData =self.synchronousJsonCall( '../../../plugin/data-access/api/connection/list',"GET",param);
                 //$log.log(jsonData);
                 
                 //$log.log(jsonData.databaseConnections.length)
                for(i=0;i<jsonData.databaseConnections.length;i++){
                    scope.selection.push(jsonData.databaseConnections[i].name);
                    var connection = jsonData.databaseConnections[i].name.replace(/\s+/g, '');
                    var conn = jsonData.databaseConnections[i].name
                        temp = temp +'<button type="button" class="col-lg-12 col-md-12 col-sm-12 listGroup list-group-item" id="'+connection+'" ng-click="select(\''+connection+'\')" idd="'+conn+'">'+connection+'</button>'  
                }

                scope.select = function(connection){
                    //$log.log("this is clicked");
                    var conn = connection.replace(/\s+/g, '');
                    if($('.listGroup').hasClass('active'))
                        $('.listGroup').removeClass('active');

                    $('#'+conn).addClass('active');
                }

                $('#connection').append($compile(temp)(scope));
                $('#'+selectVal).addClass('active');

            },
            buttons : [{
                label : 'Apply',
                cssClass : 'btn-primary',
                action : function(dialogItself) {
                    
                    scope.selectVal =$('#connection .active').attr("idd");
                    //$log.log(scope.selectVal);
                    var param = {
                        'name' : scope.selectVal
                    }
                    var jsonData =self.synchronousJsonCall( '../../../plugin/data-access/api/connection/get',"GET",param);
                    //$log.log(jsonData);


                    dialogItself.close();
                    onOk(jsonData);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });   
    }
    

    this.codeMirrorDialog = function(mode,currentScrpt,onOk,onCancel,scope){
        var editor;

        if((scope.dbType==undefined || scope.dbType.length <1) && (scope.jndi!= undefined && scope.jndi.length >1)){
            var param ={'name': scope.jndi}
            var data = self.synchronousJsonCall( '../../../plugin/data-access/api/connection/get',"GET",param);
            scope.dbtype = data.databaseType.shortName;
            scope.dbuser = data.username;
            scope.dbhost = data.hostname;
            scope.dbport = data.databasePort;
            scope.dbname = data.databaseName;
        }
        
        scope.queryBuilder = false;

        // if(scope.jndi == undefined || scope.jndi.length<1)
        //     scope.queryBuilder = true;

        var data=BootstrapDialog.show({
            title: mode.charAt(0).toUpperCase()+mode.slice(1)+" Dialog",
            message: function(dialog) {
                var template =  '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                                '<span class="sr-only">Error:</span>'+
                                ' ' +"Please input valid script." +'</div>'+
                                '<textarea id="codedata" name="codedata">' + currentScrpt + '</textarea>'+
                                '<div align="center" style="padding-top:15px;"><button class="btn btn-md btn-blue" ng-click="selectOption()" ng-show="queryBuilder">Query Builder</button>'+
                               // '<button class="btn btn-default btn-lg btn-primary" ng-click="tableData()">Table Data</button>'+
                               // '<button class="btn btn-default btn-lg btn-primary" ng-click="fieldData()">Field data</button>'+
                                '</div>';

                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {
                //$log.log(scope.dbtype+" " +scope.dbuser)
                if(mode=='sql')
                    mode = 'text/x-sql'
                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: mode
                });

                $log.log("query builder");
                //var tableData  = self.getTableName();
                //$log.log(tableData.resultSet);
                if(!scope.queryBuilder){
                    scope.schemaName = '';
                    scope.schemaNames = [];

                    scope.tableName = '';
                    scope.tableNames = [];

                    scope.fieldSelection = {};
                    //scope.fieldNames = [];
                    //scope.fieldName = '';

                    //$log.log(scope.dbtype);
                    //get schema and table details

                    var tableName = self.getTableName(scope.dbtype,scope.dbuser,scope.password,scope.dbhost,scope.dbport,scope.dbname);

                    if(tableName==null){
                        //alert("Please check password for datasource.\nYou require to enter password to user Query Builder functionality");
                        scope.queryBuilder = false;
                        //dialogRef.close();
                        self.safeApply(scope,function(){});
                        return;
                    }
                    else{
                        scope.queryBuilder = true;
                         self.safeApply(scope,function(){});
                    }

                    if(tableName.tableInfo.length == undefined || tableName.tableInfo.length <1){
                        $log.log("this is in this");
                        scope.dtsrcTables = {};
                        scope.dtsrcTables[scope.dbname] = tableName.tableInfo.tableList;
                    }
                    else{
                        scope.dtsrcTables = {};
                        for(var i=0;i<tableName.tableInfo.length;i++)
                            if(tableName.tableInfo[i].tableList != undefined)
                                scope.dtsrcTables[tableName.tableInfo[i].schemaName] = tableName.tableInfo[i].tableList; 
                    }
                    $log.log(scope.dtsrcTables);


                    //set schema and table names
                    for(var key in scope.dtsrcTables)
                        scope.schemaNames.push(key);

                    scope.schemaName = scope.schemaNames[0];
                    scope.tableNames = scope.dtsrcTables[scope.schemaName];
                    scope.tableName = scope.tableNames[0];


                    var fieldName = self.getFieldName(scope.dbtype,scope.dbuser,scope.password,scope.dbhost,scope.dbport,scope.dbname,scope.schemaName,scope.tableName).tablefield;
                    scope.dtsrcField = {};
                    if(fieldName.schemaName == undefined || fieldName.schemaName== "" || fieldName.schemaName=="noSchema")
                        fieldName.schemaName = 'pentahosalesdashboard';
                    scope.dtsrcField[fieldName.schemaName+'.'+fieldName.tableName] = fieldName.tableFieldList;
                    $log.log(scope.dtsrcField);  

                }
                
                scope.commonJoinTables = [];
                scope.joinTables = [];
                scope.joinArea = "";
                // get Field names 
                                  

                //set Field Names        
                

                //scope.fieldNames1 = scope.fieldNames;
                //scope.fieldName1 = scope.fieldNames1[0];

                //$log.log(scope.schemaName)
                //$log.log(scope.schemaNames)
                //$log.log(scope.tableName)
                //$log.log(scope.tableNames)
                //$log.log(scope.fieldName)
                //$log.log(scope.fieldNames)

                scope.selectOption = function(){

                    BootstrapDialog.show({
                        title: "Query Option",
                        message: function(dialog){
                            var $message = $('<div></div>');
                            //var pageToLoad = dialog.getData('pageToLoad');
                            //$message.load(pageToLoad);

                            var template =  '<div style="overflow:auto">'+
                                                '<button class="btn btn-green col-md-12 col-lg-12 col-sm-12" ng-click="simpleQuery()">Simple Query</button>'+
                                                '<button class="btn btn-teal col-md-12 col-lg-12 col-sm-12" ng-click="joinQuery()">Join Query</button>'+
                                            '</div>'+
                                            //'<div class="alignCenter"><a class="blueLink" onclick="window.parent.executeCommand(\'ManageDatasourcesCommand\')"> Make a new Connection here</a></div>'
                                            //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                            '</div>';
                            var $message = $('<div></div>');
                            $message.append($compile(template)(scope));
                            return $message;

                        },
                        closable : true,
                        draggable : true,
                        cssClass: 'outputopt-dialog',
                        onshown : function(dialogRef){
                            scope.simpleQuery = function(){
                                dialogRef.close();
                                scope.simpleQueryBuilder();
                            }

                            scope.joinQuery = function(){
                                dialogRef.close();
                                scope.selectTables();
                            }
                        }
                    });
                }

                scope.simpleQueryBuilder = function(){
                    scope.selectedFields = [];
                    scope.fieldNames = [];
                    scope.fieldName = [];
                    scope.fieldNames = scope.dtsrcField[scope.schemaName+'.'+scope.tableName];
                    scope.queryArea = "";

                    BootstrapDialog.show({
                        title: 'Simple Query Builder',
                        message: function(dialog){
                            var template = self.getHtmlContent('component/templates/datasource/smplQueryBuilder.html');
                            var $message = $('<div></div>');
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        closable : false,
                        draggable : true,
                        cssClass : 'simple-query-builder',
                        onshown : function(dialogRef){

                            //scope.fieldName.push(scope.fieldNames[0]);
                            var fieldCounts = 0;
                            scope.schemaChanged = function(){
                                scope.tableNames = scope.dtsrcTables[scope.schemaName];
                                scope.tableName = scope.tableNames[0];
                                scope.tableChanged();
                            }

                            scope.tableChanged = function(option){
                                //$log.log("this is")
                                var hasField = false;

                                for(var key in scope.dtsrcField){
                                    if(key==scope.schemaName+'.'+scope.tableName){
                                        scope.fieldNames = scope.dtsrcField[scope.schemaName+'.'+scope.tableName];
                                        hasField = true;
                                    }
                                }
                                $log.log(hasField);
                                if(!hasField){
                                    var fieldName = self.getFieldName(scope.dbtype,scope.dbuser,scope.password,scope.dbhost,scope.dbport,scope.dbname,scope.schemaName,scope.tableName).tablefield;
                                    //$log.log(fieldName);
                                    if(fieldName.schemaName == undefined || fieldName.schemaName== "" || fieldName.schemaName=="noSchema")
                                        fieldName.schemaName = 'pentahosalesdashboard';
                                    scope.dtsrcField[fieldName.schemaName+'.'+fieldName.tableName] = fieldName.tableFieldList;
                                    scope.fieldNames = fieldName.tableFieldList;
                                    //$log.log(fieldNames)
                                }

                                fieldCounts = scope.fieldNames.length;
                                //scope.fieldName = scope.fieldNames[0];
                            }
                            
/*
                            scope.$watch('tableName',function(newval,oldval){
                                $log.log(newval);
                                $log.log(oldval);

                                scope.fieldSelection[oldval] = scope.selectedFields;
                                scope.selectedFields = [];

                                if(scope.fieldSelection[newval]!= undefined)
                                    scope.selectedFields = scope.fieldSelection[newval];

                            })
*/
                            self.safeApply(scope,function(){});


//                            scope.moveRight = function(){
                                /*
                                if(scope.fieldSelection[scope.tableName]==undefined){
                                    scope.fieldSelection[scope.tableName] = [];
                                }
                                
                                for(i=0;i<scope.fieldSelection[scope.tableName].length;i++){
                                    if(scope.fieldSelection[scope.tableName][i] == scope.fieldName)
                                        return;
                                }

                                scope.fieldSelection[scope.tableName].push(scope.fieldName)
*/
/*
                                for(i=0;i<scope.selectedFields.length;i++)
                                    if(scope.selectedFields[i] == scope.fieldName)
                                        return;

                                scope.selectedFields.push(scope.fieldName);
                                scope.selectedField = scope.selectedFields[0];

                            }

                            scope.removeField = function(){
                                var temp;
                                for(i=0;i<scope.selectedFields.length;i++)
                                    if(scope.selectedFields[i] == scope.fieldName)
                                        temp = i;

                                scope.selectedFields.splice(temp,1);
                            }
*/
                            scope.queryCreator = function(){
                                $log.log(fieldCounts);
                                $log.log(scope.fieldName.length);
                                var query;
                                if(scope.fieldName.length==fieldCounts){
                                    query ="SELECT * \nFROM "+scope.schemaName+"."+scope.tableName;
                                }
                                else{
                                    query ="SELECT "+scope.fieldName+"\nFROM "+scope.schemaName+"."+scope.tableName;
                                }
                                scope.queryArea = query;
                            }

                            scope.schemaChanged(); 
                        },
                        buttons : [{
                            label : 'Apply',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {
                                editor.setValue(scope.queryArea);
                                dialogItself.close();
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },{
                            label : 'Close',
                            action : function(dialogItself) {
                                dialogItself.close();                                
                            },
                            cssClass: 'btn-default btn-lg btn-danger'
                        }]
                    })
                }

                scope.tableOutput = [];

                scope.selectTables = function(){
                    BootstrapDialog.show({
                        title: 'Select Tables',
                        message: function(dialog){
                            var template = self.getHtmlContent('component/templates/datasource/querySelectTable.html');
                            var $message = $('<div></div>');
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        closable : false,
                        draggable : true,
                        cssClass : 'width700',
                        onshown : function(dialogRef){
                            

                            scope.inputTables = scope.dtsrcTables[scope.schemaName];
                            //scope.inputTable = scope.inputTables[0];

                            scope.outputTables = scope.tableOutput;

                            
                            scope.schemaChanged = function(){
                                scope.inputTables = scope.dtsrcTables[scope.schemaName];
                                //scope.inputTable = scope.inputTables[0];

                                //scope.tableOutput[scope.schemaName] = scope.outputTables;

//                                if(scope.)
                                //scope.outputTables = [];

                                //$log.log(scope.tableOutput);
                            }
                            scope.schemaChanged();
                            self.safeApply(scope,function(){})
/*
                            scope.$watch("schemaName",function(newval,oldval){
                                $log.log(newval);
                                $log.log(oldval);
                                scope.inputTables = scope.dtsrcTables[scope.schemaName];
                                scope.inputTable = scope.inputTables[0];

                                scope.tableOutput[oldval] = scope.outputTables;
*//*
                                if(scope.tableOutput[newval]!= undefined)
                                    scope.outputTables = [];
                                else
                                    scope.outputTables = scope.tableOutput[newval];
*//*
                                $log.log(scope.tableOutput);   
                            })
*/
                            scope.schemaName = scope.schemaNames[0]

                            scope.moveRight = function(){
                                $log.log("this is moverights")
                                if(scope.inputTables.length == 0 || scope.inputTable == undefined || scope.inputTable == "")
                                    return;
                                //var str = scope.inputTable;
                                var isExist = false;
                                for(i=0;i<scope.outputTables.length;i++)
                                    if(scope.outputTables[i] == scope.inputTable){
                                        isExist = true;
                                    }

                                if(!isExist)
                                    scope.outputTables.push(scope.inputTable);
                                /*
                                for(i=0;i<scope.inputTables.length;i++){
                                    if(scope.inputTable == scope.inputTables[i])
                                        temp = i;
                                }
                                */
                                //scope.inputTables.splice(temp,1);
                                //scope.inputTable = scope.inputTables[0]
                                scope.outputTable = scope.outputTables[scope.outputTables.length-1]
                            }

                            scope.removeEntry = function(){
                                $log.log("remove entry")
                                if(scope.outputTables.length == 0)
                                    return;

                                //scope.inputTables.push(scope.outputTable);
                                for(i=0;i<scope.outputTables.length;i++){
                                    if(scope.outputTable == scope.outputTables[i])
                                        temp = i;
                                }
                                
                                scope.outputTables.splice(temp,1);
                                scope.outputTable = scope.outputTables[temp]
                                //scope.inputTable = scope.inputTables[0]   
                            }
/*
                            scope.tableChanged = function(option){
                                var hasField = false;

                                for(var key in scope.dtsrcField){
                                    if(key==scope.schemaName+'.'+scope.tableName){
                                        scope.fieldNames = scope.dtsrcField[scope.schemaName+'.'+scope.tableName];
                                        hasField = true;
                                    }
                                }
                                $log.log(hasField);
                                if(!hasField){
                                    var fieldName = self.getFieldName(scope.dbtype,scope.dbuser,scope.password,scope.dbhost,scope.dbport,scope.dbname,scope.schemaName,scope.tableName).tablefield;
                                    //$log.log(fieldName);
                                    if(fieldName.schemaName == undefined || fieldName.schemaName== "" || fieldName.schemaName=="noSchema")
                                        fieldName.schemaName = 'pentahosalesdashboard';
                                    scope.dtsrcField[fieldName.schemaName+'.'+fieldName.tableName] = fieldName.tableFieldList;
                                    scope.fieldNames = fieldName.tableFieldList;
                                    //$log.log(fieldNames)
                                }
                                scope.fieldName = scope.fieldNames[0];

                            }

                            scope.queryCreator = function(){
                                $log.log("query creator called");
                                var query = "SELECT "+scope.fieldName+"\nFROM "+scope.schemaName+"."+scope.tableName;
                                scope.queryArea = query;
                            }
*/
                        },
                        buttons : [{
                            label : 'Next',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {
                                //editor.setValue(scope.queryArea);
                                if(scope.outputTables.length < 2){
                                    //self.notification(Messages.)
                                    alert("Please select at least two table to create Join");
                                    return;
                                }
                                scope.tableOutput = scope.outputTables;
                                dialogItself.close();
                                scope.createJoinBuilder()
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },{
                            label : 'Close',
                            action : function(dialogItself) {
                                dialogItself.close();                                
                            },
                            cssClass: 'btn-default btn-lg btn-danger'
                        }]
                    })
                }
                
                scope.createJoinBuilder = function(){
                    $log.log("create join called");
                    if(scope.commonJoinTables.length > 1)
                        scope.tableNames1 = scope.commonJoinTables;
                    else    
                        scope.tableNames1 = scope.tableOutput;
                    scope.tableNames2 = scope.tableOutput;
                    scope.tableName1 = scope.tableNames1[0];
                    scope.tableName2 = scope.tableNames2[0];
                    scope.fieldNames1 = [];
                    scope.fieldNames2 = [];
                    scope.fieldName1 = '';
                    scope.fieldName2 = '';
                    //scope.tableName = scop

                    
                    scope.joinCounter = scope.joinTables.length;
                    
                    var firstJoin = true;

                    BootstrapDialog.show({
                        title: 'Query Builder',
                        message: function(dialog){
                            var template = self.getHtmlContent('component/templates/datasource/queryBuilder.html');
                            var $message = $('<div></div>');
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        closable : false,
                        draggable : true,
                        cssClass : 'query-builder-dialog',
                        onshown : function(dialogRef){
                            //$log.debug(scope.filterBinder);

                            for(var i=0;i<scope.joinTables.length;i++){
                                $('#joinArea').append($compile("<div id='join"+scope.joinCounter+"'>"+scope.joinTables[i][0]+'.'+scope.joinTables[i][2]+' INNER JOIN '+scope.joinTables[i][1]+'.'+scope.joinTables[i][3]+"<span><a class='pull-right' ng-click='removeJoin("+scope.joinCounter+")'>Remove</a></span></div>")(scope))
                                scope.joinCounter++;
                            }

                            var getFields = function(conStr){
                                if(conStr==undefined || conStr.length<1)
                                    return "";
                                var schemaName = conStr.split(".")[0];
                                var tableName = conStr.split(".")[1];
                                var hasField = false;
                                var fieldNames = [];
                                for(var key in scope.dtsrcField){
                                    if(key==conStr){
                                        fieldNames = scope.dtsrcField[conStr];
                                        hasField = true;
                                    }
                                }
                                $log.log(hasField);
                                if(!hasField){
                                    var fieldName = self.getFieldName(scope.dbtype,scope.dbuser,scope.password,scope.dbhost,scope.dbport,scope.dbname,schemaName,tableName).tablefield;
                                    //$log.log(fieldName);
                                    if(fieldName.schemaName == undefined || fieldName.schemaName== "" || fieldName.schemaName=="noSchema")
                                        fieldName.schemaName = 'pentahosalesdashboard';
                                    scope.dtsrcField[fieldName.schemaName+'.'+fieldName.tableName] = fieldName.tableFieldList;
                                    fieldNames = fieldName.tableFieldList;
                                    //$log.log(fieldNames)
                                }
                                
                                return fieldNames;
                            }
/*
                            var getTables = function(schemaName){
                                var tableNames = [];
                                tableNames = scope.dtsrcTables[schemaName]
                                return tableNames;
                            }

                            scope.schemaChanged = function(option){
                                $log.log(option)
                                switch(option){
                                    case 0:{
                                        scope.tableNames = getTables(scope.schemaName);
                                        scope.tableName = scope.tableNames[0];
                                        scope.tableChanged(0);
                                        break;
                                    }
                                    case 1:{
                                        scope.tableNames1 = getTables(scope.schemaName1);
                                        scope.tableName1 = scope.tableNames1[0];
                                        scope.tableChanged(1);
                                        break;
                                    }
                                }
                            }

                            */
                            

                            scope.tableNameChanged = function(option){
                                $log.log("table changed");
                                $log.log(option)
                                switch(option){
                                    case 1:{
                                        if(scope.tableNames1!=undefined){
                                            scope.fieldNames1 = getFields(scope.tableName1);
                                            scope.fieldName1 = scope.fieldNames1[0];    
                                        }
                                        break;
                                    }
                                    case 2:{
                                        if(scope.tableNames2!=undefined){
                                            scope.fieldNames2 = getFields(scope.tableName2);
                                            scope.fieldName2 = scope.fieldNames2[0];    
                                        }
                                        break;
                                    }
                                }
                            }
                            var firstJoinQuery = "FROM "+scope.tableName1;
                            

                            //var query = "";
                            scope.joinCreator = function(){
                                $log.log("join creator called");

                                if(scope.tableName1== scope.tableName2){
                                    alert("Choose different table to create a join");
                                    return;                                    
                                }
                                for(var i=0;i<scope.joinTables.length;i++){
                                    if((scope.joinTables[i][0]==scope.tableName1 && scope.joinTables[i][1]==scope.tableName2) || (scope.joinTables[i][0]==scope.tableName2 && scope.joinTables[i][0]==scope.tableName1)){
                                        alert("Both the tables are already joined");
                                        return;
                                    }
                                }
                                $log.log(scope.joinTables);
                                scope.joinTables.push([scope.tableName1,scope.tableName2,scope.fieldName1,scope.fieldName2,scope.joinCounter]);
                                

                                if(firstJoin){
                                    firstJoin = false;
                                //    query = firstJoinQuery;                                    
                                    scope.commonJoinTables = [scope.tableName1,scope.tableName2];
                                    
                                }
                                else{
                                    var isExist = false;
                                    for(var i=0;i<scope.commonJoinTables.length;i++){
                                        if(scope.commonJoinTables[i]==scope.tableName2)
                                            isExist = true;
                                    }
                                    if(!isExist)
                                        scope.commonJoinTables.push(scope.tableName2);
                                }

                                //query = query + "\nINNER JOIN "+scope.tableName2+
                                  //              "\nON "+scope.tableName1+'.'+scope.fieldName1+' = '+scope.tableName2+'.'+scope.fieldName2;


                                //scope.joinArea = query;

                                //var len = scope.joinTable.length-1;

                                $('#joinArea').append($compile("<div id='join"+scope.joinCounter+"'>"+scope.tableName1+'.'+scope.fieldName1+' INNER JOIN '+scope.tableName2+'.'+scope.fieldName2+"<span><a class='pull-right' ng-click='removeJoin("+scope.joinCounter+")'>Remove</a></span></div>")(scope))

                                scope.tableNames1 = scope.commonJoinTables;

                                scope.joinCounter++;
                                $log.log(scope.joinTables)
                            }

                            scope.removeJoin = function(index){
                                $log.log(scope.joinTables);

                                var temp;
                                for(var i=0;i<scope.joinTables.length;i++)
                                    if(scope.joinTables[i][4]==index)
                                        temp = i;
                                
                                scope.joinTables.splice(temp,1);
                                var tableName = [];
                                for(var j=0;j<scope.joinTables.length;j++){
                                    tableName.push(scope.joinTables[j][0]);
                                    tableName.push(scope.joinTables[j][1]);
                                }
                                $log.log(tableName);
                                if(tableName.length > 0){
                                    scope.tableNames1 = $.unique(tableName.sort()).sort();
                                    scope.tableName1=scope.tableNames1[0];
                                    scope.commonJoinTables = scope.tableNames1
                                }
                                    
                                else{
                                    scope.tableNames1 = scope.tableNames2;
                                    scope.tableName1=scope.tableNames1[0]; 
                                    scope.commonJoinTables = [];
                                    firstJoin = true;
                                }
                                   

                                $log.log(scope.joinArea);


                                /*
                                var temp;
                                for(var i=0;i<scope.tableNames1.length;i++){
                                    $log.log(scope.tableNames1[i]+"=="+scope.joinTable[index][1])
                                    if(scope.tableNames1[i]==scope.joinTable[index][1])
                                        temp = i
                                }
                                scope.tableNames1.splice(temp,1);
                                if(scope.tableNames1.length==1){
                                    scope.tableNames1 = scope.tableNames2;
                                }

                                */
                                //scope.joinTable.splice(index,1);
                                $('#join'+index).remove();

                            }

                            scope.tableNameChanged(1);
                            scope.tableNameChanged(2);
                            self.safeApply(scope,function(){});
                            
/*
                            scope.addJoin = function(){
                                $('#table2').removeClass('displayNone');
                                $('#table2').addClass('joinQuery');
                                $('#table1').addClass('joinQuery');
                                $('#createQuery').hide();
                                $('#createJoin').show();
                            
                            }
*/
                        },
                        buttons : [
                        {
                            label : 'Back',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {
                                //editor.setValue(scope.queryArea);
                                dialogItself.close();
                                scope.selectTables();
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },
                        {
                            label : 'Next',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {
                                //editor.setValue(scope.queryArea);
                                dialogItself.close();
                                scope.selectJoinTables();
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },
                        /*
                        {
                            label : 'Apply',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {1
                                editor.setValue(scope.joinArea);
                                dialogItself.close();
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },
                        */
                        {
                            label : 'Close',
                            action : function(dialogItself) {
                                dialogItself.close();
                                
                            },
                            cssClass: 'btn-default btn-lg btn-danger'
                        }]
                    })
                }

                scope.selectJoinTables = function(){
                    scope.hideFields = false;
                    if(scope.joinTables == undefined || scope.joinTables.length <1)
                        scope.hideFields = true;


                    $log.log(scope.joinTables);
                    $log.log(scope.joinArea);
                    $log.log("selected join tables");
                    //scope.joinTables= [];
                    scope.joinTable = scope.commonJoinTables[0];
                    scope.selectedFields = [];
                    scope.selectedField = [];
                    scope.outputFields = [];
                    scope.outputField = '';

                    BootstrapDialog.show({
                        title: 'Query Builder',
                        message: function(dialog){
                            var template = self.getHtmlContent('component/templates/datasource/selectQueryTables.html');
                            var $message = $('<div></div>');
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        closable : false,
                        draggable : true,
                        cssClass : 'width700',
                        onshown : function(dialogRef){
                            //$log.debug(scope.filterBinder);
                            

                            var getFields = function(conStr){
                                var schemaName = conStr.split(".")[0];
                                var tableName = conStr.split(".")[1];
                                var hasField = false;
                                var fieldNames = [];
                                for(var key in scope.dtsrcField){
                                    if(key==conStr){
                                        fieldNames = scope.dtsrcField[conStr];
                                        hasField = true;
                                    }
                                }
                                $log.log(hasField);
                                if(!hasField){
                                    var fieldName = self.getFieldName(scope.dbtype,scope.dbuser,scope.password,scope.dbhost,scope.dbport,scope.dbname,schemaName,tableName).tablefield;
                                    //$log.log(fieldName);
                                    if(fieldName.schemaName == undefined || fieldName.schemaName== "" || fieldName.schemaName=="noSchema")
                                        fieldName.schemaName = 'pentahosalesdashboard';
                                    scope.dtsrcField[fieldName.schemaName+'.'+fieldName.tableName] = fieldName.tableFieldList;
                                    fieldNames = fieldName.tableFieldList;
                                    //$log.log(fieldNames)
                                }
                                
                                return fieldNames;
                            }

                            scope.selectTableChanged = function(){
                                $log.log("table changed");
                                if(scope.joinTable!=undefined){
                                    scope.selectedFields = getFields(scope.joinTable);
                                    scope.selectedField.push(scope.selectedFields[0]);   
                                }
                                    
                            }


                            scope.addColumn = function(){
                                if(scope.selectedFields.length == 0 || scope.selectedField == undefined || scope.selectedField.length == 0)
                                    return;
                                $log.log(scope.selectedField);

                                for(i=0;i<scope.selectedField.length;i++){
                                    var str = scope.joinTable+'.'+scope.selectedField[i];
                                    var isExist = false;
                                    $log.log(scope.outputFields);
                                    for(j=0;j<scope.outputFields.length;j++){
                                        $log.log("as|||"+scope.outputFields[j][0]+"||=+"+scope.selectedField[i])
                                        if(scope.outputFields[j][0] == scope.selectedField[i]){
                                            isExist = true;
                                        }
                                        $log.log(isExist);
                                    }
                                        

                                    if(!isExist)
                                        scope.outputFields.push([scope.selectedField[i],str]);

                                }
                                //scope.outputField = scope.outputFields[0];
                                scope.outputField = scope.outputFields[scope.outputFields.length-1][0];                                
                            }

                            scope.removeColumn = function(){
                                $log.log("remove column")
                                if(scope.outputFields.length == 0)
                                    return;

                                $log.log(scope.outputFields);
                                $log.log(scope.outputField);
                                //scope.inputTables.push(scope.outputTable);
                                for(i=0;i<scope.outputFields.length;i++){
                                    if(scope.outputField == scope.outputFields[i][0])
                                        temp = i;
                                }
                                $log.log(temp)
                                scope.outputFields.splice(temp,1);
                                scope.outputField = scope.outputFields[scope.outputFields.length-1][0];                                
                            }
                            
                            //var firstQuery = "FROM "+scope.tableName1;
                            
                            
                            scope.selectFieldQuery = function(){
                                $log.log("select field query");

                                var query = "SELECT ";
                                for(var i=0;i<scope.outputFields.length;i++){
                                    query = query + scope.outputFields[i][1];
                                    if(i < scope.outputFields.length-1)
                                        query = query+',';
                                }

                                scope.fieldArea = query
                                //scope.tableNames1 = scope.commonJoinTables;
                            }
                            scope.selectTableChanged();
                            self.safeApply(scope,function(){});
                            
/*
                            scope.addJoin = function(){
                                $('#table2').removeClass('displayNone');
                                $('#table2').addClass('joinQuery');
                                $('#table1').addClass('joinQuery');
                                $('#createQuery').hide();
                                $('#createJoin').show();
                            
                            }
*/
                        },
                        buttons : [
                        {
                            label : 'Back',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {
                                //editor.setValue(scope.queryArea);
                                dialogItself.close();
                                scope.createJoinBuilder();
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },
                        {
                            label : 'Apply',
                            cssClass : 'btn-primary',
                            action : function(dialogItself) {
                                if(scope.fieldArea==undefined ||scope.fieldArea.length<1)
                                    scope.fieldArea = 'SELECT *';
                                var joinQuery='';
                                for(i=0;i<scope.joinTables.length;i++){
                                    var t1,t2,f1,f2;
                                    t1= scope.joinTables[i][0];
                                    t2= scope.joinTables[i][1];
                                    f1= scope.joinTables[i][2];
                                    f2= scope.joinTables[i][3];
                                    if(i==0){
                                        joinQuery = 'FROM '+t1+'\n\tINNER JOIN '+t2+'\n\t\tON '+t1+'.'+f1+' = '+t2+'.'+f2;
                                    }
                                    else{
                                        joinQuery = joinQuery + '\n\tINNER JOIN'+t2+'\n\t\tON '+t1+'.'+f1+' = '+t2+'.'+f2;
                                    }
                                    
                                }

                                if(scope.joinTables == undefined || scope.joinTables.length < 0){
                                    alert("No join created");
                                    dialogItself.close();
                                    editor.setValue();
                                    
                                }
                                else{
                                    editor.setValue(scope.fieldArea+'\n'+joinQuery+';');
                                    dialogItself.close();    
                                }
                                
                            },
                            cssClass: 'btn-default btn-lg btn-primary'
                        },{
                            label : 'Close',
                            action : function(dialogItself) {
                                dialogItself.close();
                                
                            },
                            cssClass: 'btn-default btn-lg btn-danger'
                        }]
                    })
                }

            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        dialogItself.close();
                        //$log.log(editor.getValue());
                        onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    }

    this.notification = function (message, nType, nDelay, icon) {
        if(nType == null || nType == undefined || nType.length <1)
            nType=this.notificationType;
        if(nDelay == null || nDelay == undefined || nDelay.length <1)
            nDelay=this.notificationDelay;

        $.growl({
                message: message
            }
            ,{
                type: nType,
                allow_dismiss: true,
                placement: {
                    from: "top",
                    align: "right"
                },
                offset: 20,
                spacing: 10,
                z_index: 10031,
                delay: nDelay,
                timer: 300,
                animate: {
                    enter: 'animated bounceIn',
                    exit: 'animated bounceOut'
                }
            });
    };

    this.saveNotification = function(message){
        var notification = new NotificationFx({
            wrapper : document.body,
            message : '<span class="icon icon-settings"></span><p>'+message+'</p>',
            layout : 'bar',
            effect : 'exploader',
            ttl : 9000,
            type : 'notice', // notice, warning or error
            onClose : function() {
                //bttn.disabled = false;
            }
        });

        // show the notification
        notification.show();
    }

    this.safeApply=function (scope, fn){
        (scope.$$phase || scope.$root.$$phase) ? fn() : scope.$apply(fn);
    };


    this.loadjscssfile = function(filename, filetype){

        if (filetype=="js"){ //if filename is a external JavaScript file
            /*
            var message = "";
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = filename;
            
            script.onload = function(){
                message = "loading"
                callback(message);
            }
            
            document.getElementsByTagName("head")[0].appendChild(script);

            */
            var ajaxObj;
            if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
                ajaxObj=new XMLHttpRequest();
            }
            else{// code for IE6, IE5
                ajaxObj=new ActiveXObject("Microsoft.XMLHTTP");
            }
            ajaxObj.onreadystatechange=function(){
                if (ajaxObj.readyState!=4 ) return ;
                eval(ajaxObj.responseText);   
            }
            
            ajaxObj.open("GET",filename,true);
            ajaxObj.send('');

        }
        else if (filetype=="css"){ //if filename is an external CSS file
            var fileref=document.createElement("link")
            fileref.setAttribute("rel", "stylesheet");
            fileref.setAttribute("type", "text/css");
            fileref.setAttribute("href", filename);

            document.getElementsByTagName("head")[0].appendChild(fileref);
            //var css = document.createElement("link");
            //css.rel = "stylesheet";
            //css.type = "text/css"
            //css.href = filename;
        }

        //if (typeof fileref!="undefined")
        //    document.getElementsByTagName("head")[0].appendChild(fileref)
    }
    //currently this function is not using anywhere
    this.loadComponentRes = function()
    {
        var DEFAULT_PATH ="component/";
        var self = this;

        for(var i = 0; i < this.components.selfServiceBI.length; i++) {

            for(var j = 0; j < this.components.selfServiceBI[i].properties.files.css.length; j++) {

                var filePath = this.components.selfServiceBI[i].properties.files.css[j];
                if(filePath.substr(0,2) == ".." ||  filePath.substr(0,3) == "/.." ) // Load Relative path
                {   
                    //this.loadjscssfile(filePath,"css");
                }
                else
                {
                    this.loadjscssfile(DEFAULT_PATH+this.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath,"css")
                    filePath =DEFAULT_PATH+this.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath;
                }


                //$log.debug("\tCSS : " + filePath);
            }
            angular.forEach(this.components.selfServiceBI[i].properties.files.js , function(item,j){

                var filePath = item;
                var reply = undefined;

                if(filePath.substr(0,2) == ".." ||  filePath.substr(0,3) == "/.." ) // Load Relative path
                {
                    //self.loadjscssfile(filePath,"js");

                }
                else
                {
                    self.loadjscssfile(DEFAULT_PATH+self.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath,"js")
                    filePath = DEFAULT_PATH+self.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath;
                }
                //$log.debug("\tjs : " + filePath);
            })
        }
        //$log.log("this is finished");
    }
    
    this.setComponents = function()
    {
        this.components = this.readJSONFile('component/components.json');
        this.loadComponentRes();
    }

    this.getIndex = function(name){
        var properties = {};
        for(i=0;i<this.components.selfServiceBI.length;i++){
            if(name == this.components.selfServiceBI[i].chartName){
                return i;
            };

        }
    }

    this.getChartType = function(input){
        var chartType;
        //$log.log(scope.chartType)
        if(input == "Saiku Analytics")
            chartType = 'Saiku';
        else if(input == "CCC Chart Library")
            chartType = 'CCC';
        else if(input == "Data Tables")
            chartType = 'Table';
        else if(input == "Label")
            chartType = 'Label'
        return chartType
    }
    this.propertiesHTMLComponent= function(pName,caption,dataType,htmlComp,defaultVal,listOfVal,advance,htmlAppend,scope,hidden)
    {
        var cssClass= '';

        //var isHidden = hidden == 0? 'hidden' : '';
        var isHidden = '';
        //console.log(htmlComp+" "+advance);
        if(advance == 1) // 1 = Advance, 2 = Advance + Primary , 0 = Not implements but we can use as primary only
            cssClass="advance";
        else if(advance == 2)
            cssClass="primary";
        else if(advance == 0)
            isHidden = 'hidden';

        
        var comp = '<div class="form-group '+ cssClass +'" '+isHidden+'><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">'+caption+'</div>';
        //var comp = '<tr '+ cssClass + isHidden+' ><td style="width:40%">'+caption+'</td>'; // this row Tr close within switch case
        //$log.log(comp);
        switch(htmlComp){
            case "textbox":
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></div>';
                //comp = comp + '<td><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></td></tr>';
                $('#'+htmlAppend).append($compile(comp)(scope));
                //$('#'+pName).val(defaultVal);
                scope[pName] = defaultVal;

                break;
            }
            case "password":
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="password" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></div>';
                //comp = comp + '<td><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></td></tr>';
                $('#'+htmlAppend).append($compile(comp)(scope));
                //$('#'+pName).val(defaultVal);
                scope[pName] = defaultVal;

                break;
            }
            case "combobox" :
            {
                var possible = listOfVal;
                var options = '';
                for(j=0;j<possible.length;j++){
                    if(possible[j] == defaultVal){
                        option = '<option value="'+possible[j]+'">'+possible[j]+'</option>'
                    }
                    else{
                        option = '<option value="'+possible[j]+'">'+possible[j]+'</option>'
                    }

                    options = options.concat(option)
                }
                comp = comp +'<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><select id="'+pName+'" class="form-control input-sm" ng-model="'+pName+'">'+
                options+
                '</div></div>'
                
                $('#'+htmlAppend).append($compile(comp)(scope));

                scope[pName] = defaultVal;
                break;
            }
            case "switch" :
            case "combo" :
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="checkbox" class="form-control" id="'+pName+'" name="my-checkbox" data-size="mini" data-handle-width="42" data-on-text="True" data-off-text="False" data-on-color="success" data-off-color="danger" checked=false /></td>'+
                '</div></div>';

                $('#'+htmlAppend).append($compile(comp)(scope));

                if(defaultVal){
                    $('#'+pName).bootstrapSwitch('state',true);
                }
                else{
                    $('#'+pName).bootstrapSwitch('state',false);
                }
                break;
            }
            case "javascript" :
            case "sql" :
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><div class="input-group form-inline" ng-click="openScriptDialog()"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                '<span class="input-group-addon input-sm" id="'+pName+'button" style="cursor:pointer;" ><i class="glyphicon glyphicon-pencil"></i></button>'+
                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div></div>';
                //$('#'+pName+'text').val(data.substring(0,30));
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = defaultVal;
                    if(defaultVal.length > 20 )
                        scope[pName+'text'] = defaultVal.substring(0,20)+'..(...)';
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openScriptDialog = function(){

                    var onOk = function(data) {
                        scope[pName+'text'] = data;
                        if(data.length >20)
                            scope[pName+'text'] = data.substring(0,20)+'..(...)' ;
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.codeMirrorDialog(htmlComp,currentVal,onOk,function(){},scope);
                };
                break;
            }
            /*
            case "colorDialog" :
            {
                comp = comp +   '<td><div class="input-group form-inline"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" class="form-control input-sm" size="15" />'+
                                '<span class="input-group-addon input-sm" id="'+pName+'button" style="cursor:pointer;" ><i class="glyphicon glyphicon-pencil"></i></button>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></td></tr>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = defaultVal.substring(0,30);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                scope[pName] = defaultVal;
                var currentVal = scope[pName];
                
                $('#'+pName+'button').on('click',function(){
                    $log.debug("color panel selected");

                    var onOk = function(data) {
                        scope[pName+'text'] = data.substring(0,15);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.colorDialog("Select Colors",currentVal,onOk,function(){},scope);
                });

                break;
            }
            */
            case "colorDialog" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><div class="form-group-right input-group form-inline"><input type="text" id="'+pName+'text" ng-click="openColorDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openColorDialog = function(){
                    $log.debug("Color Dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else if(data.length == 0)
                            scope[pName+'text'] = "";
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.colorDialog("Select Colors",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "database" : 
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openDtsrcDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" style="cursor:text" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = defaultVal;
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openDtsrcDialog = function(){
                    $log.debug("Add Datasource Connection dialog");

                    var onOk = function(data) {
                        scope[pName+'text'] = data.name;
                        scope[pName] = data.name;
                        currentVal = data.name;
                        //var connection = self.getDBConnection(data.databaseType.shortName);
                        $log.debug(connection);
                        //$log.log(data.databaseType.extraOptionsHelpUrl.name);
                        //if(data.databaseType.name == 'MySQL')
                        //scope.driver = connection[0]
                        scope.dbtype = data.databaseType.shortName;
                        scope.dbuser = data.username;
                        scope.dbhost = data.hostname;
                        scope.dbport = data.databasePort;
                        scope.dbname = data.databaseName;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        //scope.url = connection[1]+'://'+data.hostname+':'+data.databasePort+'/'+data.databaseName;
                        self.safeApply(scope,function(){});
                    }
                    self.datasourceDialog("Select Datasource",currentVal,onOk,function(){},scope);
                }
                break;   
            }
            case "cdaparameters" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openParamDialog()" ng-model="'+pName+'text" class=" form-control input-sm readonlybg"  style="cursor:text" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openParamDialog = function(){
                    $log.debug("Add CDA Parameter dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.cdaparamDialog("Add parameters",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "outputOpt" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" ng-click="openOutputDialog()" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openOutputDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.outputOptDialog("Output Options",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "columns" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openColumnDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openColumnDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.columnsDialog("Columns Configuration",currentVal,onOk,function(){},scope);
                }
                break;
            }

            case "calcColumns" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" ng-click="openCalColDialog()" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openCalColDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.calcColumnsDialog("Calculated Columns",currentVal,onOk,function(){},scope);
                }
                break;
            }
        }
    }

    this.getDBConnection = function(dbname){
        var connection = [];
        switch(dbname){
            case 'MYSQL':{
                connection = ['com.mysql.jdbc.Driver','jdbc:mysql'];
                break;
            }   
            case 'ORACLE':{
                connection = ['oracle.jdbc.driver.OracleDriver','jdbc:oracle'];
                break;
            }
            case 'HIVE':{
                connection = ['org.apache.hadoop.hive.jdbc.HiveDriver','jdbc:hive'];
                break;
            }
            case 'HIVE2':{
                connection = ['org.apache.hadoop.hive.jdbc.HiveDriver','jdbc:hive2'];
                break;
            }
            case 'VERTICA5':{
                connection = ['com.vertica.jdbc.Driver','jdbc:vertica'];
                break;
            }
            case 'HYPERSONIC':{
                connection = ['org.hsqldb.jdbcDriver','jdbc:hsqldb:hsql'];
                break;
            }
            case 'POSTGRESQL':{
                connection = ['org.postgresql.Driver','jdbc:postgresql'];
                break;
            }
            case 'MSSQL':{
                connection = ['com.microsoft.sqlserver.jdbc.SQLServerDriver','jdbc:sqlserver'];
                break;   
            }
            case 'MSSQLNative':{
                connection = ['com.microsoft.sqlserver.jdbc.SQLServerDriver','jdbc:sqlserver'];
                break;   
            }
            case 'H2':{
                connection = ['org.h2.Drive','jdbc:h2'];
                break;   
            }
            case 'MONETDB':{
                connection = ['nl.cwi.monetdb.jdbc.MonetDriver','jdbc:monetdb'];
                break;
            }
            case 'IMPALA':{
                connection = ['com.cloudera.impala.jdbc.Driver','jdbc:impala'];
                break;
            }
        }
        return connection;
    }


    this.parsePropertiesDataType = function(value, dataType)
    {
        if(dataType == "boolean")
            value = JSON.parse(value);
        else if (dataType == "array")
        {
            if(value != undefined)
            {
                if(!Array.isArray(value)) {
                    if (value.length > 0)
                    {
                        value = value.split(",");
                    }
                    //$log.debug("property val: "+value);
                }
            }

        }
        return value;
    }
}]);