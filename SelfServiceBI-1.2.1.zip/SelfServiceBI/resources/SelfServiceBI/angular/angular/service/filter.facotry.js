angular.module('pinboard')
.factory('filter',['commonUtils','$log',function(commonUtils,$log){
    var filter = function(){
        console.log("filter initmap : ")
        console.log(this);
        this.filterId = "";
        this.filterName = "";
        this.filterCaption = "";
        this.defaultVal = "";
        this.filterVal = "";
        this.filterType = "";
        this.htmlComponent = "";
        this.dataSource = "";
        this.dataAccessId = "";
        this.datasourceArray = [];
        this.listenerPins = [];
        this.position = "";
        this.filterWidth = "120";
    };
    filter.prototype.initmap = function(o){
        
        this.filterId = o.filterId || '';
        this.filterName = o.filterName||"";
        this.filterCaption = o.filterCaption||"";
        this.defaultVal = o.defaultVal||"";
        this.filterVal = o.filterVal||"";
        this.filterType = o.filterType||"";
        this.htmlComponent = o.htmlComponent||"";
        this.dataSource = o.dataSource||"";
        this.dataAccessId = o.dataAccessId||"";
        this.datasourceArray = o.datasourceArray||[];
        this.listenerPins = o.listenerPins||[];
        this.position = o.position||"";
        this.filterWidth = o.filterWidth||"120";
    }

    
    return filter;
}]);