angular.module('pinboard')
.factory('filterPanel',['commonUtils','$log',function(commonUtils,$log){
    var filterPanel = function(){
        this.filterArray = [];
        this.filterPanelId = '';
        this.filterPanelTitle = 'Filter Panel 1';
        this.filterPanelIcon = 'glyphicon glyphicon-filter';
        this.filterPanelColor = 'panel-green1';
        this.filterPanelHeight = '100';
        this.filterPanelShow = false;
        this.filterPanelFontColor = "Light";
    };

    filterPanel.prototype.init = function(){
        this.filterArray = [];
        this.filterPanelId = '';
        this.filterPanelTitle = 'Filter Panel';
        this.filterPanelIcon = 'glyphicon glyphicon-filter';
        this.filterPanelColor = 'panel-green1';
        this.filterPanelHeight = '100';
        this.filterPanelShow = false;
        this.filterPanelFontColor = "Light";
    }
    filterPanel.prototype.initmap = function(o){
        this.filterArray = o.filterArray || [];
        this.filterPanelId = o.filterPanelId || '';
        this.filterPanelTitle = o.filterPanelTitle||'Filter Panel';
        this.filterPanelIcon = o.filterPanelIcon||'glyphicon glyphicon-filter';
        this.filterPanelColor = o.filterPanelColor||'panel-green1';
        this.filterPanelHeight = o.filterPanelHeight||'100';
        this.filterPanelFontColor = o.filterPanelFontColor || "Light";
        if(o.filterPanelShow != undefined && typeof o.filterPanelShow!="boolean")
            this.filterPanelShow = o.filterPanelShow=="true"?true:false;
        
        else if(o.filterPanelShow != undefined && typeof o.filterPanelShow=="boolean")
            this.filterPanelShow = o.filterPanelShow;
            
        else
            this.filterPanelShow = false;
    }

    return filterPanel;
}]);