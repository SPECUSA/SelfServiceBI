
angular.module('messagesModule',[])
    .service('Messages',function(){
        // Common
        this.onInvalidFileName = "Please input valid file name";
        this.onSaikuFileNotSelected = "No data source selected";
        this.onPopWindowError = "Please allow popups for this site";
        this.NoDataSourceSelected = "No data source selected.";
        this.onChartRenderError = "Error while rendering chart.";
        //Pin
        this.onNewPinNotification = "New pin created successfully.";
        this.onOpenPinNotification = "Pin opened successfully.";
        this.onSavePinNotification = "Pin saved successfully.";
        this.onAlreadySavedPinNotification = "Pin already saved.";
        this.onSaveAsPinNotification = "Pin save as successfully.";

        this.onDefaultPinNotification = "Pin with default configuration can't saved";

        this.onPinSaveUserRightError = "You don't have rights to modify pin.";
        this.onUnsavePinConfirm = "Would you like to save existing open pin ?";
        this.onPreviewUnsavePinError = "Please save pin before preview.";

        //PinBoard
        this.onNewPinboardNotification =  "New pin Board created successfully.";
        this.onOpenPinboardNotification = "Pin Board opened successfully.";
        this.onSavePinboardNotification = "Pin Board saved successfully.";
        this.onAlreadySavedPinboardNotification = "Pin Board already saved.";
        this.onSaveAsPinboardNotification = "Pin Board save as successfully.";

        this.onNullPinboardNotification = "Pinboard doesn't have any pin to save";

        this.onPinBoardInserRowSuccess = "New row inserted successfully.";
        this.onPinBoardRemoveRowSuccess = "Row removed successfully.";
        this.onRemoveAllNotification = "Pin Board all row(s) removed successfully.";

        this.onPinBoardSaveUserRightError = "You don't have rights to modify Pin Board.";
        this.onUnsavePinBobardConfirm = "Would you like to save existing open pin Board ?";
        this.onPreviewUnsavePinBoardError = "Please save pin Board before preview.";
        this.onRemoveRowConfirm = "Are you sure to delete selected row?";

        this.onInvalidMediumScreenInputError = "Please enter medium screen size values.";
        this.onInvalidLargeScreenInputError = "Please enter leage screen size values.";
        this.onInvalidSmallScreenInputError = "Please enter small  screen size values.";
        this.onInvalidExtraSmallScreenInputError = "Please enter extra small screen size values.";
        this.onInvalidNumberOfColumnInputError = "All your screen size values must have same numbers of columns.";
        this.onFilterNameAlreadyExist = "Filter name already exist. Please try another";

        this.onInvalidPinSizeInput = "Pin size should integer and from 1-12";
        this.onInvalidDateFormat = "Date should be in format YYYY-MM-DD";

        this.onCCCbulletChartSelect = "Please set appropriate height for bullet chart from properties option";
        this.unableLoadData = "Unable to load data, Try again";
        this.onPinBoardDatasourceAdded = "Datasource added";

        //datasource
        this.onNewDatasourceNotification = "New Data source created successfully";
        this.onOpenDatasourceNotification = "Datasource open successfully";
        this.onNullDatasourceNotification = "Datasource doesn't have any data to save";
        this.onSaveDatasourceNotification = "Datasource saved successfully";
        this.onSaveAsDatasourceNotification = "Datasource saved successfully";
        this.onAlreadySaveDatasourceNotification = "Datasource already saved";
        this.onUnsaveDatasourceConfirm = "Would you like to save existing datasource";
        this.onPropertiesSavedNotification = "Properties for Datasource Saved";
        this.saveDatasourceProperties = "Please save Datasource Properties first"

    })