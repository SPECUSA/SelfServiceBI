angular.module('pinboard')
.factory('Pin',['commonUtils','$log','Messages',function (commonUtils,$log,Messages) {
    $log.debug("Pin Factory called");
    var pin = function(){
        this.mode = "";
        this.cIdx =-1; // Column Index
        this.pinId = "newPin" ; //Extension Perpose
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.pinHeaderColor = "panel-blue3";
        this.pinFontColor  = "Light"
        //this.dataSource = "/home/admin/SelfServiceBI/Test.saiku";
        
        this.height = 200;
        this.width = "100";
        this.htmlObj = "PanelChart";
        this.version = commonUtils.version;
        this.buildVersion= commonUtils.buildVersion;

        this.chartType = "CCC";
        this.dataSource = "";
        this.visualization = "Bar"; // Chart type
        this.dataAccessId = "";
        this.defaultParamStr = {};
        this.paramStr = "";
        this.paramValStr = "";

        this.conditions = [];

        this.listenerFilters = [];
        this.chartProperties = [];

        this.listenerPins = [];
        this.comments = [];
        this.commentsCount = '';
        this.currentSaiku = false;
    };
    pin.prototype.init = function(options){

        $log.debug("Pin( "+  this.pinId  +  " ).init : Default values");
        this.pinId = "newPin";
        this.cIdx =-1;
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.pinHeaderColor = "panel-green1";
        this.pinFontColor  = "Light"
        
        this.height = 200;
        this.width = "100";
        this.htmlObj = "PanelChart";

        this.chartType = "CCC";
        this.dataSource = "";
        this.visualization = "Bar"; // Chart type
        this.dataAccessId = "";
        this.defaultParamStr = {};
        this.paramStr = "";
        this.paramValStr = "";
        this.conditions = [];
        this.listenerFilters = [];
        this.chartProperties = [];
        this.listenerPins = [];
        this.comments = [];
        this.commentsCount = '';
        this.currentSaiku = false;
    };

    pin.prototype.initmap = function(o){

        this.pinId = o.pinId;
        this.cIdx = o.cIdx;
        this.pinIcon = o.pinIcon
        this.pinFile = o.pinFile||"";
        this.title = o.title;
        this.minimize = (o.minimize=="true"?true:false)||true;
        this.isHeader = (o.isHeader=="true"?true:false)||true;
        this.pinHeaderColor = o.pinHeaderColor || "panel-green1";
        this.pinFontColor  = o.pinFontColor || "Light"
        this.height = o.height;
        this.width = o.width;
        this.htmlObj = o.htmlObj;
        this.chartType = o.chartType;
        this.dataSource = o.dataSource;
        this.visualization = o.visualization; // Chart type
        this.dataAccessId = o.dataAccessId||'';
        this.defaultParamStr = o.defaultParamStr||{};
        this.paramStr = o.paramStr||'';
        this.conditions = o.conditions||[];
        this.listenerFilters = o.listenerFilters||[];
        this.chartProperties = o.chartProperties||[];
        this.listenerPins = o.listenerPins||[];
        this.comments = o.comments||[];
        this.commentsCount = o.commentsCount||'';
        this.currentSaiku = o.currentSaiku||false;

    }

    pin.prototype.isDefault = function(){
        if(this.pinId == "newPin" && this.pinIcon == "glyphicon glyphicon-pushpin" && this.title == "New Pin" && this.minimize == true && this.isHeader == true && this.pinHeaderColor == "panel-blue3" && this.height == 200 && this.chartType == "CCC" && this.dataSource == "")
            return true;
        else
            return false;
    }


    pin.prototype.getJson = function(){
        $log.debug("pinid : "+this.pinId);
        var json =  "{"+
                    "\"pinId\" : \""+  $.trim(this.pinId)  +  "\" , " +
                    "\"pinIcon\" : \""+  $.trim(this.pinIcon)  +  "\" , " +
                    "\"title\" : \""+  $.trim(this.title)  +  "\" , " +
                    "\"minimize\" : \""+  this.minimize +  "\" , " +
                    "\"isHeader\" : \""+  this.isHeader +  "\" , " +
                    "\"pinHeaderColor\" : \""+  $.trim(this.pinHeaderColor)  +  "\" , " +
                    "\"dataSource\" : \""+  $.trim(this.dataSource)   +  "\" , " +
                    "\"dataAccessId\" : \""+  $.trim(this.dataAccessId)   +  "\" , " +
                    "\"defaultParamStr\" : \""+  $.trim(this.defaultParamStr)   +  "\" , "  +
                    //"\"paramStr\" : \""+  $.trim(this.paramStr)   +  "\" , "  +
                    "\"chartType\" : \""+  $.trim(this.chartType)   +  "\" , " +
                    "\"visualization\" : \""+  $.trim(this.visualization)   +  "\" , "  ;


            if(this.chartProperties != undefined && this.chartProperties.length > 0)
            {

                json = json +  "\"chartProperties\" : " ;
                json = json + "[";

                for(var i=0;i<this.chartProperties.length;i++){
                    if(this.chartProperties[i][2] == "javascript" || this.chartProperties[i][1] == "array") // we use stringify for array and javascript store in json
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" ,"+  JSON.stringify($.trim(this.chartProperties[i][3]))   +  ", " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                        //$log.debug(this.chartProperties[i][0] + " - "  + this.chartProperties[i][3]);
                    }
                    else
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][3])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                    }

                    if(i == this.chartProperties.length-1)
                    {
                        json = json + "]";
                    }
                    else{
                        json = json + "],";
                    }

                }
                json = json + "],";
            }
            else
            {
                json = json + "\"chartProperties\" : [] , " ;
            }

        $log.debug("listenerFilters "+this.listenerFilters);
        json = json + "\"listenerFilters\" : ";
        json = json + "[";
        len = this.listenerFilters.length;
        if(this.listenerFilters.length >0){
            for(var i=0;i<len;i++){
                json = json + "[";
                json = json  + "\"" +$.trim(this.listenerFilters[i][0])+"\" ,";
                json = json  + "\"" +$.trim(this.listenerFilters[i][1])+"\" ";
                if(i == len-1){
                    json = json + "]";    
                }
                else{
                    json = json + "],";   
                }
                
            }
        }
        json = json +   "],";

        $log.debug("listenerPins "+this.listenerPins);
        json = json + "\"listenerPins\" : ";
        json = json + "[";

        if(this.listenerPins != undefined){
            len = this.listenerPins.length;
            if(this.listenerPins.length >0){
                for(var i=0;i<len;i++){
                    json = json + "[";
                    json = json  + "\"" +$.trim(this.listenerPins[i][0])+"\" ,";
                    json = json  + "\"" +$.trim(this.listenerPins[i][1])+"\" ,";
                    json = json  + "\"" +$.trim(this.listenerPins[i][2])+"\" ";
                    if(i == len-1){
                        json = json + "]";    
                    }
                    else{
                        json = json + "],";   
                    }
                    
                }
            }    
        }
        
        json = json +   "],";

        $log.debug("comments "+this.comments);
        json = json + "\"comments\" : ";
        json = json + "[";
        
        if(this.comments!=undefined){
            len = this.comments.length;
            if(this.comments.length >0){
                for(var i=0;i<len;i++){
                    $log.log(this.comments[i][1]);
                    json = json + "[";
                    json = json  + "\"" +$.trim(this.comments[i][0])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][1])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][2])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][3])+"\" ";
                    if(i == len-1){
                        json = json + "]";    
                    }
                    else{
                        json = json + "],";   
                    } 
                }
            }    
        }
        
        json = json +   "],";


        json = json +   "\"commentCounts\" : \""+  $.trim(this.commentsCount)   +  "\" , " +
                        "\"height\" : \""+  $.trim(this.height)   +  "\" , " +
                        "\"width\" : \""+  $.trim(this.width)   +  "\" , " +
                        "\"htmlObj\" : \""+  $.trim(this.htmlObj)+  "\" , " +
                        "\"version\" : \""+  $.trim(this.version)+  "\" , " +
                        "\"buildVersion\" : \""+  $.trim(this.buildVersion)+  "\" " +
                        "}";

        /* if(Config.debug)
         $log.debug("Pin("+  this.pinId  +  " ).getJson() : " + json);
         */
        //$log.log(json);
        return json;
    };

    pin.prototype.render = function(param,htmlDiv,isZoom){
        
        var htmlObj = htmlDiv || this.htmlObj
        var width = $("#" + htmlObj).parent().width()-5;
        var height = $('#'+htmlDiv).height()  || this.height;
        
        if(isZoom){
            height = $('#'+htmlDiv).height();
        }

        height -=30;
        width -=30;
        $("#" + htmlObj+"_chart").empty();
        $("#" + htmlObj).html('<div id="'+ htmlObj+'_chart" style="height:'+height+'px;width:'+width+'px;"></div>' );

        //console.log($("#" + htmlObj).html());
        // $("#"+this.htmlObj).append('<canvas id="'+ this.htmlObj+'_chart_1" style="width:'+width+'px; height:'+ this.height+'px;"></canvas>')

                                // console.log(this.htmlObj);
                                // console.log(this.chartType);
                                // console.log(param)
        try {
            if (this.dataSource == undefined || this.dataSource.length < 1) {
                $("#" + this.htmlObj+ "_chart").html("<div style=\"text-align: center;\">" + Messages.NoDataSourceSelected + "</div>");
            }
            else if (this.chartType == "Saiku") {
                console.log(this.chartProperties)
                console.log(this.currentSaiku);
                var visualization = this.currentSaiku || this.visualization;

                var saikuClientRenderer = new SaikuClient(
                    {
                        server: "/pentaho/plugin/saiku",
                        path: "/cde-component"
                    });

                console.log(param)
                var tempParamObj = {};

                for(paramval in param){
                    //console.log(paramval + " " + param[paramval])
                    if(param[paramval]!=null){
                        tempParamObj[paramval] = param[paramval];
                    }
                }

                

                var chartDef = {};
                for(var i=0;i<this.chartProperties.length;i++){
                    chartDef[this.chartProperties[i][0]] = this.chartProperties[i][3]
                }
                if ((visualization).toLowerCase() != "table"){
                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: "#" + htmlObj,
                        render: "chart",
                        mode: (visualization).substring(0,1).toLowerCase()+(visualization).substring(1),
                        zoom: true,
                        params:tempParamObj,
                        chartDefinition: chartDef
                    });
                }
                else {
                    $("#" + htmlObj).addClass('workspace_results');
                    var t = $("<div></div>");
                    $("#" + htmlObj).html(t);
                    htmlId = t;

                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: htmlId,
                        render: "table",
                        mode: "sparkline",
                        zoom: true
                    });
                }
                $log.debug("Rendering configuration");
                $log.debug("Pin( " + this.pinId + " ).render : htmlID : " + htmlObj);
                $log.debug("Pin( " + this.pinId + " ).render : dataSource : " + this.dataSource);
                $log.debug("Pin( " + this.pinId + " ).render : chart : " + visualization);
                $log.debug("Pin( " + this.pinId + " ).render : Ended");

            }
            else if (this.chartType == "CCC") {

                var chartType = window["CCC"+ this.visualization];
                var visualization = new chartType();
                $log.debug(this.chartType + " " + this.visualization);
                // if (param == undefined) {
                //     param = "";
                // }
                
                var paramStr = commonUtils.parseParams(angular.copy(param));
                //console.log(this);
                // var data = commonUtils.getDatasourceData(this.dataSource,this.dataAccessId,"data");
                // if(!data){
                //     url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + this.dataSource + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                //     data = commonUtils.synchronousJsonCall(url);

                //     commonUtils.setDatasourceData(this.dataSource,this.dataAccessId,data,"data");
                // }

                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + paramStr + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);

                visualization.init(this.pinId, data, htmlObj+"_chart", this.chartProperties);

            }
            else if(this.chartType == "Fusion"){
                if (param == undefined) {
                    param = "";
                }
                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);


                var visualization = new fusionChart();
                visualization.init(this.pinId,data,htmlObj+"_chart");
            }
            else{
                $log.log(this.chartType+this.visualization);
                var chartType = window[this.visualization];
                //$log.log(chartType);
                var visualization = new chartType();
                // if (param == undefined) {
                //     param = "";
                // }
                var paramStr = commonUtils.parseParams(angular.copy(this.paramStr));
                // var data = commonUtils.getDatasourceData(this.dataSource,this.dataAccessId,"data");
                // if(!data){
                //     url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + this.dataSource + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                //     data = commonUtils.synchronousJsonCall(url);

                //     commonUtils.setDatasourceData(this.dataSource,this.dataAccessId,data,"data");
                // }

                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + paramStr + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);
                
                visualization.init(this.pinId,data,htmlObj+"_chart",this.chartProperties,this.conditions);
            }

            //console.log($("#" + htmlObj).css("display"));

        }
        catch(error)
        {
            if(error == "Error: [pvChart ERROR]: Invalid operation. Chart type requires unassigned role 'y'."){
                //alert(Messages.onChartRenderError + "\nError : Inproper dataset : Please give dataset with one category and two measures and change one property called cross tab mode to false " );
                $("#" + htmlObj+ "_chart").html("<div style=\"text-align: center;text-decoration:underline;color:red;\">Error <br /> Inproper dataset </div><div style='text-align:center;'><h6><u>Tip</u><br/> Please provide dataset with one category and two measures.<br /> Also change one property called CrossTabMode to false </h6></div>");
            }
            else
            {
                //alert(Messages.onChartRenderError + "\nError : " + error);    
                $log.error(error);
            }
        }

        $("#" + htmlObj+"_chart").css("display","block");

    };

    pin.prototype.saveConfigToFile = function(){
        $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : Started");
        var param = {
            "file"  :  this.pinFile ,
            "content"  : this.getJson()
        };
        $log.debug(this.getJson());
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);
        if(jsonData.result =="Success."){
            $log.debug("Pin( "+  this.pinId  +  " ).saveConfigToFile : ended : SuccessFully");
            return true;
        }
        else{
            $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : ended : Error : " + jsonData.result );
            return false;
        }
    };

    pin.prototype.getConfigFromFile = function() {
        $log.log("Pin( "+  this.pinId  +  " ).getConfigFromFile : Started" );

        if(this.pinFile == undefined || this.pinFile.length <1)
        {

            this.title = "Existing Pin is not Configured";
            this.pinHeaderColor = "panel-blue3";
            this.dataSource = "";
            this.height = 200;
            this.width = "100";

        }
        else
        {
            var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ this.pinFile,"GET",null).result);
            $log.debug(jsonData);
            try
            {
                this.pinId = jsonData.pinId;
                this.pinIcon = jsonData.pinIcon;
                this.title = jsonData.title;
                this.minimize = jsonData.minimize=="true"?true :false;
                this.isHeader = jsonData.isHeader=="true"?true :false;
                if(jsonData.pinHeaderColor==undefined && (jsonData.bootstrapStyle!= undefined && jsonData.bootstrapStyle.length > 0))
                    this.pinHeaderColor = 'panel-blue3';
                else if(jsonData.pinHeaderColor.length>0)
                    this.pinHeaderColor = jsonData.pinHeaderColor;
                else
                    this.pinHeaderColor = 'panel-green1';
                this.dataSource = jsonData.dataSource;
                this.dataAccessId = jsonData.dataAccessId;
                this.defaultParamStr = jsonData.defaultParamStr;
                this.paramStr =  jsonData.defaultParamStr;
                this.chartType = jsonData.chartType;
                this.visualization = jsonData.visualization;

                if(jsonData.chartProperties != undefined && jsonData.chartProperties.length > 0)
                {
                    //var chartType = commonUtils.getChartType(this.chartType);
                    this.chartProperties = commonUtils.readJSONFile('component/'+this.chartType+'/'+this.chartType+'.'+this.visualization+'.properties.json');
                    for(var i=0;i< this.chartProperties.length ;i++)
                    {
                        if(this.chartProperties[i][0] == jsonData.chartProperties[i][0])
                        {

                            this.chartProperties[i][3] = commonUtils.parsePropertiesDataType(jsonData.chartProperties[i][1],jsonData.chartProperties[i][2]);
                        }
                    }
                }
                else
                {
                    this.chartProperties = [];
                }
                this.comments = jsonData.comments;
                this.commentsCount = jsonData.commentsCount;
                this.listenerFilters = [];
                this.listenerPins = [];
                this.htmlObj = jsonData.htmlObj;
                this.height = jsonData.height;
                this.width = jsonData.width;
                this.version =jsonData.version;
                this.buildVersion=jsonData.buildVersion;
            }
            catch(err)
            {
                $log.error("Pin( "+  this.pinId  +  " ).getConfigFromFile : Error : " + err.message);
                $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ServerError :  \n" + jsonData);
            }
            $log.debug("pin json data : ");
            $log.debug(this.getJson());
        }

        $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ended : getJson : \n" + this.getJson());
    };
    return pin ;
}]);