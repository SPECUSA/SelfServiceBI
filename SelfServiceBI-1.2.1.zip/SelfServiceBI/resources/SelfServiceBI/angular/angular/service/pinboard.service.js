angular.module('pinboard')
.service('pinboard', ['commonUtils','filterPanel','filter','Pin','$log','$compile',function (commonUtils,filterPanel,filter,Pin,$log,$compile){
    $log.debug("Pinboard service called");
    this.PinBoardID = "NewPinBoard";
    this.PinboardName = "Self Service BI - Pinboard";
    this.pinLists = [];
    this.PinBoardFile = "";
    this.title = "Title";
    this.rowsCount = 0;
    this.uniquePinIdCnt = 0;
    this.filterPanel = Object();
    this.htmlObj = "pinboard";
    this.version = commonUtils.version;
    this.buildVersion = commonUtils.buildVersion;
    this.pinListenerArray = [];
    this.userComments = [];
    this.commentsCount = '';
    this.bgcolor = 'Light';
    this.fonts = 'Default';
    this.transTheme = false;

    this.datasourceList = [];
    this.dataAccessList = [];

    this.options = {
        cellHeight: 60,
        verticalMargin: 10,
        disableDrag : false,
        disableResize : false,
        draggable : {
            scroll : true
        }   
    }

    this.isGridDisable = false;
        
    this.init= function(options) {
        $log.debug("pinboard init is called");
        this.PinBoardID = "NewPinBoard";
        this.PinboardName = "Self Service BI - Pinboard";
        this.pinLists = [];
        this.PinBoardFile = "";
        this.title = "Title";
        this.rowsCount = 0;
        this.uniquePinIdCnt = 0;
        this.htmlObj = "pinboard";
        this.version = commonUtils.version;
        this.buildVersion = commonUtils.buildVersion;
        this.pinListenerArray = [];
        this.userComments = [];
        this.commentsCount = '';
        this.bgcolor = 'Light';
        this.fonts = 'Default';
        this.transTheme = false;

        this.datasourceList = [];
        this.dataAccessList = [];


        this.filterPanel = new filterPanel();
        this.filterPanel.init();
        $log.debug("Pinboard.init: " + this.getJson());
    };

    this.getJson= function() {
        return JSON.stringify(this)
    };

    this.removeAt = function(index) {
        $log.debug("Row remove at index :"+ (index+1));
        //$log.debug("Before remove row" + this.getJson());
        //this.removeListenerFilter(index);
        this.pinLists.splice(index,1);

        
        //$log.debug("After remove row : " + this.getJson());
        if(this.pinLists.length == 0)
            return true;
        else
            return false;

        
    };

    this.removeDAelement = function(dbsrc){
        
        var self = this;
        $.each(this.dataAccessList,function(i,v){
            if(dbsrc==v.dbsrc){
                self.dataAccessList.splice(i,1);
                return false;
            }
                
        })

        //console.log(this.dataAccessList);
    }


    this.addDAelement = function(indx){
        //var lastIdx = datasourceList.length;

        console.log(indx)
        var self = this;
        var dbsrc = this.datasourceList[indx];

        if(dbsrc.indexOf('.saiku')>0)
            return;
        var tempDASrc = commonUtils.synchronousJsonCall('http://'+location.host+'/pentaho/plugin/cda/api/listQueries?path='+dbsrc,'GET',null);
        if(tempDASrc!=undefined && tempDASrc.resultset.length>0){
            var daList = [];
            $.each(tempDASrc.resultset,function(i,v){
                daList.push(v[0]);
            })
            var tempObj =   {
                                "dbsrc":dbsrc,
                                "daIds":daList
                            }

                            console.log(tempObj);
            self.dataAccessList.push(tempObj);
        } 


        //console.log(this.dataAccessList);           
    }
    this.saveConfigToFile = function(){
        console.log(this);

        $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Starterd");
        var param = { "file"  :  this.PinBoardFile ,
            "content"  : JSON.stringify(this) };
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);

        if(jsonData.result =="Success.")
        {
            $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Ended : Successfully");
            return true;
        }
        else
        {
            $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Ended : Error : " + jsonData.result );
            return false;
        }
        
    };

    this.getConfigFromFile = function() {
        $log.log("Pinboard( "+  this.pinId  +  " ).getConfigToFile(" +  this.pinFile  + ") :   Started");
        var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ this.PinBoardFile,"GET",null).result);
        $log.log(jsonData);

        this.removeAll();

        
        
        this.PinBoardID = jsonData.PinBoardID;
        this.PinboardName=void 0==jsonData.PinboardName?"Self Service BI - Pinboard":jsonData.PinboardName;

        this.PinBoardFile = jsonData.PinBoardFile;
        this.title =jsonData.title;
        this.rowsCount = parseInt(jsonData.rowsCount);
        this.uniquePinIdCnt = parseInt(jsonData.uniquePinIdCnt);
        this.htmlObj = jsonData.htmlObj;
        this.version =jsonData.version;
        this.buildVersion=jsonData.buildVersion;
        
        this.filterPanel = new filterPanel();
        this.filterPanel.initmap(jsonData.filterPanel);
        var filterListArray = [];
        $.each(jsonData.filterPanel.filterArray, function( index, filterVal ){
            filterListArray[index] = new filter();
            filterListArray[index].initmap(filterVal);
        });
        this.filterPanel.filterArray = [];
        this.filterPanel.filterArray = filterListArray;

        undefined==jsonData.userComments?(this.userComments=[],this.commentsCount=0):(this.userComments = jsonData.userComments, this.commentsCount =jsonData.commentsCount)
        undefined==jsonData.bgcolor?(this.bgcolor = 'Light',this.fonts = 'open_sansregular'):(this.bgcolor = jsonData.bgcolor,this.fonts = jsonData.fonts)
        this.transTheme = jsonData.transTheme;
        this.pinLists = [];
        var self = this;

        if(3.1<=parseFloat(this.version) && jsonData.pinLists[0].pin != void 0){
            console.log("here i am")
            $.each(jsonData.pinLists,function(i,v){
                console.log(v);
                var objPin = {};
                objPin.x = v.x;
                objPin.y = v.y;
                objPin.height = v.height;
                objPin.width = v.width;
                objPin.id = v.id;
                objPin.pin = [];
                objPin.pin[0] = new Pin();
                objPin.pin[0].initmap(v.pin[0]);
                objPin.pin[0].height = objPin.height*70- 48;

                self.pinLists.push(objPin)
            })

            this.pinListenerArray = jsonData.pinListenerArray;
        }
        else{
            var pinLists = [];
            $.each(jsonData.pinLists,function(i,v){
                var cols = parseInt(v.cols);
                var layout = v.mdLayout;

                for(var p=0;p<cols;p++){
                    var temp = Math.round((Number(v.pins[p].height)+38+10)/70);
                    self.uniquePinIdCnt++;
                    var objPin = {};
                    objPin.x = 0;
                    objPin.y = 0;
                    objPin.height = temp>1?temp:2;
                    objPin.width = layout[p];
                    objPin.id = v.pins[p].pinId;
                    objPin.pin = [];
                    objPin.pin[0] = new Pin();
                    objPin.pin[0].initmap(v.pins[p]);
                    objPin.pin[0].height = objPin.height*70- 48;

                    
                    //console.log(objPin.pin[0].chartProperties)
                    if(objPin.pin[0].chartProperties.length > 0 && objPin.pin[0].chartProperties[0].length <4){
                        var a = objPin.pin[0].chartProperties
                        var b = commonUtils.readJSONFile('component/'+objPin.pin[0].chartType+'/'+objPin.pin[0].chartType+'.'+objPin.pin[0].visualization+'.properties.json');
                        for(var i=0;i<b.length;i++){
                            for(var j=0;j<a.length;j++){
                                if(b[i][0]==a[j][0])
                                    b[i][3] = commonUtils.parsePropertiesDataType(a[j][1],a[j][2]); 
                            }
                        }

                        objPin.pin[0].chartProperties = b;

                    }



                    // var defaultParams = objPin.pin[0].defaultParamStr.split("&");
                    // defaultParams[0]==""?defaultParams.shift():console.log("defaultParams");
                    // var tempObj = {};
                    // for(var x=0;x<defaultParams.length;x++){
                    //     var tempParams = defaultParams[x].split("=");
                        
                    //     tempObj[tempParams[0].substr(5)] = tempParams[1];
                    // }

                    // console.log(tempObj);

                    console.log(self.filterPanel);



                    // {
                    //     console.log(objPin.pin[0].defaultParamStr);
                    //     var tempTemp = objPin.pin[0].defaultParamStr.split("&");
                    //     tempTemp.shift();
                    //     var tempObject = {};
                    //     var tempAbc = tempTemp[0].split("=");
                    //     tempObject[tempAbc[0].substr(5)] = tempAbc[1];
                    //     console.log(tempObject)
                    // }
                    self.pinLists.push(objPin)

                }

            })
            //console.log(this.pinLists);

            var tempArry = jsonData.pinListenerArray==void 0?[]:jsonData.pinListenerArray;

            for(var i=0;i<tempArry.length;i++){
                tempArry[i].pinId = jsonData.pinLists[tempArry[i].rowIdx].pins[tempArry[i].colIdx].pinId;
                delete tempArry[i].rowIdx;
                delete tempArry[i].colIdx;
            }

            this.pinListenerArray = tempArry;
            this.version =commonUtils.version;
            
        }


        



        console.log(this);

    };

    this.removeAll= function(pinData) {
        while(this.pinLists.length > 0) {
            this.pinLists.pop();
        }
        
        //this.filterPanel.filterPanelShow = true;
        //this.rowsCount = 0;
    };
    
    this.getPinRow = function(index) {
        var pinRow;
        pinRow = this.pinLists[index-1];
        //if(Config.debug)
            $log.debug("getPinRow.getJson() : " + pinRow.getJson());
        return pinRow;
    };

    this.resizeChart = function (){
        $log.log("Resize Called.");
        for(var i =0; i<this.pinLists.length;i++)
            this.pinLists[i].pin[0].render(this.pinLists[i].pin[0].paramStr);
    }
   
}]);