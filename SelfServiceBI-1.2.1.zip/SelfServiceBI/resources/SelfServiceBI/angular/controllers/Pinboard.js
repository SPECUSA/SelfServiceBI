angular.module('pinboard',['commonUtilModule','messagesModule','colorpicker.module','ui.bootstrap','gridstack-angular','ui.checkbox']);

angular.module('pinboard')
.config(['$logProvider',function($logProvider){
    $logProvider.debugEnabled(false);
}]);

function fireChange(param){

    for(var i=0;i<param.length;i++){
        angular.element($("#"+param[i].pinId)).scope().fireChange(param[i].param,param[i].value);
    }

}
angular.module('pinboard')
.factory('Pin',['commonUtils','$log','Messages',function (commonUtils,$log,Messages) {
    $log.debug("Pin Factory called");
    var pin = function(){
        this.mode = "";
        this.cIdx =-1; // Column Index
        this.pinId = "newPin" ; //Extension Perpose
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.pinHeaderColor = "panel-blue3";
        this.pinFontColor  = "Light"
        //this.dataSource = "/home/admin/SelfServiceBI/Test.saiku";
        
        this.height = 200;
        this.width = "100";
        this.htmlObj = "PanelChart";
        this.version = commonUtils.version;
        this.buildVersion= commonUtils.buildVersion;

        this.chartType = "CCC";
        this.dataSource = "";
        this.visualization = "Bar"; // Chart type
        this.dataAccessId = "";
        this.defaultParamStr = {};
        this.paramStr = "";
        this.paramValStr = "";

        this.conditions = [];

        this.listenerFilters = [];
        this.chartProperties = [];

        this.listenerPins = [];
        this.comments = [];
        this.commentsCount = '';
        this.currentSaiku = false;
    };
    pin.prototype.init = function(options){

        $log.debug("Pin( "+  this.pinId  +  " ).init : Default values");
        this.pinId = "newPin";
        this.cIdx =-1;
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.pinHeaderColor = "panel-green1";
        this.pinFontColor  = "Light"
        
        this.height = 200;
        this.width = "100";
        this.htmlObj = "PanelChart";

        this.chartType = "CCC";
        this.dataSource = "";
        this.visualization = "Bar"; // Chart type
        this.dataAccessId = "";
        this.defaultParamStr = {};
        this.paramStr = "";
        this.paramValStr = "";
        this.conditions = [];
        this.listenerFilters = [];
        this.chartProperties = [];
        this.listenerPins = [];
        this.comments = [];
        this.commentsCount = '';
        this.currentSaiku = false;
    };

    pin.prototype.initmap = function(o){

        this.pinId = o.pinId;
        this.cIdx = o.cIdx;
        this.pinIcon = o.pinIcon
        this.pinFile = o.pinFile||"";
        this.title = o.title;
        this.minimize = (o.minimize=="true"?true:false)||true;
        this.isHeader = (o.isHeader=="true"?true:false)||true;
        this.pinHeaderColor = o.pinHeaderColor || "panel-green1";
        this.pinFontColor  = o.pinFontColor || "Light"
        this.height = o.height;
        this.width = o.width;
        this.htmlObj = o.htmlObj;
        this.chartType = o.chartType;
        this.dataSource = o.dataSource;
        this.visualization = o.visualization; // Chart type
        this.dataAccessId = o.dataAccessId||'';
        this.defaultParamStr = o.defaultParamStr||{};
        this.paramStr = o.paramStr||'';
        this.conditions = o.conditions||[];
        this.listenerFilters = o.listenerFilters||[];
        this.chartProperties = o.chartProperties||[];
        this.listenerPins = o.listenerPins||[];
        this.comments = o.comments||[];
        this.commentsCount = o.commentsCount||'';
        this.currentSaiku = o.currentSaiku||false;

    }

    pin.prototype.isDefault = function(){
        if(this.pinId == "newPin" && this.pinIcon == "glyphicon glyphicon-pushpin" && this.title == "New Pin" && this.minimize == true && this.isHeader == true && this.pinHeaderColor == "panel-blue3" && this.height == 200 && this.chartType == "CCC" && this.dataSource == "")
            return true;
        else
            return false;
    }


    pin.prototype.getJson = function(){
        $log.debug("pinid : "+this.pinId);
        var json =  "{"+
                    "\"pinId\" : \""+  $.trim(this.pinId)  +  "\" , " +
                    "\"pinIcon\" : \""+  $.trim(this.pinIcon)  +  "\" , " +
                    "\"title\" : \""+  $.trim(this.title)  +  "\" , " +
                    "\"minimize\" : \""+  this.minimize +  "\" , " +
                    "\"isHeader\" : \""+  this.isHeader +  "\" , " +
                    "\"pinHeaderColor\" : \""+  $.trim(this.pinHeaderColor)  +  "\" , " +
                    "\"dataSource\" : \""+  $.trim(this.dataSource)   +  "\" , " +
                    "\"dataAccessId\" : \""+  $.trim(this.dataAccessId)   +  "\" , " +
                    "\"defaultParamStr\" : \""+  $.trim(this.defaultParamStr)   +  "\" , "  +
                    //"\"paramStr\" : \""+  $.trim(this.paramStr)   +  "\" , "  +
                    "\"chartType\" : \""+  $.trim(this.chartType)   +  "\" , " +
                    "\"visualization\" : \""+  $.trim(this.visualization)   +  "\" , "  ;


            if(this.chartProperties != undefined && this.chartProperties.length > 0)
            {

                json = json +  "\"chartProperties\" : " ;
                json = json + "[";

                for(var i=0;i<this.chartProperties.length;i++){
                    if(this.chartProperties[i][2] == "javascript" || this.chartProperties[i][1] == "array") // we use stringify for array and javascript store in json
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" ,"+  JSON.stringify($.trim(this.chartProperties[i][3]))   +  ", " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                        //$log.debug(this.chartProperties[i][0] + " - "  + this.chartProperties[i][3]);
                    }
                    else
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][3])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                    }

                    if(i == this.chartProperties.length-1)
                    {
                        json = json + "]";
                    }
                    else{
                        json = json + "],";
                    }

                }
                json = json + "],";
            }
            else
            {
                json = json + "\"chartProperties\" : [] , " ;
            }

        $log.debug("listenerFilters "+this.listenerFilters);
        json = json + "\"listenerFilters\" : ";
        json = json + "[";
        len = this.listenerFilters.length;
        if(this.listenerFilters.length >0){
            for(var i=0;i<len;i++){
                json = json + "[";
                json = json  + "\"" +$.trim(this.listenerFilters[i][0])+"\" ,";
                json = json  + "\"" +$.trim(this.listenerFilters[i][1])+"\" ";
                if(i == len-1){
                    json = json + "]";    
                }
                else{
                    json = json + "],";   
                }
                
            }
        }
        json = json +   "],";

        $log.debug("listenerPins "+this.listenerPins);
        json = json + "\"listenerPins\" : ";
        json = json + "[";

        if(this.listenerPins != undefined){
            len = this.listenerPins.length;
            if(this.listenerPins.length >0){
                for(var i=0;i<len;i++){
                    json = json + "[";
                    json = json  + "\"" +$.trim(this.listenerPins[i][0])+"\" ,";
                    json = json  + "\"" +$.trim(this.listenerPins[i][1])+"\" ,";
                    json = json  + "\"" +$.trim(this.listenerPins[i][2])+"\" ";
                    if(i == len-1){
                        json = json + "]";    
                    }
                    else{
                        json = json + "],";   
                    }
                    
                }
            }    
        }
        
        json = json +   "],";

        $log.debug("comments "+this.comments);
        json = json + "\"comments\" : ";
        json = json + "[";
        
        if(this.comments!=undefined){
            len = this.comments.length;
            if(this.comments.length >0){
                for(var i=0;i<len;i++){
                    
                    json = json + "[";
                    json = json  + "\"" +$.trim(this.comments[i][0])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][1])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][2])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][3])+"\" ";
                    if(i == len-1){
                        json = json + "]";    
                    }
                    else{
                        json = json + "],";   
                    } 
                }
            }    
        }
        
        json = json +   "],";


        json = json +   "\"commentCounts\" : \""+  $.trim(this.commentsCount)   +  "\" , " +
                        "\"height\" : \""+  $.trim(this.height)   +  "\" , " +
                        "\"width\" : \""+  $.trim(this.width)   +  "\" , " +
                        "\"htmlObj\" : \""+  $.trim(this.htmlObj)+  "\" , " +
                        "\"version\" : \""+  $.trim(this.version)+  "\" , " +
                        "\"buildVersion\" : \""+  $.trim(this.buildVersion)+  "\" " +
                        "}";

        /* if(Config.debug)
         $log.debug("Pin("+  this.pinId  +  " ).getJson() : " + json);
         */
        //$log.log(json);
        return json;
    };

    pin.prototype.render = function(param,htmlDiv,isZoom){
        
        var htmlObj = htmlDiv || this.htmlObj
        var width = $("#" + htmlObj).parent().width()-5;
        var height = $('#'+htmlDiv).height()  || this.height;
        
        if(isZoom){
            height = $('#'+htmlDiv).height();
        }
        console.log(height);
        height -=30;
        width -=30;


        $("#" + htmlObj+"_chart").empty();
        $("#" + htmlObj).html('<div id="'+ htmlObj+'_chart" style="height:'+height+'px;width:'+width+'px;"></div>' );

        //console.log($("#" + htmlObj).html());
        // $("#"+this.htmlObj).append('<canvas id="'+ this.htmlObj+'_chart_1" style="width:'+width+'px; height:'+ this.height+'px;"></canvas>')

                                // console.log(this.htmlObj);
                                // console.log(this.chartType);
                                // console.log(param)
        try {
            if (this.dataSource == undefined || this.dataSource.length < 1) {
                $("#" + this.htmlObj+ "_chart").html("<div style=\"text-align: center;\">" + Messages.NoDataSourceSelected + "</div>");
            }
            else if (this.chartType == "Saiku") {
                var visualization = this.currentSaiku || this.visualization;

                var saikuClientRenderer = new SaikuClient(
                    {
                        server: "/pentaho/plugin/saiku",
                        path: "/cde-component"
                    });

                
                var tempParamObj = {};

                for(paramval in param){
                    //console.log(paramval + " " + param[paramval])
                    if(param[paramval]!=null){
                        tempParamObj[paramval] = param[paramval];
                    }
                }

                

                var chartDef = {};
                for(var i=0;i<this.chartProperties.length;i++){
                    chartDef[this.chartProperties[i][0]] = this.chartProperties[i][3]
                }
                if ((visualization).toLowerCase() != "table"){
                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: "#" + htmlObj+"_chart",
                        render: "chart",
                        mode: (visualization).substring(0,1).toLowerCase()+(visualization).substring(1),
                        zoom: true,
                        params:tempParamObj,
                        chartDefinition: chartDef
                    });
                }
                else {
                    $("#" + htmlObj).addClass('workspace_results');
                    var t = $("<div></div>");
                    $("#" + htmlObj+"_chart").html(t);
                    htmlId = t;

                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: htmlId,
                        render: "table",
                        mode: "sparkline",
                        zoom: true
                    });
                }
                $log.debug("Rendering configuration");
                $log.debug("Pin( " + this.pinId + " ).render : htmlID : " + htmlObj);
                $log.debug("Pin( " + this.pinId + " ).render : dataSource : " + this.dataSource);
                $log.debug("Pin( " + this.pinId + " ).render : chart : " + visualization);
                $log.debug("Pin( " + this.pinId + " ).render : Ended");

            }
            else if (this.chartType == "CCC") {

                var chartType = window["CCC"+ this.visualization];
                var visualization = new chartType();
                $log.debug(this.chartType + " " + this.visualization);
                // if (param == undefined) {
                //     param = "";
                // }
                
                var paramStr = commonUtils.parseParams(angular.copy(param));
                //console.log(this);
                // var data = commonUtils.getDatasourceData(this.dataSource,this.dataAccessId,"data");
                // if(!data){
                //     url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + this.dataSource + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                //     data = commonUtils.synchronousJsonCall(url);

                //     commonUtils.setDatasourceData(this.dataSource,this.dataAccessId,data,"data");
                // }

                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + paramStr + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);

                visualization.init(this.pinId, data, htmlObj+"_chart", this.chartProperties);

            }
            else if(this.chartType == "Fusion"){
                if (param == undefined) {
                    param = "";
                }
                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);


                var visualization = new fusionChart();
                visualization.init(this.pinId,data,htmlObj+"_chart");
            }
            else{
                
                var chartType = window[this.visualization];
                //$log.log(chartType);
                var visualization = new chartType();
                // if (param == undefined) {
                //     param = "";
                // }
                var paramStr = commonUtils.parseParams(angular.copy(this.paramStr));
                // var data = commonUtils.getDatasourceData(this.dataSource,this.dataAccessId,"data");
                // if(!data){
                //     url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + this.dataSource + '&dataAccessId=' + this.dataAccessId + param + '&outputIndexId=1';
                //     data = commonUtils.synchronousJsonCall(url);

                //     commonUtils.setDatasourceData(this.dataSource,this.dataAccessId,data,"data");
                // }

                uri = this.dataSource;
                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + uri + '&dataAccessId=' + this.dataAccessId + paramStr + '&outputIndexId=1';
                var data = commonUtils.readJSONFile(url);
                
                visualization.init(this.pinId,data,htmlObj+"_chart",this.chartProperties,this.conditions);
            }

            //console.log($("#" + htmlObj).css("display"));

        }
        catch(error)
        {
            if(error == "Error: [pvChart ERROR]: Invalid operation. Chart type requires unassigned role 'y'."){
                //alert(Messages.onChartRenderError + "\nError : Inproper dataset : Please give dataset with one category and two measures and change one property called cross tab mode to false " );
                $("#" + htmlObj+ "_chart").html("<div style=\"text-align: center;text-decoration:underline;color:red;\">Error <br /> Inproper dataset </div><div style='text-align:center;'><h6><u>Tip</u><br/> Please provide dataset with one category and two measures.<br /> Also change one property called CrossTabMode to false </h6></div>");
            }
            else
            {
                //alert(Messages.onChartRenderError + "\nError : " + error);    
                $log.error(error);
            }
        }

        $("#" + htmlObj+"_chart").css("display","block");

    };

    pin.prototype.saveConfigToFile = function(){
        $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : Started");
        var param = {
            "file"  :  this.pinFile ,
            "content"  : this.getJson()
        };
        $log.debug(this.getJson());
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);
        if(jsonData.result =="Success."){
            $log.debug("Pin( "+  this.pinId  +  " ).saveConfigToFile : ended : SuccessFully");
            return true;
        }
        else{
            $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : ended : Error : " + jsonData.result );
            return false;
        }
    };

    pin.prototype.getConfigFromFile = function() {
        


        if(this.pinFile == undefined || this.pinFile.length <1)
        {

            this.title = "Existing Pin is not Configured";
            this.pinHeaderColor = "panel-blue3";
            this.dataSource = "";
            this.height = 200;
            this.width = "100";

        }
        else
        {
            var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ getBURIComponent(this.pinFile),"GET",null).result);
            $log.debug(jsonData);
            try
            {
                this.pinId = jsonData.pinId;
                this.pinIcon = jsonData.pinIcon;
                this.title = jsonData.title;
                this.minimize = jsonData.minimize=="true"?true :false;
                this.isHeader = jsonData.isHeader=="true"?true :false;
                if(jsonData.pinHeaderColor==undefined && (jsonData.bootstrapStyle!= undefined && jsonData.bootstrapStyle.length > 0))
                    this.pinHeaderColor = 'panel-blue3';
                else if(jsonData.pinHeaderColor.length>0)
                    this.pinHeaderColor = jsonData.pinHeaderColor;
                else
                    this.pinHeaderColor = 'panel-green1';
                this.dataSource = jsonData.dataSource;
                this.dataAccessId = jsonData.dataAccessId;
                this.defaultParamStr = jsonData.defaultParamStr;
                this.paramStr =  jsonData.defaultParamStr;
                this.chartType = jsonData.chartType;
                this.visualization = jsonData.visualization;

                if(jsonData.chartProperties != undefined && jsonData.chartProperties.length > 0)
                {
                    //var chartType = commonUtils.getChartType(this.chartType);
                    this.chartProperties = commonUtils.readJSONFile('component/'+this.chartType+'/'+this.chartType+'.'+this.visualization+'.properties.json');
                    for(var i=0;i< this.chartProperties.length ;i++)
                    {
                        if(this.chartProperties[i][0] == jsonData.chartProperties[i][0])
                        {

                            this.chartProperties[i][3] = commonUtils.parsePropertiesDataType(jsonData.chartProperties[i][1],jsonData.chartProperties[i][2]);
                        }
                    }
                }
                else
                {
                    this.chartProperties = [];
                }
                this.comments = jsonData.comments;
                this.commentsCount = jsonData.commentsCount;
                this.listenerFilters = [];
                this.listenerPins = [];
                this.htmlObj = jsonData.htmlObj;
                this.height = jsonData.height;
                this.width = jsonData.width;
                this.version =jsonData.version;
                this.buildVersion=jsonData.buildVersion;
            }
            catch(err)
            {
                $log.error("Pin( "+  this.pinId  +  " ).getConfigFromFile : Error : " + err.message);
                $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ServerError :  \n" + jsonData);
            }
            $log.debug("pin json data : ");
            $log.debug(this.getJson());
        }

        $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ended : getJson : \n" + this.getJson());
    };
    return pin ;
}]);


angular.module('pinboard')
.service('pinboard', ['commonUtils','Messages','filterPanel','filter','Pin','$log','$compile',function (commonUtils,Messages,filterPanel,filter,Pin,$log,$compile){
    $log.debug("Pinboard service called");
    this.PinBoardID = "NewPinBoard";
    this.PinboardName = "Self Service BI - Pinboard";
    this.pinLists = [];
    this.PinBoardFile = "";
    this.title = "Title";
    this.rowsCount = 0;
    this.uniquePinIdCnt = 0;
    this.filterPanel = Object();
    this.htmlObj = "pinboard";
    this.version = commonUtils.version;
    this.buildVersion = commonUtils.buildVersion;
    this.pinListenerArray = [];
    this.userComments = [];
    this.commentsCount = '';
    this.bgcolor = 'Light';
    this.fonts = 'Default';
    this.transTheme = false;

    this.datasourceList = [];
    this.dataAccessList = [];



    this.options = {
        cellHeight: 60,
        verticalMargin: 10,
        disableDrag : false,
        disableResize : false,
        draggable : {
            scroll : true
        }
    }

    this.isGridDisable = false;
        
    this.init= function(options) {
        $log.debug("pinboard init is called");
        this.PinBoardID = "NewPinBoard";
        this.PinboardName = "Self Service BI - Pinboard";
        this.pinLists = [];
        this.PinBoardFile = "";
        this.title = "Title";
        this.rowsCount = 0;
        this.uniquePinIdCnt = 0;
        this.htmlObj = "pinboard";
        this.version = commonUtils.version;
        this.buildVersion = commonUtils.buildVersion;
        this.pinListenerArray = [];
        this.userComments = [];
        this.commentsCount = '';
        this.bgcolor = 'Light';
        this.fonts = 'Default';
        this.transTheme = false;

        this.datasourceList = [];
        this.dataAccessList = [];


        this.filterPanel = new filterPanel();
        this.filterPanel.init();
        $log.debug("Pinboard.init: " + this.getJson());
    };

    this.getJson= function() {
        return JSON.stringify(this)
    };

    this.removeAt = function(index) {
        $log.debug("Row remove at index :"+ (index+1));
        //$log.debug("Before remove row" + this.getJson());
        //this.removeListenerFilter(index);
        this.pinLists.splice(index,1);

        
        //$log.debug("After remove row : " + this.getJson());
        if(this.pinLists.length == 0)
            return true;
        else
            return false;

        
    };

    this.removeDAelement = function(dbsrc){
        
        var self = this;
        $.each(this.dataAccessList,function(i,v){
            if(dbsrc==v.dbsrc){
                self.dataAccessList.splice(i,1);
                return false;
            }
                
        })
    }


    this.addDAelement = function(indx){
        var self = this;
        var dbsrc = this.datasourceList[indx];

        if(dbsrc.indexOf('.saiku')>0)
            return;
        var tempDASrc = commonUtils.synchronousJsonCall('http://'+location.host+'/pentaho/plugin/cda/api/listQueries?path='+dbsrc,'GET',null);
        if(tempDASrc!=undefined && tempDASrc.resultset.length>0){
            var daList = [];
            $.each(tempDASrc.resultset,function(i,v){
                daList.push(v[0]);
            })
            var tempObj =   {
                                "dbsrc":dbsrc,
                                "daIds":daList
                            }
            self.dataAccessList.push(tempObj);
        } 
    }
    this.saveConfigToFile = function(){
        
        $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Starterd");
        var param = { "file"  :  this.PinBoardFile ,
            "content"  : JSON.stringify(this) };
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);

        if(jsonData.result =="Success.")
        {
            $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Ended : Successfully");
            return true;
        }
        else
        {
            $log.debug("Pinboard( "+  this.PinBoardID  +  " ).saveConfigToFile(" +  this.PinBoardFile  + ") :   Ended : Error : " + jsonData.result );
            return false;
        }
        
    };

    this.getConfigFromFile = function() {
        //this.PinBoardFile = decodeURIComponent(this.PinBoardFile);
        $log.debug("Pinboard.getConfigToFile(" +  this.PinBoardFile  + ") :   Started");
        //console.log(encodeURIComponent(this.pinFile));
        var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ encodeURIComponent(this.PinBoardFile),"GET",null).result);
        

        this.removeAll();

        
        
        this.PinBoardID = jsonData.PinBoardID;
        this.PinboardName=void 0==jsonData.PinboardName?"Self Service BI - Pinboard":jsonData.PinboardName;

        this.PinBoardFile = jsonData.PinBoardFile;
        this.title =jsonData.title;
        this.rowsCount = parseInt(jsonData.rowsCount);
        this.uniquePinIdCnt = parseInt(jsonData.uniquePinIdCnt);
        this.htmlObj = jsonData.htmlObj;
        this.version =jsonData.version;
        this.buildVersion=jsonData.buildVersion;
        
        this.filterPanel = new filterPanel();
        this.filterPanel.initmap(jsonData.filterPanel);
        var filterListArray = [];
        $.each(jsonData.filterPanel.filterArray, function( index, filterVal ){
            filterListArray[index] = new filter();
            filterListArray[index].initmap(filterVal);
        });
        this.filterPanel.filterArray = [];
        this.filterPanel.filterArray = filterListArray;

        undefined==jsonData.userComments?(this.userComments=[],this.commentsCount=0):(this.userComments = jsonData.userComments, this.commentsCount =jsonData.commentsCount)
        undefined==jsonData.bgcolor?(this.bgcolor = 'Light',this.fonts = 'open_sansregular'):(this.bgcolor = jsonData.bgcolor,this.fonts = jsonData.fonts)
        this.transTheme = jsonData.transTheme;
        this.pinLists = [];
        var self = this;

        if(3.1<=parseFloat(this.version) && jsonData.pinLists[0].pin != void 0){
            
            $.each(jsonData.pinLists,function(i,v){
            
                var objPin = {};
                objPin.x = v.x;
                objPin.y = v.y;
                objPin.height = v.height;
                objPin.width = v.width;
                objPin.id = v.id;
                objPin.pin = [];
                objPin.pin[0] = new Pin();
                objPin.pin[0].initmap(v.pin[0]);
                objPin.pin[0].height = objPin.height*70- 48;

                self.pinLists.push(objPin)
            })

            this.pinListenerArray = jsonData.pinListenerArray;
        }
        else{
            var pinLists = [];
            $.each(jsonData.pinLists,function(i,v){
                var cols = parseInt(v.cols);
                var layout = v.mdLayout;

                for(var p=0;p<cols;p++){
                    var temp = Math.round((Number(v.pins[p].height)+38+10)/70);
                    self.uniquePinIdCnt++;
                    var objPin = {};
                    objPin.x = 0;
                    objPin.y = 0;
                    objPin.height = temp>1?temp:2;
                    objPin.width = layout[p];
                    objPin.id = v.pins[p].pinId;
                    objPin.pin = [];
                    objPin.pin[0] = new Pin();
                    objPin.pin[0].initmap(v.pins[p]);
                    objPin.pin[0].height = objPin.height*70- 48;

                    
                    //console.log(objPin.pin[0].chartProperties)
                    if(objPin.pin[0].chartProperties.length > 0 && objPin.pin[0].chartProperties[0].length <4){
                        var a = objPin.pin[0].chartProperties
                        var b = commonUtils.readJSONFile('component/'+objPin.pin[0].chartType+'/'+objPin.pin[0].chartType+'.'+objPin.pin[0].visualization+'.properties.json');
                        for(var i=0;i<b.length;i++){
                            for(var j=0;j<a.length;j++){
                                if(b[i][0]==a[j][0])
                                    b[i][3] = commonUtils.parsePropertiesDataType(a[j][1],a[j][2]); 
                            }
                        }

                        objPin.pin[0].chartProperties = b;

                    }



                    // var defaultParams = objPin.pin[0].defaultParamStr.split("&");
                    // defaultParams[0]==""?defaultParams.shift():console.log("defaultParams");
                    // var tempObj = {};
                    // for(var x=0;x<defaultParams.length;x++){
                    //     var tempParams = defaultParams[x].split("=");
                        
                    //     tempObj[tempParams[0].substr(5)] = tempParams[1];
                    // }

                    // console.log(tempObj);
                    // {
                    //     console.log(objPin.pin[0].defaultParamStr);
                    //     var tempTemp = objPin.pin[0].defaultParamStr.split("&");
                    //     tempTemp.shift();
                    //     var tempObject = {};
                    //     var tempAbc = tempTemp[0].split("=");
                    //     tempObject[tempAbc[0].substr(5)] = tempAbc[1];
                    //     console.log(tempObject)
                    // }
                    self.pinLists.push(objPin)

                }

            })
            //console.log(this.pinLists);

            var tempArry = jsonData.pinListenerArray==void 0?[]:jsonData.pinListenerArray;

            for(var i=0;i<tempArry.length;i++){
                tempArry[i].pinId = jsonData.pinLists[tempArry[i].rowIdx].pins[tempArry[i].colIdx].pinId;
                delete tempArry[i].rowIdx;
                delete tempArry[i].colIdx;
            }

            this.pinListenerArray = tempArry;
            this.version =commonUtils.version;
            
        }
    };

    this.removeAll= function(pinData) {
        while(this.pinLists.length > 0) {
            this.pinLists.pop();
        }
        
        //this.filterPanel.filterPanelShow = true;
        //this.rowsCount = 0;
    };
    
    this.getPinRow = function(index) {
        var pinRow;
        pinRow = this.pinLists[index-1];
        //if(Config.debug)
            $log.debug("getPinRow.getJson() : " + pinRow.getJson());
        return pinRow;
    };

    this.resizeChart = function (){
        
        for(var i =0; i<this.pinLists.length;i++)
            this.pinLists[i].pin[0].render(this.pinLists[i].pin[0].paramStr);
    }
    
    this.resizePinNoti = function(){
        
        commonUtils.notification(Messages.onPinResize);
    }
}]);

angular.module('pinboard')
.factory('filter',['commonUtils','$log',function(commonUtils,$log){
    var filter = function(){
        this.filterId = "";
        this.filterName = "";
        this.filterCaption = "";
        this.defaultVal = "";
        this.filterVal = "";
        this.filterType = "";
        this.htmlComponent = "";
        this.dataSource = "";
        this.dataAccessId = "";
        this.datasourceArray = [];
        this.listenerPins = [];
        this.position = "";
        this.filterWidth = "120";
    };
    filter.prototype.initmap = function(o){
        
        this.filterId = o.filterId || '';
        this.filterName = o.filterName||"";
        this.filterCaption = o.filterCaption||"";
        this.defaultVal = o.defaultVal||"";
        this.filterVal = o.filterVal||"";
        this.filterType = o.filterType||"";
        this.htmlComponent = o.htmlComponent||"";
        this.dataSource = o.dataSource||"";
        this.dataAccessId = o.dataAccessId||"";
        this.datasourceArray = o.datasourceArray||[];
        this.listenerPins = o.listenerPins||[];
        this.position = o.position||"";
        this.filterWidth = o.filterWidth||"120";
    }

    
    return filter;
}]);

angular.module('pinboard')
.factory('filterPanel',['commonUtils','$log',function(commonUtils,$log){
    var filterPanel = function(){
        this.filterArray = [];
        this.filterPanelId = '';
        this.filterPanelTitle = 'Filter Panel 1';
        this.filterPanelIcon = 'glyphicon glyphicon-filter';
        this.filterPanelColor = 'panel-green1';
        this.filterPanelHeight = '100';
        this.filterPanelShow = false;
        this.filterPanelFontColor = "Light";
    };

    filterPanel.prototype.init = function(){
        this.filterArray = [];
        this.filterPanelId = '';
        this.filterPanelTitle = 'Filter Panel';
        this.filterPanelIcon = 'glyphicon glyphicon-filter';
        this.filterPanelColor = 'panel-green1';
        this.filterPanelHeight = '100';
        this.filterPanelShow = false;
        this.filterPanelFontColor = "Light";
    }
    filterPanel.prototype.initmap = function(o){
        this.filterArray = o.filterArray || [];
        this.filterPanelId = o.filterPanelId || '';
        this.filterPanelTitle = o.filterPanelTitle||'Filter Panel';
        this.filterPanelIcon = o.filterPanelIcon||'glyphicon glyphicon-filter';
        this.filterPanelColor = o.filterPanelColor||'panel-green1';
        this.filterPanelHeight = o.filterPanelHeight||'100';
        this.filterPanelFontColor = o.filterPanelFontColor || "Light";
        if(o.filterPanelShow != undefined && typeof o.filterPanelShow!="boolean")
            this.filterPanelShow = o.filterPanelShow=="true"?true:false;
        
        else if(o.filterPanelShow != undefined && typeof o.filterPanelShow=="boolean")
            this.filterPanelShow = o.filterPanelShow;
            
        else
            this.filterPanelShow = false;
    }



    // filterPanel.prototype.getJson = function(){
    //     var json = "{"+
    //         "\"filterPanelId\" : \""+  $.trim(this.filterPanelId)  +  "\" , " + // currently not using for anything
    //         "\"filterPanelTitle\" : \""+  $.trim(this.filterPanelTitle)  +  "\" , " +
    //         "\"filterPanelIcon\" : \""+  $.trim(this.filterPanelIcon)  +  "\" , " +
    //         "\"filterPanelColor\" : \""+  $.trim(this.filterPanelColor)  +  "\" , " +
    //         "\"filterPanelHeight\" : \""+  this.filterPanelHeight +  "\" , " +
    //         "\"filterArray\" : [";

        
    //     var len = this.filterArray.length ;
    //     $.each( this.filterArray, function( index, value ){

    //         if(index < len-1)
    //             json = json  + value.getJson()+ ",";
    //         else
    //             json = json  + value.getJson();
    //     });

    //     json = json  +"] ,";
    //     json = json  +"\"filterPanelShow\" : \""+  this.filterPanelShow +  "\"" ;
    //     json = json  +"}";
    //     return json;
        
    // }
    return filterPanel;
}]);

angular.module('pinboard')
.directive("filterpanel",['pinboard','$log','$compile','commonUtils','$timeout',function(pinboard,$log,$compile,commonUtils,$timeout){
    return{
        restrict : 'E',
        scope : {
            'filterPanel' : '='
        },
        //transclude: true,
        //bindtoController:true,
        //controllerAs :'filterpanelctrl',
        controller : ['$scope', '$attrs','$element', function (scope, attrs,element) {
            $log.debug("This is filterPanel controller");

            $log.debug("filterPanel : "+pinboard.filterPanel);
            scope.settingVisible = commonUtils.editor;
            scope.filterPanelMinimize = false;

            scope.filterPanel.filterPanelHeight = scope.filterPanel.filterPanelHeight >99 ? scope.filterPanel.filterPanelHeight :100;
            //console.log(scope.filterPanel.filterPanelHeight);

            scope.submitFilter = function(){
                $log.debug("this is submit filter method");
                var len = scope.filterPanel.filterArray.length;
                pinboard.pinListenerArray = [];
                
                //console.log(scope.filterPanel.filterArray); 
                //console.log(pinboard.pinLists[0]);

                var pinListeners = {};

                for(var i=0;i<len;i++){
                    p=scope.filterPanel.filterArray[i].listenerPins.length;
                    if(p>0){
                        for(var j=0;j<p;j++){
                            var pinId = scope.filterPanel.filterArray[i].listenerPins[j].pinId;
                            var cdaParam = scope.filterPanel.filterArray[i].listenerPins[j].param
                            var paramval = scope.filterPanel.filterArray[i].filterVal;

                            if(cdaParam!=undefined){
                                if(pinListeners[pinId]==void 0){
                                    pinListeners[pinId] = {};
                                } 
                                pinListeners[pinId][cdaParam] = paramval;    
                            }
                            

                            
                            //console.log(pinListeners)
                        }
                    }
                }


                for(var key in pinListeners){
                    for(var m=0;m<pinboard.pinLists.length;m++){
                        if(key==pinboard.pinLists[m].pin[0].pinId){
                            pinboard.pinLists[m].pin[0].paramStr = pinListeners[key] ;    
                            pinboard.pinLists[m].pin[0].render(pinListeners[key]);
                        }
                    }
                }

                commonUtils.savedFlag = false;
                $log.debug("Pinboard Json data : ");
                $log.debug(pinboard.getJson());

                $log.debug(pinboard.pinListenerArray);
            };
            scope.resetFilters = function(){
 
                for(i=0;i<scope.filterPanel.filterArray.length;i++){
                    if(scope.filterPanel.filterArray[i].filterType == "multiSelect"){
                        var temp = [];
                        temp= scope.filterPanel.filterArray[i].defaultVal;
                        scope.filterPanel.filterArray[i].filterVal = [];
                        for(j=0;j<temp.length;j++){
                            scope.filterPanel.filterArray[i].filterVal.push(temp[j]);    
                        }
                    }
                    else{
                        scope.filterPanel.filterArray[i].filterVal = scope.filterPanel.filterArray[i].defaultVal;
                    }
                    
                }
                
                $log.debug(scope.filterPanel.filterArray);
                $log.debug("Filter Panel reseted");
            }

            scope.filterPanelSetting = function(){
                $log.debug("this is filter panel setting");
                BootstrapDialog.show({
                            title : 'Filter Panel Setting',
                            message : function(dialog) {
                                var $message = $('<div></div>');
                                //var pageToLoad = dialog.getData('pageToLoad');
                                var template = commonUtils.getHtmlContent('component/templates/filter/filterPanelSetting.html');
                                
                                $message.append($compile(template)(scope));
                                return $message;
                            },
                            // data : {
                            //         'pageToLoad' : 'component/templates/filter/filterPanelSetting.html'
                            // },
                            closable : false,
                            draggable : true,
                            cssClass : 'setting-dialog',
                            onshown : function(dialogRef) {
                                $('#filterpanel').collapse('show');
                                scope.filterPanelTitle = scope.filterPanel.filterPanelTitle;
                                scope.filterPanelIcon = scope.filterPanel.filterPanelIcon;
                                scope.filterPanelColor = scope.filterPanel.filterPanelColor;
                                
                                scope.filterPanelHeight = scope.filterPanel.filterPanelHeight >99 ? scope.filterPanel.filterPanelHeight : 100;
                                commonUtils.safeApply(scope,function(){});
                            },
                            buttons : [{
                                label : 'Apply',
                                action : function(dialogItself) {
                                    scope.filterPanel.filterPanelTitle = scope.filterPanelTitle; 
                                    scope.filterPanel.filterPanelIcon = scope.filterPanelIcon;
                                    scope.filterPanel.filterPanelColor = scope.filterPanelColor;
                                    if(scope.filterPanelHeight < 100 || scope.filterPanelHeight >300){
                                        scope.filterPanelHeight = 100;
                                    }
                                    scope.filterPanel.filterPanelHeight = scope.filterPanelHeight;
                                    commonUtils.safeApply(scope,function(){});
                                    commonUtils.savedFlag = false;
                                    dialogItself.close();
                                },
                                cssClass : 'btn-default btn-lg btn-primary'
                            },{
                                label : 'Close',
                                action : function(dialogItself) {
                                    dialogItself.close();
                                },
                                cssClass : 'btn-default btn-lg btn-danger'
                            }]
                        });
            }

            scope.minimizeFilterPanel = function(){
                //$log.log(scope.filterPanelMinimize);
                if($('#filterpanel').hasClass('collapse') && $('#filterpanel').hasClass('in') )
                    scope.filterPanelMinimize = true;                    
                else
                    scope.filterPanelMinimize = false;   
                
            }


            scope.filterPanelColor = function(){
                BootstrapDialog.show({
                    title:'Set Filter Header Color',
                    message: function(dialog) {
                        var $message = $('<div></div>');
                        var template = commonUtils.getHtmlContent('component/templates/chart/setHeaderColor.html');
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    cssClass:'width542',
                    onshown:function(dialogRef){
                        /*
                        $('.colorPallete').on('click',function(){
                            $log.log(this.id);
                            $('.colorPreview').addClass('panel-'+this.id);
                        })
                        */
                        var colorname = 'red1'
                        //$log.log(scope.colorNames['panel-'+colorname]);
                        //$log.log(scope.pinobj.pinHeaderColor)
                        scope.previewColor = scope.filterPanel.filterPanelColor;
                        scope.colorLabel = commonUtils.colorNames[scope.filterPanel.filterPanelColor];

                        scope.setPreview = function(color){
                            scope.previewColor = 'panel-'+color;
                            scope.colorLabel = commonUtils.colorNames['panel-'+color];

                            scope.filterPanel.filterPanelColor = scope.previewColor;
                        }

                        scope.setColor = function(){
                            dialogRef.close();
                            //scope.pinobj.pinHeaderColor = scope.previewColor;
                            scope.filterPanel.filterPanelColor = scope.previewColor;
                        }
                        commonUtils.savedFlag = false;
                        commonUtils.safeApply(scope,function(){});
                    }
                });
            }


        }],
        link : function(scope,element,attrs){
            scope.init = function(){
                //$log.log($('#filterpanel').height());
                if(!$('#filterpanel').hasClass('collapse') && !$('#filterpanel').hasClass('in'))
                    scope.filterPanelMinimize = false;
            }
            scope.init();

            if(scope.filterPanel.filterPanelShow && scope.filterPanel.filterArray.length > 0){
                
                
                $('#filterpanel').collapse('show');
            }
            var html = '<div class="filterpanelWrapper font{{filterPanel.filterPanelFontColor}}"><div id="filterpanelHeader" class="filterpanelHeader panel panel-filter" >' +
                        '<div class="panel-heading clearfix {{filterPanel.filterPanelColor}}">' +
                            '<h4 id="filterpanelTitle" class="panel-title panel-filterpanel-main pull-left">'+
                                //'<i id="filterPanIcon" class="{{filterPanel.filterPanelIcon}}"></i> ' +
                                ' {{filterPanel.filterPanelTitle}}' +
                            '</h4>' +
                            '<div class="pull-right">' +
                                '<button class="btn btn-default btn-xs btn-xs-last" ng-click="minimizeFilterPanel()" ng-hide=settingVisible data-toggle="collapse" data-target="#filterpanel" title="Minimize Filter">'+
                                    '<i class="glyphicon glyphicon-minus"></i></button>' +
                                '<button class="btn btn-default btn-xs" ng-show=settingVisible ng-click="filterPanelSetting()" title="Filter Setting">'+
                                    '<i class="glyphicon glyphicon-cog"></i></button>'+
                                '<button class="btn btn-default btn-xs" id="panel_color" ng-show=settingVisible ng-click="filterPanelColor()" title="Filter Header Color">'+
                                    '<i class="fa fa-paint-brush"></i></button>';
                                
                if(commonUtils.editor)
                    html = html +'<button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()">Reset</button><button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()">Submit</button>';
                else
                    html = html +'<button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()" ng-hide=filterPanelMinimize>Reset</button><button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()" ng-hide=filterPanelMinimize>Submit</button>';

                html = html +'</div>' +
                        '</div>' +
                        '<div id="filterpanel" class="panel-body panel-filter-body collapse in filterpanel">'+
                           // '<div  class="filterPanelBody col-md-12  col-sm-12  column " style="height:{{filterPanel.filterPanelHeight}}px;" > '+
                            '<div  class="filterPanelBody col-md-12  col-sm-12  column " style="height:{{filterPanel.filterPanelHeight}}px;"> '+
                                "<filtercomponent ng-repeat='filter in filterPanel.filterArray' filterconfig=filter ></filtercomponent>" +
                            '</div>' +
                        '</div>'+
                    '</div></div>';


            element.html(html);
            $compile(element.contents())(scope);
        }
    }
}]);

angular.module('pinboard')
.directive("filtercomponent",['commonUtils','pinboard','$log','$compile','$timeout',function(commonUtils,pinboard,$log,$compile,$timeout){
    return{
        restrict: 'E',
        scope : {
            filterconfig : "="
        },
        bindtoController:true,
        controllerAs : 'filterComponentCtrl',
        controller : ['$scope','$attrs','$element',function(scope,attrs,element){
            var vm = this;
            scope.filterSetting = function(){
                $log.debug("Set component Width");

                scope.selectPin = "";
                scope.pinLists = [];
                scope.totalPins = [];

                $.each(pinboard.pinLists,function(i,v){
                    
                    for(a in v.pin[0].defaultParamStr){
                        scope.totalPins.push({pinId:v.pin[0].pinId,param:a,title:v.pin[0].title});
                    }
                })  
                scope.bindPins = [];
                scope.bindPins = angular.copy(scope.filterconfig.listenerPins);


                var i=0;
                while(i<scope.totalPins.length){
                    var hasEntry = false;
                    for(var j=0;j<scope.bindPins.length;j++){
                        if(scope.bindPins[j].pinId==scope.totalPins[i].pinId && scope.bindPins[j].param==scope.totalPins[i].param){
                            scope.bindPins[j].title = scope.totalPins[i].title;
                            hasEntry = true;
                            break; 
                        }
                    }
                    if(hasEntry)
                        scope.totalPins.splice(i,1);
                    else
                        i++;
                }   

                BootstrapDialog.show({
                    title : 'Filter Settings',
                    message : function(dialog) {
                        var $message = $('<div></div>');
                        var template = commonUtils.getHtmlContent('component/templates/filter/filterSetting.html');										;
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    
                    closable : false,
                    draggable : true,
                    cssClass : 'width650',
                    onshown : function(dialogRef) {

                        scope.componentWidth = scope.filterconfig.filterWidth;
                        
                        scope.addItem = function(indx){
                            scope.bindPins.push(scope.totalPins[indx])
                            scope.totalPins.splice(indx,1)
                            //updateCss();
                            commonUtils.safeApply(scope,function(){})
                        }
                        scope.removeItem = function(indx){
                            scope.totalPins.push(scope.bindPins[indx]);
                            scope.bindPins.splice(indx,1);
                        }

                        if(scope.selectPin != "")
                            scope.changePinParams();
                    },
                    buttons : [{
                        label : 'Apply',
                        action : function(dialogItself) {
                            scope.filterconfig.filterWidth = scope.componentWidth;
                            scope.filterconfig.listenerPins = angular.copy(scope.bindPins);

                            commonUtils.safeApply(scope,function(){});
                            scope.hideOption();
                            dialogItself.close();
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : 'Close',
                        action : function(dialogItself) {
                            dialogItself.close();
                        },
                        cssClass : 'btn-lg btn-danger'
                    }]
                });
            }

            scope.removeFilterComponent = function(filterId){
                $log.debug("remove filter is"+ filterId);
                var indx,temp;
                for(i=0;i<pinboard.filterPanel.filterArray.length;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                
                pinboard.filterPanel.filterArray.splice(indx,1);
                if(pinboard.filterPanel.filterArray.length == 0){
                    pinboard.filterPanel.filterPanelShow = false;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }
            scope.slideFilterLeft = function(filterId){
                var indx;
                for(i=0;i<pinboard.filterPanel.filterArray.length;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                //$log.debug("slide filter component of index :"+indx+" to new index :"+indx-1);
                if(indx!=0){
                    var temp = pinboard.filterPanel.filterArray[indx];
                    pinboard.filterPanel.filterArray[indx] =  pinboard.filterPanel.filterArray[indx-1];
                    pinboard.filterPanel.filterArray[indx-1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }

            scope.slideFilterRight = function(filterId){
                var indx;
                var len=pinboard.filterPanel.filterArray.length;
                for(i=0;i<len;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                //$log.debug("slide filter component of index :"+indx+" to new index :"+indx+1);
                if(indx < len-1 ){
                    var temp = pinboard.filterPanel.filterArray[indx];
                    pinboard.filterPanel.filterArray[indx] =  pinboard.filterPanel.filterArray[indx+1];
                    pinboard.filterPanel.filterArray[indx+1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }

            scope.showOption = function(){  
                //$log.log("this is clicked"+ scope.filterconfig.filterId);
                $('.'+scope.filterconfig.filterId+'-show').hide();
                $('.'+scope.filterconfig.filterId+'-hide').show();
                $('.'+scope.filterconfig.filterId+'-buttons').show('fast');   
                //$('.btn-filterComponent .'+scope.filterconfig.filterId).show('fast');
            }

            scope.hideOption = function(){
                $('.'+scope.filterconfig.filterId+'-hide').hide();
                $('.'+scope.filterconfig.filterId+'-show').show();
                $('.'+scope.filterconfig.filterId+'-buttons').hide('fast');   
            }
        }],

        link: function(scope,element,attrs){
            //pinboard.filterScope = scope;


            if(scope.filterconfig.filterType=="combobox" || scope.filterconfig.filterType=="multiselect"){
                var url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/'+encodeURIComponent(scope.filterconfig.dataSource)+'&dataAccessId='+scope.filterconfig.dataAccessId+'&outputIndexId=1';
                var datasrcVal = commonUtils.readJSONFile(url);

                if(datasrcVal!=undefined && datasrcVal.metadata.length==1){
                    scope.filterconfig.datasourceArray = [];
                    angular.forEach(datasrcVal.resultset,function(v,i){
                        scope.filterconfig.datasourceArray.push(v);
                    })
                }
                var filterType = window[scope.filterconfig.filterType];
                var addHtmlComponent = new filterType();
                scope.filterconfig.htmlComponent = addHtmlComponent.init(scope.filterconfig.datasourceArray);
            }

            if(commonUtils.editor == true)
            {
                var inputPopoover = ""
                var html ="<div class='filterComponentOuter'>"+
                    "<div class='filterComponent btn-filterComponent form-inline pull-right {{filterconfig.filterId}}-buttons' >" +
                    "<button class='btn  btn-xs filterButton' title='remove' ng-click='removeFilterComponent(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-remove'></i></button>" +
                    "<button class='btn  btn-xs filterButton' title='slide-left' ng-click='slideFilterLeft(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-arrow-left'></i></button>" +
                    "<button class='btn  btn-xs filterButton' title='slide-right' ng-click='slideFilterRight(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-arrow-right'></i></button>" +
                    "<button tabindex='0' title='Settings' ng-click='filterSetting()' class='btn btn-xs filterButton filterPopover fa fa-cog'"+
                    "></button>"+
                    "</div>"+
                    "<div class='btn-show-filteroption {{filterconfig.filterId}}-show' ng-click='showOption()'><i class='fa fa-plus-square'></i></div><div class='btn-hide-filteroption {{filterconfig.filterId}}-hide' ng-click='hideOption()'><i class='fa fa-minus-square'></i></div>" ;
            }
            else
                var html = "<div class='filterComponentOuter'>";

            html = html+scope.filterconfig.htmlComponent+"</div>";
            element.html(html);
            $compile(element.contents())(scope);



            $timeout(function(){
            
                if(scope.filterconfig.filterType == 'datePicker'){
                    if(scope.filterconfig.filterVal.match(/^[0-9]{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])/)){
                        $('#'+scope.filterconfig.filterId).daterangepicker(
                            { 
                                singleDatePicker: true,
                                format :'YYYY-MM-DD',
                                startDate : scope.filterconfig.filterVal
                            },
                            function(start, end, label) {
                            $log.debug("date into ISOstring: "+start.toISOString());
                        });    
                    }
                    
                }
                else{
                    var d = new Date();
                    var month = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                    if(scope.filterconfig.defaultVal=="currentDay")
                        scope.filterconfig.filterVal= d.getDate().toString();

                    else if(scope.filterconfig.defaultVal=="currentMonth")
                        scope.filterconfig.filterVal= month[d.getMonth()];
                    else if(scope.filterconfig.defaultVal=="currentYear")
                        scope.filterconfig.filterVal= d.getFullYear().toString();

                }
            },0)
        }   
    }
}])

angular.module('pinboard')
.directive("dashboard",['pinboard','$log',function(pinboard,$log){
    return {
        restrict : 'E',
        scope : {
            'editor' : '@'
        },
        bindtoController:true,
        controllerAs :'databoard',
        template :  "<filterpanel filter-panel='databoard.pinboard.filterPanel' ng-show=databoard.pinboard.filterPanel.filterPanelShow></filterpanel>"+
                    '<div gridstack class="grid-stack grid" options=databoard.pinboard.options>'+
                        '<div gridstack-item ng-repeat="w in databoard.pinboard.pinLists" class="grid-stack-item" gs-item-x="w.x" gs-item-y="w.y"'+
                             'gs-item-width="w.width" gs-item-height="w.height" data-gs-min-width="2" gs-item-autopos="1" on-item-added="onItemAdded(d)" on-item-removed="onItemRemoved(item)">'+
                                '<div class="grid-stack-item-content">'+
                                    '<pin ng-repeat="pin in w.pin" idd="{{w.x}}_{{w.y}}_{{w.width}}_{{w.height}}" pinobj=pin class="column"></pin>'+
                                '</div>'+
                        '</div>'+
                    '</div>',
        transclude : true,
        controller : ['$scope','$attrs','$element', function (scope,attrs,element) {
            $log.debug("This is Dashboard directive");
            var vm  = this;
            vm.pinboard = pinboard;
            //console.log("pinboard")
            //console.log(vm.pinboard.pinLists)


            scope.options = vm.pinboard.options;
        }]
    }

}])

angular.module('pinboard')
.directive("pin",['pinboard','Pin','$timeout','commonUtils','$log','$http','$compile','Messages',function(pinboard,Pin,$timeout,commonUtils,$log,$http,$compile,Messages){
    return {
        restrict :'E',
        scope : {
            'pinobj'  : '=',
            'pinboardrow' : '@',
            'pinboardcol' : '@',
            'pintype' : '=',
            'idd' : '@'
        },
        link : function (scope,element,attrs ){

            $log.debug("This is Pin directive");
            $log.debug("PinType  : " + scope.pintype);
            
            scope.editor=commonUtils.editor;
            scope.preview = !commonUtils.editor;

            scope.dataSources = [];


            if(pinboard.datasourceList.indexOf(scope.pinobj.dataSource)<0 && scope.pinobj.dataSource.length>0){
                pinboard.datasourceList.push(scope.pinobj.dataSource);
                //console.log(scope.pinobj.dataSource.indexOf(".cda"))
                scope.pinobj.dataSource.indexOf(".cda")>0?pinboard.addDAelement(pinboard.datasourceList.length-1):console.log("saiku");
            }
            //console.log(pinboard.datasourceList)
            //console.log("datasource :"+scope.pinobj.dataSource)

            if(scope.pinobj.commentsCount==undefined && (scope.pinobj.comments.length>0 && scope.pinobj.comments.length<11))
                scope.pinobj.commentsCount = scope.pinobj.comments.length;
            else if(scope.pinobj.commentsCount==undefined && scope.pinobj.comments.length>10)
                scope.pinobj.commentsCount = '10+'
            else if(scope.pinobj.commentsCount==undefined && scope.pinobj.comments.length==0)
                scope.pinobj.commentsCount = '';   
            

            if(scope.preview && scope.pinobj.chartType != 'Saiku')
                scope.showExport = true;    
            else
                scope.showExport = false;

            scope.listParameters = [];



            var getDefaultParams = function(){
                scope.listParameters = [];
                            //alert(listParams);
                uri = encodeURIComponent(scope.pinobj.dataSource);

                var listParams = commonUtils.getDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,"parameter");

                if(!listParams){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+scope.pinobj.dataAccessId ;
                    listParams = commonUtils.synchronousJsonCall(url);

                    commonUtils.setDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,listParams,"parameter");
                }
                //scope.listParameters = listParams;

                var param = {};
                var  l = listParams.resultset.length;
                //console.log(scope.listParameters);

                for(var i=0;i<l;i++){
                    paramObj = listParams.resultset[i];
                    param[paramObj[0]] = paramObj[2];
                }
                scope.pinobj.defaultParamStr = param;

                //console.log(param);
                for(var x=0;x<scope.pinobj.listenerFilters.length;x++){
                    //console.log("asd")
                    for(var i=0;i<pinboard.filterPanel.filterArray.length;i++){
                        if(pinboard.filterPanel.filterArray[i].filterId==scope.pinobj.listenerFilters[x][0]){
                            $.each(pinboard.filterPanel.filterArray[i].listenerPins,function(j,v){
                                if(v.pinId == scope.pinobj.pinId){
                                    pinboard.filterPanel.filterArray[i].listenerPins[j].param = scope.pinobj.listenerFilters[x][1];
                                }
                            })
                        }
                            
                    }
                        
                }


                var paramStr = commonUtils.parseParams(angular.copy(scope.pinobj.defaultParamStr));

                //console.log(paramStr)
                var data = commonUtils.getDatasourceData(scope.dataSource,scope.dataAccessId,"data");

                if(!data){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + paramStr + '&outputIndexId=1';
                    data = commonUtils.synchronousJsonCall(url);

                    commonUtils.setDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,data,"data");
                }
            }

            $timeout(function(){
                if(scope.pinobj.dataAccessId.length>0)
                    getDefaultParams();
                
                if(scope.pinobj.chartType == 'CCC' || scope.pinobj.chartType == 'Label'){
                    $log.debug("paramStr "+scope.pinobj.defaultParamStr);
                    scope.pinobj.paramStr = scope.pinobj.defaultParamStr;
                    scope.pinobj.render(scope.pinobj.defaultParamStr);    
                }
                else{
                    //console.log(scope.pinobj)
                    scope.pinobj.render();    
                }
            }, 0);

            if(commonUtils.mode == "pin")
                scope.pinMode = true
            else
                scope.pinMode = false;

            var populateDatasrc = function(filext){
                
                scope.dataSources = [];
                var flagCda = false;
                for(i=0;i<pinboard.datasourceList.length;i++){
                    if(pinboard.datasourceList[i].indexOf('.cda')>0)
                        flagCda = true;
                    if(pinboard.datasourceList[i].indexOf('.'+filext)>0)
                        scope.dataSources.push(pinboard.datasourceList[i]);
                }

                
                if(scope.dataSource == undefined || scope.dataSource.length <= 0 || scope.dataSources.indexOf(scope.dataSource)<0){
                    scope.dataSource = scope.dataSources[0];
                }
                else if(scope.pinobj.dataSource==scope.dataSource)
                    scope.dataSource = scope.pinobj.dataSource;
                
                if(flagCda && filext=='cda'){
                    scope.populateDAId();
                }
            }

            scope.populateDAId = function(){
                scope.dataAccessIds = [];
                for(var i=0;i<pinboard.dataAccessList.length;i++){
                    if(pinboard.dataAccessList[i].dbsrc==scope.dataSource)
                        scope.dataAccessIds = angular.copy(pinboard.dataAccessList[i].daIds)
                }

                //scope.dataAccessId = scope.dataAccessIds[0];

                if(scope.dataAccessId == undefined || scope.dataAccessId.length <= 0 || scope.dataSource != scope.pinobj.dataSource){
                    scope.dataAccessId = scope.dataAccessIds[0];    
                }
                else{
                    scope.dataAccessId = scope.pinobj.dataAccessId;
                }

                scope.dataAccessIdChanged();
            }

            //initialization method of the chart properties
            scope.initChartProperties = function(){
                scope.isPinboard = false;
                scope.chartTypes = [];
                scope.errorMsg = null;
                scope.numericVal = false;

                for(var i=0; i<commonUtils.components.selfServiceBI.length; i++) {
                    scope.chartTypes.push(commonUtils.components.selfServiceBI[i].chartCaption);
                };
                scope.chartType = scope.chartTypes[0];

                if(commonUtils.mode == 'pinboard'){
                    //scope.getChartClass = 'chart_table_body';
                    scope.isPinboard = true;

                }

                    

                if(scope.chartType=="Saiku")
                    scope.isCCCchart = false;
                else
                    scope.isCCCchart = true;

                // init - pinlistener

                if(scope.pinobj.listenerPins == undefined){
                    scope.pinobj.listenerPins = [];
                }

                scope.totalPins = [];
                $.each(pinboard.pinLists,function(i,v){
                    if(v.pin[0].pinId != scope.pinobj.pinId)
                        for(a in v.pin[0].defaultParamStr){
                            scope.totalPins.push({pinId:v.pin[0].pinId,title:v.pin[0].title,param:a});
                        }
                })

                scope.bindPins = [];
                scope.bindPins = angular.copy(scope.pinobj.listenerPins);

                var i=0;
                while(i<scope.totalPins.length){
                    var hasEntry = false;
                    for(var j=0;j<scope.bindPins.length;j++){
                        if(scope.bindPins[j].pinId==scope.totalPins[i].pinId && scope.bindPins[j].param==scope.totalPins[i].param){
                            scope.bindPins[j].title = scope.totalPins[i].title;
                            hasEntry = true;
                            
                            break; 
                        }
                    }
                    if(hasEntry)
                        scope.totalPins.splice(i,1);
                    else
                        i++;
                }

                scope.cccChart = false;
            }

            

            scope.fireChange = function(param,value){
                
                scope.pinobj.paramStr[param] = value;
                scope.pinobj.render(scope.pinobj.paramStr);
            }

            scope.chartProperties = function(){
                $log.debug("chart properties called");
                scope.initChartProperties();
                
                BootstrapDialog.show({
                    title: 'Settings of '+scope.pinobj.title+'',
                    message: function(dialog){
                        var $message = $('<div></div>');
                        //var pageToLoad = dialog.getData('pageToLoad');
                        //$message.load(pageToLoad);
                        var template = commonUtils.getHtmlContent('component/templates/chart/chartsProperties.html');
                        $message.append($compile(template)(scope));
                        $('.existingPin').hide();
                        return $message;

                    },
                    closable : false,
                    draggable : true,
                    cssClass : 'chart-properties-dialog',
                    onshown : function(dialogRef){

                        var cdaParams = [];
                        var getDataAccessId = [];
                        //$log.log(scope.pinobj.pinId);


                        scope.pinId = scope.pinobj.pinId;
                        scope.properties = scope.pinobj.chartProperties;
                        //console.log(scope.properties);
                        scope.chartType = scope.pinobj.chartType;
                        scope.dataSource = scope.pinobj.dataSource;

                        scope.visualization = scope.pinobj.visualization ;
                        scope.dataAccessId = scope.pinobj.dataAccessId ;
                        //console.log(scope.pinobj.dataAccessId)
                                               

                        scope.addListenerPin = function(indx){
                            
                            scope.bindPins.push(scope.totalPins[indx])
                            scope.totalPins.splice(indx,1)
                            //updateCss();
                            //commonUtils.safeApply(scope,function(){})
                        }
                        scope.removeListenerPin = function(indx){
                            scope.totalPins.push(scope.bindPins[indx]);
                            scope.bindPins.splice(indx,1);
                        }

                        var loadVisualization = function(indx,isNew){
                            
                            scope.visualizations = [];
                            var charts = commonUtils.components.selfServiceBI[indx].properties.files.charts;
                            //$log.debug(charts);
                            scope.browseExt = commonUtils.components.selfServiceBI[indx].properties.datasourceExt;

                            for(i = 0; i < charts.length; i++) {
                                scope.visualizations.push(charts[i]);
                            }
                            if(isNew){
                                scope.visualization = scope.visualizations[0];        
                            }
                            else{
                                scope.visualization = scope.pinobj.visualization;        
                            }

                        }                        
                        
                        var loadProperties = function(){
                            
                            $("#primaryProperties").html("");
                            //scope.properties = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');
                            var tempProps = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');
                            var l = tempProps.length;
                            //$log.log(scope.properties);
                            console.log(scope.pinobj.chartProperties);
                            console.log(scope.pinobj)
                            for(var i=0;i<l;i++){
                                if(typeof scope.properties  != 'undefined' &&  scope.properties.length >0 && scope.visualization == scope.pinobj.visualization && scope.properties[i][0] == tempProps[i][0]){
                                    commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                    tempProps[i] = angular.copy(scope.properties[i]);
                                }
                            }

                            scope.properties = angular.copy(tempProps);
                        }
                        scope.loadProperties = function(){
                            
                            BootstrapDialog.show({
                                title: ''+scope.visualization+' Properties',
                                message: function(dialog){
                                    var template =  '<div id="propertiesPanel" class="panel propertiesPanel" style="margin-bottom:0px;" >'+
                                                        '<div class="panel-heading" style="text-align:center">'+
                                                            '<input class="form-control input-sm" type="checkbox" id="switchProperties" data-size="small" data-handle-width="75" data-on-text="Primary" data-off-text="Advance" data-on-color="primary" data-off-color="danger"  checked />'+
                                                        '</div>'+
                                                        '<div class="panel" style="overflow:auto;max-height:340px;border:1px solid #DCDCDC">'+
                                                            '<div class="modal-form" id="primaryProperties1">'+
                                                            '</div>'+
                                                        '</div>'+
                                                    '</div>';

                                    var $message = $('<div></div>');
                                    $message.append($compile(template)(scope));
                                    return $message;
                                },
                                closable : false,
                                draggable : true,
                                cssClass : 'width500',
                                onshown : function(dialogRef){
                                    
                                    $("#primaryProperties1").html("");

                                    var changeProperties = function(indx){
                                        if(indx == 0 ){
                                            $(".advance").hide();
                                        }
                                        else{
                                            $(".advance").show();
                                        }  
                                    }

                                    $('#switchProperties').bootstrapSwitch('state',true,true);
                                    $('#switchProperties').on('switchChange.bootstrapSwitch', function(event, state){
                                        if(!state)
                                            changeProperties(1);
                                        else
                                            changeProperties(0);
                                    });

                                    
                                    //scope.properties = commonUtils.readJSONFile('component/'+scope.chartType+'/'+scope.chartType+'.'+scope.visualization+'.properties.json');
                                    
                                    var l = scope.properties.length;
                                    //$log.log(scope.properties);
                                    for(i=0;i<l;i++){
                                        //$log.log(scope.pinobj.chartProperties[i][0] +" == "+ scope.properties[i][0] +" "+scope.pinobj.visualization+" == "+scope.visualization)

                                        if(typeof scope.pinobj.chartProperties  != 'undefined' &&  scope.pinobj.chartProperties.length >0 && scope.pinobj.visualization == scope.visualization && scope.pinobj.chartProperties[i][0] == scope.properties[i][0]){
                                            commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.pinobj.chartProperties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                        }
                                            
                                        else{
                                            //$log.log(scope.pinobj.visualization+" == "+scope.visualization);
                                            commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][6],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][5],"primaryProperties1",scope);
                                        }
                                            
                                    }
                                    
                                    if(scope.chartType){
                                        
                                        $('#newMeasure').on('switchChange.bootstrapSwitch',function(event,state){
                                            if(state)
                                                $('#measure').prop('disabled',true);
                                            else
                                                $('#measure').prop('disabled',false);
                                        })


                                    }

                                    changeProperties(0);
                                },
                                buttons : [{
                                    label : 'Ok',
                                    action : function(dialogItself) {
                                        //$log.log(scope.properties);

                                        
                                        var l = scope.properties.length;
                                        //$log.log(scope.properties);
                                        for(var i=0;i<l;i++){
                                            //$log.log(scope.properties[i][2]);
                                            if(scope.properties[i][2] == 'switch' || scope.properties[i][2] == 'combo'){
                                                temp = $('#'+scope.properties[i][0]).bootstrapSwitch('state');
                                                scope[scope.properties[i][0]] = temp;
                                            }
                                            //scope.pinobj.chartProperties[i] = scope.properties[i];
                                            scope.properties[i][3] = commonUtils.parsePropertiesDataType(scope[scope.properties[i][0]],scope.properties[i][1]);
                                            //$log.debug(scope.pinobj.chartProperties[i]);
                                        }
                                        //scope.pinobj.visualization = scope.visualization;
                                        //$log.log(scope.properties);                                        
                                        dialogItself.close();
                                    },
                                    cssClass: 'btn-default btn-lg btn-primary btn-sameWidth'
                                },{
                                    label : 'Close',
                                    action : function(dialogItself) {
                                        dialogItself.close();
                                        
                                    },
                                    cssClass: 'btn-default btn-lg btn-danger btn-sameWidth'
                                }]
                            })
                        }

                        scope.getParams = function(dataAccessId){
                            
                            var listParams = [];
                            //cdaParams = [];
                            scope.listParameters = [];
                            //alert(listParams);


                            uri = encodeURIComponent(scope.dataSource);

                            listParams = commonUtils.getDatasourceData(scope.dataSource,dataAccessId,"parameter");

                            if(!listParams){
                                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+dataAccessId ;
                                listParams = commonUtils.synchronousJsonCall(url);

                                commonUtils.setDatasourceData(scope.dataSource,dataAccessId,listParams,"parameter");
                            }
                            scope.listParameters = listParams;

                        }

                        scope.getParamString = function(){
                            
                            var param = {};
                            var  l = scope.listParameters.resultset.length;
                            

                            for(var i=0;i<l;i++){
                                paramObj = scope.listParameters.resultset[i];
                                param[paramObj[0]] = paramObj[2];
                            }

                            return param;
                        }

                        scope.chartTypeChanged = function(){
                            var temp;
                            
                            //scope.dataSource = "";
                            scope.isNew = true;
                            var index = commonUtils.getIndex(scope.chartType);
                            
                            //scope.browseExt = commonUtils.components.selfServiceBI[index].properties.datasourceExt;

                            if(scope.chartType == 'Table' || scope.chartType == 'Label'){
                                //$log.log("this is happend")
                                $('.cccProperties').show();
                                $('.chartType').hide();
                                $('.dataProperties').show();
                                scope.cccChart = false;
                            }
                            else if(scope.chartType == 'Saiku'){
                                $('.dataProperties').hide();
                                $('.chartType').show();
                                $('.cccProperties').hide();
                                scope.cccChart = true;
                            }
                            else{
                                $('.cccProperties').show();
                                $('.dataProperties').hide();
                                $('.chartType').show();
                                scope.cccChart = true;
                            }

                            if(scope.pinobj.chartType == scope.chartType){
                                scope.dataSource = scope.pinobj.dataSource;
                                scope.isNew = false;          
                            }

                            loadVisualization(index,scope.isNew);
                            

                            if(pinboard.datasourceList.length>0)
                                populateDatasrc(scope.browseExt);
                            
                            if(commonUtils.components.selfServiceBI[index].properties.files.chartProperties=="true"?true:false){
                                
                                loadProperties();
                            }
                            
                            //scope.datasourceChanged();
                        }

                        scope.visualChanged = function(){
                            
                            if(scope.chartType != 'Fusion' ){
                                $log.debug("visualization changed");
                                if(scope.visualization == 'Bullet'){
                                    commonUtils.notification(Messages.onCCCbulletChartSelect);
                                }
                                loadProperties(); 
                            }
                        }
                        
                        scope.dataAccessIdChanged = function(){
                            
                            if(scope.dataAccessId != undefined && scope.dataAccessId != null &&  scope.dataAccessId.length >0){
                                scope.getParams(scope.dataAccessId);

                                var param = scope.getParamString();
                                var paramStr = commonUtils.parseParams(angular.copy(param));
                                var data = commonUtils.getDatasourceData(scope.dataSource,scope.dataAccessId,"data");

                                if(!data){
                                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.dataSource + '&dataAccessId=' + scope.dataAccessId + paramStr + '&outputIndexId=1';
                                    data = commonUtils.synchronousJsonCall(url);

                                    commonUtils.setDatasourceData(scope.dataSource,scope.dataAccessId,data,"data");
                                }


                                // url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.dataSource + '&dataAccessId=' + scope.dataAccessId + param + '&outputIndexId=1';
                                // data = commonUtils.synchronousJsonCall(url);
                                if(data==void 0)
                                    return false;


                                var len = data.metadata.length;
                                //var numericAvail = false;
                                scope.numericVal = false;
                                $log.debug(data.metadata);
                                
                                scope.listenerColumns = [];


                                for(var i=0;i<len;i++){
                                    if(data.metadata[i].colType=="Numeric" || data.metadata[i].colType=="Integer"){
                                        scope.numericVal = true;
                                    }
                                    scope.listenerColumns.push(data.metadata[i].colName);
                                    
                                }

                                if(!scope.numericVal)
                                    for(var i=0;i<data.resultset.length;i++){
                                        for(var j=0;j<data.resultset[i].length;j++){
                                            if(!isNaN(data.resultset[i][j]))
                                                scope.numericVal = true;
                                        }
                                    }

                                if(scope.numericVal)
                                    scope.errorMsg = null;
                                else
                                    scope.errorMsg = "No numeric values in selected Data Access Id";

                                if(scope.numericVal && scope.chartType == "Label" && data.resultset.length>1){
                                    scope.errorMsg = "Datasource should be single valued. It has multiple value";
                                    scope.labelAllow = false;
                                }
                                else if(scope.numericVal && scope.chartType == "Label" && data.resultset.length==1){
                                    scope.labelAllow = true;
                                    scope.errorMsg = null;
                                }
                                    

                                scope.listenerColumn = scope.listenerColumns[0];
                            }
                            

                        }

                        scope.removePin = function(){
                            commonUtils.BootstrapConfirm(Messages.onRemoveRowConfirm, function(result){
                                if(result) {
                                    var temp;
                                    for(var i=0;i<pinboard.pinLists.length;i++){
                                        if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                                            temp = i;
                                    }

                                    //pinboard.pinLists.splice(temp,1);

                                    //removeRow= parseInt(removeRow);
                                    var nullPinboard = pinboard.removeAt(temp);
                                    
                                    //commonUtils.notification(Messages.onPinBoardRemoveRowSuccess);
                                    if(nullPinboard)
                                        commonUtils.isNull = true;
                                    else
                                        commonUtils.isNull = false;



                                    dialogRef.close();
                                    commonUtils.safeApply(scope,function(){});
                                    commonUtils.savedFlag =false; //to-do set flag to root or commonutil
                                }
                            });
                            $("#mainpage").height(document.getElementById("mainpage").scrollHeight)
                        }


                        $timeout(function(){
                            scope.chartTypeChanged();                           
                        },0)                            
                        
                    },
                    buttons : [{
                        label : 'Apply',
                        action : function(dialogItself) {

                            if(scope.chartType != 'Saiku' && !scope.numericVal || (scope.chartType == "Label" && !scope.labelAllow)){
                                
                                return;
                            }
                            
                            if(scope.dataSource != undefined && scope.dataSource.length > 0){
                                var temp;
                                var param = '';
                                scope.pinobj.chartType = scope.chartType;
                                scope.pinobj.dataSource= scope.dataSource;
                                scope.pinobj.visualization = scope.visualization;
                                
                                

                                if(scope.bindPins.length>0){
                                    // var strArry1 =[];
                                    // angular.forEach(scope.bindPins,function(v,i){
                                    //     strArry1.push({pinId:v.pinId,param:v.param,value:"clickVal"}) 
                                    // })
                                    //console.log(JSON.stringify(strArry1));
                                    var strArry = "["
                                    angular.forEach(scope.bindPins,function(v,i){
                                        //strArry.push({pinId:v.pinId,param:v.param,value:"clickVal"}) 
                                        if(i!=0)
                                            strArry1 +=",";
                                        strArry += '{"pinId":"'+v.pinId+'","param":"'+v.param+'","value":clickVal}'
                                    })
                                    strArry+="]"
                                    
                                    for(var i=0;i<scope.properties.length;i++){
                                        if(scope.properties[i][0]=='clickable'){
                                            scope.properties[i][3] = true;
                                        }

                                        if(scope.properties[i][0]=='clickAction'){
                                            var fun = "function(scene){\n\t\tvar arryListener=[],clickVal='';\n\t\t"+
                                                        "\n\t\tif(scene.vars.category.value!= null){\n\t\t\tclickVal=scene.vars.category.value}\n\t\telse{\n\t\t\tclickVal=scene.vars.category.value\n\t\t}"+
                                                        "\n\t\tarryListener="+strArry+";\n\t\tfireChange(arryListener);\n}";
                                            
                                            scope.properties[i][3] = fun;
                                        }
                                    }




                                }
                                else{
                                    for(var i=0;i<scope.properties.length;i++){
                                        if(scope.properties[i][0]=='clickable'){
                                            scope.properties[i][3] = false;
                                        }

                                        if(scope.properties[i][0]=='clickAction'){
                                            scope.properties[i][3] = "";
                                        }
                                    }
                                }

                                scope.pinobj.listenerPins = angular.copy(scope.bindPins);
                                for(var i=0;i<pinboard.pinLists.length;i++){
                                    if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                                        scope.pinobj.height = pinboard.pinLists[i].height * 70 - 10 -38;
                                }
                                if(scope.pinobj.chartType == 'Saiku'){
                                    url = location.protocol +"//"+location.host+"/pentaho/plugin/saiku/api/cde-component/export/saiku/json?formatter=flattened&file="+scope.dataSource;
                                    var data = commonUtils.readJSONFile(url)
                                    
                                    scope.pinobj.dataAccessId = "";
                                    scope.pinobj.paramStr = {};
                                    scope.pinobj.paramStr = data.query.parameters;
                                    scope.pinobj.defaultParamStr = data.query.parameters;
                                    commonUtils.savedFlag = false;
                                    commonUtils.safeApply(scope,function(){});
                                    scope.pinobj.chartProperties = scope.properties;
                                    scope.pinobj.currentSaiku = scope.pinobj.visualization;  
                                    scope.pinobj.render(scope.pinobj.paramStr);
                                }
                            
                                else{

                                    if(!scope.numericVal){
                                        return;
                                    }
                                    // if(scope.pinobj.chartType == "Label" && !scope.labelAllow){
                                    //     return;
                                    //     // var paramStr = commonUtils.parseParams(angular.copy(scope.pinobj.paramStr));

                                    //     // url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + paramStr + '&outputIndexId=1';
                                    //     // var data = commonUtils.readJSONFile(url); 
                                    //     // if(data.resultset.length > 1){
                                    //     //     //scope.errorMsg = "Datasource should be single valued. It has multiple value"
                                    //     //     //alert();
                                    //     //     return
                                    //     // }

                                        
                                    //     // if(!scope.labelAllow){
                                    //     //     return;
                                    //     // }
                                            
                                    // }

                                    scope.pinobj.dataAccessId = scope.dataAccessId;    
                                    scope.pinobj.defaultParamStr = scope.getParamString();
                                    scope.pinobj.visualization = scope.visualization;
                                    scope.pinobj.chartProperties = scope.properties;                                


                                    scope.pinobj.paramStr = scope.getParamString();

                                    if(scope.pinobj.chartType=="Table"){
                                        scope.isTable = true;
                                    }
                                    else{
                                        scope.isTable = false;
                                    }   

                                    $log.debug("scope.pinobj.defaultParamStr "+scope.pinobj.defaultParamStr);
                                    scope.pinobj.render(scope.pinobj.defaultParamStr);
                                }
                            }   

                            commonUtils.savedFlag = false;
                            commonUtils.safeApply(scope,function(){});
                            //scope.pinobj.getJson();
                            dialogItself.close();
                            
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : 'Close',
                        action : function(dialogItself) {
                            dialogItself.close();
                            
                            //console.log(commonUtils.datasourceData)
                        },
                        cssClass : 'btn-default btn-lg btn-danger'
                    }]
                })
            }
 
            scope.pinComments = function(){
                scope.username = commonUtils.username;
                //$log.log(scope.pinobj.comments);
                BootstrapDialog.show({
                    title : 'Comments - '+scope.pinobj.title,
                    message : function(dialog) {
                        var $message = $('<div style="overflow:auto;"></div>');
                        //var pageToLoad = scope.pageToLoad;
                        var template =  '<div class="modal-form"><div id="comment-area" class="form-control comment-display"></div><div class="form-group comment-input">'+
                                        '<div class="col-lg-11 col-md-11 col-sm-11 comment-input-left">'+
                                            '<textarea id="comment" class="form-control textarea comment-textarea" ng-model="comment" style="height:68px"/></div>'+
                                        '<div class="col-md-1 col-lg-1 col-sm-1" style="padding-left:0px;">'+
                                            '<button class="btn btn-md btn-blue comment-send" title="Make comment" ng-click="makeComment()"><i class="glyphicon glyphicon-send"></i></button>'+
                                        '</div></div>';

                        //'<div class="modal-form"><div class="col-md-12 comment-search"><div class="c-search c-seach-icon col-md-1"><i class="glyphicon glyphicon-search"></i></div><div class="c-search col-md-11"><input type="text" class="form-control c-search-input" /></div></div>'+
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    closable : true,
                    cssClass : 'width500 '+scope.pinobj.pinHeaderColor,
                    onshown : function(dialogRef){

                        scope.addComment = function(username,comment,date,time,repeat,sameDate,owner){
                            var addNewComment = '';
                            //$log.log(sameDate);

                            if(!sameDate){
                                addNewComment +='<div class="comment-date">'+date+'</div>';
                            }


                            if(owner){
                                if(!repeat)
                                    addNewComment = addNewComment+'<div class="comment-user">You</div>';
                                
                                addNewComment = addNewComment+ '<div class="comment-comment"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                            }
                            else{
                                if(!repeat)
                                    addNewComment = addNewComment+'<div class="comment-user-v">'+username+'</div>'
                                addNewComment = addNewComment + '<div class="comment-comment-v"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                            }
                            $('#comment-area').append(addNewComment);

                        }

                        scope.makeComment = function(){
                            
                            if(scope.comment == undefined || scope.comment.length < 1){
                                return;
                            }
                            else if(scope.comment.length>500){
                                commonUtils.notification(Messages.commentCharExceeds+scope.comment.length,"danger");
                                return;
                            }



                            var d = new Date();
                            var day = d.getDate();
                            var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                            var month = months[d.getMonth()];
                            var year = d.getFullYear();
                            var hour = d.getHours();
                            var format = "am"
                            var mins = d.getMinutes();
                            if(mins.toString().length == 1){
                                mins = '0'+mins;
                            }

                            if(hour>12){
                                hour-=12;
                                format = 'pm';
                            }
                            var date = month+' '+day+','+year;
                            var time = hour+':'+mins+' '+format;

                            var repeat = false;
                            var sameDate = false;
                            var owner = true;
                            var username = scope.username;
                            var comment = $.trim(scope.comment);
                            //$log.log(comment);

                            scope.pinobj.comments.push([scope.username,comment,date,time]);
                            var len = scope.pinobj.comments.length;

                            if(len>1 && (scope.pinobj.comments[len-1][2]== scope.pinobj.comments[len-2][2])){
                                sameDate = true;
                            }

                            if(sameDate && len>1 && (scope.pinobj.comments[len-1][0]== scope.pinobj.comments[len-2][0])){
                                repeat = true;
                            }
                            
                            scope.addComment(scope.username,comment,date,time,repeat,sameDate,owner);


                            if(scope.pinobj.commentsCount=='')
                                scope.pinobj.commentsCount=1;
                            else if(isNaN(scope.pinobj.commentsCount) || scope.pinobj.commentsCount==10)
                                scope.pinobj.commentsCount='10+';
                            else
                                scope.pinobj.commentsCount++;
                            
                            //var addNewComment = '<div class="comment-user">'+username+'</div><div class="comment-comment"><pre>'+comment+'</pre></div>';
                            //$('#comment-area').append(addNewComment);
                            
                            scope.comment = "";
                            $('#comment').focus();
                            commonUtils.savedFlag = false;

                            var mode = commonUtils.getParameterByName("mode").split("?")[0];
                            //$log.log(commonUtils.getParameterByName("mode").split("?")[0]);

                            if("generatedContent"==mode && commonUtils.mode == 'pinboard'){
                                pinboard.saveConfigToFile();
                            }
                            else if("generatedContent"==mode && commonUtils.mode == 'pin'){
                                scope.pinobj.saveConfigToFile();   
                            }
                            commonUtils.safeApply(scope,function(){});

                            
                        }


                        $('#comment').focus();
                        for(var i=0;i<scope.pinobj.comments.length;i++){
                            var repeat = false;
                            var sameDate = false;
                            var owner = false;


                            if(i>0 && (scope.pinobj.comments[i][2]== scope.pinobj.comments[i-1][2])){
                                //$log.log(scope.pinobj.comments[len-1][2]+" "+scope.pinobj.comments[len-2][2])   
                                sameDate = true;
                            }
                            

                            if(sameDate && i>0 && (scope.pinobj.comments[i][0]== scope.pinobj.comments[i-1][0]))
                                repeat = true;
                            
                            if(scope.pinobj.comments[i][0]==scope.username)
                                owner = true;

                            scope.addComment(scope.pinobj.comments[i][0],scope.pinobj.comments[i][1],scope.pinobj.comments[i][2],scope.pinobj.comments[i][3],repeat,sameDate,owner);

                            //var addOldComments = '<div class="comment-user-v">'+scope.pinobj.comments[i][0]+'</div><div class="comment-comment-v"><pre>'+scope.pinobj.comments[i][1]+'</pre></div>';
                            //$('#comment-area').append(addOldComments);
                        }                       
                    }
                });
            }
            scope.colorNames = {'panel-red1':'Wine Red','panel-red2':'Cherry Red','panel-red3':'Imperial Red','panel-red4':'Pure Red','panel-red5':'Orange Red','panel-orange1':'Orange','panel-orange2':'Spanish Orange','panel-orange3':'Amber','panel-orange4':'Peachy Orange','panel-orange5':'Apricot',
                                'panel-yellow1':'Sunglow','panel-yellow2':'Gold','panel-yellow3':'Honey','panel-yellow4':'Marigold','panel-yellow5':'Lemon Yellow','panel-green1':'Winter Teal','panel-green2':'Sea Green','panel-green3':'Frost Green','panel-green4':'Fresh Grass','panel-green5':'Lemon Green',
                                'panel-blue1':'Navy Blue','panel-blue2':'Spanish Blue','panel-blue3':'Royal Blue','panel-blue4':'Azure','panel-blue5':'Sky Blue','panel-violet1':'Russian Violet','panel-violet2':'Spanish Violet','panel-violet3':'Purple','panel-violet4':'Lavender Purple','panel-violet5':'Orchid',
                                'panel-grey1':'Charcoal','panel-grey2':'Arsenic','panel-grey3':'Grey','panel-grey4':'Pastel Grey','panel-grey5':'Silver'
                                };

            scope.setHeaderColor = function(){
                BootstrapDialog.show({
                    title:'Set Header Color',
                    message: function(dialog) {
                        var $message = $('<div></div>');
                        var template = commonUtils.getHtmlContent('component/templates/chart/setHeaderColor.html');
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    cssClass:'width542',
                    onshown:function(dialogRef){
                        /*
                        $('.colorPallete').on('click',function(){
                            $log.log(this.id);
                            $('.colorPreview').addClass('panel-'+this.id);
                        })
                        */
                        var colorname = 'red1'
                        //$log.log(scope.colorNames['panel-'+colorname]);
                        
                        scope.previewColor = scope.pinobj.pinHeaderColor;
                        scope.colorLabel = scope.colorNames[scope.pinobj.pinHeaderColor];

                        scope.setPreview = function(color){
                            scope.previewColor = 'panel-'+color;
                            scope.colorLabel = scope.colorNames['panel-'+color];
                            scope.pinobj.pinHeaderColor = scope.previewColor;
                        }

                        scope.setColor = function(){
                            dialogRef.close();
                            scope.pinobj.pinHeaderColor = scope.previewColor;
                        }
                        commonUtils.savedFlag = false;
                        commonUtils.safeApply(scope,function(){});
                    }
                });
                
            }

            scope.exportPng = function(){
                //$log.log(scope.pinobj)
                //alert(scope.pinobj.htmlObj);

                var width = $('#'+scope.pinobj.htmlObj+'_chart').width();
                if(width < 450 ){
                    widthclass= 'width450';
                }
                else if(width>449 && width <700){
                    widthclass= 'width700';
                }
                else if(width >699 && width <1000){
                    widthclass= 'width1000';
                }
                else if(width >999 && width < 1400){
                    widthclass= 'width1400';
                }
                else{
                   widthclass= 'width1600'; 
                }

                $('#'+scope.pinobj.htmlObj+'_chart div').remove();
                var xml = $('#'+scope.pinobj.htmlObj+'_chart').html();
                //$log.log($('#'+scope.pinobj.pinId+'_chart svg').length)
                

                if($('#'+scope.pinobj.htmlObj+'_chart svg').length){
                    BootstrapDialog.show({
                        title:'Png Export',
                        message: function(dialog) {
                            var $message = $('<div align="center"></div>');
                            var template = '<div><canvas id="chart_png"></canvas></div><button class="btn btn-default" ng-click="getPng()">Export</button><!--<button class="btn" ng-click="setWidth()">width</button>--><div class="cl">&nbsp;</div>'
                            //$message.load(pageToLoad);
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        cssClass : widthclass+' '+scope.pinobj.pinHeaderColor,
                        onshown:function(dialogRef){
                            
                            //$log.log(xml)
                            canvg(document.getElementById('chart_png'), xml);
                            
                            scope.setWidth = function(){
                                //var c = document.getElementById('chart_png');
                                //c.width= 500;
                                $('#chart_png').css('width','500px');
                            }
                            scope.getPng = function(){

                                var  canvas = document.getElementById('chart_png');
                                var a = document.createElement('a');
                                a.download = "image.png";
                                a.href = canvas.toDataURL('image/png');
                                document.body.appendChild(a);
                                dialogRef.close();

                                a.click();
                                a.remove();

                            }


                            //var canvas = document.getElementById('chart_png');
                            //$log.log(canvas.toDataURL('image/png'));
                            

                        }
                    });
                }                
            }

            //scope.commentCount = 2;

            scope.export = function(extension){
                var paramStr = commonUtils.parseParams(angular.copy(scope.pinobj.paramStr));

                url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + paramStr + '&outputIndexId=1&outputType='+extension;

                window.open(url);
                // var data = commonUtils.readJSONFile(url);
                // //$log.log(data);
                // JSONToCSVConvertor(data.metadata,data.resultset, scope.pinobj.title+scope.pinobj.paramValStr, false,extension);
                 $('#exportToggle').collapse(true);
                               
            };


            scope.minimize = false;
            scope.minimizeClick = function(){
                
                if($('#'+scope.idd).hasClass("collapse in"))
                    scope.minimize = true;

                else{
                    scope.pinobj.render(scope.pinobj.defaultParamStr);
                    scope.minimize = false;
                }
            }

            scope.zoom = function(){
                var width = $(window).width();
                var height = $(window).height();


                width = width - 50;
                height = height - 200;      
                //console.log(width);

                BootstrapDialog.show({
                    title: this.pinobj.title,
                    message: function(dialog) {
                        var $message = $('<div align="center"></div>');
                        var template = '<div id="open_modal" style="overflow:auto;"></div><div class="cl">&nbsp;</div>'
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    cssClass:scope.pinobj.pinHeaderColor,
                    onshown:function(dialogRef){
                        // var propIdx,rowVal;
                        // console.log(scope.pinobj.chartType)
                        // if(scope.pinobj.chartType=="Table"){
                        //     for(var i=0;i<scope.pinobj.chartProperties.length;i++){
                        //         if(scope.pinobj.chartProperties[i][0]=="noOfRows"){
                        //             propIdx = i;
                        //             rowVal = scope.pinobj.chartProperties[i][3];

                        //             scope.pinobj.chartProperties[i][3] = "150";
                        //         }
                        //     }
                        // }
                        $(".modal-dialog").css("width",width+"px");
                        $("#open_modal").css("height",height+"px");
                        //$("#open_modal").css("overflow","auto");
                        scope.pinobj.render(scope.pinobj.paramStr,"open_modal",true);
                        commonUtils.safeApply(scope,function(){});

                        // if(scope.pinobj.chartType=="Table"){
                        //     scope.pinobj.chartProperties[propIdx][3] = rowVal;
                        // }

                    }
                });
            }
            
            var currentSaiku;
            scope.showSaiku = false;

            if(scope.pinobj.chartType=="Saiku"){
                scope.showSaiku = scope.preview ? true : false; 
                currentSaiku = scope.pinobj.visualization;
                scope.pinobj.currentSaiku = scope.pinobj.visualization;
            }
            
            scope.swapData = function(){
                
                if(scope.pinobj.currentSaiku != "table"){
                    scope.pinobj.currentSaiku = 'table';
                    scope.pinobj.render(scope.pinobj.defaultParamStr,scope.pinobj.htmlObj);
                }
                else{
                    scope.pinobj.currentSaiku = scope.pinobj.visualization;
                    scope.pinobj.render(scope.pinobj.defaultParamStr);   
                }
            }

            scope.refreshPin = function(){
                //console.log("refresh pin")
                for(var i=0;i<pinboard.pinLists.length;i++){
                    if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                        scope.pinobj.height = pinboard.pinLists[i].height * 70 - 10 - 38;
                }
                //console.log(scope.pinobj.height)
                //console.log(pinboard.pinLists[0]);
                scope.pinobj.render(scope.pinobj.paramStr);
                commonUtils.savedFlag = false;
            }

            
            
            scope.condFomrat = function(){
                
                scope.dataHeaders = [];
                var temp = commonUtils.getDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,"data").metadata;

                angular.forEach(temp,function(v,i){
                    if(v.colType=="Numeric" ||v.colType=="Integer")
                        scope.dataHeaders.push(v.colName);
                })
                

                if(scope.pinobj.conditions.length==0){
                    scope.conditions = [{
                                        "column":scope.dataHeaders[0],
                                        "cond":"<",
                                        "val1":"1000",
                                        "val2":"2000",
                                        "color":"red",
                                        "isBetween":false
                                    }];
                }
                else{
                    scope.conditions = angular.copy(scope.pinobj.conditions);
                }
                

                var mydata =BootstrapDialog.show({
                    title: "Conditional Formatting",
                    message: function(dialog) {
                        var $message = $('<div align=center></div>');

                        var template = commonUtils.getHtmlContent('component/templates/chart/conditionalFormat.html')
                        
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    draggable: true,
                    closable : false,
                    cssClass : 'width700',
                    onshown: function(dialogRef){
                        
                        scope.addCondition = function(){
                            var temp = {
                                        "column":scope.dataHeaders[0],
                                        "cond":"<",
                                        "val1":"1000",
                                        "val2":"2000",
                                        "color":"red",
                                        "isBetween":false
                                    }
                            scope.conditions.push(temp);
                        }

                        scope.removeCond = function(i){
                            scope.conditions.splice(i,1)
                        }

                        scope.condChange = function(a,b){
                            
                            if(a.cond=="><")
                                a.isBetween = true;
                            else
                                a.isBetween = false;
                            
                        }

                        commonUtils.safeApply(scope,function(){});
                    },

                    buttons: [{
                        label: 'Apply',
                        cssClass: 'btn-primary',
                        action: function(dialogItself){
                            scope.pinobj.conditions = angular.copy(scope.conditions)
                            
                            dialogItself.close();
                            scope.pinobj.render(scope.pinobj.defaultParamStr);
                            commonUtils.savedFlag = false;
                        },
                            
                    },
                    {
                        label: 'Cancel',
                        action: function(dialogItself){
                            dialogItself.close();
                            //onCancel();
                        },
                        cssClass: 'btn-danger'
                    }]
                });
            }

            scope.showExpOpt = false;
            scope.exportOver = function(){
                scope.showExpOpt = true;
            }
            scope.exportLeave = function(){
                scope.showExpOpt = false;   
            }

            scope.iconPreview = scope.preview;
            if(!scope.pinobj.dataSource){
                scope.iconPreview = false;
                scope.showExport = false;
            }

            //scope.pngExpEnable = false;
            scope.iscccChart = false;
            scope.isLabel = false;
            scope.isTable = false;
            if(scope.pinobj.chartType=="CCC"){
                //scope.pngExpEnable = true;
                scope.iscccChart = true;
            }
            else if(scope.pinobj.chartType=="Label"){
                scope.isLabel = true;
            }
            else if(scope.pinobj.chartType=="Table"){
                scope.isTable = true;
            }

            
            scope.editTitle = function(){
                scope.editOn = true;
                //$(".pin-header").focus();
            }

            scope.hideEditTitle = function(){
                scope.editOn=false;
            }

            $log.debug(scope.pinobj.pinHeaderColor);
            var html = '<div class="panel pin font{{pinobj.pinFontColor}}">';   

            if(commonUtils.editor){
                html = html+'<div class="panel-heading clearfix {{pinobj.pinHeaderColor}}" >';
            }
                

            else if(scope.preview)
                html = html+'<div class="panel-heading clearfix  {{pinobj.pinHeaderColor}}" ng-show={{pinobj.isHeader}}>';

                html = html+'<div class="col-md-7 panel-title" style="padding-left:0px;">';
                            //'<div class="col-md-2 col-sm-2 col-xs-2 pin-icon"><i class="{{pinobj.pinIcon}}" ng-click="setPinIcon()"></i></div>';
                            //'<div class="col-md-2 col-sm-2 col-xs-2 pin-icon"></div>';

            if(commonUtils.editor)
                
                html = html +'<div class="col-md-9 col-sm-7 col-xs-6"><a class="pinTitle" ng-hide="editOn">{{pinobj.title}}</a><i class="editTitleIcon fa fa-pencil" ng-hide="editOn" ng-click="editTitle()"></i><input type="text" class="pin-header form-control" ng-model="pinobj.title" ng-if="editOn" ng-blur="hideEditTitle()"/> </div>';
            else if(scope.preview)
                html = html +'<div class="col-md-9 col-sm-7 col-xs-6 pin-header">{{pinobj.title}}</div>';

            //    html = html +'<h3 id="pinTitle" class="panel-title pull-left" style="padding-top: 3px;padding-bottom:3px;">'+
              //                  '<i class="{{pinobj.pinIcon}}" ng-click="setPinIcon()"></i>'+
                //                '&nbsp;{{pinobj.title}}</h3>';

                html = html +'</div>' +
                            '<div class="btn-group pull-right">' +
                                //'<button id="export_png"  ng-if=editor class="btn btn-xs btn-default" ng-click="exportPng()" title="Png" ng-hide="minimize"><i class="fa fa-minus"></i></button>' +
                                '<button id="panel_color" class="btn btn-xs btn-default" ng-click="setHeaderColor()" title="Set Color" ng-hide="minimize" ng-if=editor ><i class="fa fa-paint-brush"></i></button>' +
                                '<button id="panel_refresh"  ng-if=editor class="btn btn-xs btn-default" ng-click="refreshPin()" title="Refresh" ng-hide="minimize"><i class="fa fa-refresh" aria-hidden="true"></i></button>' +
                                '<button id="panel_condFormat"  ng-if=editor class="btn btn-xs btn-default" ng-click="condFomrat()" title="Conditional Formatting" ng-show=isTable ><i class="fa fa-table" aria-hidden="true"></i></button>' +
                                '<button id="Panel_Properties"  ng-if=editor class="btn btn-xs btn-default" ng-click="chartProperties()" title="Pin Settings" ng-hide="minimize"><i class="glyphicon glyphicon-cog"></i></button>' +
                                '<button id="panel_zoom" class="btn btn-xs btn-default" ng-click="zoom()" title="Zoom" ng-show=iconPreview ng-if=!'+scope.isLabel+'><i class="fa fa-arrows-alt"></i></button>' +
                                '<button id="Panel_Comment" class="btn btn-xs btn-default" ng-click="pinComments()" title="Comments" ng-show=iconPreview><i class="glyphicon glyphicon-comment"></i><div class="comment-count">{{pinobj.commentsCount}}</div></button>' +
                                //'<button id="Panel_Minimize" ng-if="pinobj.minimize" class="btn btn-xs btn-default" data-target="#{{idd}}" data-toggle="collapse" title="Minimize" ng-click="minimizeClick()" ng-show=iconPreview><i class="glyphicon glyphicon-minus"></i></button>' +
                                '<div class="dropdown dropdown-setting" ng-show=iconPreview ng-if=!'+scope.isLabel+'>'+
                                    '<button id="dLabel1" type="button" title="settings" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-xs btn-default">'+
                                        '<i class="fa fa-cog"></i></button>'+
                                    '<ul class="dropdown-menu" aria-labelledby="dLabel1">'+
                                        //'<li ng-click="zoom()" ng-show=iconPreview><a href="#">Zoom</a></li>'+
                                        '<li ng-click="swapData()" ng-show=showSaiku><a href="#">Swap to Data</a></li>'+
                                        '<li ng-show=showExport ng-mouseover="exportOver()" ng-mouseleave="exportLeave()"><a href="#">Export ></a>'+
                                            '<ul ng-show="showExpOpt">'+
                                                '<li ng-click="export(\'csv\')">CSV</li>'+
                                                '<li ng-click="export(\'xls\')">XLS</li>'+
                                                '<li ng-click="exportPng()" ng-show="iscccChart">PNG</li>'+
                                            '</ul>'+                                       
                                        '</li>'+
                                        //'<li ng-if="pinobj.minimize" data-target="#{{idd}}" data-toggle="collapse" ng-click="minimizeClick()" ng-show=iconPreview><a href="#">Minimize</a></li>'+
                                    //'<li class="last"><a href="#">.pdf</a></li>'+
                                    '</ul></div>' +
                            '</div>' +
                        '</div>'+
                        '<div id="{{idd}}" class="panel-body collapse in" style="padding:0;"> '+
                            '<div id="{{pinobj.htmlObj}}" class="pin_body" style="width:100%; height:{{pinobj.height}}px;">'+
                                // '<div id="{{pinobj.htmlObj}}_chart" style="width:{{pinobj.width}}%; height:{{pinobj.height}}px;"></div>' +
                                // '<canvas id="{{pinobj.htmlObj}}_canvas" style="width:{{pinobj.width}}%; height:{{pinobj.height}}px;display:none;"></canvas>'
                            '</div>' +
                        '</div>' +
                    '</div>' 

            element.html(html);
            $compile(element.contents())(scope);
        }
    }
}]);            