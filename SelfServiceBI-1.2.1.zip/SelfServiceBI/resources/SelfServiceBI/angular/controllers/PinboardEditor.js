angular.module('pinboard')
.controller('pinboardEditorCtr',['$scope','$element','pinboard','Pin' ,'filter','filterPanel','commonUtils','Messages','$log','$timeout','$compile','$window',function($scope,$element,pinboard,Pin,filter,filterPanel,commonUtils,Messages,$log,$timeout,$compile,$window){
    //$log.debug("Pinboard Editor Controller called");
    commonUtils.setComponents();

    $scope.mode =  commonUtils.getParameterByName("mode");
    commonUtils.editor = true;
    commonUtils.mode = "pinboard";

    $scope.filterType = '';
    $scope.filterTypes = [];
    $scope.pinbCtrl = {};
    $scope.pinbCtrl.filterDatasource = '';
    $scope.pinbCtrl.filterDatasources = [];
    $scope.disableAppend = false;
    $scope.disableNew = false;
    $scope.disableSave = false;
    $scope.disableSaveAs = false;
    $scope.disablePreview = false;
    $scope.disableSubmit = false;
    pinboard.init();

    var winH = $(window).height();
    var winW = $(window).width();
    var leftW = $('#lsetting').width();
    var leftpanelW = leftW+55;


    $scope.isEmpty = true;


//$(".mainpage-singlepin").css("width",winW);

    /*
    $("#mainpage").css("width",winW-55);
    $("#mainpage").css("left",55);  

    */
    $("#mainpage").css("min-height",winH-50);
//    $("#LayoutMaker_container").css("top",$("#topButton").height()+10);

    $scope.PinBoardFile = pinboard.PinBoardFile;
    $scope.pinboardName = pinboard.PinboardName;
    $scope.usercomments = pinboard.userComments;
    $scope.commentsCount = pinboard.commentsCount;

    $scope.bgcolor = pinboard.bgcolor;
    $scope.webfont = pinboard.fonts;
    $scope.transTheme = pinboard.transTheme;

    var w = angular.element($window);


    w.bind('resize', function(){

        winH = $(window).height();
        winW = $(window).width();
        leftW = 0;

        $('body').css('height',$('html').height()-50);
        $("#mainpage").css('height',document.getElementById("mainpage").scrollHeight)
        commonUtils.safeApply($scope,function(){});
    });


    $scope.$watch("pinboardName",function(){
        commonUtils.savedFlag = false;
    })

    if($scope.mode == "edit")
    {
        $scope.showEditorOption = false ;
        pinboard.PinBoardFile = commonUtils.getParameterByName("solutionFile");
        $('#filterpanel').collapse('show');
        pinboard.getConfigFromFile();
        $scope.PinBoardFile = pinboard.PinBoardFile;
        $scope.pinboardName = pinboard.PinboardName;
        $scope.usercomments = pinboard.userComments;
        $scope.commentsCount = pinboard.commentsCount;

        $scope.bgcolor = pinboard.bgcolor;
        $scope.webfont = pinboard.fonts;
        $scope.transTheme = pinboard.transTheme;

        commonUtils.savedFlag = true;
        commonUtils.isNull = false;
        commonUtils.savedFileFlag = true;

        $scope.isEmpty = false;
        $timeout(function(){
            $scope.dblist = angular.copy(pinboard.datasourceList);
            if($scope.dblist.length>0)
                $scope.isDbListNull = false;
            
            else
                $scope.isDbListNull = true;   
        },0);
    }
    else
    {
        commonUtils.savedFlag = false;
        commonUtils.savedFileFlag = false;
        $scope.PinBoardFile = pinboard.PinBoardFile;
        $scope.showEditorOption = true;
    }

    $('#setting-panel .btn').on('click', function() {
        $('#setting-panel .btn').removeClass('active');
        $(this).addClass('active');
    });

    $scope.sidebarAction = function(panelid,btnid){
        $(".nav-btn").removeClass("panel-setting-active");
        

        if($("#"+panelid).hasClass("opened")){
            $("#wrapper").removeClass("toggleSidebar")
            $("#"+panelid).removeClass("opened");
            pinboard.resizeChart(); 
        }
        else if($(".sidepanel").hasClass("opened")){
            $(".sidepanel").removeClass("opened");
            $("#"+panelid).addClass("opened");
            $("#"+btnid).addClass("panel-setting-active");
        }
        else{
            $("#wrapper").addClass("toggleSidebar")
            $("#"+panelid).addClass("opened");
            $("#"+btnid).addClass("panel-setting-active");
        }
        
    }
    $scope.setting = function(){
        if($('#wrapper').hasClass('toggle')){
            $("#wrapper").removeClass("toggle")
            $("#wrapper").removeClass("toggleSidebar")
            $(".sidepanel").removeClass("opened")
        }
        else{
            $("#wrapper").addClass("toggle")
        } 
    }

    $scope.showFilterAdv = true;
    $scope.filterTypeChanged = function(){
        if($scope.filterType == 'datePicker'){
            $scope.dateFormat = "( YYYY-MM-DD )";
            $scope.showDataSource = false;
            //$('#filterDatasourcePanel').hide();
            $scope.showFilterAdv = false;
        }
        else if($scope.filterType == "combobox" || $scope.filterType == "multiSelect"){
            $scope.showDataSource = true;
            //$('#filterDatasourcePanel').show();
            $scope.dateFormat = "";
            $scope.showFilterAdv = true;
        }
        else{
            $scope.showDataSource = false;
            $scope.dateFormat = "";
            $scope.showFilterAdv = true;
            //$('#filterDatasourcePanel').hide();
        }
    };
    $scope.setCaption = function(){
        $scope.filterCaption = $scope.filterName;
    }    
    
    var init = function(){
        var filterObj;
        //available component for filtering
        filterObj = commonUtils.readJSONFile('component/filter/filterComponent.json');
        for(i=0;i<filterObj.filterComponent.length;i++)
            $scope.filterTypes.push(filterObj.filterComponent[i].componentName);
        $scope.showDataSource = false;
        //$('#filterDatasourcePanel').hide();
        //$("#filterpanel").collapse("show");
    }
    init();

    $scope.setFilterVal = function(val){
        $scope.filterVal = "current"+val;
    }

    $scope.loadDataAccessId = function(){
        var getDataAccessId = [];
        $scope.pinbCtrl.filterDatasources = [];
        uri = encodeURIComponent($scope.pinbCtrl.dataSource);
        url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listQueries?path=/'+uri ;

        if(($scope.pinbCtrl.dataSource == undefined || $scope.pinbCtrl.dataSource.length <1 ) && ($scope.pinbCtrl.filterDatasource == undefined || $scope.pinbCtrl.filterDatasource.length < 1 ))
            return;
        else{
            var queryData = commonUtils.synchronousJsonCall(url,'GET',null);
        }

        if(queryData == undefined || queryData.length <= 0){
            return;
        }

        for(i=0,l=queryData.resultset.length;i<l;i++)
            getDataAccessId.push(queryData.resultset[i][0]);

        $log.debug("getDataAccessId : "+getDataAccessId);

        
        for(var i = 0; i < getDataAccessId.length; i++) {
                $scope.pinbCtrl.filterDatasources.push(getDataAccessId[i]);
            }
        $scope.pinbCtrl.filterDatasource = getDataAccessId[0];
        $scope.checkValid();
    }

    $scope.checkValid = function(){
        var listParams;
        uri = encodeURIComponent($scope.pinbCtrl.dataSource);
        url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+$scope.pinbCtrl.filterDatasource ;
        if(($scope.pinbCtrl.dataSource != undefined || $scope.pinbCtrl.dataSource.length > 0 ) && ($scope.pinbCtrl.filterDatasource != undefined || $scope.pinbCtrl.filterDatasource.length > 0 ))
            listParams = commonUtils.readJSONFile(url);
        else
            return;    
                
        var param = '';

        var  l = listParams.resultset.length;
        for(var i=0;i<l;i++){
            var cdaParam = listParams.resultset[i][0];
            if(listParams.resultset[i][1].search("Array") >= 0){
                var valArray = [];
                valArray = JSON.parse(listParams.resultset[i][2])
                for(var j=0;j<(len=valArray.length);j++)
                    param = param + '&param'+cdaParam+'='+valArray[j];
            }
            else{
                param = param + '&param'+cdaParam+'='+listParams.resultset[i][2];
            }
        }

        url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/'+uri+'&dataAccessId='+$scope.pinbCtrl.filterDatasource+param+'&outputIndexId=1';
        var datasourceVal = commonUtils.readJSONFile(url);

        if(datasourceVal.metadata.length > 1 || datasourceVal.metadata.length <1){
            $scope.validDatasource = false;
        }
        else{
            $scope.validDatasource = true;   
        }

        if($scope.validDatasource){
            $scope.datasourceArray= [];    
            for(var a=0;a<datasourceVal.resultset.length;a++){
                $scope.datasourceArray.push(datasourceVal.resultset[a][0]);
            }
        }   
    }

    $scope.addFilter = function(){
        $log.debug("add filter called");
        

        if($scope.filter.$valid){
            if($scope.filterType=="multiSelect" || $scope.filterType=="combobox"){
                if($scope.pinbCtrl.dataSource == undefined || $scope.pinbCtrl.dataSource.length <= 0)
                    return;
                else if(!$scope.validDatasource){
                    alert("datasource should contain only one column");
                    return;
                }
                    
            }
            else if($scope.filterType=="datePicker"){
                if(!$scope.filterVal.match(/^[0-9]{4}\-(0[1-9]|1[012])\-(0[1-9]|[12][0-9]|3[01])/)){
                    commonUtils.notification(Messages.onInvalidDateFormat,"danger");
                    $scope.filterVal = "";
                    $("#filterVal").focus();
                    return;
                }
            }
            $("#filterpanel").collapse("show");
            var len = pinboard.filterPanel.filterArray.length;

            var checkId = function(indx){
                for(a=0;a<indx;a++){
                    if($scope.filterName == pinboard.filterPanel.filterArray[a].filterName){
                        $scope.disableSubmit = true;
                        commonUtils.notification(Messages.onFilterNameAlreadyExist,"danger");
                        $timeout(function(){
                            $scope.disableSubmit = false;
                        },3000);
                        return false;                       
                    }
                }
                return true;
            }
            
            var status = checkId(len);
            if(status){
                pinboard.filterPanel.filterArray[len] = new filter();
                pinboard.filterPanel.filterArray[len].filterId  = $scope.filterName.replace(/\s+/g, '');
                //$log.log(pinboard.filterPanel.filterArray[len].filterId);
                pinboard.filterPanel.filterArray[len].filterType = $.trim($scope.filterType);
                pinboard.filterPanel.filterArray[len].filterName = $scope.filterName.replace(/\s+/g, '');
                pinboard.filterPanel.filterArray[len].filterCaption = $.trim($scope.filterCaption);
                //pinboard.filterPanel.filterArray[len].filterWidth = "120";

                var filterVal = $scope.filterVal.split(",");
                if($scope.filterType == 'multiSelect'){
                    pinboard.filterPanel.filterArray[len].filterVal = [];
                    pinboard.filterPanel.filterArray[len].defaultVal = [];
                    for(i=0;i<filterVal.length;i++){
                        pinboard.filterPanel.filterArray[len].filterVal.push(filterVal[i]);
                        pinboard.filterPanel.filterArray[len].defaultVal.push(filterVal[i]);    
                    }
                    pinboard.filterPanel.filterArray[len].dataSource = $.trim($scope.pinbCtrl.dataSource);
                    pinboard.filterPanel.filterArray[len].dataAccessId = $scope.pinbCtrl.filterDatasource;
                    pinboard.filterPanel.filterArray[len].datasourceArray =$scope.datasourceArray;
                }
                else if($scope.filterType == 'combobox'){
                    pinboard.filterPanel.filterArray[len].filterVal = filterVal[0];    
                    pinboard.filterPanel.filterArray[len].defaultVal = filterVal[0];
                    pinboard.filterPanel.filterArray[len].dataSource = $scope.pinbCtrl.dataSource;
                    pinboard.filterPanel.filterArray[len].dataAccessId = $scope.pinbCtrl.filterDatasource;
                    pinboard.filterPanel.filterArray[len].datasourceArray = $scope.datasourceArray;
                }
                else{
                    pinboard.filterPanel.filterArray[len].filterVal = filterVal[0];    
                    pinboard.filterPanel.filterArray[len].defaultVal = filterVal[0];
                    pinboard.filterPanel.filterArray[len].dataSource = "";
                    pinboard.filterPanel.filterArray[len].dataAccessId = "";
                    pinboard.filterPanel.filterArray[len].datasourceArray = "";
                }
                
                var filterType = window[$scope.filterType];
                var addHtmlComponent = new filterType();
                pinboard.filterPanel.filterArray[len].htmlComponent = addHtmlComponent.init(pinboard.filterPanel.filterArray[len].datasourceArray);
                pinboard.filterPanel.filterArray[len].listenerPins = [];
                pinboard.filterPanel.filterPanelShow = true; 
                $log.log(pinboard.filterPanel);
                
                $timeout(function(){
                    //$(".btn-hide-filteroption").hide();
                    $scope.filterName = "";
                    $scope.filterCaption = "";
                    $scope.filterType = "textbox";
                    $scope.showDataSource = false;
                    $scope.filterVal = "";
                    $scope.pinbCtrl.dataSource = "";
                    $scope.pinbCtrl.filterDatasource = "";
                    $scope.dateFormat = "";
                    $log.debug("filterPanelShow "+pinboard.filterPanel.filterPanelShow);
                    commonUtils.savedFlag = false;
                    $log.log($('#filterpanel').height())
                    if($('#filterpanel').height() == 0){
                        $('#filterpanel').height("");
                        $('#filterpanel').addClass('in');
                    }
                    //pinboard.filterPanel.filterArray[len].getJson();
                },0)
            }
            $("#filterName").focus();
        }
    };
 
    var sortArray = function(arry){
        arry.sort(function(a,b){
            return a.y == b.y ? a.x - b.x : a.y - b.y;
        })
    }

    function removeAllRowsPinboard()
    {
        pinboard.removeAll();
        commonUtils.safeApply($scope,function(){});
        commonUtils.isNull = true;
    }

    function savePinboard()
    {
        if(!pinboard.saveConfigToFile())
        {
            commonUtils.notification(Messages.onPinBoardSaveUserRightError,"danger");
            commonUtils.savedFileFlag=false;
            commonUtils.savedFlag = false;
            return false;
        }
        else
        {
            commonUtils.savedFileFlag=true;
            commonUtils.savedFlag = true;
            return true;
        }
        
    }


    $scope.newPinboardClick = function ()
    {
        if(!commonUtils.isNull && !commonUtils.savedFlag){
            var r = commonUtils.BootstrapConfirm(Messages.onUnsavePinBobardConfirm,function(r){
                if (r){
                    if(commonUtils.savedFileFlag){
                        if(savePinboard())
                            createNewPinBoard();
                    }
                    else{
                        function onSave(path){
                            pinboard.PinBoardFile = path;
                            if(savePinboard())
                                createNewPinBoard();
                        }
                        function onCancel(){
                            //createNewPinBoard();
                        }
                        commonUtils.saveDialogBox("Save Pin Board","pinb",onSave,onCancel);
                    }
                }
                else{
                    createNewPinBoard();
                }
            });
        }
        else
        {
            createNewPinBoard();
        }
        function createNewPinBoard()
        {
            pinboard.init();
            $scope.PinBoardFile = pinboard.PinBoardFile;
            removeAllRowsPinboard();
            commonUtils.isNull = true;
            commonUtils.savedFileFlag =false;
            commonUtils.savedFlag =false;
            $scope.disableNew = true;
            $scope.pinboardName = pinboard.PinboardName;
            $scope.usercomments = pinboard.userComments;
            $scope.commentsCount = pinboard.commentsCount;

            $scope.dblist = [];
            $scope.isDbListNull = true;
            $scope.bgcolor = pinboard.bgcolor;
            $scope.webfont = pinboard.fonts;
            $scope.transTheme = pinboard.transTheme;

            $scope.isEmpty = true;
            commonUtils.notification(Messages.onNewPinboardNotification);
            $timeout(function(){
                $scope.disableNew = false;
            },4000);
            $log.debug("New Pinboard Created");
        }
    }

    $scope.openPinboardClick = function ()
    {
        if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            var r = commonUtils.BootstrapConfirm(Messages.onUnsavePinBobardConfirm,function(r){
                if (r)
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(savePinboard())
                            openPinBoard();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            pinboard.PinBoardFile = path;
                            $scope.PinBoardFile = pinboard.PinBoardFile;
                            commonUtils.safeApply($scope,function(){});
                            if(savePinboard())
                                openPinBoard();
                        }
                        function onCancel()
                        {
                            openPinBoard();
                        }
                        commonUtils.saveDialogBox("Save Exiting Pin Board","pinb",onSave,onCancel);
                    }
                }
                else
                {
                    openPinBoard();
                }
            });
        }
        else
        {
            openPinBoard();
        }

        function openPinBoard()
        {
            function onOpen(path)
            {
                $("#wrapper").removeClass("toggleSidebar");
                $(".nav-btn").removeClass("panel-setting-active");
                $(".sidepanel").removeClass("opened");
                pinboard.PinBoardFile = path;
                $scope.PinBoardFile = pinboard.PinBoardFile;
                pinboard.getConfigFromFile();
                //$log.log(pinboard)
                pinboard.PinBoardFile = path;
                $scope.pinboardName = pinboard.PinboardName;
                $scope.usercomments = pinboard.userComments;
                $scope.commentsCount = pinboard.commentsCount;

                
                $scope.bgcolor = pinboard.bgcolor;
                $scope.webfont = pinboard.fonts;
                $scope.transTheme = pinboard.transTheme;
                $scope.changeTrans();
                
                commonUtils.safeApply($scope,function(){});
                commonUtils.isNull = false;
                commonUtils.savedFlag =true;
                commonUtils.savedFileFlag=true;
                $scope.isEmpty = false;
                commonUtils.notification(Messages.onOpenPinboardNotification);
                $timeout(function(){
                    $scope.dblist = angular.copy(pinboard.datasourceList);
                    $scope.fontChanged();
                },0)
            }
            function onCancel()
            {
                $log.debug("Open file option canceled");
            }
            commonUtils.openDialogBox("Open Pin Board","pinb",onOpen,onCancel);
        }
    }
    $scope.savePinboardClick = function ()
    {   
        pinboard.PinboardName = $scope.pinboardName;
        pinboard.userComments = $scope.usercomments;
        pinboard.commentsCount = $scope.commentsCount;

        pinboard.bgcolor = $scope.bgcolor;
        pinboard.fonts = $scope.webfont;
        pinboard.transTheme = $scope.transTheme;

        sortArray(pinboard.pinLists);
        /*
        if(commonUtils.isNull){
            $scope.disableSave = true;
            commonUtils.notification(Messages.onNullPinboardNotification,"danger");
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }
        */
        if(!commonUtils.savedFlag)
        {
            if(commonUtils.savedFileFlag)
            {
                if(savePinboard())
                    commonUtils.saveNotification(Messages.onSavePinboardNotification);
            }
            else
            {
                function onSave(path)
                {
                    pinboard.PinBoardFile = path;
                    //$log.log("on save");
                    //$log.log(path);
                    $scope.PinBoardFile = pinboard.PinBoardFile;
                    commonUtils.safeApply($scope,function(){});
                    if(savePinboard())
                        commonUtils.saveNotification(Messages.onSavePinboardNotification);
                }
                function onCancel()
                {
                    $log.debug("Save file option canceled");
                }
                commonUtils.saveDialogBox("Save Pin Board","pinb",onSave,onCancel);
            }
        }
        else
        {
            $scope.disableSave = true;
            commonUtils.notification(Messages.onAlreadySavedPinboardNotification);
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }
    }

    $scope.saveAsPinboardClick = function ()
    {   
        pinboard.PinboardName = $scope.pinboardName;
        pinboard.userComments = $scope.usercomments;
        pinboard.commentsCount = $scope.commentsCount;

        pinboard.bgcolor = $scope.bgcolor;
        pinboard.fonts = $scope.webfont;
        pinboard.transTheme = $scope.transTheme;
        if(commonUtils.isNull){
            $scope.disableSaveAs = true;
            commonUtils.notification(Messages.onNullPinboardNotification,"danger");
            $timeout(function(){
                $scope.disableSaveAs = false;
            },4000)
        }
        else{
            function onSave(path)
            {
                pinboard.PinBoardFile = path;
                $scope.PinBoardFile = pinboard.PinBoardFile;
                commonUtils.safeApply($scope,function(){});
                if(savePinboard())
                    commonUtils.notification(Messages.onSaveAsPinboardNotification);

            }
            function onCancel()
            {
                $log.debug("Save file option canceled");
            }
            commonUtils.saveDialogBox("Save As Pin Board","pinb",onSave,onCancel);    
        }
        
    }

    $scope.previewPinboardClick = function ()
    {
        if(!commonUtils.savedFlag){
            $scope.disablePreview = true;
            commonUtils.notification(Messages.onPreviewUnsavePinBoardError,"danger");
            $timeout(function(){
                $scope.disablePreview = false;
            },4000)
        }
        else
        {
            $log.debug("Pinboard preview selected");
            var win = window.open('pinboardPreview.html?mode=generatedContent&solutionFile='+encodeURIComponent(pinboard.PinBoardFile), '_blank');
            if(win){
                win.focus();
            }
            else{
                commonUtils.notification(Messanges.OnPopWindowError,"danger");

            }
        }
    }

    function getPinHeaderColor(theme){
        var color;
        switch(theme){
            case 'Light':{
                color= 'panel-grey1';
                break;
            }
            case 'Dark':{
                color= 'panel-orange2';
                break;
            }
            case 'Magenta':{
                color= 'panel-green1';
                break;
            }
            case 'Green':{
                color= 'panel-orange2';
                break;
            }
            case 'Blue':{
                color= 'panel-blue2';
                break;
            }
            case 'Grey':{
                color= 'panel-grey1';
                break;
            }
            default:{
                color='panel-green4';
                break;
            }
        }
        return color;
    }


    $scope.webfonts = ['Default','Ubuntu','Myriad Pro','Oswald','PT Serif','Lobster','Bebas','Fabfelt','Oregon','League Gothic','Lato'];
    $scope.webfont = $scope.webfonts[0];
    
    var fontMap = {"Default":"open_sansregular","Ubuntu":"Ubuntu-R","Myriad Pro":"Myriad Pro Regular","Oswald":"Oswald-Regular","PT Serif":"pt_serifregular","Lobster":"Lobster","Bebas":"BebasNeue_Regular","Fabfelt":"fabfeltscript-bold","Oregon":"Oregon LDO","League Gothic":"LeagueGothic","Lato":"Lato"};
   
    $scope.fontChanged = function(){
        //$('body').css('font-family',fontMap[$scope.webfont]);
        $(".pinTitle").css('font-family',fontMap[$scope.webfont]);
        $(".header-name").css('font-family',fontMap[$scope.webfont]);
        $("filterpanel  #filterpanelTitle").css('font-family',fontMap[$scope.webfont]);
         commonUtils.savedFlag = false;
    }


    $scope.fontChanged();
    $scope.webfontColors = ["Light","Dark"];
    $scope.webfontColor = "Light";

    $scope.fontColorChanged = function(){
        //pinboard.pinLists
        angular.forEach(pinboard.pinLists,function(v,i){
            pinboard.pinLists[i].pin[0].pinFontColor = $scope.webfontColor;
        })

        pinboard.filterPanel.filterPanelFontColor = $scope.webfontColor;
        commonUtils.savedFlag = false;
    }


    $scope.transTheme = false;

    $scope.changeTrans = function(){

        if($scope.transTheme){
            $('body').addClass('transTheme');
            pinboard.transTheme = true;
            $("button#panel_color").hide();
        }
            
        else{
            $('body').removeClass('transTheme');
            pinboard.transTheme = true;   
            $("button#panel_color").show();
        }
            

        commonUtils.savedFlag = false;
    }

    $scope.bgcolors = ['Dark','Magenta','Green','Blue','Grey','Light'];
    $scope.bgcolor = 'Light';


    // $scope.bgColorChanged = function(){
    //     if($scope.bgcolor!= void 0)
    //         $('body').removeClass('bg-'+$scope.bgcolor.toLowerCase());
    //     commonUtils.savedFlag = false;
    // }
    // $scope.bgColorChanged()

    $scope.$watch('bgcolor',function(newval,oldval){
        if(oldval!= undefined){
            $('body').removeClass('bg-'+oldval.toLowerCase());
            $('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
            //$('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
        }
        if(newval!=undefined){
            $('body').addClass('bg-'+newval.toLowerCase());
            $('#LayoutMaker_container').addClass('bg-'+newval.toLowerCase());
            //$('.bootstrap-dialog.type-primary .modal-header').css('background-color','#333');
            //$scope.setFont(newval);
        }

        commonUtils.savedFlag = false;
    });
    // var currentTheme;
    // $scope.changeTheme = function(theme){
    //     //console.log(angular.element(event.target).addClass("selected"))
    //     $('.theme-icon').removeClass("selected")
    //     $('.'+theme+"-theme-btn").addClass("selected");


    //     $('body').removeClass("theme-custom");
    //     $('body').removeClass("theme-dark");
    //     $('body').removeClass("theme-light");
    //     $('body').addClass("theme-"+theme);

    //     if(theme=="dark"){
    //         for(var i=0;i<pinboard.pinLists.length;i++){
    //             for(var j=0;j<pinboard.pinLists[i].pin[0].chartProperties.length;j++){
    //                 if(pinboard.pinLists[i].pin[0].chartProperties[j][0]=="colors")
    //                     pinboard.pinLists[i].pin[0].chartProperties[j][3] = ["#333333","#454545","#666666","#808080","#999999"];
    //             }
    //             pinboard.pinLists[i].pin[0].render(pinboard.pinLists[i].pin[0].paramStr)

    //         }
    //     }
    // }

    // $scope.changeTheme('custom');



    $scope.numpins = '1';

    $scope.resetPinboard = function ()
    {
        BootstrapDialog.confirm({
            title: 'Confirmation',
            message: Messages.onRemoveAllPinConfirm,
            closable: true, // <-- Default value is false
            btnOKClass: 'btn-lg btn-primary btn-sameWidth',
            btnCancelClass: 'btn-lg btn-danger btn-sameWidth',
            callback: function(result) {
                if(result) {
                    removeAllRowsPinboard();
                    commonUtils.notification(Messages.onPinBoardRemoveRowSuccess);
                    commonUtils.savedFlag =false;
                    $("#mainpage").height(document.getElementById("mainpage").scrollHeight);
                    $scope.isEmpty = true;
                }
            }
        });
    }


    $scope.disableDD = false;
    $scope.refreshGrid = true;
    
    $scope.disableDragDrop = function(){
        $scope.disableDD?(pinboard.options.disableResize=false,pinboard.options.disableDrag=false,pinboard.isGridDisable=false,$scope.disableDD=false):(pinboard.options.disableResize=true,pinboard.options.disableDrag=true,pinboard.isGridDisable=true,$scope.disableDD=true)
        // console.log(pinboard.options);
        // console.log(pinboard.isGridDisable);
        // $element.find("#LayoutMaker_container").html("");

        // $element.find("#LayoutMaker_container").html($compile("<dashboard></dashboard>")($scope))
        // $element.find('dashboard').removeClass('ng-scope');

        $scope.refreshGrid = false;

        
        $timeout(function(){
            sortArray(pinboard.pinLists);
            $scope.refreshGrid = true;
        },0);        
    }


    $scope.appendGrid = function(){
        var width = 12/$scope.numpins;
        for(var i=0;i<$scope.numpins;i++){
            
            pinboard.uniquePinIdCnt++;

            var l_obj = { x: 0,y:0,width:width,height:4,id:'Pin_'+(pinboard.uniquePinIdCnt)};

            var pinInit = new Pin();
            
            pinInit.init();

            pinInit.pinId = l_obj.id;
            //$log.log(pinrow.pins[i].pinId);
            pinInit.cIdx = 0;
            pinInit.title = l_obj.id;
            pinInit.htmlObj = l_obj.id; // chart genrate unique ID
            
            pinInit.cellwidth = 'col-md-'+l_obj.width;
            pinInit.height = l_obj.height*70-78;
            pinInit.pinFontColor = $scope.webfontColor;
            
            //console.log(pinInit)
            //$scope.pinoj.push(pinInit);
            l_obj.pin = [];

            l_obj.pin.push(pinInit); 
            pinboard.pinLists.push(l_obj);
            
        }

        $scope.isEmpty = false;
    }

    $scope.browseDatasource = function(){
        function getData(path){
            $timeout(function(){
                $scope.brwsDataSource = path;
                $scope.addDatasource();
             },0)
        }
        commonUtils.btnPinSaikuBrowse("Browse Data Source",$scope.dboption,"browseFile",getData);
    }

    $scope.addDatasource = function(){
        if($scope.brwsDataSource!=void 0 && $.inArray($scope.brwsDataSource,$scope.dblist)<0){
            $scope.dblist.push($scope.brwsDataSource);
            $scope.isDbListNull = false;
        }
            

        commonUtils.notification(Messages.onPinBoardDatasourceAdded);
        $scope.brwsDataSource = null;
    }

    Array.prototype.compare = function(testArr) {
        if (this.length != testArr.length) return false;
        for (var i = 0; i < testArr.length; i++) {
            if (this[i].compare) { 
                if (!this[i].compare(testArr[i])) return false;
            }
            if (this[i] !== testArr[i]) return false;
        }
        return true;
    }

    $scope.dboption = "cda";
    //$scope.isDbListNull = false;
    $scope.dblist = [];

    if($scope.dblist.length>0){
        $scope.pinbCtrl.dataSource = $scope.dblist[0];
        $scope.loadDataAccessId();
    }
        

    $scope.$watchCollection('dblist',function(newval,oldval){
        if($scope.dblist.length>0)
            $scope.isDbListNull = false;
        else
            $scope.isDbListNull = true; 


        
        pinboard.datasourceList = angular.copy(newval);
        //console.log("Waatch collection")
         //console.log(commonUtils.synchronousJsonCall('http://'+location.host+'/pentaho/plugin/cda/api/listQueries?path=','GET',null));
        if(oldval.length>newval.length){
            var indx ="";
            $.each(oldval,function(i,v){
                if(newval.indexOf(v)==-1)
                    indx = i;
            })
            pinboard.removeDAelement(oldval[indx]);
        }


        else if($scope.dboption=='cda' && newval.length>0 && newval.length-oldval.length ==1){
            
            pinboard.addDAelement(pinboard.datasourceList.length-1);
        }

        else if($scope.dboption=='cda' && newval.length>0 &&  oldval==newval){
            $.each(pinboard.datasourceList,function(i,v){
                if(v.indexOf(".cda")>0)
                    pinboard.addDAelement(i);           
            })

        }

    })

    $scope.removeDb = function(i){
        $scope.dblist.splice(i,1);
        if($scope.dblist.length==0)
            $scope.isDbListNull = true;
    }


    $(function(){
        $('body').removeClass("fade-out");
    })

}]);

angular.module('pinboard')
.controller('pinboardViewerCtr',['$scope','pinboard','Pin' ,'filter','filterPanel','commonUtils','Messages','$window','$log','$compile','$timeout',function($scope,pinboard,Pin,filter,filterPanel,commonUtils,Messages,$window,$log,$compile,$timeout){
    $log.debug("This is Pinboard View Controller");
    commonUtils.mode = "pinboard";
    var mode=commonUtils.getParameterByName("mode").split("?")[0] ;
    if(mode == "editor")
        $window.location.href ="../../../content/SelfServiceBI-res/SelfServiceBI/pinboardEdit.html?mode=edit&solutionFile=" +  commonUtils.getParameterByName("solutionFile");

    else
    {
        pinboard.PinBoardFile = commonUtils.getParameterByName("solutionFile");
        pinboard.PinBoardFile = pinboard.PinBoardFile.replace(/%([^\d].)/, "%25$1");
        pinboard.PinBoardFile = decodeURIComponent(pinboard.PinBoardFile);
        commonUtils.editor=false;

        pinboard.options.disableDrag = true;
        pinboard.options.disableResize = true;


        

        pinboard.getConfigFromFile();

        
        $scope.pinboardName = pinboard.PinboardName;
        $scope.usercomments = pinboard.userComments;
        $scope.commentsCount = pinboard.commentsCount;


        $scope.bgcolor = pinboard.bgcolor;
        $scope.webfont = pinboard.fonts;
        $scope.transTheme = pinboard.transTheme;
        var w = angular.element($window);
        w.bind('resize', function () {

            pinboard.resizeChart();
            
            //$('body').height($('html').height());
        });
        $("#filterpanel").collapse("show");

        


        $("body").css("min-height",$(window).height()-10)
        $scope.fileComments = function(){
            commonUtils.comments($scope,$scope.pinboardName,$scope.usercomments,$scope.commentsCount);
        }

        $scope.$watchCollection('usercomments',function(){
            var len = $scope.usercomments.length;

            if(len == undefined || len < 0 )
                $scope.commentsCount='';
            else if(len > 0 && len <10)
                $scope.commentsCount= len;
            else if(len > 10)
                $scope.commentsCount = '10+'; 

            pinboard.saveConfigToFile();
        })
        
        $scope.changeTrans = function(){
            
            if($scope.transTheme)
                $('body').addClass('transTheme');
            else
                $('body').removeClass('transTheme');
        }

        $scope.changeTrans();

        $scope.$watch('bgcolor',function(newval,oldval){
            if(oldval!= undefined){
                $('body').removeClass('bg-'+oldval.toLowerCase());
                $('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
                //$('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
            }
            if(newval!=undefined){
                $('body').addClass('bg-'+newval.toLowerCase());
                $('#LayoutMaker_container').addClass('bg-'+newval.toLowerCase());
                //$('.bootstrap-dialog.type-primary .modal-header').css('background-color','#333');
                //$scope.setFont(newval);
            }

            if(newval!=undefined && newval=='Transparent'){
                $('pin').addClass('transTheme');
            }
            else{
                $('pin').removeClass('transTheme');   
            }
            commonUtils.safeApply($scope,function(){});

        });

        var fontMap = {"Default":"open_sansregular","Ubuntu":"Ubuntu-R","Myriad Pro":"Myriad Pro Regular","Oswald":"Oswald-Regular","PT Serif":"pt_serifregular","Lobster":"Lobster","Bebas":"BebasNeue_Regular","Fabfelt":"fabfeltscript-bold","Oregon":"Oregon LDO","League Gothic":"LeagueGothic","Lato":"Lato"};
        
        $(".pinboard-header-preview").css('font-family',fontMap[$scope.webfont]);


        $(function(){
            
            //$compile($('.pinboard-preview-div').html('<dashboard></dashboard>'))
            //$('body').css('min-height',$('html').height()-50);
            $("pin .pin-header").css('font-family',fontMap[$scope.webfont]);
            $("filterpanel  #filterpanelTitle").css('font-family',fontMap[$scope.webfont]);
            $('body').removeClass("fade-out");
        })

    }
     //$('.dropdown-toggle').dropdown()
}]);