angular.module('dataSourceModule',['commonUtilModule','messagesModule']);

angular.module('dataSourceModule')
.config(['$logProvider',function($logProvider){
    $logProvider.debugEnabled(false);
}]);

angular.module('dataSourceModule')
.controller('datasourceCtrl',['$scope','$log','$compile','commonUtils','Messages','dataSource','datasrc','$timeout','datasrcOuter',function($scope,$log,$compile,commonUtils,Messages,dataSource,datasrc,$timeout,datasrcOuter){

	commonUtils.isNull = true;
	commonUtils.savedFlag = false;
    commonUtils.savedFileFlag = false;
    commonUtils.propertiesSaved = false;

    $scope.datasourceFile = "";
    $scope.disableNew = false;
    $scope.disableSave = false;
    $scope.disableSaveAs = false;

    $('#propertiesPanel').change(function(){
    	commonUtils.savedFlag = false;
		commonUtils.propertiesSaved = false;
    	commonUtils.safeApply($scope,function(){});		
    })

    $scope.dblist = [];

    var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/data-access/api/connection/list',"GET",{'ts' : '1437031684490'});

    for(i=0;i<jsonData.databaseConnections.length;i++){
        $scope.dblist.push(jsonData.databaseConnections[i].name);
    }


	$scope.sqlJndi = function(){
		
        $scope.ds_name="";
        $scope.dbcon = $scope.dblist[0];
        $scope.dbcon_pass = "";

        BootstrapDialog.show({
            title: "Create Datasource",
            message: function(dialog) {

                var template = '<div class="modal-form">'+

                               '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Name</div>'+
                               '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right">'+
                               '<input type="text" id="ds_name" class="form-control input-sm" ng-model="ds_name"></div>'+
                               '</div>'+

                               '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Datasource Connection</div>'+
                               '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right">'+
                               '<select id="dbcon" class="form-control input-sm" ng-model="dbcon" ng-options="n for n in dblist" ng-change="dbChange()"></select></div>'+
                               '</div>'+



                               '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Password</div>'+
                               '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right">'+
                               '<input type="password" id="dbcon_pass" class="form-control input-sm" ng-model="dbcon_pass"></div>'+
                               '</div>'+  
                               
                               '</div>'+
                               '<div class="cl"></div>'
                var $message = $('<div></div>');
                $message.append($compile(template)($scope))
                return $message;
            },
            draggable: true,
            closable : true,
            //cssClass : 'browse-dialog',
            onshown: function(dialogRef){
                
                //console.log($scope.dblist);
                var data,dbtype,dbuser,dbhost,dbport,dbname;
                $scope.dbChange = function(){
                    data = commonUtils.synchronousJsonCall( '../../../plugin/data-access/api/connection/get',"GET",{name:$scope.dbcon});
                    dbtype = data.databaseType.shortName;
                    dbuser = data.username;
                    dbhost = data.hostname;
                    dbport = data.databasePort;
                    dbname = data.databaseName;
                }

                $scope.checkpassword = function(){
                    var tableName = commonUtils.getTableName(dbtype,dbuser,$scope.dbcon_pass,dbhost,dbport,dbname);
                    if(tableName==null)
                        return false;
                    else
                        return true;
                }

            },
            buttons: [{
                id: 'btn-save',
                label: 'Save',
                action: function(dialogItself){
                    var regexp = /^[a-zA-Z0-9-_\.]+$/;
                    if($scope.ds_name.search(regexp) == -1 && $scope.ds_name != undefined && $scope.ds_name.length > 0){
                        alert("Invalid datasource name. It only contain Alphanumeric character and special _ and . characters.");
                        return;
                    }
                    if($scope.checkpassword()){
                        //$('.row-datasource').removeClass('select');
                        $scope.addDatasource('sql.jndi',$scope.ds_name,$scope.dbcon,$scope.dbcon_pass);
                        dialogItself.close();
                        commonUtils.safeApply($scope,function(){});
                    }
                    else{
                        //alert("Wrong password");
                        $scope.addDatasource('sql.jndi',$scope.ds_name,$scope.dbcon,"");
                        dialogItself.close();
                        commonUtils.safeApply($scope,function(){});
                    }
                    
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
            {
                label: 'Cancel',
                action: function(dialogItself){
                    dialogItself.close();
                    
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
	}
	$scope.addDatasource = function(type,titleName,dbcon,dbcon_pass){
        //$log.log(dataSource.count)
		var len = dataSource.datasources.length;

        var temp = '';
        dataSource.newDtsrcType = true;

        if(len!=0){
            for(var i=0;i<dataSource.datasources.length;i++){
                //$log.log(dataSource.datasources[i].datasrcName+' '+type.substr(0, type.indexOf('.')))
                if(dataSource.datasources[i].datasrcName == type.substr(0, type.indexOf('.'))){
                    //$log.log("im here")
                    dataSource.newDtsrcType = false;
                    temp = i;
                }    
            }
        }


        if(dataSource.newDtsrcType){
            dataSource.datasources[len] = new datasrcOuter();
            dataSource.datasources[len].datasrcName = type.substr(0, type.indexOf('.'));
            dataSource.datasources[len].datasrcEntry = [];
            dataSource.datasources[len].position = len;
            makeDtsrcEntry(len,0);
        }
        else{
            var arryLen = dataSource.datasources[temp].datasrcEntry.length;
            makeDtsrcEntry(temp,arryLen);      
        }


        function makeDtsrcEntry(len,index){
            dataSource.datasources[len].datasrcEntry[index] = new datasrc();
            dataSource.datasources[len].datasrcEntry[index].id = "dtsrc"+dataSource.count;
            dataSource.datasources[len].datasrcEntry[index].name = titleName;
            dataSource.datasources[len].datasrcEntry[index].type = type;
            dataSource.datasources[len].datasrcEntry[index].properties = commonUtils.readJSONFile('component/datasource/'+type+'.properties.json');
            dataSource.datasources[len].datasrcEntry[index].properties[0][3] = dbcon;
            dataSource.datasources[len].datasrcEntry[index].properties[1][3] = dbcon_pass;

            console.log(dataSource);
            dataSource.currentCda = dataSource.datasources[len].datasrcEntry[index].id;
            console.log(dataSource.currentCda);
        }

		
		$log.debug(dataSource.datasources);

		dataSource.count++;
		commonUtils.isNull = false;
	}

	function saveDatasource()
    {   
        console.log(commonUtils.propertiesSaved);
        console.log(commonUtils.isNull)


        if(!dataSource.saveConfigToFile())
        {
            commonUtils.savedFileFlag=false;
            commonUtils.savedFlag = false;
            return false;
        }
        else
        {
            commonUtils.savedFileFlag=true;
            commonUtils.savedFlag = true;
            return true;
        }
    }
	$scope.newFile = function ()
    {
    	if(!commonUtils.propertiesSaved && !commonUtils.isNull){
    		
            commonUtils.savedFlag =false;
    	}

        if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            var r = commonUtils.BootstrapConfirm(Messages.onUnsaveDatasourceConfirm,function(r){
                if (r)
                {
                    if(commonUtils.savedFileFlag)
                    {
                        if(saveDatasource())
                            newDatasource();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            dataSource.fileName = path;
                            if(saveDatasource())
                                newDatasource();
                        }
                        function onCancel()
                        {
                        }
                        commonUtils.saveDialogBox("Save Datasource File","cda",onSave,onCancel);
                    }
                }
                else
                {
                    newDatasource();
                }
            });
        }
        else
        {
            newDatasource();
        }
        function newDatasource()
        {
            dataSource.init();
            commonUtils.isNull = true;
            commonUtils.savedFileFlag =false;
            commonUtils.savedFlag =false;
            dataSource.newDtsrcType = true;
            $scope.datasourceFile = ""
            $scope.disableNew = true;
            commonUtils.notification(Messages.onNewDatasourceNotification);
            $timeout(function(){
                $scope.disableNew = false;
            },4000);
            dataSource.blankPropertiesPanel();
            commonUtils.safeApply($scope,function(){});	
            $log.debug("New Datasource Created");
        }
    }

    $scope.openFile = function(){

    	if(!commonUtils.isNull && !commonUtils.savedFlag)
        {
            var r = commonUtils.BootstrapConfirm(Messages.onUnsaveDatasourceConfirm,function(r){
                if (r)
                {   
                    if(!commonUtils.propertiesSaved && !commonUtils.isNull){
                        
                        console.log(Messages.saveDatasourceProperties);
                        if(!dataSource.nullPropertyPanel){
                            commonUtils.notification(Messages.saveDatasourceProperties,"danger");
                        }
                    }
                    else if(commonUtils.savedFileFlag)
                    {
                        if(saveDatasource())
                            openDatasource();
                    }
                    else
                    {
                        function onSave(path)
                        {
                            dataSource.fileName = path;
                            commonUtils.safeApply($scope,function(){});
                            if(saveDatasource())
                                openDatasource();
                        }
                        function onCancel()
                        {
                            openDatasource();
                        }
                        commonUtils.saveDialogBox("Save Exiting Datasource","cda",onSave,onCancel);
                    }
                }
                else
                {
                    openDatasource();
                }
            });
        }
        else
        {
            openDatasource();
        }

        function openDatasource()
        {
            function onOpen(path)
            {
                dataSource.fileName = path;
                $scope.datasourceFile = dataSource.fileName;
	            dataSource.getConfigFromFile();
	            commonUtils.safeApply($scope,function(){});
	            commonUtils.isNull = false;
	            commonUtils.savedFlag =true;
	            commonUtils.savedFileFlag=true;
                commonUtils.notification(Messages.onOpenDatasourceNotification);
            }
            function onCancel()
            {
                $log.debug("Open datasource option canceled");
            }
            commonUtils.openDialogBox("Open Datasource","cda",onOpen,onCancel);
        }
    };

    $scope.saveFile = function(){
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            
            console.log(Messages.saveDatasourceProperties);
            if(!dataSource.nullPropertyPanel){
                commonUtils.notification(Messages.saveDatasourceProperties,"danger");
                return
            }
        }
    	if(commonUtils.isNull){
            $scope.disableSave = true;
            commonUtils.notification(Messages.onNullDatasourceNotification,"danger");
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }

        else if(!commonUtils.savedFlag)
        {
            if(commonUtils.savedFileFlag)
            {
                if(saveDatasource())
                    commonUtils.notification(Messages.onSaveDatasourceNotification);
            }
            else
            {
                function onSave(path)
                {
                    dataSource.fileName = path;
                    $scope.datasourceFile = dataSource.fileName;
                    commonUtils.safeApply($scope,function(){});
                    if(saveDatasource())
                        commonUtils.notification(Messages.onSaveDatasourceNotification);
                }
                function onCancel()
                {
                    $log.debug("Save datasrouce option canceled");
                }
                commonUtils.saveDialogBox("Save CDA data source ","cda",onSave,onCancel);
            }
        }
        else
        {
            $scope.disableSave = true;
            commonUtils.notification(Messages.onAlreadySaveDatasourceNotification);
            $timeout(function(){
                $scope.disableSave = false;
            },4000);
        }
    }

    $scope.saveFileAs = function(){
        
        if(!commonUtils.propertiesSaved && !commonUtils.isNull){
            
            console.log(Messages.saveDatasourceProperties);
            if(!dataSource.nullPropertyPanel){
                commonUtils.notification(Messages.saveDatasourceProperties,"danger");
                return
            }
        }

    	if(commonUtils.isNull){
            $scope.disableSaveAs = true;
            commonUtils.notification(Messages.onNullDatasourceNotification,"danger");
            $timeout(function(){
                $scope.disableSaveAs = false;
            },4000)
        }
        else{
            function onSave(path)
            {
                dataSource.fileName = path;
                $scope.datasourceFile = dataSource.fileName;
                commonUtils.safeApply($scope,function(){});
                if(saveDatasource())
                    commonUtils.notification(Messages.onSaveAsDatasourceNotification);

            }
            function onCancel()
            {
                $log.debug("Save datasource option canceled");
            }
            commonUtils.saveDialogBox("Save As CDA datasource","cda",onSave,onCancel);    
        }
    }
}]);

angular.module('dataSourceModule').
factory('datasrc',['commonUtils','$log',function(commonUtils,$log){
	var datasrc = function(){
		this.id = "";
		this.name = "";
		this.type = "";
		this.base = "";
		this.properties = [];
		this.position = "";
	}
	
	datasrc.prototype.init = function(){
		this.id = "";
		this.name = "";
		this.type = "";
		this.base = "";
		this.properties = [];
		this.position = "";
	}

	return datasrc;
}]);


angular.module('dataSourceModule').
factory('datasrcOuter',['commonUtils','$log',function(commonUtils,$log){
    var datasrcOuter = function(){
        this.datasrcName = "";
        this.datasrcEntry = [];
        this.position = "";
    }


    datasrcOuter.prototype.init = function(){
        this.datasrcName = "";
        this.datasourceEntry = [];   
        this.position = "";
    }
    return datasrcOuter;
}])


angular.module('dataSourceModule').
service('dataSource',['commonUtils','$log','datasrcOuter','datasrc', function(commonUtils,$log,datasrcOuter,datasrc){
	this.fileName = "";
	this.datasources = [];
	this.count = 0;
	this.currentCda = "";
	this.newDtsrcType = true;
	this.nullPropertyPanel = true;

	this.init = function(){
		this.fileName = "";
		this.datasources = [];
		this.count = 0;
		this.currentCda = "";
		this.newDtsrcType = true;
	};

	this.getXml = function(){
		var xml,datasources,dataAccess,columns,output,parameters,query;

		xml =	'<?xml version="1.0" encoding="UTF-8"?>'+
						'<CDADescriptor>';
		datasources = '<DataSources>';
		dataAccess = '';

        $log.log(this.datasources);
		for(var i=0;i<this.datasources.length;i++){
            for(var z=0;z<this.datasources[i].datasrcEntry.length;z++){

            
				var isOutput = false;
                this.datasources[i].datasrcEntry[z].type = 'sql.jndi'
				datasources = datasources + '<Connection id="'+this.datasources[i].datasrcEntry[z].name+'" type="'+this.datasources[i].datasrcEntry[z].type+'">';
				dataAccess = dataAccess+"<DataAccess ";
				columns = "<Columns>";
				parameters = '<Parameters>'
				output = '';

				for(var j=0;j<this.datasources[i].datasrcEntry[z].properties.length;j++){

					switch(this.datasources[i].datasrcEntry[z].properties[j][0]){
						case "driver":{
							datasources = datasources + '<Driver>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</Driver>';
							break;
						}
						case "username":{
							datasources = datasources + '<User>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</User>';
							break;
						}
						case "url":{
							datasources = datasources + '<Url>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</Url></Connection>';
							break;
						}
                        case "database":{
                            datasources = datasources + '<DataConn>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</DataConn>';
                            break;
                        }
						case "jndi":{
							datasources = datasources + '<Jndi>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</Jndi>';
							break;
						}
                        case "password":{
                            datasources = datasources + '<pass>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</pass></Connection>';
                            break;
                        }
						case "accessLevel":{
							dataAccess = dataAccess + 'access = "'+this.datasources[i].datasrcEntry[z].properties[j][3].toLowerCase()+'" ';
							break;
						}
						case "cache":{
							dataAccess = dataAccess + 'cache = "'+this.datasources[i].datasrcEntry[z].properties[j][3]+'" ';
							break;
						}
						case "cacheDuration":{
							dataAccess = dataAccess + 'cacheDuration = "'+this.datasources[i].datasrcEntry[z].properties[j][3]+'" ';
							break;
						}
						case "columns":{
							colLen = this.datasources[i].datasrcEntry[z].properties[j][3].length;
							for(var a=0;a<colLen;a++){
								columns = columns + '<Column idx="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][0]+'">'+
													'<Name>'+this.datasources[i].datasrcEntry[z].properties[j][3][a][1]+'</Name></Column>';
							}	
							break;							
						}
						case "calcColumns":{
							colLen = this.datasources[i].datasrcEntry[z].properties[j][3].length;
							for(var a=0;a<colLen;a++){
								columns = columns + '<CalculatedColumn> <Name>'+this.datasources[i].datasrcEntry[z].properties[j][3][a][0]+'</Name>'+
													'<Formula>'+this.datasources[i].datasrcEntry[z].properties[j][3][a][1]+'</Formula></CalculatedColumn>';
							}	
							columns = columns + '</Columns>';
							break;						
						}
						case "outputOpt":{
							if(this.datasources[i].datasrcEntry[z].properties[j][3].length > 0){
								output = '<Output indexes="'+this.datasources[i].datasrcEntry[z].properties[j][3]+'" ';
								isOutput = true;
							}
							break;
						}
						case "outputMode" :{
							if(isOutput){
								output = output + 'mode="'+this.datasources[i].datasrcEntry[z].properties[j][3].toLowerCase()+'" />';	
							}
							break;
						}
						case "parameters" :{
							paramLen = this.datasources[i].datasrcEntry[z].properties[j][3].length;
							for(var a=0;a<paramLen;a++){
								var isPrivate = this.datasources[i].datasrcEntry[z].properties[j][3][a][3]=="true"? "private" : "public";
								parameters = parameters + '<Parameter access="'+isPrivate+'" default="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][1]+'" '+
												'name="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][0]+'" type="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][2]+'" />';	
							}
							parameters = parameters + '</Parameters>';
							break;
						}
						case "query" :{
							query = '<Query><![CDATA['+this.datasources[i].datasrcEntry[z].properties[j][3]+']]></Query>';
							break;
						}
					}
					//columns = columns + '</Columns>';
				}				
				dataAccess = dataAccess + 'connection="'+this.datasources[i].datasrcEntry[z].name+'" id="'+this.datasources[i].datasrcEntry[z].name+'" type="sql">'+
											columns+output+parameters+query+'</DataAccess>';
            }
		}
		datasources = datasources + '</DataSources>';
		xml = xml + datasources + dataAccess +'</CDADescriptor>';
		//$log.log(xml);

		return xml;
	};

	this.saveConfigToFile = function(){
		
		var xml = this.getXml();
		xml = this.formatXml(xml);
        var param = { "file"  :  this.fileName ,
            "content"  : xml };
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);

        if(jsonData.result =="Success.")
        {
            return true;
        }
        else
        {
            return false;
        }
	}

	this.getConfigFromFile = function(){
		var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ this.fileName,"GET",null);
        $log.debug(jsonData.result);
	    //var xml = $.parseXML(jsonData.result);
		//$log.log(xml2json(xml));
		jsonData = $.xml2json(jsonData.result);
		//$log.log(JSON.stringify(jsonData));
        $log.debug(jsonData);
		this.datasources= [];

		if(jsonData.DataSources.Connection.length== undefined){
			this.setConnection(jsonData.DataSources.Connection,jsonData.DataAccess,0)
            this.count = 1;
		}
		else{
			var l = jsonData.DataSources.Connection.length;
			for(var c=0;c<l;c++)
				this.setConnection(jsonData.DataSources.Connection[c],jsonData.DataAccess[c],c);
            this.count = l;
		}
        //$log.log(this.datasources[0].datasrcEntry[5].properties[0][3]);

		$log.debug(this.datasources);
	}

	this.setConnection = function(connection,dataAccess,indx){
	
		this.newDtsrcType = true;

        var temp;
        var len1 = this.datasources.length;

        if(indx > 0){
            for(var i=0;i<len1;i++){
                if(this.datasources[i].datasrcName == connection.type.substr(0, connection.type.indexOf('.'))){
                    this.newDtsrcType = false;
                    temp = i;
                    //$log.log(temp)
                }    
            }
        }

        var len2= '';

        if(this.newDtsrcType){
            this.datasources[len1] = new datasrcOuter();
            this.datasources[len1].datasrcName = connection.type.substr(0, connection.type.indexOf('.'));
            this.datasources[len1].datasrcEntry = [];
            this.datasources[len1].position = len1;
            //this.datasources[len]datasrcEntry.isFirst = true;
            len2 = 0;

        }
        else{
            len2 = this.datasources[temp].datasrcEntry.length;
            //this.datasources[len].isFirst = false;
            //makeDtsrcEntry(index,arryLen);      
            //len2 = arraylen
            len1 = temp;
        }       

        this.datasources[len1].datasrcEntry[len2] = new datasrc();
        this.datasources[len1].datasrcEntry[len2].id = "dtsrc"+indx;
        this.datasources[len1].datasrcEntry[len2].name = connection.id;
        this.datasources[len1].datasrcEntry[len2].type = connection.type;
		this.datasources[len1].datasrcEntry[len2].base = connection.type.substr(0, connection.type.indexOf('.'));
		this.datasources[len1].datasrcEntry[len2].properties = [];
		this.datasources[len1].datasrcEntry[len2].properties = commonUtils.readJSONFile('component/datasource/'+connection.type+'.properties.json');
		//var self = this;
		for(var i=0;i<this.datasources[len1].datasrcEntry[len2].properties.length;i++){
			
			if(this.datasources[len1].datasrcEntry[len2].properties[i][0] == 'jndi')
				this.datasources[len1].datasrcEntry[len2].properties[i][3] = connection.Jndi;
            else if(this.datasources[len1].datasrcEntry[len2].properties[i][0] == 'password' && connection.pass != undefined){
                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = connection.pass;
            }
                
			switch(this.datasources[len1].datasrcEntry[len2].properties[i][0]){
				case "accessLevel":{
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.access.substr(0,1).toUpperCase()+dataAccess.access.slice(1);
					break;
				}
				case "query":{
					//$log.log(dataAccess.Query);
					//$log.log(JSON.parse(dataAccess.Query));
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.Query;
					break;
				}
				case "parameters":{
					if(dataAccess.Parameters == ""){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Parameters.Parameter.length == undefined){
						len = 1;
					}
					else{
						len = dataAccess.Parameters.Parameter.length;
					}

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<len;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [];
						//this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [1,2,3]
						//$log.log(this.datasources[len1].datasrcEntry[len2].properties[i][3][a])
						if(len == 1){
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Parameters.Parameter.name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Parameters.Parameter.default;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][2] = dataAccess.Parameters.Parameter.type;
							//if(dataAccess.Parameter.Parameter.access == undefined){
							//	dataAccess.Parameter.Parameter.access == 'Public'
							//}
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][3] = (dataAccess.Parameters.Parameter.access == "private" ? "true" : "false");
						}
						else{
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Parameters.Parameter[a].name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Parameters.Parameter[a].default;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][2] = dataAccess.Parameters.Parameter[a].type;
							//if(dataAccess.Parameter.Parameter.access == undefined){
							//	dataAccess.Parameter.Parameter.access == 'Public'
							//}
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][3] = (dataAccess.Parameters.Parameter[a].access == "private" ? "true" : "false");	
						}
					}
					break;
				}
				case "outputOpt":{
					if(dataAccess.Output == undefined){
						output = "";
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else
						output = dataAccess.Output.indexes.split(',');

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<output.length;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3].push(output[a]);		
					}
					break;
				}
				case "outputMode":{
					if(dataAccess.Output == undefined)
						output = 'Include';
					else
						output = dataAccess.Output.mode;

					this.datasources[len1].datasrcEntry[len2].properties[i][3] = output.substr(0,1).toUpperCase()+ output.slice(1);
					break;
				}
				case "columns":{
					//$log.log(dataAccess.Columns);
					if(dataAccess.Columns == "" || dataAccess.Columns.Column == undefined ){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Columns.Column.length == 0){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Columns.Column.length == undefined)
						len = 1;
					else
						len = dataAccess.Columns.Column.length;

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<len;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [];
						if(len == 1){
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column.idx);
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column.Name);
						}
						else{
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column[a].idx);
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column[a].Name);
						}
					}
					break;
				}
				case "calcColumns":{
					if(dataAccess.Columns == "" || dataAccess.Columns.CalculatedColumn == undefined ){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Columns.CalculatedColumn.length == 0){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;	
					}
					else if(dataAccess.Columns.CalculatedColumn.length == undefined)
						len = 1;
					else
						len = dataAccess.Columns.CalculatedColumn.length;

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<len;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [];
                        //$log.log(this.datasources[len1].datasrcEntry[len2].properties[i][3][a]);
            
						if(len == 1){
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Columns.CalculatedColumn.Name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Columns.CalculatedColumn.Formula;
						}
						else{
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Columns.CalculatedColumn[a].Name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Columns.CalculatedColumn[a].Formula;
						}
					}
                    //$log.log(this.datasources[len1].datasrcEntry[len2].properties[i][3]);
					break;
				}
				case "cache":{
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.cache;
					break;
				}
				case "cacheDuration" :{
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.cacheDuration;
				}
			}
		}
	}

	this.formatXml = function(xml){
	    var formatted = '';
	    var reg = /(>)(<)(\/*)/g;
	    xml = xml.replace(reg, '$1\r\n$2$3');
	    var pad = 0;
	    jQuery.each(xml.split('\r\n'), function(index, node) {
	        var indent = 0;
	        if (node.match( /.+<\/\w[^>]*>$/ )) {
	            indent = 0;
	        } else if (node.match( /^<\/\w/ )) {
	            if (pad != 0) {
	                pad -= 1;
	            }
	        } else if (node.match( /^<\w[^>]*[^\/]>.*$/ )) {
	            indent = 1;
	        } else {
	            indent = 0;
	        }
	 
	        var padding = '';
	        for (var i = 0; i < pad; i++) {
	            padding += '  ';
	        }
	 
	        formatted += padding + node + '\r\n';
	        pad += indent;
	    });
	    return formatted;
	}

	this.blankPropertiesPanel = function(){
		this.nullPropertyPanel = true;
		$('#propertiesPanel').html('');
		$('#propertiesPanelSave').html('');
	}

    this.changePosition = function(index){
        //$log.log(index);
        var len = this.datasources.length-1;
        for(var i=len;i>index;i--){
            //$log.log(i);
            this.datasources[i].position = i-1;
        }
    }

}]);

angular.module('dataSourceModule').
directive('datasrcComp',['dataSource','datasrc','commonUtils','$log','$compile','$timeout','Messages',function(dataSource,datasrc,commonUtils,$log,$compile,$timeout,Messages){
	return{
		restrict : 'E',
		scope : {
			'obj' : '=',
			'position' : '@'
			
		},

		link: function(scope,element,attrs){
			//scope.datasourceType = scope.obj.type.substr(0, scope.obj.type.indexOf('.')); 
            $log.debug("this is datasrc comp")
            $log.log(scope.obj)
            //$log.log(scope.obj);
			scope.dtsrcProperties = function(){
                
                
                if(element.children().hasClass('select')){
                    return;
                }
                else{
                    $('.row-datasource').removeClass('select');
                    element.children().addClass('select');
                    //console.log(element.children().hasClass('select'));
                }
                
                $log.log("datasrc comp");
                $('.properties').show();
                //$('.row-datasource').removeClass('select');
                $(this).addClass('select');
                $('#currentDtsrc').text(scope.obj.name)
				dataSource.currentCda = scope.obj.id;
				scope.name = scope.obj.name;
                scope.dbtype='';
                scope.dbuser='';
                scope.dbhost='';
                scope.dbport='';
                scope.dbname='';
				scope.properties = [];
				scope.properties = scope.obj.properties;
				$('#propertiesPanel').html('');

				var html = '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Name</div><div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input id="name" type="text" class="form-control input-sm" ng-model="name" title={{name}}/></div></div>'
				$('#propertiesPanel').append($compile(html)(scope));

				for(var i=0;i<scope.properties.length;i++)
						commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][5],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][6],"propertiesPanel",scope);

				$('#propertiesPanelSave').html($compile('<button class="btn" id="saveButton" ng-click="saveData()" ng-disabled="disablePSave"><i class="glyphicon glyphicon-floppy-disk">&nbsp;</i></button>')(scope));
	
				dataSource.nullPropertyPanel = false;;
			}

			scope.saveData = function(){
				//$log.log(scope.name)
                $log.log(scope.obj.properties)
				var regexp = /^[a-zA-Z0-9-_\.]+$/;
				if(scope.name.search(regexp) == -1 && scope.name != undefined && scope.name.length > 0){
					alert("Invalid datasource name. It only contain Alphanumeric character and special _ and . characters.");
					return;
				}

				scope.obj.name = scope.name;
				for(var i=0;i<scope.obj.properties.length;i++){
					if(scope.obj.properties[i][2] == 'switch' || scope.obj.properties[i][2] == 'combo'){
                        temp = $('#'+scope.obj.properties[i][0]).bootstrapSwitch('state');
                        scope[scope.obj.properties[i][0]] = temp;
                    }
					scope.obj.properties[i][3] = scope[scope.obj.properties[i][0]];
                    //$log.log(scope.obj.properties[i][0]+" "+scope.obj.properties[i][3]);
				}
				commonUtils.savedFlag = false;
				commonUtils.propertiesSaved = true;
				//$log.log(scope.obj.properties);
                scope.disablePSave = true;
                commonUtils.notification(Messages.onPropertiesSavedNotification);
                $timeout(function(){
                    scope.disablePSave = false;
                },4000)
			}
			
			scope.removeDatasource = function(id){
                $log.debug("remove datasource");
         
                var temp = [];
                var datasrcClone = [];
                for(var i=0;i<dataSource.datasources.length;i++){
                    var datasrcCompClone = [];
                    for(var j=0;j<dataSource.datasources[i].datasrcEntry.length;j++){
                        if(dataSource.datasources[i].datasrcEntry[j].id != id){
                            datasrcCompClone.push(dataSource.datasources[i].datasrcEntry[j]);
                        }    
                    }
                    dataSource.datasources[i].datasrcEntry = datasrcCompClone;
                    if(dataSource.datasources[i].datasrcEntry.length > 0)
                        datasrcClone.push(dataSource.datasources[i]);
                    else
                        dataSource.changePosition(i);
                }

                dataSource.datasources = datasrcClone;
                //$log.log(dataSource.datasources);				
                
				//$log.log(dataSource.datasources[i]);
				
				if(dataSource.datasources.length == 0)
					commonUtils.isNull = true;

				dataSource.blankPropertiesPanel();
                $('.properties').hide();
				commonUtils.savedFlag = false;
			}

			scope.moveUp = function(id){
				var index1,index2;
                //$log.log(id);
                //$log.log(dataSource.datasources)
				for(var i=0;i<dataSource.datasources.length;i++){
                    for(var j=0;j<dataSource.datasources[i].datasrcEntry.length;j++){
                        if(dataSource.datasources[i].datasrcEntry[j].id == id){
                            index1 = i;
                            index2 = j;
                        }    
                    }
				}
                //$log.log(index1+" "+index2)
				if(index2 != 0){
					var temp = dataSource.datasources[index1].datasrcEntry[index2];
					dataSource.datasources[index1].datasrcEntry[index2] = dataSource.datasources[index1].datasrcEntry[index2-1];
					dataSource.datasources[index1].datasrcEntry[index2-1] = temp;
				}
				commonUtils.savedFlag = false;
				$log.debug(dataSource.datasources);
			};

			scope.moveDown = function(id){
				var index1,index2;
				//var len = dataSource.datasources.length;
				for(var i=0;i<dataSource.datasources.length;i++){
                    for(var j=0;j<dataSource.datasources[i].datasrcEntry.length;j++){
                        if(dataSource.datasources[i].datasrcEntry[j].id == id){
                            index1 = i;
                            index2 = j;
                        }    
                    }
                }
                var len = dataSource.datasources[index1].datasrcEntry.length;
				if(index2 < len-1){
					var temp = dataSource.datasources[index1].datasrcEntry[index2];
					dataSource.datasources[index1].datasrcEntry[index2] = dataSource.datasources[index1].datasrcEntry[index2+1];
					dataSource.datasources[index1].datasrcEntry[index2+1] = temp;
				}
				commonUtils.savedFlag = false;
				$log.debug(dataSource.datasources);
			};
			

			scope.dtsrcProperties();

            var len = dataSource.datasources.length;
			var html = '<div class="row-datasource select"><div class="paddingSide0 datasrcComp panel-heading clearfix " ng-click="dtsrcProperties()">'+
                            '<!--<span class="col-lg-4 col-md-4">{{obj.type}}</span>--><span class="col-lg-4 col-md-4 textoverflow" title={{obj.name}}>{{obj.name}}</span>'+
                            '<div class="btn-group pull-right drcComp" >'+
                                //'<button class="btn btn12 btn-xs" ng-click="setting(obj.id)"><i class="glyphicon glyphicon-cog"></i></button>'+
                                '<button class="btn btn12 btn-xs" ng-click="moveUp(obj.id)"><i class="glyphicon glyphicon-arrow-up"></i></button>'+
                                '<button class="btn btn12 btn-xs" ng-click="moveDown(obj.id)"><i class="glyphicon glyphicon-arrow-down"></i></button>'+
                                '<button class="btn btn12 btn-xs" ng-click="removeDatasource(obj.id)"><i class="glyphicon glyphicon-remove"></i></button>'+
                            '</div>'+
                        '</div></div>';

			element.html(html);
            $compile(element.contents())(scope);

            $timeout(function(){
                commonUtils.safeApply(scope,function(){});
            },0)
        
		}
	}
}]);


angular.module('dataSourceModule').
directive('datasourceOuter',['dataSource','$log','$compile','commonUtils','$timeout',function(dataSource,$log,$compile,commonUtils,$timeout){
    return{
        restrict : 'E',
        scope:{
            pos : "@",
            datasrcobj : "="
        },
        transclude : true,
        //template:   '<div>asd</div>'
                    //'<datasrc-comp ng-repeat="datasourceCmp in datasourceOuterCtrl.dataSource.datasources" position={{datasourceCmp.position}} obj=datasourceCmp ></datasrc-comp>',
        controller : function($scope,$element,$attrs){
            var vm = this;
            vm.dataSource = dataSource;
            $log.debug("This is datasource directive")
        },
        link:function(scope,element){
            $log.debug("this is datasource outer");


            scope.popup = function(){
                $log.log("popup ");
                var pos = scope.datasrcobj.position
                if($('#heading'+pos).hasClass('active')){
                    $('#heading'+pos).removeClass('active');
                    $('#heading'+pos).find('.glyphicon').removeClass('glyphicon-minus').addClass('glyphicon-plus');
                }
                else{
                    $('#heading'+pos).addClass('active');
                    $('#heading'+pos).find('.glyphicon').removeClass('glyphicon-plus').addClass('glyphicon-minus');
                    //.find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');   
                }
            }

            var html='';
            //$log.log(commonUtils.isFirst)           
            //html = html+'<div class="dtsrcPanel panel-heading clearfix">asd</div>';
            html = html +   '<div class="panel-heading active" role="tab" id="heading{{datasrcobj.position}}" data-toggle="collapse" href="#datasourceContent{{datasrcobj.position}}" aria-expanded="true" aria-controls="datasourceContent{{datasrcobj.position}}" ng-click="popup()">'+
                                '<h4 class="panel-title">'+
                                    '<a role="button" ><i class="glyphicon glyphicon-minus"></i>{{datasrcobj.datasrcName}} Datasources</a>'+
                                '</h4>'+
                            '</div>'+
                            '<div id="datasourceContent{{datasrcobj.position}}" class="panel-collapse collapse in " role="tabpanel" aria-labelledby="headingOne">'+
                                '<datasrc-comp ng-repeat="datasourceCmp in datasrcobj.datasrcEntry" position={{pos}} obj=datasourceCmp ></datasrc-comp>'+
                            '</div>'  

            //$log.log(data)
            //html = html + 
            element.html(html);
            $compile(element.contents())(scope);

            var pos = scope.datasrcobj.position;
        }
    }
}])
angular.module('dataSourceModule').
directive('datasource',['dataSource','$log',function(dataSource,$log){
	return{
		restrict : 'E',
		scope : {},
		transclude : true,
		bindtoController:true,
        controllerAs :'datasourceCtrl',
		template : '<datasource-outer ng-repeat="datasourceCmp in datasourceCtrl.dataSource.datasources" pos={{datasourceCmp.position}} datasrcobj=datasourceCmp></datasource-outer>',
		controller : function($scope,$element,$attrs){
			var vm = this;
			vm.dataSource = dataSource;
			$log.debug("This is datasource directive")
		},
		link : function(scope){
			$log.debug(dataSource.datasources);
		}
	}
}]);