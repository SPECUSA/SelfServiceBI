function Label(){};
Label.prototype = new SSBBaseComponent();
Label.prototype = {
    chartType : "Label",
    
    init: function (chartID,data,htmlObj,chartProperties) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.properties =prepareChartDefination(chartProperties,htmlObj);
        //console.log(this.properties);
        this.preExecution();
    },
    render: function () {
        //this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        if(this.data.resultset.length > 1){
            alert("Datasource should be single valued. It has multiple value");
            return;
        }

        var titleFontSize,valFontSize;
        titleFontSize = this.getSize(this.properties["titleFontSize"]) - 6;
        valFontSize = this.getSize(this.properties["valueFontSize"]);


        var val = this.data.resultset[0];
        //val = val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

        var prefix='',postfix='';
        if(this.properties["measure"] != "None" || this.properties["newMeasure"]){
            var measure = this.properties["measure"];
            var prefix='',postfix='';
            if(this.properties["newMeasure"] == false){
                if(measure == "Dollar")
                    prefix = '$';
                
                else if(measure == "Pound")
                    prefix = "&pound;";
                
                else if(measure == "Euro")
                    prefix = "&#8364;";
                
                else if(measure == "Rupee")
                    prefix = "&#8377;";    
            }
            else if(this.properties["addMeasure"].length >0)
                postfix = this.properties["addMeasure"] ;
        }

        var html = '';
        var head =  '<div class="form-inline" style="height:'+this.properties["height"]+'px;widht:'+this.properties["width"]+'px;text-align:'+this.properties["align"]+';color:#666;">';
        var title = '<div style="font-size:'+titleFontSize+'px;font-family:unset;" >'+this.properties["title"]+'</div>';
        var titleInline = '<div style="font-size:'+titleFontSize+'px;font-family:unset;display:inline-block;" >'+this.properties["title"]+'&nbsp;</div>'
        var value = '<div style="font-size:36px;font-family:times new roman;">'+prefix+' '+val+' '+postfix+'</div>';
        var valueInline = '<div style="font-size:36px;font-family:times new roman;display:inline-block;">'+prefix+' '+val+' '+postfix+'&nbsp;</div>'
        var endHead = '</div>';

        switch(this.properties["position"]){
            case 'Stacked Title-Value':
                html = head+title+value+endHead;
                break;

            case 'Stacked Value-Title':
                html = head+value+title+endHead;
                break;

            case 'Inline Title-Value':
                html = head+titleInline+valueInline+endHead;
                break;

            case 'Inline Value-Title':
                html = head+valueInline+titleInline+endHead;
                break;
        }

        /*
        if(this.properties["measure"]== "none" && this.properties["newMeasure"] == false)
            html = html +'<div style="font-size:'+valFontSize+'px;text-align:'+this.properties["align"]+';font-family:georgia;">'+val+'</div></div>'
        
        else{
            var measure = this.properties["measure"];
            var prefix='',postfix='';
            if(this.properties["newMeasure"] == false){
                if(measure == "dollar")
                    prefix = '$';
                
                else if(measure == "pound")
                    prefix = "&pound;";
                
                else if(measure == "euro")
                    prefix = "&#8364;";
                
                else if(measure == "rupee")
                    prefix = "&#8377;";    
            }
            else if(this.properties["addMeasure"].length >0)
                postfix = this.properties["addMeasure"] ;
            
                
            
            html = html + '<div style="font-size:36px;text-align:'+this.properties["align"]+';font-family:georgia;">'+prefix+' '+val+' '+postfix+'</div>'+
                    '</div>';
        }
        */            
        //console.log(this.properties["canvas"]);
        $('#'+this.properties["canvas"]).append(html);
        this.postExecution();        
    },   

    getSize : function(string){
        if(string == "Small")
            return 26;
        else if(string == "Medium")
            return 32;
        else if(string == "Large")
            return 38;
    },
    preExecution: function () {
        this.render();
        //console.log("CCCarea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCarea : postExecution");
    } 
}

