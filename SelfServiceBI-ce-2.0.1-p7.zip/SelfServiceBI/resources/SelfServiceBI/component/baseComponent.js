var SSBBaseComponent = function(){ }
SSBBaseComponent.prototype = {
    chartID: "", // componentName;
    data : "",
    htmlObj : "",
    chart : Object(),
    chartType : "",
    chartDefination : "",
    
    init: function () {
        this.preExecution();        
    },
    render: function () {

        this.postExecution();
    },
    preExecution: function () {

        this.render();

    },
    postExecution: function () {}
};

var filterBaseComponent = function(){}	
filterBaseComponent.prototype = {
	width : "",
	init : function(){},
}