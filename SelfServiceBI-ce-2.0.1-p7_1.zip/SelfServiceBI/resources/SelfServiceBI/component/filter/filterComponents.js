function textbox(){};
textbox.prototype = new filterBaseComponent();
textbox.prototype = {
	width : 80,
	init : function(){
		var component =  "<label>{{filterconfig.filterCaption}}</label><br /><input tabindex='1' id='{{filterconfig.filterId}}' class='{{filterconfig.filterId}} form-control input-sm' ng-model='filterconfig.filterVal' type='text' style='width:{{filterconfig.filterWidth}}px;'/>";
        return component;
	}
}

function combobox(){};
combobox.prototype = new filterBaseComponent();
combobox.prototype = {
	width : 80,
	init : function(datasourceArray){
		var option = '';
		
        for (i=0;i<datasourceArray.length;i++){
           option += '<option value="'+ datasourceArray[i] + '">' + datasourceArray[i] + '</option>';
        }
        return "<label>{{filterconfig.filterCaption}}</label><br/><select tabindex='1' id='{{filterconfig.filterId}}' class='{{filterconfig.filterId}} form-control input-sm' ng-model='filterconfig.filterVal' style='width:{{filterconfig.filterWidth}}px;'>"+option+"</select>";
	}
}

function multiSelect(){};
multiSelect.prototype = new filterBaseComponent();
multiSelect.prototype = {
	width : 80,
	init : function(){
		var options = '';
	    var option = '<label>{{filterconfig.filterCaption}}</label><br/><dropdown-multiselect selected-options="filterconfig.filterVal" datasource="filterconfig.datasourceArray" idd="filterconfig.filterName"></dropdown-multiselect>'
        return option;
	}
}

function datePicker(){};
datePicker.prototype = new filterBaseComponent();
datePicker.prototype = {
	width : 100,
	init : function(datasourceArray){

		var dateComponent = "<label>{{filterconfig.filterCaption}}</label><br />"+
						"<div class='input-group'>"+
	                       	//"<span class='add-on input-group-addon'><i class='glyphicon glyphicon-calendar'></i></span>"+
							"<input date-range-picker id='{{filterconfig.filterId}}' class='form-control input-sm date-picker {{filterconfig.filterId}}' options='{locale: {format: \"YYYY-MM-DD\"}}' type='text' ng-model='filterconfig.filterVal' options='opts' style='width:156px;' required/>"
							 
                		"</div>";

        return dateComponent;
	} 
}