//---------------------------------------------------- HIGHCHART  ----------------------------------------

function generateHighChart(htmlObj,chartProp){
    Highcharts.setOptions({
        lang : {
            thousandsSep : ","
        }
    })
    Highcharts.chart(htmlObj,chartProp);
}

function HighChart(){};
HighChart.prototype = new SSBBaseComponent();
HighChart.prototype = {
    init : function(visualization,data,htmlObj,chartProperties,editor,listenerPins){
        this.visualization = visualization;
        this.data = data;
        //this.htmlObj = htmlObj;
        this.chartProperties = chartProperties;
        this.chartProp = editor;
        this.listenerPins = listenerPins;
        
        
        if(this.data.resultset && this.data.resultset.length==0){
            $("#"+htmlObj).html("No data found");
            return;
        }        

        
        this.render(htmlObj,this.data,null);
    
     },
     render: function (htmlObj,data,serName) {
        var self = this;
        var series = [];
        var categories = [];
        var pins = [];        

        
        if(this.visualization.name=="Pie" || this.visualization.name=="Donut"){

            /*amar-2017-feb-01*/
            if(data.metadata.length == 2 || data.metadata.length == 3){
            for(var i=0;i<data.resultset.length;i++){
                if(data.resultset[i].length == 3){
                    series.push({"name": data.resultset[i][0]+"-"+data.resultset[i][1], "y":data.resultset[i][2]});
                }else if(data.resultset[i].length == 2){
                    series.push({"name": data.resultset[i][0], "y":data.resultset[i][1]}) 
                }
            }
            /*amar-2017-feb-01*/
            this.chartProp.series = [{
                data : series
            }];
            
            this.chartProp.plotOptions == void 0 && (this.chartProp.plotOptions = {});
            this.chartProp.plotOptions.pie == void 0 && (this.chartProp.plotOptions.pie = {})
            this.chartProp.plotOptions.pie.cursor = 'pointer';
            this.chartProp.plotOptions.pie.point = {
                events: {
                    click: function () {
                        chartClick(self.listenerPins,this.name);
                    }
                }
            } 
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }
        else if(this.visualization.name=="Columns" || this.visualization.name=="Line_Column" || this.visualization.name=="Area_Column"){
            if(data.metadata.length == 3){
            var s1={},s2={};
            s1 = {
                name : data.metadata[1].colLabel || data.metadata[1].colName,
                type: "column",
                yAxis: 1
            }
            
            if(this.visualization.name=="Columns")
                s2 = {
                    type : "column"
                }
            else if(this.visualization.name=="Line_Column")
                s2 = {
                    type: "line"
                }
            
            else if(this.visualization.name=="Area_Column")
                s2 = {
                    type : "area"
                }
            
            
            s1.data = [];
            s2.name = data.metadata[2].colLabel || data.metadata[2].colName;
            s2.data = [];
            var len = data.resultset.length;
            for(var i=0;i<len;i++){
                categories.push(data.resultset[i][0]);
                s1.data.push(data.resultset[i][1]);
                s2.data.push(data.resultset[i][2]);
            }

            this.chartProp.series = [s1,s2];
            this.chartProp.xAxis.categories =  categories; 


            this.chartProp.plotOptions == void 0 && (this.chartProp.plotOptions = {});
            this.chartProp.plotOptions.series == void 0 && (this.chartProp.plotOptions.series = {});

            this.chartProp.plotOptions.series.cursor = 'pointer';
            this.chartProp.plotOptions.series.point = {
                events: {
                    click: function () {
                        chartClick(self.listenerPins,this.category);
                    }
                }
            }
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }
        else if(this.visualization.name== "Bubble"){
            if(data.metadata.length == 5 && data.metadata[2].colType == "Numeric" && data.metadata[3].colType == "Numeric" && data.metadata[4].colType == "Numeric"){
                //console.log(data);
                 var s1={},s2={};
                s1.data = [];
                 s2.data = [];
        
                var temp = {};
                for(var i=0;i<data.resultset.length;i++){
                    
                    if(i!=0)
                        if(categories.indexOf(data.resultset[i][1]) == -1)
                            categories.push(data.resultset[i][1])
                    
                    var idx = categories.indexOf(data.resultset[i][1]);

                    if(temp[data.resultset[i][0]]==void 0)
                        temp[data.resultset[i][0]] = [];

                    //temp[data.resultset[i][0]][idx] = [data.resultset[i][2],data.resultset[i][3],data.resultset[i][4]];
                    var objj = {
                        x : data.resultset[i][2],
                        y : data.resultset[i][3],
                        z : data.resultset[i][4],
                        name : data.resultset[i][1]
                    }
                    //temp[data.resultset[i][0]].push([data.resultset[i][2],data.resultset[i][3],data.resultset[i][4],data.resultset[i][1]]);
                    temp[data.resultset[i][0]].push(objj);

                    hasSeries = true;
                }
                                   
                for(obj in temp){
                    var tempObj = {};
                    tempObj.name = obj;
                    
                    temp[obj] = parseArray(temp[obj]);
                    //if(temp[obj] != null)
                    tempObj.data = temp[obj];
                    series.push(tempObj);
                }
                serName != void 0 && (this.chartProp.title.text = serName);
                this.chartProp.series = series;
                this.chartProp.xAxis.categories = categories;
                this.chartProp.tooltip.pointFormat = "<tr><th colspan='2'><h3>{point.name}</h3></th></tr><tr><th>"+data.metadata[2].colName+" : </th><td>{point.x}</td></tr><tr><th>"+data.metadata[3].colName+" : </th><td>{point.y}</td></tr><tr><th>"+data.metadata[4].colName+" : </th><td>{point.z}</td></tr>";
                
             }

            else if(data.metadata.length == 4 && data.metadata[1].colType == "Numeric" && data.metadata[2].colType == "Numeric" && data.metadata[3].colType == "Numeric"){
                console.log(data);
                var s1={
                    name : data.metadata[0].colLabel || data.metadata[0].colName,
                };

                s1.data = [];
                var len = data.resultset.length;
                for(var i=0;i<len;i++){

                    categories.push(data.resultset[i][0]);
                    var objj = {
                        x : data.resultset[i][1],
                        y : data.resultset[i][2],
                        z : data.resultset[i][3],
                        name : data.resultset[i][0]
                    }
                    s1.data.push(objj);

                }
                this.chartProp.series = [s1];
                this.chartProp.xAxis.categories =  categories; 
                this.chartProp.tooltip.pointFormat = "<tr><th colspan='2'><h3>{point.name}</h3></th></tr><tr><th>"+data.metadata[1].colName+" : </th><td>{point.x}</td></tr><tr><th>"+data.metadata[2].colName+" : </th><td>{point.y}</td></tr><tr><th>"+data.metadata[3].colName+" : </th><td>{point.z}</td></tr>";
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }

        else if(this.visualization.name== "HeatMap"){

            var xdata = [];
            var ydata = [];

            if(data.metadata.length == 3  && data.metadata[0].colType == "String" && data.metadata[1].colType == "String" && data.metadata[2].colType == "Numeric"){
                var s1={
                    name : data.metadata[0].colName,
                };
                s1.data = [];
                var len = data.resultset.length;
                for(var i=0;i<len;i++){
                    var elementx = data.resultset[i][0];
                    if(xdata.indexOf(elementx)===-1){
                        xdata.push(elementx);
                    }
                    var elementy = data.resultset[i][1];
                    if(ydata.indexOf(elementy)===-1){
                        ydata.push(elementy);
                    }

                    var x = xdata.indexOf(elementx);
                    var y = ydata.indexOf(elementy);
                    var z = data.resultset[i][2];
                    s1.data.push([x,y,z]);
                }

                this.chartProp.series = [s1];
                this.chartProp.xAxis.max = xdata.length - 1;
                this.chartProp.xAxis.categories = xdata;
                this.chartProp.yAxis.max = ydata.length - 1;
                this.chartProp.yAxis.categories = ydata;
                this.chartProp.tooltip.formatter = function () {
                    return data.metadata[0].colName +' <b> : ' + this.series.xAxis.categories[this.point.x] + '</b> <br> '+ data.metadata[1].colName + '<b> : ' + this.series.yAxis.categories[this.point.y] + '</b><br>' + data.metadata[2].colName + ' : <b>' +
                    this.point.value + ' </b>';
                }
                //console.log(this.chartProp);
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }

        else if(this.visualization.name=="Treemap"){
            
            var colors = ["#f68a89","#fcc78e","#53c0b7","#4cb1e4","#6978cd","#e8729b","#748fb1","#fd9d73"];
            var clen = colors.length;
            var s1 = {
                type: "treemap",
                layoutAlgorithm: 'squarified'
            };

            s1.data = [];
            if(data.metadata.length == 2 && data.metadata[0].colType == "String" && data.metadata[1].colType == "Numeric"){
                var len = data.resultset.length;
                for(var i=0;i<len;i++){
                    var c = (i)%clen;
                    var objj = {
                        value : data.resultset[i][1],
                        name : data.resultset[i][0],
                        color : colors[c]
                    }
                    s1.data.push(objj);
                }
                this.chartProp.series[0].data = s1.data;
                //console.log(this.chartProp);
            }
            else if(data.metadata.length == 3 && data.metadata[0].colType == "String" && data.metadata[1].colType == "String" && data.metadata[2].colType == "Numeric"){
                var temp = [];
                var tempParent = {};
                for(var i=0;i<data.resultset.length;i++){
                    if(data.resultset[i].length == 3){
                        if(i!=0)
                            if(categories.indexOf(data.resultset[i][1]) == -1)
                                categories.push(data.resultset[i][1])

                        if(temp[data.resultset[i][0]]==void 0)
                            tempParent[data.resultset[i][0]] = [];
                        
                        var objj = {
                            name : data.resultset[i][1],
                            parent : data.resultset[i][0],
                            value : data.resultset[i][2]
                        }
                        temp.push(objj);
                        hasSeries = true;
                    }
                }
                var colorCode = 0;
                for(obj in tempParent){ 
                    var c = (colorCode)%clen;
                    var tempObj = {
                        id : obj,
                        name : obj,
                        color : colors[c]
                    }
                    temp.push(tempObj);
                    colorCode = colorCode + 1;
                }
                this.chartProp.series[0].data = temp;
                this.chartProp.plotOptions.treemap.colorByPoint = "";
            }
            
            else if(data.metadata.length == 4 && data.metadata[0].colType == "String" && data.metadata[1].colType == "String" && data.metadata[2].colType == "String" && data.metadata[3].colType == "Numeric"){
                var temp = [];
                var tempParent = {};
                var parent = {};
                for(var i=0;i<data.resultset.length;i++){
                    if(data.resultset[i].length == 4){

                        if(temp[data.resultset[i][0]]==void 0) 
                            parent[data.resultset[i][0]] = [];

                        if(tempParent[data.resultset[i][1]]==void 0){
                            tempParent[data.resultset[i][1]] = [];
                            var objj = {
                                name : data.resultset[i][1],
                                parent : data.resultset[i][0],
                                id : data.resultset[i][1]
                            }
                            temp.push(objj);
                        }

                        var objj = {
                            name : data.resultset[i][2],
                            parent : data.resultset[i][1],
                            value : data.resultset[i][3]
                        }
                        temp.push(objj);

                        hasSeries = true;
                    }
                }
                var colorCode = 0;
                for(obj in parent){ 
                    var c = (colorCode)%clen;
                    var tempObj = {
                        id : obj,
                        name : obj,
                        color : colors[c]
                    }
                    temp.push(tempObj);
                    colorCode = colorCode + 1;
                }
                
                this.chartProp.series[0].data = temp;
                this.chartProp.plotOptions.treemap.colorByPoint = "";
                //console.log(this.chartProp);
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }

        else if(this.visualization.name== "SolidGauge"){
            if(data.metadata.length == 2 && data.metadata[0].colType == "String" && data.metadata[1].colType == "Numeric")
            {
                //this.isValidData = true;
                var sum=0;
                var len = data.resultset.length;
                for(var i=0;i<len;i++){    
                    sum+=data.resultset[i][1];    
                }

                var max = Math.round((sum*5)/4);
                if(this.chartProp.yAxis.max == 0){
                    this.chartProp.yAxis.max = max;
                }

                sum = Math.round(sum);
                this.chartProp.yAxis.tickPositioner = function() {
                    return [this.min, this.max];
                }
                var t1 = Math.round((max*60)/100);
                var t2 = Math.round(t1 + ((max*20)/100));
                //var temp = Math.round((max*10)/100);

                this.chartProp.series[0].data = [sum];
                //this.chartProp.yAxis.tickPositions = [0,temp*2,temp*4,temp*6,temp*8,max];
                this.chartProp.plotBands = [];
                this.chartProp.yAxis.plotBands = [{
                    from: 0,
                    to: t1,
                    color: "#55BF3B",
                    thickness: "50%"
                }, {
                    from: t1,
                    to: t2,
                    color: "#DDDF0D",
                    thickness: "50%"
                }, {
                    from: t2,
                    to: max,
                    color: "#DF5353",
                    thickness: "50%"
                }];
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }

        else if(this.visualization.name=="ColumnRange"){
            if(data.metadata.length == 3 && data.metadata[0].colType == "String" && data.metadata[1].colType == "Numeric" && data.metadata[2].colType == "Numeric"){
            var s1 = {};

            s1.data = [];
            var len = data.resultset.length;
            for(var i=0;i<len;i++){
                categories.push(data.resultset[i][0]);
                s1.data.push([data.resultset[i][1],data.resultset[i][2]]);
                
            }

            this.chartProp.series = [s1];
            this.chartProp.xAxis.categories =  categories; 

            this.chartProp.plotOptions == void 0 && (this.chartProp.plotOptions = {});
            this.chartProp.plotOptions.series == void 0 && (this.chartProp.plotOptions.series = {});
            this.chartProp.plotOptions.series = {
                cursor : 'pointer',
                point : {
                    events: {
                        click: function () {
                            chartClick(self.listenerPins,this.category);
                        }
                    } 
                }
            };
            }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }
        else{
            if(data.metadata.length == 2 || data.metadata.length == 3){
            var temp = {};
            for(var i=0;i<data.resultset.length;i++){
                if(data.resultset[i].length == 3){
                    if(categories.indexOf(data.resultset[i][1]) == -1)
                        categories.push(data.resultset[i][1])
                    
                    var idx = categories.indexOf(data.resultset[i][1]);

                    if(temp[data.resultset[i][0]]==void 0)
                        temp[data.resultset[i][0]] = [];
                    
                    temp[data.resultset[i][0]][idx] = data.resultset[i][2];

                    hasSeries = true;
                }
                else{
                    if(i === 0){
                        var series = [{"data":[]}];
                        serName != void 0 && (series[0].name = serName);
                    }
                        
                    categories.push(data.resultset[i][0]);
                    series[0].data.push(Number(data.resultset[i][1]));
                }
            }

            for(obj in temp){
                var tempObj = {};
                tempObj.name = obj;
                
                temp[obj] = parseArray(temp[obj]);
                tempObj.data = temp[obj];
                series.push(tempObj);
            }
            serName != void 0 && (this.chartProp.title.text = serName);
            this.chartProp.series = series;
            this.chartProp.xAxis.categories = categories;

            this.chartProp.plotOptions == void 0 && (this.chartProp.plotOptions = {});
            this.chartProp.plotOptions.series == void 0 && (this.chartProp.plotOptions.series = {});
            this.chartProp.plotOptions.series.cursor = 'pointer';
            this.chartProp.plotOptions.series.point = {
                events: {
                    click: function () {
                        chartClick(self.listenerPins,this.category);
                    }
                }
            }  
        }
            else
            {
                $("#" + htmlObj).html("Please provide proper data to render chart").css('text-align', "center");
                return;
            }
        }
        
        generateHighChart(htmlObj, this.chartProp);
        
        // this.postExecution();        
    },     
    preExecution: function () {
        //this.render();
    },
    postExecution: function () {
    } 
}


var parsemapData = function(res,initial){
    var data = [];
    for(var i=0;i<res.resultset.length;i++){
        var code,value;
        // if(isLatLong){
        //     code = getCountryCode(res.resultset[i][0],res.resultset[i][1]);
        //     if(code=="error")
        //         return code;
        //     value = res.resultset[i][2]
        // }
        code = initial.length != 0 ? initial+"-"+res.resultset[i][0] : res.resultset[i][0] 
        code = code.toLowerCase();
        value = res.resultset[i][1]
    
            
        var tempObj = {
            code : code,
            value : value
        }
        data.push(tempObj);
    }

    return data;
}