function prepareChartDefination (properties,htmlObj,chartType){
    properties.canvas = htmlObj;
    properties.width = $("#"+htmlObj).width();
    
    if(chartType != 'CCCBullet')
        properties.height =  $("#"+htmlObj).height();

    return properties;

}

function CCCArea(){};
CCCArea.prototype = new SSBBaseComponent();
CCCArea.prototype = {
    chartType : "CCCarea",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;

        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCarea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCarea : postExecution");
    } 
}



function CCCBar(){};
CCCBar.prototype = new SSBBaseComponent();
CCCBar.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {


        //console.log(chartProperties);
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();

        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}
function CCCStackedBar(){};
CCCStackedBar.prototype = new SSBBaseComponent();
CCCStackedBar.prototype = {
    chartType : "CCCStackedBar",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}
function CCCStackedBar100(){};
CCCStackedBar100.prototype = new SSBBaseComponent();
CCCStackedBar100.prototype = {
    chartType : "CCCStackedBar100",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}
function CCCBar_with_Line(){};
CCCBar_with_Line.prototype = new SSBBaseComponent();
CCCBar_with_Line.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }

        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();

        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    }
}

function CCCBoxplot(){};
CCCBoxplot.prototype = new SSBBaseComponent();
CCCBoxplot.prototype = {
    chartType : "CCCboxplot",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BoxplotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCboxplot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCboxplot : postExecution");
    } 
}

function CCCBullet(){};
CCCBullet.prototype = new SSBBaseComponent();
CCCBullet.prototype = {
    chartType : "CCCbullet",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj,"CCCBullet");
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }      
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }  
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BulletChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCbullet : preExecution");
    },
    postExecution: function () {
        //console.log("CCCbullet : postExecution");
    } 
}

function CCCDot(){};
CCCDot.prototype = new SSBBaseComponent();
CCCDot.prototype = {
    chartType : "CCCdot",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.DotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}

function CCCHeatGrid(){};
CCCHeatGrid.prototype = new SSBBaseComponent();
CCCHeatGrid.prototype = {
    chartType : "CCCheat",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.HeatGridChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCheat : preExecution");
    },
    postExecution: function () {
        //console.log("CCCheat : postExecution");
    } 
}

function CCCLine(){};
CCCLine.prototype = new SSBBaseComponent();
CCCLine.prototype = {
    chartType : "CCCline",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.LineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCline : preExecution");
    },
    postExecution: function () {
        //console.log("CCCline : postExecution");
    } 
}

function CCCMetricDot(){};
CCCMetricDot.prototype = new SSBBaseComponent();
CCCMetricDot.prototype = {
    chartType : "CCCmetricDot",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.MetricDotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCmetricDot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCmetricDot : postExecution");
    } 
}

function CCCPie(){};
CCCPie.prototype = new SSBBaseComponent();
CCCPie.prototype = {
    chartType : "CCCpie",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}
function CCCDonut(){};
CCCDonut.prototype = new SSBBaseComponent();
CCCDonut.prototype = {
    chartType : "CCCDonut",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}

function CCCStackedArea(){};
CCCStackedArea.prototype = new SSBBaseComponent();
CCCStackedArea.prototype = {
    chartType : "CCCstackedArea",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}

function CCCStackedLine(){};
CCCStackedLine.prototype = new SSBBaseComponent();
CCCStackedLine.prototype = {
    chartType : "CCCstackedLine",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.StackedLineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedLine : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedLine : postExecution");
    } 
}

function CCCSunburst(){};
CCCSunburst.prototype = new SSBBaseComponent();
CCCSunburst.prototype = {
    chartType : "CCCsunburst",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.SunburstChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCsunburst : preExecution");
    },
    postExecution: function () {
        //console.log("CCCsunburst : postExecution");
    } 
}

function CCCTreemap(){};
CCCTreemap.prototype = new SSBBaseComponent();
CCCTreemap.prototype = {
    chartType : "CCCtreemap",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.TreemapChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCtreemap : preExecution");
    },
    postExecution: function () {
        //console.log("CCCtreemap : postExecution");
    } 
}

function CCCWaterfall(){};
CCCWaterfall.prototype = new SSBBaseComponent();
CCCWaterfall.prototype = {
    chartType : "CCCwaterfall",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.WaterfallChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCwaterfall : preExecution");
    },
    postExecution: function () {
        //console.log("CCCwaterfall : postExecution");
    } 
}
