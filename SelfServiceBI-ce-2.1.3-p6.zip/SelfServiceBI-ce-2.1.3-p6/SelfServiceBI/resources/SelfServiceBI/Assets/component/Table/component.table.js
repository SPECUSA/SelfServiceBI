function Table(){};
Table.prototype = new SSBBaseComponent();
Table.prototype = {
    chartType : "CCCTable",

    init : function(chartID,data,htmlObj,chartProperties,conditions,dimLen){
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.dimLen = dimLen || 0; 
        this.chartDefination = prepareChartDefination(chartProperties,htmlObj);
        this.conditions = conditions;
        this.preExecution();
    },
    render : function(){

        //console.log(this.chartDefination);
        //console.log(this.conditions)
        var table = "<table class='table table1' width='100%'></table>";

        //console.log(this.data)
        $('#'+this.chartDefination['canvas']).append(table);


        var outputCols = [];
        var len = this.chartDefination['outputCols'].length;
        var cols = this.data.metadata.length;

        for(var a=0;a<len;a++)
            if(this.chartDefination['outputCols'][a] <= cols)
                outputCols.push(this.chartDefination['outputCols'][a] -1);

        //console.log(outputCols);

        if(cols >= this.chartDefination['noOfColumns'])
            cols = this.chartDefination['noOfColumns'];
        //console.log(cols);

        if(outputCols.length > cols)
            while(outputCols.length>cols)
                outputCols.pop();

            else if(outputCols.length < cols){
                var addEle = true;
                for(var a=0;outputCols.length<cols;a++){

                    if(outputCols.length > 0)
                        for(var b=0;b<outputCols.length;b++){
                            addEle = true;
                        //console.log(outputCols[b] +" "+a)
                        if(outputCols[b] == a){
                            //console.log("this is true");
                            addEle = false;
                            break;
                        }
                    }

                    if(addEle)
                        outputCols.push(a);
                //console.log(outputCols);
            }
        }     
        outputCols.sort(function(a, b){return a-b});

        //console.log(outputCols);

        if(outputCols.length==0){
            var p = this.data.metadata.length;
            var i=0;
            while(i<p){
                outputCols.push(i);
                i++;
            }
        }


        var columns = [];
        var colIdx = {}
        for(var i=0;i<this.data.metadata.length;i++){
            for(var j=0;j<outputCols.length;j++){
                if(outputCols[j]==i){
                    colIdx[this.data.metadata[i].colName] = j;
                    if(i>=this.dimLen && (this.data.metadata[i].colType=="Numeric" ||this.data.metadata[i].colType=="Integer" || this.data.metadata[i].colType=="DECIMAL" || this.data.metadata[i].colType=="INT" || this.data.metadata[i].colType == "NUMBER"))
                        columns.push({title:this.data.metadata[i].colLabel || this.data.metadata[i].colName,class:"numeric"})
                    else
                        columns.push({title:this.data.metadata[i].colLabel || this.data.metadata[i].colName})
                }
            }
        }
        var dataSet = [];
        for(var i=0;i<this.data.resultset.length;i++){
            dataSet[i] = [];
            for(var j=0;j<outputCols.length;j++){
                dataSet[i].push(this.data.resultset[i][outputCols[j]]);
            }

        }

        //console.log(colIdx);

        var self = this;
        if(dataSet.length==0){
            $('#'+this.chartDefination['canvas']).append("<div style='text-align:center;font-size:13px;'>No data found</div>");    
            return;
        }
        $('#'+this.chartDefination['canvas']+' .table1').DataTable( {
            data: dataSet,
            columns: columns,
            
            "iDisplayLength": 10,
            rowCallback: function(row, data, index) {
                //console.log(self.conditions);

                for(var i=0;i<self.conditions.length;i++){
                    //console.log(colIdx[self.conditions[i].column]);
                    if(self.conditions[i].cond=="><"){
                        if(eval(data[colIdx[self.conditions[i].column]]+">="+self.conditions[i].val1) && eval(data[colIdx[self.conditions[i].column]]+"<="+self.conditions[i].val2)){
                            //console.log("here")
                            $(row).find('td:eq('+colIdx[self.conditions[i].column]+')').addClass('color'+self.conditions[i].color)
                        }
                    }
                    else{
                        if(eval(data[colIdx[self.conditions[i].column]]+self.conditions[i].cond+self.conditions[i].val1)){
                            //console.log("here")
                            $(row).find('td:eq('+colIdx[self.conditions[i].column]+')').addClass('color'+self.conditions[i].color)
                        }    
                    }
                    
                }

            }

        });
    },
    preExecution : function(){
        this.render();
    },
    postExecution : function(){

    }
}