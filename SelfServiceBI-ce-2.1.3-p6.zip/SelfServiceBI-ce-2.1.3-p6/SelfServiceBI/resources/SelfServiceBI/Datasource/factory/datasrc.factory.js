angular.module('dataSourceModule').
factory('datasrc',['commonUtils','$log',function(commonUtils,$log){
	var datasrc = function(){
		this.id = "";
		this.name = "";
		this.type = "";
		this.base = "";
		this.properties = [];
		this.position = "";
	}
	
	datasrc.prototype.init = function(){
		this.id = "";
		this.name = "";
		this.type = "";
		this.base = "";
		this.properties = [];
		this.position = "";
	}

	return datasrc;
}]);