angular.module('pinboard')
.controller('pinboardViewerCtr',['$scope','pinboard','Pin' ,'filter','filterPanel','commonUtils','translationService','Messages','$window','$log','$compile','$timeout',function($scope,pinboard,Pin,filter,filterPanel,commonUtils,translationService,Messages,$window,$log,$compile,$timeout){
    $log.debug("This is Pinboard View Controller");
    commonUtils.mode = "pinboard";
    var mode=commonUtils.getParameterByName("mode").split("?")[0] ;
    if(mode == "editor")
        $window.location.href ="../../../content/SelfServiceBI-res/SelfServiceBI/pinboardEdit.html?mode=edit&solutionFile=" +  commonUtils.getParameterByName("solutionFile");

    else
    {
        pinboard.PinBoardFile = commonUtils.getParameterByName("solutionFile");
        pinboard.PinBoardFile = pinboard.PinBoardFile.replace(/%([^\d].)/, "%25$1");
        pinboard.PinBoardFile = decodeURIComponent(pinboard.PinBoardFile);
        commonUtils.editor=false;

        $scope.i18n = translationService.trans;
        
        pinboard.options.disableDrag = true;
        pinboard.options.disableResize = true;

        pinboard.getConfigFromFile();
        
        
        $scope.pinboardName = pinboard.PinboardName;
        $scope.usercomments = pinboard.userComments;
        $scope.commentsCount = pinboard.commentsCount;


        $scope.bgcolor = pinboard.bgcolor;
        $scope.webfont = pinboard.fonts;
        $scope.transTheme = pinboard.transTheme;
        var w = angular.element($window);
        w.bind('resize', function () {

            pinboard.resizeChart();
            
            //$('body').height($('html').height());
        });
        $("#filterpanel").collapse("show");

        


        $("body").css("min-height",$(window).height()-10)
        $scope.fileComments = function(){
            commonUtils.comments($scope,$scope.pinboardName,$scope.usercomments,$scope.commentsCount);
        }

        $scope.$watchCollection('usercomments',function(){
            var len = $scope.usercomments.length;

            if(len == undefined || len < 0 )
                $scope.commentsCount='';
            else if(len > 0 && len <10)
                $scope.commentsCount= len;
            else if(len > 10)
                $scope.commentsCount = '10+'; 

            pinboard.saveConfigToFile();
        })
        
        $scope.changeTrans = function(){
            
            if($scope.transTheme)
                $('body').addClass('transTheme');
            else
                $('body').removeClass('transTheme');
        }

        $scope.changeTrans();

        $scope.$watch('bgcolor',function(newval,oldval){
            if(oldval!= undefined){
                $('body').removeClass('bg-'+oldval.toLowerCase());
                $('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
                //$('#LayoutMaker_container').removeClass('bg-'+oldval.toLowerCase());
            }
            if(newval!=undefined){
                $('body').addClass('bg-'+newval.toLowerCase());
                $('#LayoutMaker_container').addClass('bg-'+newval.toLowerCase());
                //$('.bootstrap-dialog.type-primary .modal-header').css('background-color','#333');
                //$scope.setFont(newval);
            }

            if(newval!=undefined && newval=='Transparent'){
                $('pin').addClass('transTheme');
            }
            else{
                $('pin').removeClass('transTheme');   
            }
            commonUtils.safeApply($scope,function(){});

        });

        var fontMap = {"Default":"open_sansregular","Ubuntu":"Ubuntu-R","Myriad Pro":"Myriad Pro Regular","Oswald":"Oswald-Regular","PT Serif":"pt_serifregular","Lobster":"Lobster","Bebas":"BebasNeue_Regular","Fabfelt":"fabfeltscript-bold","Oregon":"Oregon LDO","League Gothic":"LeagueGothic","Lato":"Lato"};
        
        $(".pinboard-header-preview").css('font-family',fontMap[$scope.webfont]);


        $(function(){
            
            //$compile($('.pinboard-preview-div').html('<dashboard></dashboard>'))
            //$('body').css('min-height',$('html').height()-50);
            $("pin .pin-header").css('font-family',fontMap[$scope.webfont]);
            $("filterpanel  #filterpanelTitle").css('font-family',fontMap[$scope.webfont]);
            $('body').removeClass("fade-out");
        })

    }
     //$('.dropdown-toggle').dropdown()
}]);