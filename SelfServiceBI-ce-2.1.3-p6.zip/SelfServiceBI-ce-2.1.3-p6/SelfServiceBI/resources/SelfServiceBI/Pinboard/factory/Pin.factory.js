angular.module('pinboard')
.factory('Pin',['commonUtils','translationService','$log','Messages',function (commonUtils,translationService,$log,Messages) {
    $log.debug("Pin Factory called");
    var pin = function(){
        this.mode = "";
        this.pinId = "newPin" ;
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.pinHeaderColor = "panel-blue3";
        this.pinFontColor  = "Dark"       
        this.height = 200;
        this.width = "100";
        this.h_pin = 4;
        this.w_pin = 4;
        this.htmlObj = "PanelChart";
        this.version = commonUtils.version;
        this.buildVersion= commonUtils.buildVersion;

        this.dtsrcType = "";
        this.contentType = "chart";
        this.chartType = "";
        this.dataSource = "";
        this.dataAccessId = "";
        this.defaultParamStr = {};
        this.paramStr = {};
        this.paramValStr = "";

        this.conditions = [];

        this.listenerFilters = [];
        this.chartProperties = [];
        this.propJson ="";
        this.listenerPins = [];
        this.comments = [];
        this.commentsCount = '';
        this.currentSaiku = false;
        
        this.hasPermission = true;
        this.hasUrl = false;
        this.url = null;
        
        this.visualization = {
            name : "Bar"
        };      
    };
    pin.prototype.init = function(options){

        $log.debug("Pin( "+  this.pinId  +  " ).init : Default values");
        this.pinId = "newPin";
        this.pinIcon = "glyphicon glyphicon-pushpin";
        this.pinFile ="";
        this.title = "New Pin";
        this.minimize = true;
        this.isHeader = true;
        this.pinHeaderColor = "panel-green1";
        this.pinFontColor  = "Light"
        
        this.height = 200;
        this.width = "100";
        this.h_pin = 4;
        this.w_pin = 4;
        this.htmlObj = "PanelChart";

        this.dtsrcType = "";/*2017-v1.2.2-chudamani*/
        this.contentType = "chart";/*2017-v1.2.2-chudamani*/
        this.chartType = "";/*2017-v1.2.2-chudamani*/

        this.dataSource = "";
        this.dataAccessId = "";
        this.defaultParamStr = {};
        this.paramStr = {};
        this.paramValStr = "";
        this.conditions = [];
        this.listenerFilters = [];
        this.chartProperties = [];
        this.propJson ="";
        this.listenerPins = [];
        this.comments = [];
        this.commentsCount = '';
        this.currentSaiku = false;
                
        this.hasPermission = true;
        this.hasUrl = false;
        this.url = null;
        

        this.visualization = {
            name : "Bar"
        };
    };

    pin.prototype.initmap = function(o){

        this.pinId = o.pinId;
        this.pinIcon = o.pinIcon
        this.pinFile = o.pinFile||"";
        this.title = o.title;
        this.minimize = (o.minimize=="true"?true:false)||true;
        this.isHeader = (o.isHeader=="true"?true:false)||true;
        this.pinHeaderColor = o.pinHeaderColor || "panel-green1";
        this.pinFontColor  = o.pinFontColor || "Light"
        this.height = o.height;
        this.width = o.width;
        this.h_pin = o.h_pin || 4;
        this.w_pin = o.w_pin || 4;
        this.htmlObj = o.htmlObj;
        
        this.dataSource = o.dataSource;
        
        this.dataAccessId = o.dataAccessId||'';
        this.defaultParamStr = o.defaultParamStr||{};
        this.paramStr = o.paramStr||{};
        this.conditions = o.conditions||[];
        this.listenerFilters = o.listenerFilters||[];
        this.chartProperties = o.chartProperties||[];
        this.propJson =o.propJson || "";
        this.listenerPins = o.listenerPins||[];
        this.comments = o.comments||[];
        this.commentsCount = o.commentsCount||'';
        this.currentSaiku = o.currentSaiku||false;
        
        this.hasPermission = o.hasPermission|| true;
        this.hasUrl = o.hasUrl || false;
        this.url = o.url || null;
        
        this.visualization = angular.isObject(o.visualization) ? o.visualization : ({
            name : o.visualization
        });
        
        if(o.contentType==void 0){
            var chartType = o.chartType;
            o.contentType = ["Label","Table"].indexOf(o.chartType)>-1 ? o.chartType : "chart";
            o.contentType == "chart" ? (o.chartType = commonUtils.chartTypes(chartType)) : o.chartType = o.contentType;
            o.dtsrcType = commonUtils.getDtsrcType(this.dataSource.split(".")[1]);
        }
        
        
        this.contentType = o.contentType;
        this.chartType = o.chartType;
        this.dtsrcType = o.dtsrcType;

        var chartName = this.chartType.chartName==void 0 ?this.chartType : this.chartType.chartName;
        chartName!="" && this.propJson=="" && (this.propJson = commonUtils.parseProperties(chartName,this.chartProperties));
        
        this.propJson = angular.isObject(this.propJson) || this.propJson=="" ? this.propJson : JSON.parse(this.propJson);  

    }

    pin.prototype.isDefault = function(){
        if(this.pinId == "newPin" && this.pinIcon == "glyphicon glyphicon-pushpin" && this.title == "New Pin" && this.minimize == true && this.isHeader == true && this.pinHeaderColor == "panel-blue3" && this.height == 200 && this.dataSource == "")
            return true;
        else
            return false;
    }

    /*
    pin.prototype.getJson = function(){
        $log.debug("pinid : "+this.pinId);
        var json =  "{"+
                    "\"pinId\" : \""+  $.trim(this.pinId)  +  "\" , " +
                    "\"pinIcon\" : \""+  $.trim(this.pinIcon)  +  "\" , " +
                    "\"title\" : \""+  $.trim(this.title)  +  "\" , " +
                    "\"minimize\" : \""+  this.minimize +  "\" , " +
                    "\"isHeader\" : \""+  this.isHeader +  "\" , " +
                    "\"pinHeaderColor\" : \""+  $.trim(this.pinHeaderColor)  +  "\" , " +
                    "\"dataSource\" : \""+  $.trim(this.dataSource)   +  "\" , " +
                    "\"dataAccessId\" : \""+  $.trim(this.dataAccessId)   +  "\" , " +
                    "\"defaultParamStr\" : \""+  $.trim(this.defaultParamStr)   +  "\" , "  +
                    //"\"paramStr\" : \""+  $.trim(this.paramStr)   +  "\" , "  +
                    "\"chartType\" : \""+  $.trim(this.chartType)   +  "\" , " +
                    "\"visualization\" : \""+  $.trim(this.visualization)   +  "\" , "  ;


            if(this.chartProperties != undefined && this.chartProperties.length > 0)
            {

                json = json +  "\"chartProperties\" : " ;
                json = json + "[";

                for(var i=0;i<this.chartProperties.length;i++){
                    if(this.chartProperties[i][2] == "javascript" || this.chartProperties[i][1] == "array") // we use stringify for array and javascript store in json
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" ,"+  JSON.stringify($.trim(this.chartProperties[i][3]))   +  ", " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                        //$log.debug(this.chartProperties[i][0] + " - "  + this.chartProperties[i][3]);
                    }
                    else
                    {
                        json = json + "["  + "\""+  $.trim(this.chartProperties[i][0])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][3])   +  "\" , " + "\""+  $.trim(this.chartProperties[i][1])   +  "\" " ;
                    }

                    if(i == this.chartProperties.length-1)
                    {
                        json = json + "]";
                    }
                    else{
                        json = json + "],";
                    }

                }
                json = json + "],";
            }
            else
            {
                json = json + "\"chartProperties\" : [] , " ;
            }

        $log.debug("listenerFilters "+this.listenerFilters);
        json = json + "\"listenerFilters\" : ";
        json = json + "[";
        len = this.listenerFilters.length;
        if(this.listenerFilters.length >0){
            for(var i=0;i<len;i++){
                json = json + "[";
                json = json  + "\"" +$.trim(this.listenerFilters[i][0])+"\" ,";
                json = json  + "\"" +$.trim(this.listenerFilters[i][1])+"\" ";
                if(i == len-1){
                    json = json + "]";    
                }
                else{
                    json = json + "],";   
                }
                
            }
        }
        json = json +   "],";

        $log.debug("listenerPins "+this.listenerPins);
        json = json + "\"listenerPins\" : ";
        json = json + "[";

        if(this.listenerPins != undefined){
            len = this.listenerPins.length;
            if(this.listenerPins.length >0){
                for(var i=0;i<len;i++){
                    json = json + "[";
                    json = json  + "\"" +$.trim(this.listenerPins[i][0])+"\" ,";
                    json = json  + "\"" +$.trim(this.listenerPins[i][1])+"\" ,";
                    json = json  + "\"" +$.trim(this.listenerPins[i][2])+"\" ";
                    if(i == len-1){
                        json = json + "]";    
                    }
                    else{
                        json = json + "],";   
                    }
                    
                }
            }    
        }
        
        json = json +   "],";

        $log.debug("comments "+this.comments);
        json = json + "\"comments\" : ";
        json = json + "[";
        
        if(this.comments!=undefined){
            len = this.comments.length;
            if(this.comments.length >0){
                for(var i=0;i<len;i++){
                    
                    json = json + "[";
                    json = json  + "\"" +$.trim(this.comments[i][0])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][1])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][2])+"\" ,";
                    json = json  + "\"" +$.trim(this.comments[i][3])+"\" ";
                    if(i == len-1){
                        json = json + "]";    
                    }
                    else{
                        json = json + "],";   
                    } 
                }
            }    
        }
        
        json = json +   "],";


        json = json +   "\"commentCounts\" : \""+  $.trim(this.commentsCount)   +  "\" , " +
                        "\"height\" : \""+  $.trim(this.height)   +  "\" , " +
                        "\"width\" : \""+  $.trim(this.width)   +  "\" , " +
                        "\"htmlObj\" : \""+  $.trim(this.htmlObj)+  "\" , " +
                        "\"version\" : \""+  $.trim(this.version)+  "\" , " +
                        "\"buildVersion\" : \""+  $.trim(this.buildVersion)+  "\" " +
                        "}";

        
        //$log.log(json);
        return json;
    };
    */

    pin.prototype.render = function(param,htmlDiv,staticHeight){
        var htmlObj = htmlDiv || this.htmlObj
        var width = $("#" + htmlObj).parent().width()-5;
        //var height = $('#'+htmlDiv).height()  || this.height;
        
        staticHeight!=true && (this.height = this.h_pin * 70 - 48);
        
        var height = $('#'+htmlDiv).height()  || this.height;

        height -=30;
        width -=30;


        $("#" + htmlObj+"_chart").empty();
        $("#" + htmlObj).html('<div id="'+ htmlObj+'_chart" class="pin_chart" style="height:'+height+'px;width:'+width+'px;"></div>' );
        
        

        try {
            //to check, if dtsrcType has a caption prop then add ext property 
            this.dtsrcType.caption && this.dtsrcType.ext==void 0 && (this.dtsrcType.ext = this.dtsrcType.caption);
            if(this.hasUrl){
                var filterParam = commonUtils.parseParams(param);
                $("#" + this.htmlObj+ "_chart").html("<iframe class='iframe_url' src='"+this.url+"?"+filterParam+"'></iframe>")
            }
            else if (this.dataSource == undefined || this.dataSource.length < 1) {
                $("#" + this.htmlObj+ "_chart").html("<div class='pin_message' >" + translationService.trans.notif_no_datasource_selected + "</div>");
            }
            else if(!this.hasPermission){
                $("#" + htmlObj+ "_chart").html("<div class='pin_message' >"+translationService.trans.error_access_data+"</div>");
                return;
            }
            else if(this.visualization==undefined){
                $("#" + htmlObj+ "_chart").html("<div class='pin_message'>"+ translationService.trans.error_no_visualization_found+"</div>");
                return;
            }
            else if (this.dtsrcType.ext=="saiku" && this.chartType.chartName == "Saiku") {
                var visualization = this.contentType=="table"?"table":(this.currentSaiku || this.visualization.name); 
                var saikuClientRenderer = new SaikuClient(
                    {
                        server: "/pentaho/plugin/saiku",
                        path: "/cde-component"
                    });

                var tempParamObj = {};

                for(paramval in param){
                    if(param[paramval]!=null){
                        tempParamObj[paramval] = param[paramval];
                    }
                }

                var chartDef = {};
                for(var i=0;i<this.chartProperties.length;i++){
                    chartDef[this.chartProperties[i][0]] = this.chartProperties[i][3]
                }
                if ((visualization).toLowerCase() != "table"){
                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: "#" + htmlObj+"_chart",
                        render: "chart",
                        mode: (visualization).substring(0,1).toLowerCase()+(visualization).substring(1),
                        zoom: true,
                        params:tempParamObj,
                        chartDefinition: chartDef
                    });
                }
                else {
                    $("#" + htmlObj).addClass('workspace_results');
                    var t = $("<div></div>");
                    $("#" + htmlObj+"_chart").html(t);
                    htmlId = t;

                    saikuClientRenderer.execute({
                        file: this.dataSource,
                        htmlObject: htmlId,
                        render: "table",
                        mode: "sparkline",
                        zoom: true
                    });
                }
                $log.debug("Rendering configuration");
                $log.debug("Pin( " + this.pinId + " ).render : htmlID : " + htmlObj);
                $log.debug("Pin( " + this.pinId + " ).render : dataSource : " + this.dataSource);
                $log.debug("Pin( " + this.pinId + " ).render : chart : " + visualization);
                $log.debug("Pin( " + this.pinId + " ).render : Ended");

            }
            else if (this.contentType=="chart" && this.chartType.chartName == "CCC") {
                var chartType = window["CCC"+ this.visualization.name];
                var visualization = new chartType();
                
                var data = commonUtils.getQueryData(this,param)
                var propJson = angular.copy(this.propJson);
                var colOneProperVales = ["String","STRING","Date","date"];
                var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
                
                if(data=="error")
                    $("#" + htmlObj+"_chart").html(translationService.trans.error_loading_chart_data+" : "+this.chartType.chartName)
                else if(data.resultset.length == 0)
                    $("#" +htmlObj+"_chart").html(translationService.trans.error_no_data_found);
                else if(!colOneTypeCond){
                    $("#" +htmlObj+"_chart").html(translationService.trans.error_improper_data).css('text-align', "center");
                }
                else
                    visualization.init(this.pinId, data, htmlObj+"_chart", propJson,this.listenerPins);

            }
            
            else if (this.contentType=="chart"  && this.chartType.chartName == "HighChart") {
                var highchart = new HighChart();                
                var visualization = angular.copy(this.visualization);
                var propJson = angular.copy(this.propJson);
                var data = commonUtils.getQueryData(this,param);

                if(data=="error")
                    $("#" + htmlObj+"_chart").html(translationService.trans.error_loading_chart_data+" : "+this.chartType.chartName);
                else
                    highchart.init(visualization, data, htmlObj+"_chart", this.chartProperties,propJson,this.listenerPins,translationService.trans);
            }
            else if (this.contentType=="chart" && this.chartType.chartName == "Fusionchart") {
                var visualization = new Fusionchart();
                var propJson = angular.copy(this.propJson);
                var data = commonUtils.getQueryData(this,param);
                
                if(data=="error")
                    $("#" + htmlObj+"_chart").html(translationService.trans.error_loading_chart_data+" : "+this.chartType.chartName)
                else if(data.resultset.length == 0)
                    $("#" +htmlObj+"_chart").html(translationService.trans.error_no_data_found);
                else
                    visualization.init(this.visualization, data, htmlObj+"_chart", this.chartProperties, propJson,this.listenerPins,null,null,translationService.trans);
            }
            else if (this.contentType=="chart" && this.chartType.chartName == "Echarts") {
                var chartType = window["Echarts"+ this.visualization.name];
                var visualization = new chartType();
               
                var propJson = angular.copy(this.propJson);
                var data = commonUtils.getQueryData(this,param);
                
                if(data=="error")
                    $("#" + htmlObj+"_chart").html(translationService.trans.error_loading_chart_data+" : "+this.chartType.chartName)
                else if(data.resultset.length == 0)
                    $("#" +htmlObj+"_chart").html(translationService.trans.error_no_data_found);
                else
                    visualization.init(this.pinId, data, htmlObj+"_chart", this.chartProperties, propJson,this.listenerPins,null,null,translationService.trans);
            }

            else if(this.contentType=="Table" || this.contentType=="Label"){
                var chartType = window[this.visualization.name];
                var visualization = new chartType();

                var propJson = angular.copy(this.propJson);
                var data = commonUtils.getQueryData(this,param);
                
                if(data=="error")
                    $("#" + htmlObj+"_chart").html(translationService.trans.error_loading_chart_data+" : "+this.contentType)
                else if(data.resultset.length == 0)
                    $("#" +htmlObj+"_chart").html(translationService.trans.error_improper_data);
                else
                    visualization.init(this.pinId,data,htmlObj+"_chart",propJson,this.conditions,null);
            }
            else{
                $("#" + htmlObj+"_chart").html(translationService.trans.error_invalid_chartType+" : "+this.contentType)
            }
        }
        catch(error)
        {
            if(error == "Error: [pvChart ERROR]: Invalid operation. Chart type requires unassigned role 'y'."){
                $("#" + htmlObj+ "_chart").html("<div style=\"text-align: center;text-decoration:underline;color:red;\">Error <br /> Inproper dataset </div><div style='text-align:center;'><h6><u>Tip</u><br/> Also change one property called CrossTabMode to false </h6></div>");
            }
            else
            {
                $log.error(error);
            }
        }

        $("#" + htmlObj+"_chart").css("display","block");

    };

    pin.prototype.saveConfigToFile = function(){
        $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : Started");
        var param = {
            "file"  :  this.pinFile ,
            "content"  : this.getJson()
        };
        $log.debug(this.getJson());
        var jsonData =commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/saveBDDFile',"POST",param);
        if(jsonData.result =="Success."){
            $log.debug("Pin( "+  this.pinId  +  " ).saveConfigToFile : ended : SuccessFully");
            return true;
        }
        else{
            $log.debug("Pin( "+  this.pinId +  " ).saveConfigToFile : ended : Error : " + jsonData.result );
            return false;
        }
    };

    pin.prototype.getConfigFromFile = function() {
        


        if(this.pinFile == undefined || this.pinFile.length <1)
        {

            this.title = "Existing Pin is not Configured";
            this.pinHeaderColor = "panel-blue3";
            this.dataSource = "";
            this.height = 200;
            this.width = "100";

        }
        else
        {
            var jsonData =$.parseJSON(commonUtils.synchronousJsonCall( '../../../plugin/SelfServiceBI/api/getBDDFile?path='+ getBURIComponent(this.pinFile),"GET",null).result);
            $log.debug(jsonData);
            try
            {
                this.pinId = jsonData.pinId;
                this.pinIcon = jsonData.pinIcon;
                this.title = jsonData.title;
                this.minimize = jsonData.minimize=="true"?true :false;
                this.isHeader = jsonData.isHeader=="true"?true :false;
                if(jsonData.pinHeaderColor==undefined && (jsonData.bootstrapStyle!= undefined && jsonData.bootstrapStyle.length > 0))
                    this.pinHeaderColor = 'panel-blue3';
                else if(jsonData.pinHeaderColor.length>0)
                    this.pinHeaderColor = jsonData.pinHeaderColor;
                else
                    this.pinHeaderColor = 'panel-green1';
                this.dataSource = jsonData.dataSource;
                this.dataAccessId = jsonData.dataAccessId;
                this.defaultParamStr = jsonData.defaultParamStr;
                this.paramStr =  jsonData.defaultParamStr;
                this.chartType = jsonData.chartType;
                this.visualization = jsonData.visualization;

                if(jsonData.chartProperties != undefined && jsonData.chartProperties.length > 0)
                {
                    //var chartType = commonUtils.getChartType(this.chartType);
                    this.chartProperties = commonUtils.readJSONFile('../Assets/component/'+this.chartType+'/'+this.chartType+'.'+this.visualization+'.properties.json');
                    for(var i=0;i< this.chartProperties.length ;i++)
                    {
                        if(this.chartProperties[i][0] == jsonData.chartProperties[i][0])
                        {

                            this.chartProperties[i] = commonUtils.parsePropertiesDataType(jsonData.chartProperties[i][1],jsonData.chartProperties[i][2]);
                        }
                    }
                }
                else
                {
                    this.chartProperties = [];
                }
                this.comments = jsonData.comments;
                this.commentsCount = jsonData.commentsCount;
                this.listenerFilters = [];
                this.listenerPins = [];
                this.htmlObj = jsonData.htmlObj;
                this.height = jsonData.height;
                this.width = jsonData.width;
                this.version =jsonData.version;
                this.buildVersion=jsonData.buildVersion;
            }
            catch(err)
            {
                $log.error("Pin( "+  this.pinId  +  " ).getConfigFromFile : Error : " + err.message);
                $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ServerError :  \n" + jsonData);
            }
            $log.debug("pin json data : ");
            $log.debug(this.getJson());
        }

        $log.debug("Pin( "+  this.pinId  +  " ).getConfigFromFile : ended : getJson : \n" + this.getJson());
    };
    return pin ;    
}]);