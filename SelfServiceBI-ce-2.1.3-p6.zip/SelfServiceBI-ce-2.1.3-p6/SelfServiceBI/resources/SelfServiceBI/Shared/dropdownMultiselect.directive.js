/////////////////////////
/// Filter MutliSelect //
/////////////////////////
angular.module('commonUtilModule')
.directive('dropdownMultiselect', ['commonUtils','$compile','$log',function (commonUtils,$compile,$log) {
    return {
        restrict: 'E',
        scope: {
            selectedOptions: '=',
            datasource: '=',
            idd : '='
        },

        link : function($scope,element,attr)
        {
            var html = "<div class='dropdown'>" +
                    "<button class='btn btn-sm btn-default dropdown-toggle dropdownClicked' id='dropdownMenu' style='width:auto' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>{{selectedOptions.length==totalLen||selectedOptions.length==0?(i18n.all_selected):(selectedOptions.length+' '+i18n.selected)}} <b class='caret'></b></button>" +
                    "<ul class='dropdown-menu' aria-labelledby='dropdownMenu'>" +
                        "<li><a ng-click='selectAll();$event.stopPropagation();'><span class='{{idd}}' ng-class='getClass()' aria-hidden='true'></span> {{i18n.select_all}}</a></li>" +
                        "<li><span class='form-inline'><input type='text' ng-model='search' style='margin-left:5px;margin-right:5px;width:78%'/><i class='glyphicon glyphicon-search'></i></span></li>" +
                        "<li class='divider'></li>"+
                        "<li class='dropdown-data'>"+
                        "<ul style='color:black;list-style-type: none;margin-left: -20px;'><li ng-repeat='option in datasource | filter:search track by $index'><div ng-click='toggleSelectItem(option);$event.stopPropagation();'><span ng-class='getClassName(option)'aria-hidden='true'></span> {{option}}</div></li>"+
                        "</ul></li></ul>" +
                        "</div>";

            element.html(html);
            $compile(element.contents())($scope);



        },
        controller: ['$scope',function ($scope) {
            //$log.log($scope.idd);
            $scope.i18n = commonUtils.i18n;
            $scope.datasource= Array.from(new Set($scope.datasource));

            $scope.selectAll = function () {
                $scope.selectedOptions = angular.copy($scope.datasource);
                $scope.isSelectAll = true;
                $scope.title = $scope.i18n.all_selected;
            };

            $scope.getClass = function () {
                if($scope.selectedOptions.length==$scope.totalLen){
                    return 'glyphicon glyphicon-ok green';
                }
                else{
                    return 'glyphicon glyphicon-remove white';
                }
            };

            $scope.toggleSelectItem = function (option) {
                var intIndex = -1;

                if($scope.isSelectAll || $scope.selectedOptions.length==$scope.totalLen){
                    $scope.selectedOptions = [];
                }
                
                angular.forEach($scope.selectedOptions, function (item, index) {
                    if (item == option) {
                        intIndex = index;
                    }
                });
                //$log.log(intIndex);
                if (intIndex >= 0) {
                    $scope.selectedOptions.splice(intIndex, 1);
                    
                    if($scope.selectedOptions.length == 0){
                        $scope.selectedOptions = $scope.datasource;
                        $scope.isSelectAll = true;
                        $scope.title = $scope.i18n.all_selected;
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                    }
                    else{
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                        $scope.title = ($scope.selectedOptions.length)+' '+$scope.i18n.selected ;
                        $scope.isSelectAll = false;
                    }
                }
                else {
                    $scope.selectedOptions.push(option);
                    if($scope.selectedOptions.length == $scope.totalLen){
                        $scope.title = $scope.i18n.all_selected;
                        //$scope.selectedOptions = [];
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-remove white');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-ok green');
                        $scope.isSelectAll = true;
                    }
                    else{
                        $('.'+$scope.idd).removeClass('glyphicon glyphicon-ok green');
                        $('.'+$scope.idd).addClass('glyphicon glyphicon-remove white');
                        $scope.title = ($scope.selectedOptions.length)+' '+$scope.i18n.selected;
                        $scope.isSelectAll = false;
                    }
                }
            };
            $scope.getClassName = function (option) {
                var varClassName = 'glyphicon glyphicon-remove white';
                angular.forEach($scope.selectedOptions, function (item, index) {
                    if (item == option) {
                        varClassName = 'glyphicon glyphicon-ok green';
                    }
                });
                return (varClassName);
            };

            $scope.isSelectAll = false;
            $scope.optionSelect = [];

            angular.forEach($scope.datasource,function(item,index){
                for(i=0;i<$scope.selectedOptions.length;i++){
                    if($scope.selectedOptions[i] == $scope.datasource[index]){
                        $scope.optionSelect.push($scope.selectedOptions[i]);
                    }
                }
            })
            $scope.totalLen = $scope.datasource.length;
            $scope.selectedOptions = $scope.optionSelect;

            if($scope.selectedOptions.length==$scope.totalLen || $scope.selectedOptions.length == 0){
                $scope.selectAll();
                $scope.getClass();
            }
            // else if($scope.selectedOptions.length == 0){
            //     $scope.isSelectAll = true;
            //     $scope.selectedOptions = [];
            //     $scope.title = $scope.i18n.all_selected;
            // }
            else{
                $scope.title = ($scope.selectedOptions.length)+' '+$scope.i18n.selected;
            }
                
            

        }]
    }
}]);