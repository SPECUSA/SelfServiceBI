angular.module('dataSourceModule').
directive('datasrcComp',['dataSource','datasrc','commonUtils','$log','$compile','$timeout','Messages',function(dataSource,datasrc,commonUtils,$log,$compile,$timeout,Messages){
    return{
        restrict : 'E',
        scope : {
            'obj' : '=',
            'position' : '@'
            
        },

        link: function(scope,element,attrs){
            //scope.datasourceType = scope.obj.type.substr(0, scope.obj.type.indexOf('.')); 
            $log.debug("this is datasrc comp")
            $log.log(scope.obj)
            //$log.log(scope.obj);
            scope.dtsrcProperties = function(){
                
                
                if(element.children().hasClass('select')){
                    return;
                }
                else{
                    $('.row-datasource').removeClass('select');
                    element.children().addClass('select');
                    //console.log(element.children().hasClass('select'));
                }
                
                $log.log("datasrc comp");
                $('.properties').show();
                //$('.row-datasource').removeClass('select');
                $(this).addClass('select');
                $('#currentDtsrc').text(scope.obj.name)
                dataSource.currentCda = scope.obj.id;
                scope.name = scope.obj.name;
                scope.dbtype='';
                scope.dbuser='';
                scope.dbhost='';
                scope.dbport='';
                scope.dbname='';
                scope.properties = [];
                scope.properties = scope.obj.properties;
                $('#propertiesPanel').html('');

                var html = '<div class="form-group"><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">Name</div><div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input id="name" type="text" class="form-control input-sm" ng-model="name" title={{name}}/></div></div>'
                $('#propertiesPanel').append($compile(html)(scope));

                for(var i=0;i<scope.properties.length;i++)
                        commonUtils.propertiesHTMLComponent(scope.properties[i][0],scope.properties[i][5],scope.properties[i][1],scope.properties[i][2],scope.properties[i][3],scope.properties[i][4],scope.properties[i][6],"propertiesPanel",scope);

                $('#propertiesPanelSave').html($compile('<button class="btn" id="saveButton" ng-click="saveData()" ng-disabled="disablePSave"><i class="glyphicon glyphicon-floppy-disk">&nbsp;</i></button>')(scope));
    
                dataSource.nullPropertyPanel = false;;
            }

            scope.saveData = function(){
                //$log.log(scope.name)
                $log.log(scope.obj.properties)
                var regexp = /^[a-zA-Z0-9-_\.]+$/;
                if(scope.name.search(regexp) == -1 && scope.name != undefined && scope.name.length > 0){
                    alert("Invalid datasource name. It only contain Alphanumeric character and special _ and . characters.");
                    return;
                }

                scope.obj.name = scope.name;
                for(var i=0;i<scope.obj.properties.length;i++){
                    if(scope.obj.properties[i][2] == 'switch' || scope.obj.properties[i][2] == 'combo'){
                        temp = $('#'+scope.obj.properties[i][0]).bootstrapSwitch('state');
                        scope[scope.obj.properties[i][0]] = temp;
                    }
                    scope.obj.properties[i][3] = scope[scope.obj.properties[i][0]];
                    //$log.log(scope.obj.properties[i][0]+" "+scope.obj.properties[i][3]);
                }
                commonUtils.savedFlag = false;
                commonUtils.propertiesSaved = true;
                //$log.log(scope.obj.properties);
                scope.disablePSave = true;
                //commonUtils.notification(Messages.onPropertiesSavedNotification);
                commonUtils.notif(Messages.onPropertiesSavedNotification,"topRight","alert",2000,function(){});
                $timeout(function(){
                    scope.disablePSave = false;
                },4000)
            }
            
            scope.removeDatasource = function(id){
                $log.debug("remove datasource");
         
                var temp = [];
                var datasrcClone = [];
                for(var i=0;i<dataSource.datasources.length;i++){
                    var datasrcCompClone = [];
                    for(var j=0;j<dataSource.datasources[i].datasrcEntry.length;j++){
                        if(dataSource.datasources[i].datasrcEntry[j].id != id){
                            datasrcCompClone.push(dataSource.datasources[i].datasrcEntry[j]);
                        }    
                    }
                    dataSource.datasources[i].datasrcEntry = datasrcCompClone;
                    if(dataSource.datasources[i].datasrcEntry.length > 0)
                        datasrcClone.push(dataSource.datasources[i]);
                    else
                        dataSource.changePosition(i);
                }

                dataSource.datasources = datasrcClone;
                //$log.log(dataSource.datasources);             
                
                //$log.log(dataSource.datasources[i]);
                
                if(dataSource.datasources.length == 0)
                    commonUtils.isNull = true;

                dataSource.blankPropertiesPanel();
                $('.properties').hide();
                commonUtils.savedFlag = false;
            }

            scope.moveUp = function(id){
                var index1,index2;
                //$log.log(id);
                //$log.log(dataSource.datasources)
                for(var i=0;i<dataSource.datasources.length;i++){
                    for(var j=0;j<dataSource.datasources[i].datasrcEntry.length;j++){
                        if(dataSource.datasources[i].datasrcEntry[j].id == id){
                            index1 = i;
                            index2 = j;
                        }    
                    }
                }
                //$log.log(index1+" "+index2)
                if(index2 != 0){
                    var temp = dataSource.datasources[index1].datasrcEntry[index2];
                    dataSource.datasources[index1].datasrcEntry[index2] = dataSource.datasources[index1].datasrcEntry[index2-1];
                    dataSource.datasources[index1].datasrcEntry[index2-1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(dataSource.datasources);
            };

            scope.moveDown = function(id){
                var index1,index2;
                //var len = dataSource.datasources.length;
                for(var i=0;i<dataSource.datasources.length;i++){
                    for(var j=0;j<dataSource.datasources[i].datasrcEntry.length;j++){
                        if(dataSource.datasources[i].datasrcEntry[j].id == id){
                            index1 = i;
                            index2 = j;
                        }    
                    }
                }
                var len = dataSource.datasources[index1].datasrcEntry.length;
                if(index2 < len-1){
                    var temp = dataSource.datasources[index1].datasrcEntry[index2];
                    dataSource.datasources[index1].datasrcEntry[index2] = dataSource.datasources[index1].datasrcEntry[index2+1];
                    dataSource.datasources[index1].datasrcEntry[index2+1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(dataSource.datasources);
            };
            

            scope.dtsrcProperties();

            var len = dataSource.datasources.length;
            var html = '<div class="row-datasource select"><div class="paddingSide0 datasrcComp panel-heading clearfix " ng-click="dtsrcProperties()">'+
                            '<!--<span class="col-lg-4 col-md-4">{{obj.type}}</span>--><span class="col-lg-4 col-md-4 textoverflow" title={{obj.name}}>{{obj.name}}</span>'+
                            '<div class="btn-group pull-right drcComp" >'+
                                //'<button class="btn btn12 btn-xs" ng-click="setting(obj.id)"><i class="glyphicon glyphicon-cog"></i></button>'+
                                '<button class="btn btn12 btn-xs" ng-click="moveUp(obj.id)"><i class="glyphicon glyphicon-arrow-up"></i></button>'+
                                '<button class="btn btn12 btn-xs" ng-click="moveDown(obj.id)"><i class="glyphicon glyphicon-arrow-down"></i></button>'+
                                '<button class="btn btn12 btn-xs" ng-click="removeDatasource(obj.id)"><i class="glyphicon glyphicon-remove"></i></button>'+
                            '</div>'+
                        '</div></div>';

            element.html(html);
            $compile(element.contents())(scope);

            $timeout(function(){
                commonUtils.safeApply(scope,function(){});
            },0)
        
        }
    }
}]);