angular.module('pinboard')
.directive("pin",['pinboard','Pin','$timeout','commonUtils','translationService','$log','$http','$compile','Messages',function(pinboard,Pin,$timeout,commonUtils,translationService,$log,$http,$compile,Messages){
    return {
        restrict :'E',
        scope : {
            'pinobj'  : '=',
            'idd' : '@'
        },
        link : function (scope,element,attrs ){

            $log.debug("This is Pin directive");
        
            scope.editor=commonUtils.editor;
            scope.preview = !commonUtils.editor;

            scope.i18n = translationService.trans;
            scope.dataSources = [];

            

            // if(pinboard.datasourceList.indexOf(scope.pinobj.dataSource)<0 && scope.pinobj.dataSource.length>0){
            //     pinboard.datasourceList.push(scope.pinobj.dataSource);

            //     if(scope.pinobj.dataSource.indexOf(".cda")>0){
            //         pinboard.addDAelement(pinboard.datasourceList.length-1);
            //         scope.pinobj.hasPermission = true;
            //         pinboard.hasPermission = true;
            //     }
                
            // }

            // if(pinboard.hasPermission)
            //     scope.pinobj.hasPermission = true;
            // else
            //     scope.pinobj.hasPermission = false;

            if(scope.pinobj.commentsCount==undefined && (scope.pinobj.comments.length>0 && scope.pinobj.comments.length<11))
                scope.pinobj.commentsCount = scope.pinobj.comments.length;
            else if(scope.pinobj.commentsCount==undefined && scope.pinobj.comments.length>10)
                scope.pinobj.commentsCount = '10+'
            else if(scope.pinobj.commentsCount==undefined && scope.pinobj.comments.length==0)
                scope.pinobj.commentsCount = '';   
            

            if(scope.preview && scope.pinobj.chartType != 'Saiku')
                scope.showExport = true;    
            else
                scope.showExport = false;

            scope.listParameters = [];

            /*2017-v1.2.2-chudamani*/
            scope.chartProperties1 = function(){
                $(".nav-btn").removeClass("panel-setting-active");
                $("#wrapper").removeClass("toggleSidebar")
                $(".sidepanel").removeClass("opened");
                

                pinboard.activePin.push(scope.pinobj);
                //pinboard.resizeChart();
            }
            /*2017-v1.2.2-chudamani*/


            var getDefaultParams = function(){
                scope.listParameters = [];
                            //alert(listParams);
                uri = encodeURIComponent(scope.pinobj.dataSource);

                var listParams = commonUtils.getDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,"parameter");

                if(!listParams){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+scope.pinobj.dataAccessId ;
                    listParams = commonUtils.synchronousJsonCall(url);

                    commonUtils.setDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,listParams,"parameter");
                }
                //scope.listParameters = listParams;

                var param = {};
                var  l = listParams.resultset.length;

                for(var i=0;i<l;i++){
                    paramObj = listParams.resultset[i];
                    param[paramObj[0]] = paramObj[2];
                }
                scope.pinobj.defaultParamStr = param;

                
                for(var x=0;x<scope.pinobj.listenerFilters.length;x++){
                    for(var i=0;i<pinboard.filterPanel.filterArray.length;i++){
                        if(pinboard.filterPanel.filterArray[i].filterId==scope.pinobj.listenerFilters[x][0]){
                            $.each(pinboard.filterPanel.filterArray[i].listenerPins,function(j,v){
                                if(v.pinId == scope.pinobj.pinId){
                                    pinboard.filterPanel.filterArray[i].listenerPins[j].param = scope.pinobj.listenerFilters[x][1];
                                }
                            })
                        }
                            
                    }
                        
                }

                var parameter = (scope.pinobj.paramStr == null) ? scope.pinobj.defaultParamStr : scope.pinobj.paramStr;

                var param = commonUtils.parseParams(angular.copy(parameter));
                var data = commonUtils.getDatasourceData(scope.dataSource,scope.dataAccessId,"data");

                if(!data){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + scope.pinobj.dataSource + '&dataAccessId=' + scope.pinobj.dataAccessId + param + '&outputIndexId=1';
                    data = commonUtils.synchronousJsonCall(url);

                    commonUtils.setDatasourceData(scope.pinobj.dataSource,scope.pinobj.dataAccessId,data,"data");
                }
            }

            $timeout(function(){
                if(scope.pinobj.dataAccessId.length>0)
                    getDefaultParams();
                
                if(scope.pinobj.dtsrcType.ext!="saiku"){
                    $log.debug("paramStr "+scope.pinobj.defaultParamStr);
                    //scope.pinobj.paramStr = scope.pinobj.defaultParamStr;
                    var parameter = (scope.pinobj.paramStr == null) ? scope.pinobj.defaultParamStr : scope.pinobj.paramStr;
                    scope.pinobj.render(parameter);    
                }
                else{
                    scope.pinobj.render();    
                }
            }, 0);

            if(commonUtils.mode == "pin")
                scope.pinMode = true
            else
                scope.pinMode = false;

            var populateDatasrc = function(filext){
                
                scope.dataSources = [];
                var flagCda = false;
                for(i=0;i<pinboard.datasourceList.length;i++){
                    if(pinboard.datasourceList[i].indexOf('.cda')>0)
                        flagCda = true;
                    if(pinboard.datasourceList[i].indexOf('.'+filext)>0)
                        scope.dataSources.push(pinboard.datasourceList[i]);
                }

                
                if(scope.dataSource == undefined || scope.dataSource.length <= 0 || scope.dataSources.indexOf(scope.dataSource)<0){
                    scope.dataSource = scope.dataSources[0];
                }
                else if(scope.pinobj.dataSource==scope.dataSource)
                    scope.dataSource = scope.pinobj.dataSource;
                
                if(flagCda && filext=='cda'){
                    scope.populateDAId();
                }
            }

            scope.populateDAId = function(){
                scope.dataAccessIds = [];
                for(var i=0;i<pinboard.dataAccessList.length;i++){
                    if(pinboard.dataAccessList[i].dbsrc==scope.dataSource)
                        scope.dataAccessIds = angular.copy(pinboard.dataAccessList[i].daIds)
                }

                //scope.dataAccessId = scope.dataAccessIds[0];

                if(scope.dataAccessId == undefined || scope.dataAccessId.length <= 0 || scope.dataSource != scope.pinobj.dataSource){
                    scope.dataAccessId = scope.dataAccessIds[0];    
                }
                else{
                    scope.dataAccessId = scope.pinobj.dataAccessId;
                }

                scope.dataAccessIdChanged();
            }

            
            
            scope.chartClick = function(cValue,pinParam){

                scope.pinobj.paramStr[pinParam] = cValue;
                scope.pinobj.render(scope.pinobj.paramStr);
                commonUtils.safeApply(scope,function(){});
            }
            
            scope.removePin = function(){
                commonUtils.BootstrapConfirm(scope.i18n.notif_remove_pin_confirm, function(result){
                    if(result) {
                        var temp;
                        for(var i=0;i<pinboard.pinLists.length;i++){
                            if(pinboard.pinLists[i].id==scope.pinobj.pinId)
                                temp = i;
                        }

                        //pinboard.pinLists.splice(temp,1);

                        //removeRow= parseInt(removeRow);
                        var nullPinboard = pinboard.removeAt(temp);
                        if(nullPinboard)
                            commonUtils.isNull = true;
                        else
                            commonUtils.isNull = false;

                        commonUtils.safeApply(scope,function(){});
                        commonUtils.savedFlag =false; //to-do set flag to root or commonutil
                    }
                });
                $("#mainpage").height(document.getElementById("mainpage").scrollHeight)
            }
            scope.pinComments = function(){
                scope.username = commonUtils.username;
                //$log.log(scope.pinobj.comments);
                BootstrapDialog.show({
                    title : scope.i18n.comments+' - '+scope.pinobj.title,
                    message : function(dialog) {
                        var $message = $('<div style="overflow:auto;"></div>');
                        //var pageToLoad = scope.pageToLoad;
                        var template =  '<div class="modal-form"><div id="comment-area" class="form-control comment-display"></div><div class="form-group comment-input">'+
                                        '<div class="col-lg-11 col-md-11 col-sm-11 comment-input-left">'+
                                            '<textarea id="comment" class="form-control textarea comment-textarea" ng-model="comment" style="height:68px"/></div>'+
                                        '<div class="col-md-1 col-lg-1 col-sm-1" style="padding-left:0px;">'+
                                            '<button class="btn btn-md btn-blue comment-send" title={{i18n.make_comment}} ng-click="makeComment()"><i class="glyphicon glyphicon-send"></i></button>'+
                                        '</div></div>';

                        //'<div class="modal-form"><div class="col-md-12 comment-search"><div class="c-search c-seach-icon col-md-1"><i class="glyphicon glyphicon-search"></i></div><div class="c-search col-md-11"><input type="text" class="form-control c-search-input" /></div></div>'+
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    closable : true,
                    cssClass : 'width500 '+scope.pinobj.pinHeaderColor,
                    onshown : function(dialogRef){

                        scope.addComment = function(username,comment,date,time,repeat,sameDate,owner){
                            var addNewComment = '';
                            //$log.log(sameDate);

                            if(!sameDate){
                                addNewComment +='<div class="comment-date">'+date+'</div>';
                            }


                            if(owner){
                                if(!repeat)
                                    addNewComment = addNewComment+'<div class="comment-user">You</div>';
                                
                                addNewComment = addNewComment+ '<div class="comment-comment"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                            }
                            else{
                                if(!repeat)
                                    addNewComment = addNewComment+'<div class="comment-user-v">'+username+'</div>'
                                addNewComment = addNewComment + '<div class="comment-comment-v"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                            }
                            $('#comment-area').append(addNewComment);

                        }

                        scope.makeComment = function(){
                            
                            if(scope.comment == undefined || scope.comment.length < 1){
                                return;
                            }
                            else if(scope.comment.length>500){
                                commonUtils.notif(scope.i18n.notif_comment_char_count_exceeds+scope.comment.length,"topRight","error",2500,function(){});
                                return;
                            }



                            var d = new Date();
                            var day = d.getDate();
                            var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                            var month = months[d.getMonth()];
                            var year = d.getFullYear();
                            var hour = d.getHours();
                            var format = "am"
                            var mins = d.getMinutes();
                            if(mins.toString().length == 1){
                                mins = '0'+mins;
                            }

                            if(hour>12){
                                hour-=12;
                                format = 'pm';
                            }
                            var date = month+' '+day+','+year;
                            var time = hour+':'+mins+' '+format;

                            var repeat = false;
                            var sameDate = false;
                            var owner = true;
                            var username = scope.username;
                            var comment = $.trim(scope.comment);
                            //$log.log(comment);

                            scope.pinobj.comments.push([scope.username,comment,date,time]);
                            var len = scope.pinobj.comments.length;

                            if(len>1 && (scope.pinobj.comments[len-1][2]== scope.pinobj.comments[len-2][2])){
                                sameDate = true;
                            }

                            if(sameDate && len>1 && (scope.pinobj.comments[len-1][0]== scope.pinobj.comments[len-2][0])){
                                repeat = true;
                            }
                            
                            scope.addComment(scope.username,comment,date,time,repeat,sameDate,owner);


                            if(scope.pinobj.commentsCount=='')
                                scope.pinobj.commentsCount=1;
                            else if(isNaN(scope.pinobj.commentsCount) || scope.pinobj.commentsCount==10)
                                scope.pinobj.commentsCount='10+';
                            else
                                scope.pinobj.commentsCount++;
                            
                            //var addNewComment = '<div class="comment-user">'+username+'</div><div class="comment-comment"><pre>'+comment+'</pre></div>';
                            //$('#comment-area').append(addNewComment);
                            
                            scope.comment = "";
                            $('#comment').focus();
                            commonUtils.savedFlag = false;

                            var mode = commonUtils.getParameterByName("mode").split("?")[0];
                            //$log.log(commonUtils.getParameterByName("mode").split("?")[0]);

                            if("generatedContent"==mode && commonUtils.mode == 'pinboard'){
                                pinboard.saveConfigToFile();
                            }
                            else if("generatedContent"==mode && commonUtils.mode == 'pin'){
                                scope.pinobj.saveConfigToFile();   
                            }
                            commonUtils.safeApply(scope,function(){});

                            
                        }


                        $('#comment').focus();
                        for(var i=0;i<scope.pinobj.comments.length;i++){
                            var repeat = false;
                            var sameDate = false;
                            var owner = false;


                            if(i>0 && (scope.pinobj.comments[i][2]== scope.pinobj.comments[i-1][2])){
                                //$log.log(scope.pinobj.comments[len-1][2]+" "+scope.pinobj.comments[len-2][2])   
                                sameDate = true;
                            }
                            

                            if(sameDate && i>0 && (scope.pinobj.comments[i][0]== scope.pinobj.comments[i-1][0]))
                                repeat = true;
                            
                            if(scope.pinobj.comments[i][0]==scope.username)
                                owner = true;

                            scope.addComment(scope.pinobj.comments[i][0],scope.pinobj.comments[i][1],scope.pinobj.comments[i][2],scope.pinobj.comments[i][3],repeat,sameDate,owner);

                            //var addOldComments = '<div class="comment-user-v">'+scope.pinobj.comments[i][0]+'</div><div class="comment-comment-v"><pre>'+scope.pinobj.comments[i][1]+'</pre></div>';
                            //$('#comment-area').append(addOldComments);
                        }                       
                    }
                });
            }

            // scope.colorNames = {'panel-red1':'Wine Red','panel-red2':'Cherry Red','panel-red3':'Imperial Red','panel-red4':'Pure Red','panel-red5':'Orange Red','panel-orange1':'Orange','panel-orange2':'Spanish Orange','panel-orange3':'Amber','panel-orange4':'Peachy Orange','panel-orange5':'Apricot',
            //                     'panel-yellow1':'Sunglow','panel-yellow2':'Gold','panel-yellow3':'Honey','panel-yellow4':'Marigold','panel-yellow5':'Lemon Yellow','panel-green1':'Winter Teal','panel-green2':'Sea Green','panel-green3':'Frost Green','panel-green4':'Fresh Grass','panel-green5':'Lemon Green',
            //                     'panel-blue1':'Navy Blue','panel-blue2':'Spanish Blue','panel-blue3':'Royal Blue','panel-blue4':'Azure','panel-blue5':'Sky Blue','panel-violet1':'Russian Violet','panel-violet2':'Spanish Violet','panel-violet3':'Purple','panel-violet4':'Lavender Purple','panel-violet5':'Orchid',
            //                     'panel-grey1':'Charcoal','panel-grey2':'Arsenic','panel-grey3':'Grey','panel-grey4':'Pastel Grey','panel-grey5':'Silver'
            //                     };

            // scope.setHeaderColor = function(){
            //     BootstrapDialog.show({
            //         title:'Set Header Color',
            //         message: function(dialog) {
            //             var $message = $('<div></div>');
            //             var template = commonUtils.getHtmlContent('../Assets/component/templates/chart/setHeaderColor.html');
            //             //$message.load(pageToLoad);
            //             $message.append($compile(template)(scope));
            //             return $message;
            //         },
            //         cssClass:'width542',
            //         onshown:function(dialogRef){
            //             /*
            //             $('.colorPallete').on('click',function(){
            //                 $log.log(this.id);
            //                 $('.colorPreview').addClass('panel-'+this.id);
            //             })
            //             */
            //             var colorname = 'red1'
            //             //$log.log(scope.colorNames['panel-'+colorname]);
                        
            //             scope.previewColor = scope.pinobj.pinHeaderColor;
            //             scope.colorLabel = scope.colorNames[scope.pinobj.pinHeaderColor];

            //             scope.setPreview = function(color){
            //                 var color = $(event.target).attr('id');
            //                 scope.previewColor = 'panel-'+color;
            //                 scope.colorLabel = scope.colorNames['panel-'+color];
            //                 // scope.pinobj.pinHeaderColor = scope.previewColor;
            //             }

            //             scope.setColor = function(){
            //                 scope.pinobj.pinHeaderColor = scope.previewColor;
            //                 dialogRef.close();
            //             }
            //             commonUtils.savedFlag = false;
            //             commonUtils.safeApply(scope,function(){});
            //         }
            //     });
                
            // }

            scope.exportPng = function(){
                //var width = $('#'+scope.pinobj.htmlObj+'_chart').width();
                var width = $(window).width();

                $('#'+scope.pinobj.htmlObj+'_chart div').remove();
                var xml = $('#'+scope.pinobj.htmlObj+'_chart').html();
                //$log.log($('#'+scope.pinobj.pinId+'_chart svg').length)
                
                if($('#'+scope.pinobj.htmlObj+'_chart svg').length){
                    BootstrapDialog.show({
                        title:scope.i18n.png_export,
                        message: function(dialog) {
                            var $message = $('<div align="center"></div>');
                            var template = '<div><canvas id="chart_png"></canvas></div><button class="btn btn-default" ng-click="getPng()">Export</button><!--<button class="btn" ng-click="setWidth()">width</button>--><div class="cl">&nbsp;</div>'
                            //$message.load(pageToLoad);
                            $message.append($compile(template)(scope));
                            return $message;
                        },
                        cssClass : scope.pinobj.pinHeaderColor,
                        onshow: function(dialog) {
                            dialog.$modal.find(".modal-dialog").css("width",(width-50));
                        },
                        onshown:function(dialogRef){
                            
                            //$log.log(xml)
                            canvg(document.getElementById('chart_png'), xml);
                            
                            scope.setWidth = function(){
                                //var c = document.getElementById('chart_png');
                                //c.width= 500;
                                $('#chart_png').css('width','500px');
                            }
                            scope.getPng = function(){

                                var  canvas = document.getElementById('chart_png');
                                var a = document.createElement('a');
                                a.download = "image.png";
                                a.href = canvas.toDataURL('image/png');
                                document.body.appendChild(a);
                                dialogRef.close();

                                a.click();
                                a.remove();

                            }

                        }
                    });
                }                
            }

            //scope.commentCount = 2;

            scope.export = function(extension){
                var data = commonUtils.getQueryData(scope.pinobj,scope.pinobj.paramStr,extension);

                if(data != void 0 && data.returnCode == "SUCCESS"){
                    commonUtils.notif("Pin exported as : "+data.path,"bottom","success",4000,function(){});
                }
                $('#exportToggle').collapse(true);              
            };


            scope.minimize = false;
            scope.minimizeClick = function(){
                
                if($('#'+scope.idd).hasClass("collapse in"))
                    scope.minimize = true;

                else{
                    scope.pinobj.render(scope.pinobj.defaultParamStr);
                    scope.minimize = false;
                }
            }

            scope.zoom = function(){
                var width = $(window).width();
                var height = $(window).height();


                width = width - 50;
                height = height - 200;      
                BootstrapDialog.show({
                    title: this.pinobj.title,
                    message: function(dialog) {
                        var $message = $('<div align="center"></div>');
                        var template = '<div id="open_modal" style="overflow:auto;"></div><div class="cl">&nbsp;</div>'
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    cssClass:scope.pinobj.pinHeaderColor,
                    onshown:function(dialogRef){

                        $(".modal-dialog").css("width","auto");
                        $("#open_modal").css("height",height+"px");
                        //$("#open_modal").css("overflow","auto");
                        scope.pinobj.render(scope.pinobj.paramStr,"open_modal",true);
                        commonUtils.safeApply(scope,function(){});

                        // if(scope.pinobj.chartType=="Table"){
                        //     scope.pinobj.chartProperties[propIdx][3] = rowVal;
                        // }

                    }
                });
            }
            
            var currentSaiku;
            scope.showSaiku = false;

            if(scope.pinobj.chartType.chartName=="Saiku"){
                scope.showSaiku = scope.preview ? true : false; 
                scope.showExport = scope.preview ? false : true; 
                currentSaiku = scope.pinobj.visualization.name;
                scope.pinobj.currentSaiku = scope.pinobj.visualization.name;
            }
            
            scope.swapData = function(){
                
                if(scope.pinobj.currentSaiku != "table"){
                    scope.pinobj.currentSaiku = 'table';
                    scope.pinobj.render(scope.pinobj.defaultParamStr,null,scope.pinobj.htmlObj);
                }
                else{
                    scope.pinobj.currentSaiku = scope.pinobj.visualization.name;
                    scope.pinobj.render(scope.pinobj.defaultParamStr);   
                }
            }

            scope.refreshPin = function(){
               
                $("body").addClass("waiting");
                $timeout(function(){
                    scope.pinobj.render(scope.pinobj.paramStr);
                    $("body").removeClass("waiting");
                    commonUtils.savedFlag = false;
                },200);
                
            }

            scope.condFormat = function(){
                scope.dataHeaders = [];
                var temp = commonUtils.getQueryData(scope.pinobj,scope.pinobj.paramStr).metadata;
                
                
                angular.forEach(temp,function(v,i){
                    if(v.colType=="Numeric" ||v.colType=="Integer" || v.colType=="DECIMAL" || v.colType=="INT" || v.colType == "NUMBER")
                        scope.dataHeaders.push(v.colName);
                })
                

                if(scope.pinobj.conditions.length==0){
                    scope.conditions = [{
                                        "column":scope.dataHeaders[0],
                                        "cond":"<",
                                        "val1":"1000",
                                        "val2":"2000",
                                        "color":"red",
                                        "isBetween":false
                                    }];
                }
                else{
                    scope.conditions = angular.copy(scope.pinobj.conditions);
                }
                

                var mydata =BootstrapDialog.show({
                    title: scope.i18n.conditional_formatting,
                    message: function(dialog) {
                        var $message = $('<div align=center></div>');

                        var template = commonUtils.getHtmlContent('../Assets/component/templates/chart/conditionalFormat.html')
                        
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    draggable: true,
                    closable : false,
                    cssClass : 'width700',
                    onshown: function(dialogRef){
                        
                        scope.addCondition = function(){
                            var temp = {
                                        "column":scope.dataHeaders[0],
                                        "cond":"<",
                                        "val1":"1000",
                                        "val2":"2000",
                                        "color":"red",
                                        "isBetween":false
                                    }
                            scope.conditions.push(temp);
                        }

                        scope.removeCond = function(i){
                            scope.conditions.splice(i,1)
                        }

                        scope.condChange = function(a,b){
                            
                            if(a.cond=="><")
                                a.isBetween = true;
                            else
                                a.isBetween = false;
                            
                        }

                        commonUtils.safeApply(scope,function(){});
                    },

                    buttons: [{
                        label: scope.i18n.apply,
                        cssClass: 'btn-primary',
                        action: function(dialogItself){
                            scope.pinobj.conditions = angular.copy(scope.conditions)
                            
                            dialogItself.close();
                            scope.pinobj.render(scope.pinobj.defaultParamStr);
                            commonUtils.savedFlag = false;
                        },
                            
                    },
                    {
                        label: scope.i18n.cancel,
                        action: function(dialogItself){
                            dialogItself.close();
                            //onCancel();
                        },
                        cssClass: 'btn-danger'
                    }]
                });
            }

            //add url

            scope.addUrl = function(){
                var mydata =BootstrapDialog.show({
                    title: scope.i18n.add_url,
                    message: function(dialog) {
                        var $message = $('<div align=center></div>');

                        var template = commonUtils.getHtmlContent('../Assets/component/templates/chart/pinUrlLink.html')
                        
                        //$message.load(pageToLoad);
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    draggable: true,
                    closable : true,
                    cssClass : 'width500',
                    onshown: function(dialogRef){
                        $(".url_input input[type=text]").focus();
                        scope.saveUrl = function(){
                            if(scope.pinobj.url==null || $.trim(scope.pinobj.url).length==0){
                                scope.pinobj.hasUrl = false;
                                dialogRef.close();
                                scope.pinobj.render(scope.pinobj.defaultParamStr);
                                commonUtils.savedFlag = false;
                                return;
                            }
                            scope.pinobj.hasUrl = true;
                            dialogRef.close();
                            scope.pinobj.render(scope.pinobj.defaultParamStr);
                            commonUtils.savedFlag = false;
                        }
                    }
                });
            }

            scope.isArry = function(val){
                return angular.isArray(val);
            }


            scope.showExpOpt = false;
            scope.exportOver = function(){
                scope.showExpOpt = true;
            }
            scope.exportLeave = function(){
                scope.showExpOpt = false;   
            }

            scope.iconPreview = scope.preview;
            if(!scope.pinobj.dataSource){
                scope.iconPreview = false;
                scope.showExport = false;
            }

            //scope.pngExpEnable = false;
            scope.iscccChart = false;
            scope.isLabel = false;
            scope.isTable = false;

            if(scope.pinobj.chartType.chartName=="CCC"){
                //scope.pngExpEnable = true;
                scope.iscccChart = true;
            }
            else if(scope.pinobj.chartType.chartName=="Label"){
                scope.isLabel = true;
            }
            else if(scope.pinobj.chartType.chartName=="Table"){
                scope.isTable = true;
            }

            
            scope.editTitle = function(){
                scope.editOn = true;
                // $("input.pin-header").focus();
                // $("input.pin-header").select();
            }

            scope.hideEditTitle = function(){
                scope.editOn=false;
            }
            scope.changeTitle = function(){
                commonUtils.savedFlag = false;
            }

            $log.debug(scope.pinobj.pinHeaderColor);
            var html = '<div class="panel pin font{{pinobj.pinFontColor}}" id="pin_{{pinobj.htmlObj}}">';   

            if(commonUtils.editor){
                html = html+'<div class="panel-heading clearfix " >';
            }
                

            else if(scope.preview)
                html = html+'<div class="panel-heading clearfix " ng-show={{pinobj.isHeader}}>';
                
                html = html+'<div class="col-md-7 panel-title" style="padding-left:0px;">';
                            //'<div class="col-md-2 col-sm-2 col-xs-2 pin-icon"><i class="{{pinobj.pinIcon}}" ng-click="setPinIcon()"></i></div>';
                            //'<div class="col-md-2 col-sm-2 col-xs-2 pin-icon"></div>';

            if(commonUtils.editor)
                
                html = html +'<div class="col-md-9 col-sm-7 col-xs-6"><a class="pinTitle" ng-hide="editOn">{{pinobj.title}}</a><i class="editTitleIcon fa fa-pencil" ng-hide="editOn" ng-click="editTitle()"></i><input type="text" class="pin-header form-control" ng-model="pinobj.title" ng-show="editOn" ng-change="changeTitle()" ng-blur="hideEditTitle()"/> </div>';
            else if(scope.preview)
                html = html +'<div class="col-md-9 col-sm-7 col-xs-6 pin-header">{{pinobj.title}}</div>';

            //    html = html +'<h3 id="pinTitle" class="panel-title pull-left" style="padding-top: 3px;padding-bottom:3px;">'+
              //                  '<i class="{{pinobj.pinIcon}}" ng-click="setPinIcon()"></i>'+
                //                '&nbsp;{{pinobj.title}}</h3>';
                
                html = html +'</div>' +
                            '<div class="btn-group pull-right">' +
                                //'<button id="panel_color" class="btn btn-xs btn-default" ng-click="setHeaderColor()" title="Set Color" ng-hide="minimize" ng-if=editor ><i class="fa fa-paint-brush"></i></button>' +
                                '<button id="panel_refresh"  ng-if=editor class="btn btn-xs btn-default" ng-click="refreshPin()" title={{i18n.refresh}} ng-hide="minimize"><i class="fa fa-refresh" aria-hidden="true"></i></button>' +
                                '<button id="panel_condFormat"  ng-if=editor class="btn btn-xs btn-default" ng-click="condFormat()" title={{i18n.conditional_formatting}} ng-show=isTable ><i class="fa fa-table" aria-hidden="true"></i></button>' +
                                '<button id="Panel_Remove"  ng-if=editor class="btn btn-xs btn-default" ng-click="removePin()" title={{i18n.remove_pin}} ng-hide="minimize"><i class="fa fa-times"></i></button>' +
                                '<button id="buttton_url" ng-if=editor class="btn btn-xs btn-default" ng-click="addUrl()" title={{i18n.add_url}} ng-hide="minimize"><i class="fa fa-link" aria-hidden="true"></i></button>' +
                                '<button id="Panel_Properties"  ng-if=editor class="btn btn-xs btn-default" ng-click="chartProperties1()" title={{i18n.pin_settings}} ng-hide="minimize||pinobj.hasUrl"><i class="glyphicon glyphicon-cog"></i></button>' + 
                                // '<button id="Panel_Properties"  ng-if=editor class="btn btn-xs btn-default" ng-click="chartProperties()" title="Pin Settings" ng-hide="minimize"><i class="glyphicon glyphicon-cog"></i></button>' +
                                '<button id="panel_zoom" class="btn btn-xs btn-default" ng-click="zoom()" title={{i18n.zoom}} ng-show=iconPreview ng-if=!'+scope.isLabel+'><i class="fa fa-arrows-alt"></i></button>' +
                                '<button id="Panel_Comment" class="btn btn-xs btn-default" ng-click="pinComments()" title={{i18n.comments}} ng-show=iconPreview><i class="glyphicon glyphicon-comment"></i><div class="comment-count">{{pinobj.commentsCount}}</div></button>' +
                                //'<button id="Panel_Minimize" ng-if="pinobj.minimize" class="btn btn-xs btn-default" data-target="#{{idd}}" data-toggle="collapse" title="Minimize" ng-click="minimizeClick()" ng-show=iconPreview><i class="glyphicon glyphicon-minus"></i></button>' +
                                '<div class="dropdown dropdown-setting" ng-show=iconPreview ng-if=!'+scope.isLabel+'>'+
                                    '<button id="dLabel1" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-xs btn-default">'+
                                        '<i class="fa fa-cog"></i></button>'+
                                    '<ul class="dropdown-menu" aria-labelledby="dLabel1">'+
                                        //'<li ng-click="zoom()" ng-show=iconPreview><a href="#">Zoom</a></li>'+
                                        '<li ng-click="swapData()" ng-show=showSaiku>{{i18n.swap_to_data}}</li>'+
                                        '<li ng-show=showExport ng-mouseover="exportOver()" ng-mouseleave="exportLeave()"><a href="#">{{i18n.export}} ></a>'+
                                            '<ul ng-show="showExpOpt">'+
                                                '<li ng-click="export(\'csv\')">CSV</li>'+
                                                '<li ng-click="export(\'xls\')">Excel</li>'+
                                                '<li ng-click="exportPng()" ng-show="iscccChart">PNG</li>'+
                                            '</ul>'+                                       
                                        '</li>'+
                                        //'<li ng-if="pinobj.minimize" data-target="#{{idd}}" data-toggle="collapse" ng-click="minimizeClick()" ng-show=iconPreview><a href="#">Minimize</a></li>'+
                                    //'<li class="last"><a href="#">.pdf</a></li>'+
                                    '</ul></div>' +
                            '</div>' +
                        '</div>'+
                        
                        '<div id="{{idd}}" class="panel-body collapse in" style="padding:0;"> '+
                            '<div id="{{pinobj.htmlObj}}" class="pin_body" style="width:100%; height:{{pinobj.height}}px;">'+
                                
                            '</div>' +
                        '</div>' +
                    '</div>' 

            element.html(html);
            $compile(element.contents())(scope);
            // $(window).resize(function(){
            //     if($('#open_modal').is(':visible')){
            //     var width = $(window).width();
            //     var height = $(window).height();

            //     width = width - 50;
            //     height = height - 200;

            //     $("#open_modal").css("width",width+"px");
            //     $("#open_modal").css("height",height+"px");
            //     scope.pinobj.render(scope.pinobj.paramStr,pinboard.flexyParameters,"open_modal",true);
            //         pinboard.resizeChart();
            //     }
            // });
        }
    }
}]);  