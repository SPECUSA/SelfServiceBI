function prepareChartDefination (properties,htmlObj,chartType){
    properties.canvas = htmlObj;
    properties.width = $("#"+htmlObj).width();
    
    if(chartType != 'CCCBullet')
        properties.height =  $("#"+htmlObj).height();

    return properties;

}

function CCCArea(){};
CCCArea.prototype = new SSBBaseComponent();
CCCArea.prototype = {
    chartType : "CCCarea",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;

        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCarea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCarea : postExecution");
    } 
}



function CCCBar(){};
CCCBar.prototype = new SSBBaseComponent();
CCCBar.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {


        //console.log(chartProperties);
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();

        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}
function CCCStackedBar(){};
CCCStackedBar.prototype = new SSBBaseComponent();
CCCStackedBar.prototype = {
    chartType : "CCCStackedBar",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}
function CCCStackedBar100(){};
CCCStackedBar100.prototype = new SSBBaseComponent();
CCCStackedBar100.prototype = {
    chartType : "CCCStackedBar100",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}
function CCCBar_with_Line(){};
CCCBar_with_Line.prototype = new SSBBaseComponent();
CCCBar_with_Line.prototype = {
    chartType : "CCCbar",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }

        this.preExecution();
    },
    render: function () {
        
        this.chart = new pvc.BarChart(this.chartDefination).setData(this.data,{}).render();

        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    }
}

function CCCBoxplot(){};
CCCBoxplot.prototype = new SSBBaseComponent();
CCCBoxplot.prototype = {
    chartType : "CCCboxplot",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BoxplotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCboxplot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCboxplot : postExecution");
    } 
}

function CCCBullet(){};
CCCBullet.prototype = new SSBBaseComponent();
CCCBullet.prototype = {
    chartType : "CCCbullet",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj,"CCCBullet");
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }      
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }  
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.BulletChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCbullet : preExecution");
    },
    postExecution: function () {
        //console.log("CCCbullet : postExecution");
    } 
}

function CCCDot(){};
CCCDot.prototype = new SSBBaseComponent();
CCCDot.prototype = {
    chartType : "CCCdot",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.DotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCdot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCdot : postExecution");
    } 
}

function CCCHeatGrid(){};
CCCHeatGrid.prototype = new SSBBaseComponent();
CCCHeatGrid.prototype = {
    chartType : "CCCheat",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.HeatGridChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCheat : preExecution");
    },
    postExecution: function () {
        //console.log("CCCheat : postExecution");
    } 
}

function CCCLine(){};
CCCLine.prototype = new SSBBaseComponent();
CCCLine.prototype = {
    chartType : "CCCline",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.LineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCline : preExecution");
    },
    postExecution: function () {
        //console.log("CCCline : postExecution");
    } 
}

function CCCMetricDot(){};
CCCMetricDot.prototype = new SSBBaseComponent();
CCCMetricDot.prototype = {
    chartType : "CCCmetricDot",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.MetricDotChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCmetricDot : preExecution");
    },
    postExecution: function () {
        //console.log("CCCmetricDot : postExecution");
    } 
}

function CCCPie(){};
CCCPie.prototype = new SSBBaseComponent();
CCCPie.prototype = {
    chartType : "CCCpie",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}
function CCCDonut(){};
CCCDonut.prototype = new SSBBaseComponent();
CCCDonut.prototype = {
    chartType : "CCCDonut",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        //console.log(this.chartDefination);
        this.preExecution();
    },
    render: function () {
        this.chart = new pvc.PieChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCpie : preExecution");
    },
    postExecution: function () {
        //console.log("CCCpie : postExecution");
    } 
}

function CCCStackedArea(){};
CCCStackedArea.prototype = new SSBBaseComponent();
CCCStackedArea.prototype = {
    chartType : "CCCstackedArea",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.StackedAreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedArea : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedArea : postExecution");
    } 
}

function CCCStackedLine(){};
CCCStackedLine.prototype = new SSBBaseComponent();
CCCStackedLine.prototype = {
    chartType : "CCCstackedLine",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.StackedLineChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCstackedLine : preExecution");
    },
    postExecution: function () {
        //console.log("CCCstackedLine : postExecution");
    } 
}

function CCCSunburst(){};
CCCSunburst.prototype = new SSBBaseComponent();
CCCSunburst.prototype = {
    chartType : "CCCsunburst",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.SunburstChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCsunburst : preExecution");
    },
    postExecution: function () {
        //console.log("CCCsunburst : postExecution");
    } 
}

function CCCTreemap(){};
CCCTreemap.prototype = new SSBBaseComponent();
CCCTreemap.prototype = {
    chartType : "CCCtreemap",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.TreemapChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCtreemap : preExecution");
    },
    postExecution: function () {
        //console.log("CCCtreemap : postExecution");
    } 
}

function CCCWaterfall(){};
CCCWaterfall.prototype = new SSBBaseComponent();
CCCWaterfall.prototype = {
    chartType : "CCCwaterfall",
    
    init: function (chartID,data,htmlObj,chartProperties,listenerPins,cat,ser) {

        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.chartDefination =prepareChartDefination(chartProperties,htmlObj);
        if(listenerPins != void 0 && listenerPins.length>0){
            this.chartDefination.clickable = true;
            this.chartDefination.clickAction = function(scene){
                chartClick(listenerPins,scene.vars.category.value.toString().split("~")[0]);
            }    
        }
        else{
            this.chartDefination.clickable = false;
            this.chartDefination.clickAction = function(){}
        }
        this.preExecution();
    },
    render: function () {

        this.chart = new pvc.WaterfallChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
        //console.log("CCCwaterfall : preExecution");
    },
    postExecution: function () {
        //console.log("CCCwaterfall : postExecution");
    } 
}

function Table(){};
Table.prototype = new SSBBaseComponent();
Table.prototype = {
    chartType : "CCCTable",

    init : function(chartID,data,htmlObj,chartProperties,conditions,dimLen){
        this.chartID = chartID;
        this.data = data;
        this.htmlObj = htmlObj;
        this.dimLen = dimLen || 0; 
        this.chartDefination = prepareChartDefination(chartProperties,htmlObj);
        this.conditions = conditions;
        this.preExecution();
    },
    render : function(){

        //console.log(this.chartDefination);
        //console.log(this.conditions)
        var table = "<table class='table table1' width='100%'></table>";

        //console.log(this.data)
        $('#'+this.chartDefination['canvas']).append(table);


        var outputCols = [];
        var len = this.chartDefination['outputCols'].length;
        var cols = this.data.metadata.length;

        for(var a=0;a<len;a++)
            if(this.chartDefination['outputCols'][a] <= cols)
                outputCols.push(this.chartDefination['outputCols'][a] -1);

        //console.log(outputCols);

        if(cols >= this.chartDefination['noOfColumns'])
            cols = this.chartDefination['noOfColumns'];
        //console.log(cols);

        if(outputCols.length > cols)
            while(outputCols.length>cols)
                outputCols.pop();

            else if(outputCols.length < cols){
                var addEle = true;
                for(var a=0;outputCols.length<cols;a++){

                    if(outputCols.length > 0)
                        for(var b=0;b<outputCols.length;b++){
                            addEle = true;
                        //console.log(outputCols[b] +" "+a)
                        if(outputCols[b] == a){
                            //console.log("this is true");
                            addEle = false;
                            break;
                        }
                    }

                    if(addEle)
                        outputCols.push(a);
                //console.log(outputCols);
            }
        }     
        outputCols.sort(function(a, b){return a-b});

        //console.log(outputCols);

        if(outputCols.length==0){
            var p = this.data.metadata.length;
            var i=0;
            while(i<p){
                outputCols.push(i);
                i++;
            }
        }


        var columns = [];
        var colIdx = {}
        for(var i=0;i<this.data.metadata.length;i++){
            for(var j=0;j<outputCols.length;j++){
                if(outputCols[j]==i){
                    colIdx[this.data.metadata[i].colName] = j;
                    if(i>=this.dimLen && (this.data.metadata[i].colType=="Numeric" ||this.data.metadata[i].colType=="Integer" || this.data.metadata[i].colType=="DECIMAL" || this.data.metadata[i].colType=="INT" || this.data.metadata[i].colType == "NUMBER"))
                        columns.push({title:this.data.metadata[i].colLabel || this.data.metadata[i].colName,class:"numeric"})
                    else
                        columns.push({title:this.data.metadata[i].colLabel || this.data.metadata[i].colName})
                }
            }
        }
        var dataSet = [];
        for(var i=0;i<this.data.resultset.length;i++){
            dataSet[i] = [];
            for(var j=0;j<outputCols.length;j++){
                dataSet[i].push(this.data.resultset[i][outputCols[j]]);
            }

        }

        //console.log(colIdx);

        var self = this;
        if(dataSet.length==0){
            $('#'+this.chartDefination['canvas']).append("<div style='text-align:center;font-size:13px;'>No data found</div>");    
            return;
        }
        $('#'+this.chartDefination['canvas']+' .table1').DataTable( {
            data: dataSet,
            columns: columns,
            
            "iDisplayLength": 10,
            rowCallback: function(row, data, index) {
                //console.log(self.conditions);

                for(var i=0;i<self.conditions.length;i++){
                    //console.log(colIdx[self.conditions[i].column]);
                    if(self.conditions[i].cond=="><"){
                        if(eval(data[colIdx[self.conditions[i].column]]+">="+self.conditions[i].val1) && eval(data[colIdx[self.conditions[i].column]]+"<="+self.conditions[i].val2)){
                            //console.log("here")
                            $(row).find('td:eq('+colIdx[self.conditions[i].column]+')').addClass('color'+self.conditions[i].color)
                        }
                    }
                    else{
                        if(eval(data[colIdx[self.conditions[i].column]]+self.conditions[i].cond+self.conditions[i].val1)){
                            //console.log("here")
                            $(row).find('td:eq('+colIdx[self.conditions[i].column]+')').addClass('color'+self.conditions[i].color)
                        }    
                    }
                    
                }

            }

        });
    },
    preExecution : function(){
        this.render();
    },
    postExecution : function(){

    }
}



function parseArray(arr){
    // if(arr.indexOf() !== -1)
        for(var i=0;i<arr.length;i++){
            //console.log(arr[i]);
            if(arr[i] == void 0) arr[i]=null;
        }

    return arr;
}


//---------------------------------------------------- FUSION  ----------------------------------------

function Fusionchart(){};
Fusionchart.prototype = new SSBBaseComponent();
Fusionchart.prototype = {
    init : function(visualization,data,htmlObj,chartProperties,editor,listenerPins,cat,ser,trans){
        this.chartProp = editor;

        var fusionData =[];
        var tempArray = [];
        var category = [];
        var series = [];
        var temp = {};
        var hasSeries = false;
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;


        if(visualization.name=="Pie" || visualization.name=="Donut" || visualization.name=="Bar" || visualization.name=="Column" || visualization.name=="Line" || visualization.name=="Area"){
            if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
            for(var i=0;i<data.resultset.length;i++){
                if(data.resultset[i].length == 3){
                    fusionData.push({"label": data.resultset[i][0]+"-"+data.resultset[i][1], "value":data.resultset[i][2]});
                }else if(data.resultset[i].length == 2){
                    fusionData.push({"label": data.resultset[i][0], "value":data.resultset[i][1]}) 
                }
            }
            this.chartProp.dataSource.data = fusionData;
        }
            else{
                $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
        }
        else if(visualization.name == "Bubble"){
            var xmax = 0;
            var ymax = 0;

            if(data.metadata.length == 5 && colOneTypeCond && (data.metadata[1].colType == "String" || data.metadata[1].colType == "STRING") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER") && (data.metadata[4].colType == "Numeric" || data.metadata[4].colType == "NUMBER")){
                //console.log(data);
                var s1={};
                s1.data = [];

                var temp = {};
                for(var i=0;i<data.resultset.length;i++){
                    

                    if(temp[data.resultset[i][0]]==void 0)
                        temp[data.resultset[i][0]] = [];
                    
                    if(data.resultset[i][2] > xmax)
                    {
                        xmax = data.resultset[i][2];
                    }
                    if(data.resultset[i][3] > ymax)
                    {
                        ymax = data.resultset[i][3];
                    }

                    //temp[data.resultset[i][0]][idx] = [data.resultset[i][2],data.resultset[i][3],data.resultset[i][4]];
                    var objj = {
                        x : data.resultset[i][2],
                        y : data.resultset[i][3],
                        z : data.resultset[i][4],
                        name : data.resultset[i][1]
                    }
                    //temp[data.resultset[i][0]].push([data.resultset[i][2],data.resultset[i][3],data.resultset[i][4],data.resultset[i][1]]);
                    temp[data.resultset[i][0]].push(objj);

                    hasSeries = true;
                }
                                    
                xmax = Math.round((xmax*5)/4);
                ymax = Math.round((ymax*5)/4);
                
                console.log(s1.data.length);
                var len = s1.data.length;

                var first = Math.round(xmax/len);
                for(var i=0;i<len;i++){
                    var labelObjj = {
                        label : first*(i+1),
                        x : first*(i+1)
                    }
                    category.push(labelObjj);
                }

                for(obj in temp){
                    var tempObj = {};
                    tempObj.seriesName = obj;
                    
                    temp[obj] = parseArray(temp[obj]);
                    //if(temp[obj] != null)
                    tempObj.data = temp[obj];
                    series.push(tempObj);
                }

                this.chartProp.dataSource.dataset = series;
                this.chartProp.dataSource.categories = [{
                    category : category
                }];
                this.chartProp.dataSource.chart.xAxisMaxValue = xmax;
                this.chartProp.dataSource.chart.yAxisMaxValue = ymax;

                this.chartProp.dataSource.chart.plotTooltext = "<div id='nameDiv' style='font-size: 14px; border-bottom: 1px dashed #666666; font-weight:bold; padding-bottom: 3px; margin-bottom: 5px; display: inline-block;'>$name :</div>{br}"+data.metadata[2].colName+ " : <b>$xDataValue</b>{br}"+data.metadata[3].colName+ " : <b>$yDataValue</b>{br}"+data.metadata[4].colName+ "  : <b>$zvalue</b>";

            }
            else if(data.metadata.length == 4 && colOneTypeCond && (data.metadata[1].colType == "Numeric" || data.metadata[1].colType == "NUMBER") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER")){
                console.log(data);
                var s1={};

                s1.data = [];
                var len = data.resultset.length;
                for(var i=0;i<len;i++){
 

                    if(data.resultset[i][1] > xmax)
                    {
                        xmax = data.resultset[i][1];
                    }
                    if(data.resultset[i][2] > ymax)
                    {
                        ymax = data.resultset[i][2];
                    }

                    var objj = {
                        x : data.resultset[i][1],
                        y : data.resultset[i][2],
                        z : data.resultset[i][3],
                        name : data.resultset[i][0]
                    }
                    s1.data.push(objj);

                }

                xmax = Math.round((xmax*5)/4);
                ymax = Math.round((ymax*5)/4);
                
                console.log(s1.data.length);
                var len = s1.data.length;

                var first = Math.round(xmax/len);
                for(var i=0;i<len;i++){
                    var labelObjj = {
                        label : first*(i+1),
                        x : first*(i+1)
                    }
                }
                
                this.chartProp.dataSource.dataset = [s1];
                this.chartProp.dataSource.chart.xAxisMaxValue = xmax;
                this.chartProp.dataSource.chart.yAxisMaxValue = ymax;

                this.chartProp.dataSource.chart.plotTooltext = "<div id='nameDiv' style='font-size: 14px; border-bottom: 1px dashed #666666; font-weight:bold; padding-bottom: 3px; margin-bottom: 5px; display: inline-block;'>$name :</div>{br}"+data.metadata[1].colName+ " : <b>$xDataValue</b>{br}"+data.metadata[2].colName+ " : <b>$yDataValue</b>{br}"+data.metadata[3].colName+ "  : <b>$zvalue</b>";
            }
            else{
                $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
        }
        else{
            if(data.metadata.length == 3 && colOneTypeCond){
            for(var i=0;i<data.resultset.length;i++){
                if(data.resultset[i].length == 3){
                    if(tempArray.indexOf(data.resultset[i][1]) == -1){
                        tempArray.push(data.resultset[i][1]);
                        category.push({"label": data.resultset[i][1]})
                    }
                    var idx = tempArray.indexOf(data.resultset[i][1])

                    if(temp[data.resultset[i][0]]==void 0)
                        temp[data.resultset[i][0]] = [];
                    
                    temp[data.resultset[i][0]][idx] = {"value":data.resultset[i][2]};

                    hasSeries = true;
                }
                else{
                    category.push({label:data.resultset[i][0]});
                    fusionData.push({value:data.resultset[i][1]});
                }
            }

            if(hasSeries){
                for(obj in temp){
                    var tempObj = {};
                    tempObj.seriesname = obj;
                    tempObj.data = temp[obj];
                    fusionData.push(tempObj);
                }
                this.chartProp.dataSource.dataset = fusionData
            }
                
            else{
                this.chartProp.dataSource.dataset = [{
                    data : fusionData
                }];  
            }

            this.chartProp.dataSource.categories = [{
                category : category
            }];
        }
            else{
                $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
        }
        

        this.chartProp.events = {
            dataPlotClick : function(eventObj,dataObj){
                chartClick(listenerPins,dataObj.categoryLabel);
            }
        }

        

        // console.log(this.chartProp);
        // console.log(category);
        this.chartProp.renderAt = htmlObj;
//        console.log(JSON.stringify(this.chartProp));
        this.render(this.chartProp);
    },
    render: function (temp) {
        FusionCharts.ready(function () {
            var fChart = new FusionCharts(temp);
            fChart.render();
        });         
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}


//---------------------------------------------------- ECHARTS  ----------------------------------------

function parseEchartsData(data,type,isStack,isArea,trans){
    var legend = []; 
    var categories = []; 
    var series = [];
    var colOneProperVales = ["String","STRING","Date","date"];
    var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;

    var temp = {};
    if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
    for(var i=0;i<data.resultset.length;i++){
        if(data.resultset[i].length == 3){
            if(categories.indexOf(data.resultset[i][1]) == -1)
                categories.push(data.resultset[i][1])
            
            var idx = categories.indexOf(data.resultset[i][1])

            if(temp[data.resultset[i][0]]==void 0)
                temp[data.resultset[i][0]] = [];
            
            temp[data.resultset[i][0]][idx] = data.resultset[i][2];

            hasSeries = true;
        }
        else{
            if(i === 0){var series = [{"type":type,"data":[]}]}
            categories.push(data.resultset[i][0]);
            series[0].data.push(data.resultset[i][1]);
            isStack && (series[0].stack = true);
            isArea && (series[0].itemStyle = {normal: {areaStyle: {type: 'default'}}});
        }
    }

    for(obj in temp){
        var tempObj = {};
        legend.push(obj)
        tempObj.type = type;
        tempObj.name = obj;
        isStack && (tempObj.stack = true);
        isArea && (tempObj.itemStyle = {normal: {areaStyle: {type: 'default'}}});
        temp[obj] = parseArray(temp[obj]);
        tempObj.data = temp[obj];
        series.push(tempObj);
    }
    
    return [categories,series,legend];
    }
    else{
        $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
        return;
    }

}   

function EchartsBar(){};
EchartsBar.prototype = new SSBBaseComponent();
EchartsBar.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        
        var legend = []; 
        var categories = []; 
        var temp = {};
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        
        var series = [];
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",false,false,trans);


        //var eCharSeriesLine =  series;
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

        
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.yAxis[0].data = chartData[0];
        tempPropertiesForEciter.legend.data  = chartData[2];
        tempPropertiesForEciter.series = chartData[1];

        //console.log(tempPropertiesForEciter);
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
    },
    render: function () {
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsStackedBar(){};
EchartsStackedBar.prototype = new SSBBaseComponent();
EchartsStackedBar.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",true,false,trans);
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);


        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.yAxis[0].data = chartData[0];
        tempPropertiesForEciter.legend.data  = chartData[2];
        tempPropertiesForEciter.series = chartData[1];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsColumn(){};
EchartsColumn.prototype = new SSBBaseComponent();
EchartsColumn.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",false,false,trans);

        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

    
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsStackedColumn(){};
EchartsStackedColumn.prototype = new SSBBaseComponent();
EchartsStackedColumn.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",true,false,trans);
        chartData[1][0].stack = true;
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
    
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}


function EchartsLine(){};
EchartsLine.prototype = new SSBBaseComponent();
EchartsLine.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",false,false,trans);
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}



function EchartsStackedLine(){};
EchartsStackedLine.prototype = new SSBBaseComponent();
EchartsStackedLine.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
    var colOneProperVales = ["String","STRING","Date","date"];
    var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",true,false,trans);
        chartData[1][0].stack = true;
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
   
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsPie(){};
EchartsPie.prototype = new SSBBaseComponent();
EchartsPie.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
       
        var fusiondata =[];
        var legend = []; 
        var categories = []; 
        var temp = {};
        var tempArray = [];
        var temp2 = [];
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        for(var i=0;i<data.resultset.length;i++){
            if(data.resultset[i].length === 3){
                if(tempArray.indexOf(data.resultset[i][1]) == -1){
                        tempArray.push(data.resultset[i][1]);
                        categories.push(data.resultset[i][1]);
                    }
                if(temp[data.resultset[i][0]])
                    temp[data.resultset[i][0]].push(data.resultset[i][2]);
                else{
                    temp[data.resultset[i][0]] = [];
                    temp[data.resultset[i][0]].push(data.resultset[i][2]);
                }
            }
            else{
                var tempObj = {value : data.resultset[i][1], name : data.resultset[i][0]};
                temp2.push(tempObj);
                if(tempArray.indexOf(data.resultset[i][0]) == -1){
                        tempArray.push(data.resultset[i][0]);
                        categories.push(data.resultset[i][0]);
                    }
            }
        }
        for(obj in temp){
            var tempObj = {};
            legend.push(obj)
            tempObj.type = 'pie';
            tempObj.name = obj;
            tempObj.stack = true,
            tempObj.data = temp[obj];
            fusiondata.push(tempObj);
        }
        if(temp2.length > 0){
            legend.push("series")
            fusiondata.push({type:'pie',stack:true,name:"series",data:temp2})
        }
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);


        
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.legend.data  = categories;
        tempPropertiesForEciter.series = fusiondata;

        tempPropertiesForEciter.polar =[{
             indicator : [
             { text: '1'},
             { text: '2 '},
             { text: '3 '},
             { text: '4'},
             { text: '5'}
             ]
        }],
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsArea(){};
EchartsArea.prototype = new SSBBaseComponent();
EchartsArea.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",false,true,trans);

        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}



function EchartsStackedArea(){};
EchartsStackedArea.prototype = new SSBBaseComponent();
EchartsStackedArea.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",true,true,trans);
       
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
        
        var tempPropertiesForEciter =  chartProp;
        
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    }
}

/*amar-2017-feb-01*/


function EchartsBubble(){};
EchartsBubble.prototype = new SSBBaseComponent();
EchartsBubble.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){

        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
        var tempPropertiesForEciter =  chartProp;

        var fusionData =[];
        var tempArray = [];
        var category = [];
        var series = [];
        var legend = [];
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;

        var temp = {};
        var hasSeries = false;

        if(data.metadata.length == 5 && colOneTypeCond && (data.metadata[1].colType == "String" || data.metadata[1].colType == "STRING") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER") && (data.metadata[4].colType == "Numeric" || data.metadata[4].colType == "NUMBER")){
            //console.log(data);
            var s1={};
            s1.data = [];

            var temp = {};
            for(var i=0;i<data.resultset.length;i++){
                if(temp[data.resultset[i][0]]==void 0)
                    temp[data.resultset[i][0]] = [];
                
                temp[data.resultset[i][0]].push([data.resultset[i][2],data.resultset[i][3],data.resultset[i][4],data.resultset[i][1]]);

                hasSeries = true;
            }

            for(obj in temp){
                var tempObj = {};
                tempObj.name = obj;

                temp[obj] = parseArray(temp[obj]);
                //if(temp[obj] != null)
                tempObj.type = "scatter";

                tempObj.data = temp[obj];
               
                legend.push(obj);
                var tempData = tempObj.data;
                tempObj.symbolSize =  function(tempData) {
                    return Math.sqrt(tempData[2]) / 2e1;
                }
                series.push(tempObj);
                //series.type = "scatter";
            }
             console.log(series);

            tempPropertiesForEciter.series = series;
            tempPropertiesForEciter.legend.data  = legend;

        }
        else if(data.metadata.length == 4 && colOneTypeCond && (data.metadata[1].colType == "Numeric" || data.metadata[1].colType == "NUMBER") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER")){
            console.log(tempPropertiesForEciter);
            var s1={};

            s1.data = [];
            var len = data.resultset.length;
            for(var i=0;i<len;i++){

                s1.data.push([data.resultset[i][1],data.resultset[i][2],data.resultset[i][3],data.resultset[i][0]]);
            }
            
            s1.name = data.metadata[0].colName;
            tempPropertiesForEciter.legend.data  = [data.metadata[0].colName];
            s1.type = "scatter";
            console.log(s1);
            var tempData = s1.data;
            s1.symbolSize =  function(tempData) {
                return Math.sqrt(tempData[2]) / 2e1;
            }
            s1.label = {};
            s1.label.emphasis = {};

            s1.label.emphasis.show = "true";
            s1.label.emphasis.position = "top";
            s1.label.emphasis.formatter = function (s1) {
                return s1.data[3];
            }

            tempPropertiesForEciter.series = [s1];
            tempPropertiesForEciter.xAxis.name = data.metadata[0].colName || data.metadata[0].colName;
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
        myChart.setOption(tempPropertiesForEciter);
    },
    render: function () {
        
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    }
}

//---------------------------------------------------- CHART JS 2 ----------------------------------------


function ChartJs2Bar(){};
ChartJs2Bar.prototype = new SSBBaseComponent();
ChartJs2Bar.prototype = {
    init : function(chartId,data,htmlObj,chartProperties){
        var fusiondata =[];
        for(var i=0;i<data.resultset.length;i++){
            fusiondata.push({"label": data.resultset[i][0], "value":data.resultset[i][1]}) 
        }
            var options = {};
            var data = {
                    labels: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
                    datasets: [{
                      label: 'apples',
                      data: [12, 19, 3, 17, 6, 3, 7],
                      backgroundColor: "rgba(153,255,51,0.4)"
                    }, {
                      label: 'oranges',
                      data: [2, 29, 5, 5, 2, 3, 10],
                      backgroundColor: "rgba(255,153,0,0.4)"
                    }]
                };

                var ctx = document.getElementById(htmlObj);
                    var myChart = new Chart(ctx,{
                type: 'line',
                data: data,
                options: options
                })
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}