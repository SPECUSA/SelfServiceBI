angular.module('pinboard')
.filter('numkeys', function() {
  return function(object) {
    return Object.keys(object).length;
  }
});
