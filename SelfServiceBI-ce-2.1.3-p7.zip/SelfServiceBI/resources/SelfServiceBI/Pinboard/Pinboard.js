angular.module('pinboard', ['commonUtilModule', 'messagesModule', 'translationModule', 'colorpicker.module', 'ui.bootstrap', 'gridstack-angular', 'ngSanitize', 'ui.select', 'daterangepicker', 'ng.jsoneditor', 'ui.router', 'oc.lazyLoad'])
angular.module('pinboard')
    .config(['$logProvider', '$ocLazyLoadProvider', '$stateProvider', '$urlRouterProvider', function ($logProvider, $ocLazyLoadProvider, $stateProvider, $urlRouterProvider) {
        $logProvider.debugEnabled(false);
        var commonFiles = [];

        var editorFiles = commonFiles.concat(['components/edit/pinboardEditor.controller.js', 'shared/pinEdit/pinEdit.directive.js', 'shared/activePin/activePin.directive.js']);

        var previewFiles = commonFiles.concat(['components/preview/pinboardViewer.controller.js', 'https://cdnjs.cloudflare.com/ajax/libs/canvg/1.4/rgbcolor.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/stackblur-canvas/1.4.1/stackblur.min.js', 'https://cdnjs.cloudflare.com/ajax/libs/canvg/1.4/canvg.min.js']);
        //Config For ocLazyLoading
        $ocLazyLoadProvider.config({
            'debug': true, // For debugging 'true/false'
            'events': true, // For Event 'true/false'
            'modules': [{ // Set modules initially
                name: 'edit', // State1 module
                serie: true,
                files: editorFiles
            }, {
                name: 'preview', // State2 module
                serie: true,
                files: previewFiles
            }]
        });

        //Config/states of UI Router
        $stateProvider
            .state('pinboardEdit', {
                url: "/edit",
                templateUrl: "components/edit/pinboardEdit.html",
                controller: "pinboardEditorCtr",
                resolve: {
                    loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        return $ocLazyLoad.load('edit'); // Resolve promise and load before view 
                    }]
                }
            })
            .state('pinboardPreview', {
                url: "/preview",
                templateUrl: "components/preview/pinboardPreview.html",
                controller: "pinboardViewerCtr",
                resolve: {
                    loadMyCtrl: ['$ocLazyLoad', function ($ocLazyLoad) {
                        return $ocLazyLoad.load('preview'); // Resolve promise and load before view 
                    }]
                }
            });

        $urlRouterProvider.otherwise("/edit");
    }])

function fireChange(param) {

    for (var i = 0; i < param.length; i++) {
        angular.element($("#" + param[i].pinId)).scope().fireChange(param[i].param, param[i].value);
    }

}

function chartClick(pins, cValue) {

    for (var i = 0; i < pins.length; i++) {
        angular.element($("#" + pins[i].pinId)).scope().chartClick(cValue, pins[i].param);
    }
}