function parseEchartsData(data,type,isStack,isArea,trans){
    var legend = []; 
    var categories = []; 
    var series = [];
    var colOneProperVales = ["String","STRING","Date","date"];
    var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;

    var temp = {};
    if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
    for(var i=0;i<data.resultset.length;i++){
        if(data.resultset[i].length == 3){
            if(categories.indexOf(data.resultset[i][1]) == -1)
                categories.push(data.resultset[i][1])
            
            var idx = categories.indexOf(data.resultset[i][1])

            if(temp[data.resultset[i][0]]==void 0)
                temp[data.resultset[i][0]] = [];
            
            temp[data.resultset[i][0]][idx] = data.resultset[i][2];

            hasSeries = true;
        }
        else{
            if(i === 0){var series = [{"type":type,"data":[]}]}
            categories.push(data.resultset[i][0]);
            series[0].data.push(data.resultset[i][1]);
            isStack && (series[0].stack = true);
            isArea && (series[0].itemStyle = {normal: {areaStyle: {type: 'default'}}});
        }
    }

    for(obj in temp){
        var tempObj = {};
        legend.push(obj)
        tempObj.type = type;
        tempObj.name = obj;
        isStack && (tempObj.stack = true);
        isArea && (tempObj.itemStyle = {normal: {areaStyle: {type: 'default'}}});
        temp[obj] = parseArray(temp[obj]);
        tempObj.data = temp[obj];
        series.push(tempObj);
    }
    
    return [categories,series,legend];
    }
    else{
        $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
        return;
    }

}   

function EchartsBar(){};
EchartsBar.prototype = new SSBBaseComponent();
EchartsBar.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        
        var legend = []; 
        var categories = []; 
        var temp = {};
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        
        var series = [];
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",false,false,trans);


        //var eCharSeriesLine =  series;
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

        
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.yAxis[0].data = chartData[0];
        tempPropertiesForEciter.legend.data  = chartData[2];
        tempPropertiesForEciter.series = chartData[1];

        //console.log(tempPropertiesForEciter);
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
    },
    render: function () {
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsStackedBar(){};
EchartsStackedBar.prototype = new SSBBaseComponent();
EchartsStackedBar.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",true,false,trans);
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);


        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.yAxis[0].data = chartData[0];
        tempPropertiesForEciter.legend.data  = chartData[2];
        tempPropertiesForEciter.series = chartData[1];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsColumn(){};
EchartsColumn.prototype = new SSBBaseComponent();
EchartsColumn.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",false,false,trans);

        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

    
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsStackedColumn(){};
EchartsStackedColumn.prototype = new SSBBaseComponent();
EchartsStackedColumn.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"bar",true,false,trans);
        chartData[1][0].stack = true;
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
    
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}


function EchartsLine(){};
EchartsLine.prototype = new SSBBaseComponent();
EchartsLine.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",false,false,trans);
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}



function EchartsStackedLine(){};
EchartsStackedLine.prototype = new SSBBaseComponent();
EchartsStackedLine.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
    var colOneProperVales = ["String","STRING","Date","date"];
    var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",true,false,trans);
        chartData[1][0].stack = true;
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
   
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsPie(){};
EchartsPie.prototype = new SSBBaseComponent();
EchartsPie.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
       
        var fusiondata =[];
        var legend = []; 
        var categories = []; 
        var temp = {};
        var tempArray = [];
        var temp2 = [];
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        for(var i=0;i<data.resultset.length;i++){
            if(data.resultset[i].length === 3){
                if(tempArray.indexOf(data.resultset[i][1]) == -1){
                        tempArray.push(data.resultset[i][1]);
                        categories.push(data.resultset[i][1]);
                    }
                if(temp[data.resultset[i][0]])
                    temp[data.resultset[i][0]].push(data.resultset[i][2]);
                else{
                    temp[data.resultset[i][0]] = [];
                    temp[data.resultset[i][0]].push(data.resultset[i][2]);
                }
            }
            else{
                var tempObj = {value : data.resultset[i][1], name : data.resultset[i][0]};
                temp2.push(tempObj);
                if(tempArray.indexOf(data.resultset[i][0]) == -1){
                        tempArray.push(data.resultset[i][0]);
                        categories.push(data.resultset[i][0]);
                    }
            }
        }
        for(obj in temp){
            var tempObj = {};
            legend.push(obj)
            tempObj.type = 'pie';
            tempObj.name = obj;
            tempObj.stack = true,
            tempObj.data = temp[obj];
            fusiondata.push(tempObj);
        }
        if(temp2.length > 0){
            legend.push("series")
            fusiondata.push({type:'pie',stack:true,name:"series",data:temp2})
        }
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);


        
        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.legend.data  = categories;
        tempPropertiesForEciter.series = fusiondata;

        tempPropertiesForEciter.polar =[{
             indicator : [
             { text: '1'},
             { text: '2 '},
             { text: '3 '},
             { text: '4'},
             { text: '5'}
             ]
        }],
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}

function EchartsArea(){};
EchartsArea.prototype = new SSBBaseComponent();
EchartsArea.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",false,true,trans);

        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);

        var tempPropertiesForEciter =  chartProp;
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        this.chart = new pvc.AreaChart(this.chartDefination).setData(this.data,{}).render();
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}



function EchartsStackedArea(){};
EchartsStackedArea.prototype = new SSBBaseComponent();
EchartsStackedArea.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;
        if(data.metadata.length == 3 && colOneTypeCond){
        var chartData = parseEchartsData(data,"line",true,true,trans);
       
        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
        
        var tempPropertiesForEciter =  chartProp;
        
        tempPropertiesForEciter.xAxis[0].data = chartData[0];
        tempPropertiesForEciter.series = chartData[1];
        tempPropertiesForEciter.legend.data  = chartData[2];
        myChart.setOption(tempPropertiesForEciter);
        myChart.on('click', function (params){
            chartClick(listenerPins,params.name);
        });
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }

    },
    render: function () {
        
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    }
}

/*amar-2017-feb-01*/


function EchartsBubble(){};
EchartsBubble.prototype = new SSBBaseComponent();
EchartsBubble.prototype = {
    init : function(chartId,data,htmlObj,chartProperties,chartProp,listenerPins,cat,ser,trans){

        var chart = document.getElementById(htmlObj);
        var myChart = echarts.init(chart);
        var tempPropertiesForEciter =  chartProp;

        var fusionData =[];
        var tempArray = [];
        var category = [];
        var series = [];
        var legend = [];
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;

        var temp = {};
        var hasSeries = false;

        if(data.metadata.length == 5 && colOneTypeCond && (data.metadata[1].colType == "String" || data.metadata[1].colType == "STRING") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER") && (data.metadata[4].colType == "Numeric" || data.metadata[4].colType == "NUMBER")){
            //console.log(data);
            var s1={};
            s1.data = [];

            var temp = {};
            for(var i=0;i<data.resultset.length;i++){
                if(temp[data.resultset[i][0]]==void 0)
                    temp[data.resultset[i][0]] = [];
                
                temp[data.resultset[i][0]].push([data.resultset[i][2],data.resultset[i][3],data.resultset[i][4],data.resultset[i][1]]);

                hasSeries = true;
            }

            for(obj in temp){
                var tempObj = {};
                tempObj.name = obj;

                temp[obj] = parseArray(temp[obj]);
                //if(temp[obj] != null)
                tempObj.type = "scatter";

                tempObj.data = temp[obj];
               
                legend.push(obj);
                var tempData = tempObj.data;
                tempObj.symbolSize =  function(tempData) {
                    return Math.sqrt(tempData[2]) / 2e1;
                }
                series.push(tempObj);
                //series.type = "scatter";
            }
             console.log(series);

            tempPropertiesForEciter.series = series;
            tempPropertiesForEciter.legend.data  = legend;

        }
        else if(data.metadata.length == 4 && colOneTypeCond && (data.metadata[1].colType == "Numeric" || data.metadata[1].colType == "NUMBER") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER")){
            console.log(tempPropertiesForEciter);
            var s1={};

            s1.data = [];
            var len = data.resultset.length;
            for(var i=0;i<len;i++){

                s1.data.push([data.resultset[i][1],data.resultset[i][2],data.resultset[i][3],data.resultset[i][0]]);
            }
            
            s1.name = data.metadata[0].colName;
            tempPropertiesForEciter.legend.data  = [data.metadata[0].colName];
            s1.type = "scatter";
            console.log(s1);
            var tempData = s1.data;
            s1.symbolSize =  function(tempData) {
                return Math.sqrt(tempData[2]) / 2e1;
            }
            s1.label = {};
            s1.label.emphasis = {};

            s1.label.emphasis.show = "true";
            s1.label.emphasis.position = "top";
            s1.label.emphasis.formatter = function (s1) {
                return s1.data[3];
            }

            tempPropertiesForEciter.series = [s1];
            tempPropertiesForEciter.xAxis.name = data.metadata[0].colName || data.metadata[0].colName;
        }
        else{
            $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
            return;
        }
        myChart.setOption(tempPropertiesForEciter);
    },
    render: function () {
        
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    }
}
function parseArray(arr){
    // if(arr.indexOf() !== -1)
        for(var i=0;i<arr.length;i++){
            //console.log(arr[i]);
            if(arr[i] == void 0) arr[i]=null;
        }

    return arr;
}
