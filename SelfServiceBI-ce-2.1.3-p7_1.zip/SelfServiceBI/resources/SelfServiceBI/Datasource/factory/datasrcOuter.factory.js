angular.module('dataSourceModule').
factory('datasrcOuter',['commonUtils','$log',function(commonUtils,$log){
    var datasrcOuter = function(){
        this.datasrcName = "";
        this.datasrcEntry = [];
        this.position = "";
    }


    datasrcOuter.prototype.init = function(){
        this.datasrcName = "";
        this.datasourceEntry = [];   
        this.position = "";
    }
    return datasrcOuter;
}])