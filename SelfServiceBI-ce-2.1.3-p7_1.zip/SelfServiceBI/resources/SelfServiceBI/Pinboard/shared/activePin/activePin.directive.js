angular.module('pinboard')
.directive("activePin",['pinboard','commonUtils','translationService','Pin','$log','$compile','$window','$timeout',function(pinboard,commonUtils,translationService,Pin,$log,$compile,$window,$timeout){
    return {
        restrict : 'E',
        scope : {
            'pin'  : '=',
            'idd' : '@'
        },
        templateUrl : 'shared/activePin/activePin.view.html',
        link : function(scope,element){
            
            scope.i18n = translationService.trans;

            $(".pinEditor").css("display","block");
            $(".pinEditor").css("width","100%");

            
            
            scope.dtsrcTypes = [
                
                {
                    name:"CDA Library",
                    ext:"cda"
                },
                {
                    name:"Saiku Analytics",
                    ext:"saiku"
                }
            ]

            //init
            scope.pinMessage = scope.i18n.pinMessage;
            scope.showChartProp = false;
            scope.showEditor = false;
            scope.editorOn = false;
            scope.showDatasrc = false;
            scope.noData = true;
            scope.isMap = false;

            scope.pinobj = new Pin();
            scope.pinobj = angular.copy(scope.pin);
            scope.pinobj.htmlObj = "pinEdit"; 
            scope.pinobj.height = 300;

            scope.pinobj.dtsrcType =  scope.pinobj.dtsrcType.ext==void 0 ? scope.dtsrcTypes[0]:scope.pinobj.dtsrcType;


            //add-remove listener
            scope.addListenerPin = function(indx){                
                scope.bindPins.push(scope.totalPins[indx])
                scope.totalPins.splice(indx,1)

            }
            scope.removeListenerPin = function(indx){
                scope.totalPins.push(scope.bindPins[indx]);
                scope.bindPins.splice(indx,1);
            }


            //pin listener
            scope.loadListenerPins = function(){

                //pin listener
                if(scope.pinobj.listenerPins == undefined){
                    scope.pinobj.listenerPins = [];
                }

                scope.totalPins = [];
                angular.forEach(pinboard.pinLists,function(v,i){
                    if(v.id != scope.pinobj.pinId){   
                        for(var param in v.pin[0].defaultParamStr){
                            scope.totalPins.push({pinId:v.pin[0].pinId,title:v.pin[0].title,param:param});
                        }
                    }
                });
                scope.bindPins = [];
                scope.bindPins = angular.copy(scope.pinobj.listenerPins);

                
                var i=0;
                while(i<scope.totalPins.length){
                    var hasEntry = false;
                    for(var j=0;j<scope.bindPins.length;j++){
                        if(scope.bindPins[j].pinId==scope.totalPins[i].pinId && scope.bindPins[j].param==scope.totalPins[i].param){
                            scope.bindPins[j].title = scope.totalPins[i].title;
                            hasEntry = true;
                            break; 
                        }
                    }
                    if(hasEntry)
                        scope.totalPins.splice(i,1);
                    else
                        i++;
                }
            }
            
            scope.loadDatasource = function(){
                scope.pinobj.dataSources = [];
                for(i=0;i<pinboard.datasourceList.length;i++){
                    if(i>0)
                        scope.showDatasrc = true;

                    if(pinboard.datasourceList[i].indexOf('.cda')>0){
                        scope.pinobj.dtsrcType = {
                            name:"CDA Library",
                            ext:"cda"
                        }
                        scope.isSaiku = false;
                        
                    }
                        
                    else if(pinboard.datasourceList[i].indexOf('.saiku')>0){
                        scope.pinobj.dtsrcType = {
                            name:"Saiku Analytics",
                            ext:"saiku"
                        }
                        scope.isSaiku = true;
                        
                    }
                        
                      
                    scope.pinobj.dataSources.push(pinboard.datasourceList[i]);
                }

                if(scope.pinobj.dataSource == undefined || scope.pinobj.dataSource.length <= 0 || scope.pinobj.dataSources.indexOf(scope.pinobj.dataSource)<0){
                    scope.pinobj.dataSource = scope.pinobj.dataSources[0];
                }
               
                if(scope.pinobj.dataSources.length>0)
                    scope.dtsrcChanged();
                

                
                if(scope.pinobj.contentType=='chart'){
                    scope.populateChartLib(scope.pinobj.dtsrcType.ext);
                    // scope.initFunc();
                }
                else{
                    scope.loadVisualization();
                }
            }

            //datasource type changed
            scope.browseExtChange = function(){
                scope.isSaiku = false;
                
                if(scope.pinobj.dtsrcType.ext=="saiku"){
                    scope.isSaiku = true;
                    scope.populateDatasrc(scope.pinobj.dtsrcType.ext);
                    scope.populateChartLib(scope.pinobj.dtsrcType.ext);    
                }
                else{
                    scope.populateDatasrc(scope.pinobj.dtsrcType.ext);
                    scope.populateChartLib(scope.pinobj.dtsrcType.ext);
                }

            }

            //chart-table-label
            scope.selectType = function(a){
                $log.debug("Select type");
                scope.isMap = false;
                scope.pinobj.contentType = a.currentTarget.value;
                
                if(scope.pinobj.contentType=='chart' && scope.pinobj.chartTypes==void 0)
                    scope.populateChartLib(scope.pinobj.dtsrcType.ext);
                   
                else if(scope.pinobj.contentType!='chart' && scope.pinobj.dtsrcType.ext!='saiku'){
                     scope.pinobj.chartType = {chartName : scope.pinobj.contentType};
                }
                else{
                    scope.pinobj.chartType = pinboard.defaultChartLib
                }

                
                scope.loadVisualization();
                scope.populateDataTable();
            
            }

            
            //populate datasource as per extension
            scope.populateDatasrc = function(filext){
                scope.pinobj.dataSources = [];
                for(i=0;i<pinboard.datasourceList.length;i++){
                    if(pinboard.datasourceList[i].indexOf('.'+filext)>0)
                        scope.pinobj.dataSources.push(pinboard.datasourceList[i]);
                }
                
                if(scope.pinobj.dataSource == undefined || scope.pinobj.dataSource.length <= 0 || scope.pinobj.dataSources.indexOf(scope.pinobj.dataSource)<0){
                    scope.pinobj.dataSource = scope.pinobj.dataSources[0];
                }
               
                if(scope.pinobj.dataSources.length>0)
                    scope.dtsrcChanged();
            }

            //check datasource ext and populate further parameters
            scope.dtsrcChanged = function(flag){
                if(scope.pinobj.dtsrcType.ext=='cda'){
                    scope.populateDAId();
                }
                else if(flag && scope.pinobj.dtsrcType.ext=="saiku")
                    scope.generateChart();   
            }

            scope.populateDAId = function(){
                scope.pinobj.dataAccessIds = [];
                for(var i=0;i<pinboard.dataAccessList.length;i++){
                    if(scope.pinobj.dataSources!=null && pinboard.dataAccessList[i].dbsrc==scope.pinobj.dataSource)
                        scope.pinobj.dataAccessIds = angular.copy(pinboard.dataAccessList[i].daIds)
                }

                if(scope.pinobj.dataAccessId == undefined || scope.pinobj.dataAccessId.length <= 0){
                    scope.pinobj.dataAccessId = scope.pinobj.dataAccessIds[0];    
                }
                
                scope.pinobj.dataAccessIds.indexOf(scope.pinobj.dataAccessId)<0 && (scope.pinobj.dataAccessId = scope.pinobj.dataAccessIds[0]);
                //scope.pinobj.dataAccessId && scope.dataAccessIdChanged();

                scope.pinobj.dataAccessId && scope.getParams(scope.pinobj.dataAccessId);
                scope.pinobj.dataAccessId && scope.populateDataTable();
            }
            
            scope.dataAccessIdChanged = function(){
                
                scope.getParams(scope.pinobj.dataAccessId);
                if((scope.pinobj.chartType.chartName=="Table" || scope.pinobj.chartType.chartName =="Label") || (scope.pinobj.chartType && scope.pinobj.chartType.chartDatasource))
                    scope.generateChart();
                scope.populateDataTable();
            }


            scope.populateChartLib = function(filext){
                scope.pinobj.chartTypes = [];
                for(var i=0; i<commonUtils.components.selfServiceBI.length; i++) {
                    commonUtils.components.selfServiceBI[i].chartDatasource.indexOf(filext)>-1 && scope.pinobj.chartTypes.push(commonUtils.components.selfServiceBI[i]);
                    if(commonUtils.components.selfServiceBI[i].chartName == scope.pinobj.chartType.chartName)
                        scope.pinobj.chartType = commonUtils.components.selfServiceBI[i];
                };

                if(!commonUtils.equals(pinboard.defaultChartLib.chartDatasource,scope.pinobj.chartType.chartDatasource))
                    scope.pinobj.chartType = pinboard.defaultChartLib;

                scope.chartTypeChanged();
            }

            scope.searchVisuals = function(){
                
                for(var i=0;i<scope.pinobj.visualizations.length;i++){
                    if(scope.pinobj.visualization == void 0){
                        scope.pinobj.visualization = scope.pinobj.visualizations[i];
                        return i;
                    }
                    else if(scope.pinobj.visualizations[i].name==scope.pinobj.visualization.name){
                        scope.pinobj.visualization = scope.pinobj.visualizations[i]; 
                        return i;
                    }
                        
                }
                return false;
            }
            scope.loadVisualization = function(){
                if(scope.pinobj.contentType!='chart'){
                    scope.pinobj.visualization = {
                        name : scope.pinobj.contentType
                    }
                    scope.editorOn = false;
                    scope.visualChanged();
                    return;
                }
                
                var indx = commonUtils.getIndex(scope.pinobj.chartType.chartName);
                var visuals= commonUtils.components.selfServiceBI[indx].properties.files.charts;
                
                scope.pinobj.visualizations = [];
                for(var i=0;i<visuals.length;i++){
                    scope.pinobj.visualizations.push(visuals[i]);
                }

                !scope.searchVisuals() && (scope.pinobj.visualization = scope.pinobj.visualizations[0]);
                if(commonUtils.components.selfServiceBI[indx].properties.files.editorProperties)
                    scope.editorOn = true;
                else
                    scope.editorOn = false;

                    
                if(commonUtils.components.selfServiceBI[indx].properties.files.chartProperties=="true"?true:false)
                    scope.visualChanged();
                
            }

            scope.visualChanged = function(){
                scope.hideProperties();
                scope.pinobj.visualization && scope.getProperties();
                scope.generateChart();
            }
            
            scope.prevVisual = function(){
               var i = scope.searchVisuals();
               var l = scope.pinobj.visualizations.length;
               i>0 ? (scope.pinobj.visualization = scope.pinobj.visualizations[i-1]) : scope.pinobj.visualization = scope.pinobj.visualizations[l-1];
               scope.visualChanged();
            }

            scope.nextVisual = function(){
                var i = scope.searchVisuals();
                var l = scope.pinobj.visualizations.length;
                i < l-1 ? (scope.pinobj.visualization = scope.pinobj.visualizations[i+1]) : scope.pinobj.visualization = scope.pinobj.visualizations[0];
                scope.visualChanged();
            }

            scope.getProperties = function(){
                //$("#primaryProperties").html("");
                var chartName = scope.pinobj.chartType.chartName==void 0 ? scope.pinobj.chartType : scope.pinobj.chartType.chartName;
                
                var tempProps = commonUtils.readJSONFile('../Assets/component/'+chartName+'/'+chartName+'.'+scope.pinobj.visualization.name+'.properties.json');
                var l = tempProps.length;
                

                var propList = scope.pin.chartProperties;
                if(scope.pinobj.chartProperties.length==0 || ( tempProps.length!=scope.pinobj.chartProperties.length && scope.pinobj.visualization.name!=scope.pin.visualization.name) || scope.pin.chartProperties.length==0){
                    scope.pinobj.chartProperties = angular.copy(tempProps);   
                }
                else if(tempProps.length==scope.pinobj.chartProperties.length && scope.pinobj.visualization.name==scope.pin.visualization.name){
                    scope.pinobj.chartProperties = scope.pin.chartProperties;
                }
                else{
                    for(var i=0;i<l;i++){
                        var j=0;
                        while(j<propList.length){
                            if(tempProps[i][0]==propList[j][0]){
                                tempProps[i][3] = propList[j][3];
                                propList.splice(j,1);
                            }
                            else
                                j++;
                        }
                    }
                    scope.pinobj.chartProperties = angular.copy(tempProps);
                }
                
                if(scope.editorOn){
                    var editorData = commonUtils.readJSONFile('../Assets/component/'+chartName+'/'+chartName+'.'+scope.pinobj.visualization.name+'.editor.json');
                    
                    if(scope.pinobj.propJson==void 0 || scope.pinobj.chartType.chartName!=scope.pin.chartType.chartName || scope.pinobj.visualization.name!=scope.pin.visualization.name)
                        //scope.pinobj.propJson = JSON.stringify(editorData, null, 4);
                        scope.pinobj.propJson = editorData;
                    else
                        scope.pinobj.propJson = scope.pin.propJson;
                }
                else{
                    scope.pinobj.propJson = commonUtils.parseProperties(chartName,scope.pinobj.chartProperties,scope.pinobj.propJson);
                }
            }
            scope.hideProperties = function(){
                scope.showChartProp = false;
            }
            scope.loadProperties = function(flag){
                if(flag){
                    $("#primaryProperties").html("");
                    
                    var l = scope.pinobj.chartProperties.length;
                    //$log.log(scope.properties);
                    for(i=0;i<l;i++){
                        commonUtils.propertiesHTMLComponent(scope.pinobj.chartProperties[i][0],scope.pinobj.chartProperties[i][6],scope.pinobj.chartProperties[i][1],scope.pinobj.chartProperties[i][2],scope.pinobj.chartProperties[i][3],scope.pinobj.chartProperties[i][4],scope.pinobj.chartProperties[i][5],"primaryProperties",scope);
                    }
                    scope.showEditor = false;
                    scope.showChartProp = true;
                }
                else{
                    scope.showChartProp = false;
                    scope.showEditor = true;
                }
            }

            scope.applyProperties = function(){
                var l = scope.pinobj.chartProperties.length;
                
                for(var i=0;i<l;i++){
                    //$log.log(scope.properties[i][2]);
                    if(scope.pinobj.chartProperties[i][2] == 'switch' || scope.pinobj.chartProperties[i][2] == 'combo'){
                        temp = $('#'+scope.pinobj.chartProperties[i][0]).bootstrapSwitch('state');
                        scope[scope.pinobj.chartProperties[i][0]] = temp;
                    }

                    scope.pinobj.chartProperties[i][3] = scope[scope.pinobj.chartProperties[i][0]];
                }


                if(scope.showChartProp){
                    for(var i=0;i<l;i++){
                        //$log.log(scope.properties[i][2]);
                        if(scope.pinobj.chartProperties[i][2] == 'switch' || scope.pinobj.chartProperties[i][2] == 'combo'){
                            temp = $('#'+scope.pinobj.chartProperties[i][0]).bootstrapSwitch('state');
                            scope[scope.pinobj.chartProperties[i][0]] = temp;
                        }
                        //scope.pinobj.chartProperties[i] = scope.properties[i];
                        scope.pinobj.chartProperties[i][3] = commonUtils.parsePropertiesDataType(scope[scope.pinobj.chartProperties[i][0]],scope.pinobj.chartProperties[i][1]);
                        //$log.debug(scope.pinobj.chartProperties[i]);
                    }
                    scope.pinobj.propJson = commonUtils.parseProperties(scope.pinobj.chartType.chartName,scope.pinobj.chartProperties,scope.pinobj.propJson);
                }
                    
                else{
                    scope.pinobj.propJson = JSON.parse(JSON.stringify(scope.pinobj.propJson)); 
                    for(var i=0;i<l;i++){
                        scope.pinobj.chartProperties[i] = commonUtils.writeProps(scope.pinobj.chartProperties[i],scope.pinobj.propJson)
                    }
                }
                
                scope.showChartProp = false;
                scope.showEditor = false;
                
                scope.generateChart();
            }

            scope.chartTypeChanged = function(){
                scope.loadVisualization();   
            }
            scope.getParams = function(dataAccessId){
                var listParams = [];
                scope.listParameters = [];
                uri = encodeURIComponent(scope.pinobj.dataSource);
                listParams = commonUtils.getDatasourceData(scope.pinobj.dataSource,dataAccessId,"parameter");
                
                if(!listParams){
                    url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/listParameters?path=/'+uri+'&dataAccessId='+dataAccessId ;
                    listParams = commonUtils.synchronousJsonCall(url);
                    commonUtils.setDatasourceData(scope.pinobj.dataSource,dataAccessId,listParams,"parameter");
                }
                scope.listParameters = listParams;
            }
            scope.getParamString = function(){
                var param = {};
                var  l = scope.listParameters.resultset.length;
                for(var i=0;i<l;i++){
                    paramObj = scope.listParameters.resultset[i];
                    param[paramObj[0]] = paramObj[2];
                }
                return param;
            }
            scope.populateDataTable = function(){

                var data = commonUtils.getQueryData(scope.pinobj,scope.pinobj.paramStr);

                $("#editPinData").html("<thead></thead><tbody></tbody>");

                var columns = [];
                var colIdx = {}
                var thead = '<tr>',
                    tbody = '';
                var n = data.metadata.length;
                var l = data.resultset.length>10?10:data.resultset.length;
                for(var i=0;i<l;i++){
                    tbody+="<tr>"
                    for(var j=0;j<n;j++){
                        if(i==0) thead+="<th>"+ (data.metadata[j].colLabel || data.metadata[j].colName )+"</th>";
                        tbody+="<td>"+(data.resultset[i][j]==null?"":data.resultset[i][j])+"</td>";
                    }
                    tbody+="</tr>"
                }
                thead+='</tr>';
                

                $("#editPinData thead").append(thead);
                $("#editPinData tbody").append(tbody);
                scope.noData = false;

            }
            scope.generateChart = function(){
                if(scope.pinobj.dataSource==void 0 || scope.pinobj.dataSource=="")
                    return;

                
                if(scope.pinobj.chartType.chartDatasource == 'saiku'){
                    url = location.protocol +"//"+location.host+"/pentaho/plugin/saiku/api/cde-component/export/saiku/json?formatter=flattened&file="+scope.pinobj.dataSource;
                    var data = commonUtils.readJSONFile(url)
                    
                    scope.pinobj.dataAccessId = "";
                    scope.pinobj.paramStr = {};
                    scope.pinobj.paramStr = data.query.parameters;
                    scope.pinobj.defaultParamStr = data.query.parameters;
                    scope.pinobj.currentSaiku = scope.pinobj.visualization.name;  
                    
                }
                // else{
                //     scope.pinobj.defaultParam = scope.getParamString();
                //     scope.pinobj.param = scope.getParamString();
                // }
                
                $("body").addClass("waiting");
                $timeout(function(){
                    scope.pinobj.render(scope.pinobj.paramStr,scope.pinobj.htmlObj,true);
                    $("body").removeClass("waiting");
                },50);
                
            }

            scope.closePinEdit = function(){
                $(".pinEditor").css("display","none");
                pinboard.activePin.pop();
                
                $window.scrollTo(0, $("#"+scope.pin.htmlObj).offset().top);
                return;
            }
            scope.saveToPin = function(){
                
                scope.pinobj.listenerPins = angular.copy(scope.bindPins);

                scope.pinobj.htmlObj = angular.copy(scope.pin.htmlObj);
                delete scope.pinobj.chartTypes;
                scope.pin = scope.pinobj;
                
                if(scope.pinobj.dataSource==void 0){
                    $(".pinEditor").css("display","none");
                    pinboard.activePin.pop();
                    return;
                }
                    
                for(var i=0;i<pinboard.pinLists.length;i++){
                    if(pinboard.pinLists[i].id==scope.pinobj.pinId){
                        var height = pinboard.pinLists[i].pin[0].height; 
                        pinboard.pinLists[i].pin[0] = angular.copy(scope.pin);
                        pinboard.pinLists[i].pin[0].height = height;

                        $(".pinEditor").css("display","none");
                        pinboard.activePin.pop();
                        $window.scrollTo(0, $("#"+scope.pin.htmlObj).offset().top);
                        return;
                    }
                }   
            }
            scope.loadDatasource();
            scope.loadListenerPins();
            $timeout(function(){
                $window.scrollTo(0, 0);
                commonUtils.savedFlag = false;
                commonUtils.safeApply(scope,function(){});
            },0)
            $window.scrollTo(0, 0);
        }
    }

}])