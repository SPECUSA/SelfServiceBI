angular.module('commonUtilModule')
.service('commonUtils',['Messages','translationService','$http','$log','$compile','$timeout','$location',function(Messages,translationService,$http,$log,$compile,$timeout,$location){
    this.debugApplication =true;

    this.mode = "pinboard" //pin/pinboard
    this.isPinboard = true;
    this.editor = true;
    this.savedFlag = false;
    this.savedFileFlag = false;
    this.propertiesSaved = false;
    this.isNull = true;
    this.notificationDelay = 4000;
    this.notificationType = "growl";
    this.components = null;
    var self = this;


    this.version = "2.1.3";
    this.buildVersion  = 3.1;

    this.hasEmail = false;
    this.online = false;

    this.CdaUrl = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery';

    this.keyDialog = "../Assets/component/templates/other/verifyKey.html";
    this.errorDialog = "../Assets/component/templates/other/errorKey.html";

    var self = this;
    this.i18n = translationService.getTranslation(null,"../");
    
    this.colorNames = {'panel-red1':'Wine Red','panel-red2':'Cherry Red','panel-red3':'Imperial Red','panel-red4':'Pure Red','panel-red5':'Orange Red','panel-orange1':'Orange','panel-orange2':'Spanish Orange','panel-orange3':'Amber','panel-orange4':'Peachy Orange','panel-orange5':'Apricot',
                    'panel-yellow1':'Sunglow','panel-yellow2':'Gold','panel-yellow3':'Honey','panel-yellow4':'Marigold','panel-yellow5':'Lemon Yellow','panel-green1':'Winter Teal','panel-green2':'Sea Green','panel-green3':'Frost Green','panel-green4':'Fresh Grass','panel-green5':'Lemon Green',
                    'panel-blue1':'Navy Blue','panel-blue2':'Spanish Blue','panel-blue3':'Royal Blue','panel-blue4':'Azure','panel-blue5':'Sky Blue','panel-violet1':'Russian Violet','panel-violet2':'Spanish Violet','panel-violet3':'Purple','panel-violet4':'Lavender Purple','panel-violet5':'Orchid',
                    'panel-grey1':'Charcoal','panel-grey2':'Arsenic','panel-grey3':'Grey','panel-grey4':'Pastel Grey','panel-grey5':'Silver'
                    };

    this.parseParams = function(param,chartType){
        if(typeof param!="object"){
            return;
        }

        var paramStr = "";
        for(key in param){
            var values = "";
            if(typeof param[key]=="number"){
                values = [param[key]];
            }
            if(typeof param[key]=="object" && param[key].startDate){
                if(typeof param[key].startDate!="object"){
                    param[key].startDate = moment(param[key].startDate);
                    param[key].endDate = moment(param[key].endDate);
                }

                values = [param[key].startDate.format('YYYY-MM-DD'),param[key].endDate.format('YYYY-MM-DD')];
            }
            else if(typeof param[key]=="object")
                values = param[key];
            else
                values = param[key].split(",");

            
            if(param[key].startDate == null)
                paramStr += '&param'+key+'='+"\""+values.join("\",\"")+"\"";
            else{
                param[key] = values.join();
                paramStr += '&param'+key+"="+param[key];
            }
            //paramStr += '&param'+key+'='+"\""+values.join("\",\"")+"\"";

        }
        return paramStr;
    }



    this.datasourceData = [];

    this.getPinsParameter = function(dataSource,dataAccessId){

        var tempParamData = self.getDatasourceData(dataSource,dataAccessId,"parameter");

        
        if(tempParamData.resultset != void 0){
            tempParamData = tempParamData.resultset;

            var params = [];
            for(var i=0;i<tempParamData.length;i++){
                params.push(tempParamData[i][0])
            }

            
            return params;
        }
        else{
            return [];
        }
    }
    

    this.writeObj = function(prop,obj){
        var path = prop[7].split(".");

        if(path.length==1)
            obj[path[0]] = prop[3]; 
        if(path.length==2)
            obj[path[0]][path[1]] = prop[3];
        else if(path.length==3)
        {
            if(obj.chart.type == "bullet" && path[2] == "color")
            {
                var plotBonds = path[1].substring(10, 11);
                obj[path[0]]['plotBands'][plotBonds][path[2]] =  prop[3]; 
            } else {
            obj[path[0]][path[1]][path[2]] = prop[3];
            }
        }
        else if(path.length==4)
            obj[path[0]][path[1]][path[2]][path[3]] = prop[3];

        return obj; 
    }

    this.writeProps = function(prop,obj){
        //obj = JSON.parse(obj);
        var path = prop[7].split(".");
        if(path.length==1)
            prop[3] = obj[path[0]];
        else if(path.length==2)
            prop[3] = obj[path[0]][path[1]];
        else if(path.length==3)
        {
            if(obj.chart.type == "bullet" && path[2] == "color")
            {
                var plotBonds = path[1].substring(10, 11);
                prop[3] = obj[path[0]]['plotBands'][plotBonds][path[2]];
            } else {
            prop[3] = obj[path[0]][path[1]][path[2]];
            }
        }
            
        else if(path.length==4)
            prop[3] = obj[path[0]][path[1]][path[2]][path[3]];

        return prop; 
    }
    this.parsePropsCCC = function(properties){
        var props = {};

        for(var i = 0;i < properties.length;i++){
            if(properties[i][2] == "javascript" && properties[i][3] != undefined && properties[i][3].length > 0)
                props[properties[i][0]]= eval("Demo = " +properties[i][3]);
                
            else
                props[properties[i][0]]= properties[i][3];
        }
        return props;
    }

    this.parsePropsChart = function(props,obj){
        for(var i=0;i<props.length;i++){
                obj = this.writeObj(props[i],obj);
        }
        
        return obj;
    }
    this.parseProperties = function(chartType,properties,editor){
        var props = {};
        if(chartType=="CCC" || chartType=="Table" || chartType=="Label" || chartType=="Saiku")
            props = this.parsePropsCCC(properties);        
        else 
            props = this.parsePropsChart(properties,editor);
        return props;
    }
    this.encryptData = function(data,key){
        var ciphertext = CryptoJS.AES.encrypt(data, key);
        return ciphertext.toString();
    }
    this.decryptData = function(data,key){
        var bytes  = CryptoJS.AES.decrypt(data, key);
        var plaintext = bytes.toString(CryptoJS.enc.Utf8);
        return plaintext;
    }

    this.getDatasourceData = function(dataSource,dataAccessId,selection){
        var data = null;
        var flag1 = false;
        $.each(self.datasourceData,function(i1,v1){
            if(v1.datasourceFile==dataSource){
                $.each(v1.dataAccess,function(i2,v2){
                    if(v2.dataAccessId==dataAccessId && v2[selection]!=null){
                        flag1 = true;
                        data = v2[selection];
                        return false;
                    }
                })
                if(flag1)
                    return false;
            }
        })

        if(flag1)
            return data;
        return false;
    }

    this.setDatasourceData = function(dataSource,dataAccessId,data,selection){
        var flag1 = false;
        var flag2 = false;
        var idx1 = null;
        var idx2 = null;

        
        $.each(self.datasourceData,function(i1,v1){
            idx1 = i1;
            if(v1.datasourceFile==dataSource){
                flag1 = true;
                $.each(v1.dataAccess,function(i2,v2){

                    idx2 = i2;
                    if(v2.dataAccessId==dataAccessId){
                        flag2 = true;
                        
                        return false;
                    }
                    else{
                        idx1 = i1;
                        flag2 = false;
                    }
                })
                if(flag2)
                    return false;
            }
            else{
                flag1 = false;
            }
        });

        if(!flag1){
            var temp = {
                "datasourceFile": dataSource,
                dataAccess : [
                    {
                        "dataAccessId" : dataAccessId,
                        "parameter" : "",
                        "data" : ""
                    }
                ]

            }
            temp.dataAccess[0][selection] = data;

            self.datasourceData.push(temp)
        }
        else if(flag1 && !flag2){
            var temp = {
                "dataAccessId" : dataAccessId,
                "parameter" : "",
                "data" : ""
            }
        
            temp[selection] = data;
            self.datasourceData[idx1].dataAccess.push(temp)
        }
        else if(flag1 && flag2){
            
            
            self.datasourceData[idx1].dataAccess[idx2][selection] = data;   
        }
    }

    this.getParameterByName = function(name){
        // name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        // var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        //     results = regex.exec(location.search);
        // return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
        
        var results = $location.search()[name];
        return results==void 0 ? "" :results;
    };

    this.equals = function(a,b){
        if(a==void 0 || b==void 0)
            return false;
        var is_same = (a.length == b.length) && a.every(function(element, index) {
            return element === b[index]; 
        });

        return is_same;
    }

    this.getQueryData = function(pinobj, paramStr, exportData){

        var dtsrcType = pinobj.dtsrcType.ext,
            dataSource = pinobj.dataSource,
            dataAccessId = pinobj.dataAccessId,
            queryData = pinobj.queryData;


        var url,data;
        if(dtsrcType=="cda"){
            url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/' + dataSource + '&dataAccessId=' + dataAccessId + this.parseParams(angular.copy(paramStr)) + '&outputIndexId=1';

            if(exportData){
                url+='&outputType='+exportData;
                window.open(url);
            }
            else{
                data = this.readJSONFile(url);
                return data;
            }
        }
        return data;
        
    }
    
    this.synchronousJsonCall = function (url, method, data) {
        var jsonData;
        jQuery.ajax({
            url:    url,
            data:   data,
            type :  method,
            DataType:'jsonp',
            success:function(result) {
                jsonData = result;
            },
            async:  false
        });

        return jsonData;
    };

    this.postJsonCall = function(url, method, data){
        var jsonData;

        jQuery.ajax({
            url:    url,
            data:   data,
            type :  method,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success:function(result) {
                jsonData = result;
                
            },
            error : function(jqXHR,textStatus,error){
                jsonData = textStatus;
                
            },
            async:  false
        });

        return jsonData;
    }

    this.readJSONFile = function (url) {
        var jsonData;
        $.ajax({
            type: 'GET',
            url: url,
            async: false,
            dataType: 'json',
            data: null,
            success:function(response){
                jsonData = response;
            },
            error:function(response){
                jsonData = "";
            }
        });
        return jsonData;
    };
    this.getHtmlContent = function(url){
        var htmlData;
        jQuery.ajax({
            url : url,
            data: null,
            async : false,
            type : 'GET',
            success : function(result){
                htmlData = result;
            }
        });
        return htmlData;
    }
    this.getUserName = function(){
        var username;
        jQuery.ajax({
            url:"/pentaho/plugin/SelfServiceBI/api/getUsername",
            type :"GET",
            async:false,
            success:function(result) {
                username = JSON.parse(result);
            },
            complete: function (obj,textStatus) {
            }
        });            
        return username;    
    }
    var result = self.getUserName();
    this.username = result.userName;
    this.hasEmail = result.hasEmail;
    this.online = result.online;
    if(result.online)
    this.updateVersion = result.version.split(".").join("") > this.version.split(".").join("");
    

    this.getJson = function(obj){
        return JSON.stringify(obj)
    }

    this.saikuInit = function(){
        var saikuSession = self.synchronousJsonCall("/pentaho/plugin/saiku/api/session?_=1460976493562",'GET',null);
        saikuSession = self.synchronousJsonCall("/pentaho/plugin/saiku/api/admin/discover?_=1460370515397",'GET',null);
    }
    /*
    this.getTableName = function(){
        var tableData;
        $.ajax({
            type: "POST",
            url:"/pentaho/plugin/SelfServiceBI/api/getTableData",
            data:JSON.stringify({
                   "dbType":"MYSQL",
                    "dbUser":"pentaho",
                    "dbPassword":"pentaho",
                    "dbHost":"10.37.55.192",
                    "dbName":"pentahosalesdashboard",
                    "dbPort":"3306" 
             }),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(result,status,xhr) {
                tableData = result
            },
            error: function (request, status, errorThrown) {
                alert("Error");
            },
            complete: function (obj,textStatus) {
            },
            async : false
            
        });

        return tableData;
    }

    */
    this.chartTypes = function(contentName){

        for(var i=0; i<this.components.selfServiceBI.length; i++) {
            if(this.components.selfServiceBI[i].chartName == contentName)
                return this.components.selfServiceBI[i];
        };
    }

    this.getDtsrcType = function(ext){
        var dtsrcTypes = {
            "cda" : {
                name:"CDA Library",
                ext:"cda"
            },
            "flexy" : {
                name: "Flexy Cube",
                ext:"flexy"
            },
            "saiku" : {
                name:"Saiku Analytics",
                ext:"saiku"
            }
        }


        return dtsrcTypes[ext];
    }
    this.getTableName = function(jndi) {
        
        var tableName;
        $.ajax({
            type: "GET",
            url:"/pentaho/plugin/SelfServiceBI/api/getTableData?connectionName="+jndi,
            data:null,
            async : false,
            success: function(result,status,xhr) {
                tableName = result;
            },
            error : function(jqXHR, textStatus, errorThrown){
                tableName = "Error"
            },
            complete: function (obj,textStatus) {
            }
        });

        return tableName;
     }       
            
            
    this.getFieldName = function(jndi,schemaName,tableName)
    {
        var param = {
            "connectionName" : jndi,
            "tableName":tableName,
            "schemaName":schemaName
        }; 

        var fieldName;
        jQuery.ajax({
            url:"/pentaho/plugin/SelfServiceBI/api/getTableField",
            data:param,
            type :"POST",
            DataType:'json',
            async : false,
            success:function(result) {
                fieldName = result;
            },
            complete: function (obj,textStatus) {
            }
         });
         return fieldName; 
    }

    filePathValidation = function(path,ext){

        if(path == null || path == undefined || path.length <1)
        {
            //return Messanges.onInvalidFileName;
            return false;
        }
        else
        {
            var tempArray = path.split(".");
            if(tempArray.length <2)
                return false;
            else
            {
                var tempExt=tempArray[tempArray.length-1];

                if(tempExt == ext)
                    return true;
                else
                    return false;
            }
        }
    };
    
    this.saveDialogBox = function(dialogTitle,ext,onSave,onCancel){
        var selectedFile="";
        var selectedFolder="";
        var data=BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog) {
                var $message = $('<div class="modal-form"><div id="container_id" class="JqueryContainer"></div><div class="cl15"></div><div class="form-group"><div class="col-lg-4 col-md-4 col-sm-4 form-group-left">'+self.i18n.file_name+'</div><div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><input type="text" name="fileInput" class="form-control" id="fileInput"  value="" /></div></div>'+
                                '<div class="cl5"></div></div><div class="cl"></div>'+
                                '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                                '<span class="sr-only">'+self.i18n.error+':</span>'+
                                self.i18n.error_valid_file_name+'</div>');
                return $message;
            },
            draggable: true,
            closable : true,
            cssClass : 'browse-dialog',
            onshown: function(dialogRef)
            {
                $('#container_id').fileTree({
                    root: '/',
                    script: "/pentaho/plugin/SelfServiceBI/api/explore"+ "?fileExtensions="+ ext+"&access=create",
                    expandSpeed: 1,
                    collapseSpeed: 1,
                    multiFolder: false
                }, function(file) {
                    $("#fileInput").val(file);
                    selectedFile = $("#fileInput").val();
                });
                // event listeners
                $('#container_id').on('filetreeexpand', function (e, data)
                {
                    selectedFolder = data.rel;
                    $("#fileInput").val(selectedFolder);
                });
            },
            buttons: [{
                id: 'btn-save',
                label: this.i18n.save,
                action: function(dialogItself){
                    //var valid = filePathValidation($("#fileInput").val(),ext);
                    var path = $('#fileInput').val();
                    //$log.log(path);
                    /*
                    function isNotAlphaNumeric(code){
                        $log.log(code);
                        if (!(code > 47 && code < 58) && !(code > 64 && code < 91) && !(code > 96 && code < 123))
                          return true;
                        return false;
                    }
                    */
                    var len = path.length;
                    if(path == undefined || path.length < 1 || path.charAt(len-1) == '/'/* || isNotAlphaNumeric(path.charAt(path.length-1)) */){
                        $("#errorMsg").show();
                        return;
                    }
                    var valid = $('#fileInput').val().toLowerCase().search('.'+ext);
                    //$log.log($('#fileInput').val().toLowerCase())
                    //$log.log(valid);

                    if(valid < 0)
                    {
                        dialogItself.close();
                        //$log.log($("#fileInput").val()+'.'+ext);
                        onSave($("#fileInput").val()+'.'+ext);
                    }
                    else
                    {
                        dialogItself.close();
                        onSave($("#fileInput").val());
                    }


                    
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: this.i18n.cancel,
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    };

    this.openDialogBox = function(dialogTitle,ext,onSave,onCancel){
        var selectedFile="";
        var selectedFolder="";
        var data=BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog) {
                var $message = $(
                '<div class="modal-form"><div id="container_id" class="JqueryContainer"></div><div class="cl15"></div><div class="form-group"><div class="col-lg-4 col-md-4 col-sm-4 form-group-left">'+self.i18n.file_name+'</div><div class="col-lg-8 col-md-8 col-sm-8 form-group-right"><input type="text" name="fileInput" class="form-control" id="fileInput"  value="" /></div></div><div class="cl"></div>'+
                '</div><div class="cl5"></div>'+
                '</div><div class="cl"></div>'+
                '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                    '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                   '<span class="sr-only">'+self.i18n.error+':</span>'+
                    self.i18n.error_valid_file_name+'</div>'
                );
                return $message;
            },
            draggable: true,
            closable : true,
            cssClass : 'browse-dialog',
            onshown: function(dialogRef)
            {
                $('#container_id').fileTree({
                    root: '/',
                    script: "/pentaho/plugin/SelfServiceBI/api/explore"+ "?fileExtensions="+ ext+"&access=create",
                    expandSpeed: 1,
                    collapseSpeed: 1,
                    multiFolder: false
                }, function(file) {
                    $("#fileInput").val(file);
                    selectedFile = $("#fileInput").val();
                });
                // event listeners
                $('#container_id').on('filetreeexpand', function (e, data)
                {
                    selectedFolder = data.rel;
                    $("#fileInput").val(selectedFolder);
                });
            },
            buttons: [{
                id: 'btn-save',
                label: self.i18n.open,
                action: function(dialogItself){
                    var valid = filePathValidation($("#fileInput").val(),ext);
                    if(valid)
                    {
                        dialogItself.close();
                        onSave($("#fileInput").val());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: self.i18n.cancel,
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    };


    this.comments = function(scope,title,usercomments,commentCount,callBack){
        scope.username = self.username;
        //var username = self.username;
        //$log.log(username);
        scope.usercomments = usercomments;
        scope.commentCount = commentCount;
        //$log.log(scope.pinobj.comments);
        BootstrapDialog.show({
            title : 'Comments - '+title,
            message : function(dialog) {
                var $message = $('<div style="overflow:auto;"></div>');
                //var pageToLoad = scope.pageToLoad;
                var template =  '<div class="modal-form"><div id="comment-area" class="form-control comment-display"></div><div class="form-group comment-input">'+
                                '<div class="col-lg-11 col-md-11 col-sm-11 comment-input-left">'+
                                    '<textarea id="comment" class="form-control textarea" ng-model="comment" style="height:68px"/></div>'+
                                '<div class="col-xs-1 col-sm-1 col-md-1 col-lg-1" style="padding-left:0px;">'+
                                    '<button class="btn btn-md btn-blue comment-send" title="Make comment" ng-click="makeComment()" ng-disabled="disableComment"><i class="glyphicon glyphicon-send"></i></button>'+
                                '</div></div>';

                //'<div class="modal-form"><div class="col-md-12 comment-search"><div class="c-search c-seach-icon col-md-1"><i class="glyphicon glyphicon-search"></i></div><div class="c-search col-md-11"><input type="text" class="form-control c-search-input" /></div></div>'+
                $message.append($compile(template)(scope));
                return $message;
            },
            closable : true,
            cssClass : 'width500',
            onshown : function(dialogRef){
                scope.disableComment = false;
                scope.addComment = function(username,comment,date,time,repeat,sameDate,owner){
                    var addNewComment = '';
                    //$log.log(sameDate);

                    if(!sameDate){
                        addNewComment +='<div class="comment-date">'+date+'</div>';
                    }


                    if(owner){
                        if(!repeat)
                            addNewComment = addNewComment+'<div class="comment-user">You</div>';
                        
                        addNewComment = addNewComment+ '<div class="comment-comment"><pre>'+comment+'</pre><span class="comment-time">'+time+'</span></div>';
                    }
                    else{
                        if(!repeat)
                            addNewComment = addNewComment+'<div class="comment-user-v">'+username+'</div>'
                        addNewComment = addNewComment + '<div class="comment-comment-v"><pre>'+comment+' </pre><span class="comment-time">'+time+'</span></div>';
                    }
                    $('#comment-area').append(addNewComment);

                }

                scope.makeComment = function(){
                    if(scope.comment == undefined || scope.comment.length < 1){
                        return;
                    }
                    else if(scope.comment.length>500){
                        scope.disableComment = true;
                        self.notif(scope.i18n.notif_comment_char_count_exceeds+scope.comment.length,"topRight","error",2500,function(){});
                        $timeout(function(){
                            scope.disableComment = false;
                        },3000)
                        return;
                    }


                    var d = new Date();
                    var day = d.getDate();
                    var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                    var month = months[d.getMonth()];
                    var year = d.getFullYear();
                    var hour = d.getHours();
                    var format = "am"
                    var mins = d.getMinutes();
                    if(mins.toString().length == 1){
                        mins = '0'+mins;
                    }

                    if(hour>12){
                        hour-=12;
                        format = 'pm';
                    }
                    var date = month+' '+day+','+year;
                    var time = hour+':'+mins+' '+format;

                    var repeat = false;
                    var sameDate = false;
                    var owner = true;
                    var username = scope.username;
                    var comment = $.trim(scope.comment);
                    //$log.log(comment);

                    scope.usercomments.push([scope.username,comment,date,time]);
                    
                    var len = scope.usercomments.length;

                    if(len>1 && (scope.usercomments[len-1][2]== scope.usercomments[len-2][2])){
                        sameDate = true;
                    }

                    if(sameDate && len>1 && (scope.usercomments[len-1][0] == scope.usercomments[len-2][0])){
                        repeat = true;
                    }
                    
                    scope.addComment(scope.username,comment,date,time,repeat,sameDate,owner);

                    if(scope.commentCount == undefined)
                        scope.commentCount = scope.usercomments.length;

                    if(scope.commentCount=='')
                        scope.commentCount=1;
                    else if((isNaN(scope.commentCount) && scope.usercomments.length >10) || scope.commentCount>=10)
                        scope.commentCount='10+';
                    else if(isNaN(scope.commentCount) && scope.usercomments.length <11)
                        scope.commentCount = scope.usercomments.length;                        
                    else
                        scope.commentCount++;
                    /*
                    var addNewComment = '<div class="comment-user">'+username+'</div><div class="comment-comment"><pre>'+comment+'</pre></div>';
                    $('#comment-area').append(addNewComment);
                    */
                    scope.comment = "";
                    $('#comment').focus();
                    self.savedFlag = false;
                    //$log.log(scope.commentCount)

                    //var mode = self.getParameterByName("mode").split("?")[0];
                    //$log.log(commonUtils.getParameterByName("mode").split("?")[0]);


                    self.safeApply(scope,function(){});

                    //$log.log("make comment");
                }


                $('#comment').focus();
                for(var i=0;i<scope.usercomments.length;i++){
                    var repeat = false;
                    var sameDate = false;
                    var owner = false;


                    if(i>0 && (scope.usercomments[i][2]== scope.usercomments[i-1][2])){
                        //$log.log(scope.pinobj.comments[len-1][2]+" "+scope.pinobj.comments[len-2][2])   
                        sameDate = true;
                    }
                    

                    if(sameDate && i>0 && (scope.usercomments[i][0]== scope.usercomments[i-1][0]))
                        repeat = true;
                    
                    if(scope.usercomments[i][0]==scope.username)
                        owner = true;

                    scope.addComment(scope.usercomments[i][0],scope.usercomments[i][1],scope.usercomments[i][2],scope.usercomments[i][3],repeat,sameDate,owner);

                    //var addOldComments = '<div class="comment-user-v">'+scope.pinobj.comments[i][0]+'</div><div class="comment-comment-v"><pre>'+scope.pinobj.comments[i][1]+'</pre></div>';
                    //$('#comment-area').append(addOldComments);
                }                       
            }
        });
    }


    this.BootstrapConfirm = function(msg,userResult){
        //$log.log(msg);
        //$log.log("hey there")
        BootstrapDialog.confirm({
            title: 'Confirmation',
            message: msg,
            closable: true, // <-- Default value is false
            btnOkClass: 'btn-lg btn-primary',
            btnCancelClass: 'btn-default btn-lg btn-danger', // <-- If you didn't specify it, dialog type will be used,
            callback: function(result) {
                userResult(result);
            }
        });
    };

    this.removeElements = function (text, selector) {
        var wrapped = $("<div>" + text + "</div>");
        wrapped.find(selector).remove();
        return wrapped.html();
    };

     this.btnPinSaikuBrowse = function(title,ext,fileTxtbox,getData){
        var self = this;

        function onOpen(path){
           getData(path);
        }
        function onCancel(dialogItself){}
        this.openDialogBox(title,ext,onOpen,onCancel);
    };

    this.colorDialog = function(dialogTitle,colorArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);

                var template =  '<div class="colorTableWrapper">'+
                                '<div id="colorTable">'+
                                '</div>'+
                                '<div class="form-inline"><div class="label label-add-color">Add Color </div>'+
                                '<input class="form-control" type="text" id="inputColor" ng-model="inputColor" colorpicker="hex">'+
                                '<button class="btn btn-default" id="addColor" ng-click="addColor()"><i class="glyphicon glyphicon-plus"></i></button></div>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'color-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                var length = colorArray.length;
                if(colorArray.length != 0){
                    for(i=0;i<colorArray.length;i++){

                        var temp =  '<div id="row'+i+'" class="form-inline" style="padding-bottom:5px;">'+
                                    '<input colorpicker="hex" colorpicker-with-input="true" class="form-control colorText" type="text" id="colorRow'+i+'"  ng-model="colorRow'+i+'" ng-change="colorChanged('+i+')"/>'+
                                    '<button class="btn btn-sm btn-default glyphicon glyphicon-remove removeColorEvent removeParam" style="margin-left:5px;" ng-click="removeColor('+i+')"></button><div class="showColor" id="showColor'+i+'" style="background-color:{{colorRow'+i+'}}"></div></div>'
                        $('#colorTable').append($compile(temp)(scope));
                        var vari = 'colorRow'+i ;
                        scope[vari] = colorArray[i];
                    };
                }

                scope.addColor = function(){
                    if(scope.inputColor == undefined || scope.inputColor.length <= 0){
                        return
                    }
                    $log.debug("this is add color called");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<div id="row'+l+'" class="form-inline" style="padding-bottom:5px;">'+
                                '<input colorpicker="hex" colorpicker-with-input="true" class="form-control colorText" type="text" id="colorRow'+l+'"  ng-model="colorRow'+l+'" ng-change="colorChanged('+l+')"/>'+
                                '<button class="btn btn-sm btn-default glyphicon glyphicon-remove removeColorEvent removeParam" style="margin-left:5px;" ng-click="removeColor('+l+')"></button><div class="showColor" id="showColor'+l+'" style="background-color:{{colorRow'+l+'}}"></div></div>'
                    $('#colorTable').append($compile(temp)(scope));
                    var vari = 'colorRow'+l ;
                    scope[vari] = scope.inputColor;
                    scope.inputColor = "";
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeColor = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                action : function(dialogItself) {
                    colorArray = [];
                    $('.colorText').each(function(i, obj) {
                        colorArray.push($(this).val());
                    });
                    dialogItself.close();
                    onOk(colorArray);
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
    }
    
    this.outputOptDialog = function(dialogTitle,indexArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="outputOpt" style="text-align:center;">'+
                                '<tr><td>Index</td><td></td></tr>'+
                                '<tr class="form-inline inputRow indexRow"><td><input class="form-control" type="text" ng-model="inputIndex"></td>'+
                                '<td><button class="btn btn-default btn-xs" id="addIndex" ng-click="addIndex()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table></div>';                                
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                //'</div>';
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'outputopt-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.inputIndex = "";
                var length = indexArray.length;
                if(indexArray.length != 0){
                    //$log.log(indexArray.length);
                    for(i=0;i<indexArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline indexRow"><td><input class="form-control" type="text" ng-model="inputIndex'+i+'"></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeIndex('+i+')"></button></td></tr>'
                        $('.inputRow').before($compile(temp)(scope));
                        var vari = 'inputIndex'+i ;
                        scope[vari] = indexArray[i];
                    };
                }

                scope.addIndex = function(){
                    if(scope.inputIndex == undefined || scope.inputIndex.length <= 0){
                        return
                    }
                    $log.debug("this is add color called");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline indexRow"><td><input class="form-control" type="text" ng-model="inputIndex'+l+'"></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeIndex('+l+')"></button></td></tr>'
                    $('.inputRow').before($compile(temp)(scope));
                    var vari = 'inputIndex'+l ;
                    scope[vari] = scope.inputIndex;
                    scope.inputIndex = "";
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeIndex = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                action : function(dialogItself) {
                    indexArray = [];
                    $('.indexRow').each(function(i, obj) {
                        var indx = (this.id).charAt(3);
                        //$log.log(indx)
                        if((scope['inputIndex'+indx]).length <1){
                            return;
                        }
                        indexArray.push(scope['inputIndex'+indx]);
                    });
                    dialogItself.close();
                    $log.debug(indexArray);
                    onOk(indexArray);
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass: 'btn-default btn-lg btn-danger'
            }]
        });
    }

    /*
    this.javascriptDialog = function(dialogTitle,currentScrpt,onOk,onCancel){
        var resScript="";
        var editor;
        var data=BootstrapDialog.show({
            title: "Javascript Input",
            message: function(dialog) {
                var $message = $('<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                '<span class="sr-only">Error:</span>'+
                ' ' +"Please input valid script." +'</div>'+
                '<textarea id="codedata" name="codedata">' + currentScrpt + ' </textarea>');
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {

                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: "javascript"
                });

            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                cssClass: 'btn-primary',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        dialogItself.close();
                        $log.log(editor.getValue());
                        onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-danger'
                }]
        });
    };
    */


    this.cdaparamDialog = function(dialogTitle,paramArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);
                

                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Name</td><td>Value</td><td>Type</td><td>Private</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName"  ng-model="paramName" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramVal" ng-model="paramVal" /></td>'+
                                '<td><select class="form-control addParam input-sm" ng-model="paramType" ng-options="n for n in paramTypes"></select></td>'+
                                '<td><input class="form-control paramCheck input-sm" type="checkbox" id="isPrivate" ng-model="isPrivate" style="height:13px"/></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: '',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramName = "";
                scope.paramVal = "";
                scope.isPrivate = false;
                scope.paramTypes = ['String','Integer','Numeric','Date','StringArray','IntegerArray','NumericArray','DateArray'];
                scope.paramType = scope.paramTypes[0];
                self.safeApply(scope,function(){});

                var length = paramArray.length;
                if(paramArray.length != 0){
                    for(i=0;i<paramArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'"  ng-model="paramName'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramVal'+i+'" ng-model="paramVal'+i+'" /></td>'+
                                    '<td><select class="form-control input-sm" ng-model="paramType'+i+'" ng-options="n for n in paramTypes"></select></td>'+
                                    '<td><input class="input-sm" type="checkbox" id="isPrivate'+i+'" ng-model="isPrivate'+i+'" style="height:13px"/></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramName'+i ;
                        scope[vari] = paramArray[i][0];
                        vari = 'paramVal'+i;
                        scope[vari] = paramArray[i][1];
                        vari = 'paramType'+i;
                        scope[vari] = paramArray[i][2];
                        vari = 'isPrivate'+i;
                        scope[vari] = paramArray[i][3];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramVal == undefined || scope.paramVal.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'"  ng-model="paramName'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramVal'+l+'" ng-model="paramVal'+l+'" /></td>'+
                                '<td><select class="form-control addParam input-sm" ng-model="paramType'+l+'" ng-options="n for n in paramTypes"></select></td>'+
                                '<td><input type="checkbox" class="form-control addParam input-sm" id="isPrivate'+l+'" ng-model="isPrivate'+l+'" style="height:13px"/></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    vari = 'paramVal'+l;
                    scope[vari] = scope.paramVal;
                    vari = 'paramType'+l;
                    scope[vari] = scope.paramType;
                    vari = 'isPrivate'+l;
                    scope[vari] = scope.isPrivate;
                    scope.paramName = "";
                    scope.paramVal = "";
                    scope.paramType = "String";
                    scope.isPrivate = false;
                    $('#paramName').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                action : function(dialogItself) {
                    paramArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramName'+index].length <1 || scope['paramVal'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramName'+index],scope['paramVal'+index],scope['paramType'+index],scope['isPrivate'+index]];
                        paramArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(paramArray);
                    onOk(paramArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    }
    this.columnsDialog = function(dialogTitle,columnsArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Index</td><td>Name</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramIndex"  ng-model="paramIndex" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName" ng-model="paramName" /></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'column-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramIndex = "";
                scope.paramName = "";
                self.safeApply(scope,function(){});

                var length = columnsArray.length;
                if(columnsArray.length != 0){
                    for(i=0;i<columnsArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramIndex'+i+'"  ng-model="paramIndex'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'" ng-model="paramName'+i+'" style="width:90%"/></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramIndex'+i ;
                        scope[vari] = columnsArray[i][0];
                        vari = 'paramName'+i;
                        scope[vari] = columnsArray[i][1];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramIndex == undefined || scope.paramIndex.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramIndex'+l+'"  ng-model="paramIndex'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'" ng-model="paramName'+l+'" /></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramIndex'+l;
                    scope[vari] = scope.paramIndex;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    scope.paramIndex = "";
                    scope.paramName = "";
                    $('#paramIndex').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                action : function(dialogItself) {
                    columnsArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramIndex'+index].length <1 || scope['paramName'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramIndex'+index],scope['paramName'+index]];
                        columnsArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(columnsArray);
                    onOk(columnsArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    };

    this.calcColumnsDialog = function(dialogTitle,columnsArray,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<table class="table table-condensed table-striped" id="paramTable" style="text-align:center;">'+
                                '<tr><td>Name</td><td>Formula</td><td></td></tr>'+
                                '<tr class="form-inline addRow paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName"  ng-model="paramName" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramForm" ng-model="paramForm" /></td>'+
                                '<td><button class="btn btn-default btn-xs addParam input-sm" id="addParam" ng-click="addParam()"><i class="glyphicon glyphicon-plus"></i></button></td></tr>'+
                                '</table>'+
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'column-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.paramName = "";
                scope.paramForm = "";
                self.safeApply(scope,function(){});

                var length = columnsArray.length;
                if(columnsArray.length != 0){
                    for(i=0;i<columnsArray.length;i++){

                        var temp =  '<tr id="row'+i+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                    '<td><input type="text" class="form-control input-sm" id="paramName'+i+'"  ng-model="paramName'+i+'" /></td>'+
                                    '<td><input type="text" class="form-control input-sm" id="paramForm'+i+'" ng-model="paramForm'+i+'" /></td>'+
                                    '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus removeParam" style="margin-left:5px;" ng-click="removeParam('+i+')"></button></td></tr>'
                        $('.addRow').before($compile(temp)(scope));
                        var vari;
                        vari = 'paramName'+i ;
                        scope[vari] = columnsArray[i][0];
                        vari = 'paramForm'+i;
                        scope[vari] = columnsArray[i][1];
                    };
                }

                scope.addParam = function(){
                    if(scope.paramName == undefined || scope.paramName.length < 1 || scope.paramForm == undefined || scope.paramForm.length < 1){
                        return
                    }
                    $log.debug("New param added");
                    var l = length;
                    //var val = scope.inputColor;
                    var temp =  '<tr id="row'+l+'" class="form-inline paramRow" style="padding-bottom:5px;">'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramName'+l+'"  ng-model="paramName'+l+'" /></td>'+
                                '<td><input type="text" class="form-control addParam input-sm" id="paramForm'+l+'" ng-model="paramForm'+l+'" /></td>'+
                                '<td><button class="btn btn-xs btn-default glyphicon glyphicon-minus addParam input-sm removeParam" style="margin-left:5px;" ng-click="removeParam('+l+')"></button></td></tr>'
                    $('.addRow').before($compile(temp)(scope));
                    var vari;
                    vari = 'paramName'+l;
                    scope[vari] = scope.paramName;
                    vari = 'paramForm'+l;
                    scope[vari] = scope.paramForm;
                    scope.paramName = "";
                    scope.paramForm = "";
                    $('#paramName').focus();
                    length ++;
                    //scope.colorChanged(l);
                }

                scope.removeParam = function(index){
                    $('#row'+index).remove();
                }
            },
            buttons : [{
                label : 'Apply',
                action : function(dialogItself) {
                    columnsArray = [];

                    $('.paramRow').each(function(i, obj) {
                        var index = (this.id).charAt(3);
                        //$log.log(scope['paramName'+index]);
                        if(scope['paramName'+index].length <1 || scope['paramForm'+index].length < 1 ){
                            return;
                        }
                        var rowVal = [scope['paramName'+index],scope['paramForm'+index]];
                        columnsArray.push(rowVal);
                    });
                    dialogItself.close();
                    $log.debug(columnsArray);
                    onOk(columnsArray);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });
    };

    this.datasourceDialog = function(dialogTitle,selectVal,onOk,onCancel,scope){
        BootstrapDialog.show({
            title: dialogTitle,
            message: function(dialog){
                var $message = $('<div></div>');
                //var pageToLoad = dialog.getData('pageToLoad');
                //$message.load(pageToLoad);

                var template =  '<div style="max-height:450px;overflow:auto;">'+
                                '<div style="padding-bottom:5px;"> Database Connection'+
                                '</div>'+
                                '<div class="list-group" id="connection" width="100%">'+
                                '</div>'+
                                //'<div class="alignCenter"><a class="blueLink" onclick="window.parent.executeCommand(\'ManageDatasourcesCommand\')"> Make a new Connection here</a></div>'
                                //'<div><button class="btn btn-default" id="addColor" ng-click="addColor()">Add</button></div>'
                                '</div>';
                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;

            },
            closable : true,
            draggable : true,
            cssClass: 'outputopt-dialog',
            onshown : function(dialogRef){
                //$log.debug("colorArray : "+colorArray);
                scope.selection = [];
                var temp = '';
                var param = {
                    'ts' : '1437031684490'
                }

                var jsonData =self.synchronousJsonCall( '/pentaho/plugin/data-access/api/connection/list',"GET",param);
                 //$log.log(jsonData);
                 
                 //$log.log(jsonData.databaseConnections.length)
                for(i=0;i<jsonData.databaseConnections.length;i++){
                    scope.selection.push(jsonData.databaseConnections[i].name);
                    var connection = jsonData.databaseConnections[i].name.replace(/\s+/g, '');
                    var conn = jsonData.databaseConnections[i].name
                        temp = temp +'<button type="button" class="col-lg-12 col-md-12 col-sm-12 listGroup list-group-item" id="'+connection+'" ng-click="select(\''+connection+'\')" idd="'+conn+'">'+connection+'</button>'  
                }

                scope.select = function(connection){
                    //$log.log("this is clicked");
                    var conn = connection.replace(/\s+/g, '');
                    if($('.listGroup').hasClass('active'))
                        $('.listGroup').removeClass('active');

                    $('#'+conn).addClass('active');
                }

                $('#connection').append($compile(temp)(scope));
                $('#'+selectVal).addClass('active');

            },
            buttons : [{
                label : 'Apply',
                action : function(dialogItself) {
                    
                    scope.selectVal =$('#connection .active').attr("idd");
                    //$log.log(scope.selectVal);
                    var param = {
                        'name' : scope.selectVal
                    }
                    var jsonData =self.synchronousJsonCall( '/pentaho/plugin/data-access/api/connection/get',"GET",param);
                    //$log.log(jsonData);


                    dialogItself.close();
                    onOk(jsonData);
                },
                 cssClass : 'btn-default btn-lg btn-primary'
            },{
                label : 'Close',
                action : function(dialogItself) {
                    dialogItself.close();
                    onCancel();
                },
                cssClass : 'btn-default btn-lg btn-danger'
            }]
        });   
    }
    

    this.codeMirrorDialog = function(mode,currentScrpt,onOk,onCancel,scope){
        var editor;

        if((scope.dbType==undefined || scope.dbType.length <1) && (scope.jndi!= undefined && scope.jndi.length >1)){
            var param ={'name': scope.jndi}
            var data = self.synchronousJsonCall( '/pentaho/plugin/data-access/api/connection/get',"GET",param);
            scope.dbtype = data.databaseType.shortName;
            scope.dbuser = data.username;
            scope.dbhost = data.hostname;
            scope.dbport = data.databasePort;
            scope.dbname = data.databaseName;
        }
        
       
        scope.queryBuilder = false;

        // if(scope.jndi == undefined || scope.jndi.length<1)
        //     scope.queryBuilder = true;

        BootstrapDialog.show({
            title: mode.charAt(0).toUpperCase()+mode.slice(1)+" Dialog",
            message: function(dialog) {
                var template =  '<div  id="errorMsg" style="display:none" class="alert alert-danger" role="alert">' +
                                '<span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>' +
                                '<span class="sr-only">Error:</span>'+
                                ' ' +"Please input valid script." +'</div>'+
                                '<textarea id="codedata" name="codedata">' + currentScrpt + '</textarea>'+
                                '<div align="center" style="padding-top:15px;"><button class="btn btn-md btn-blue" ng-click="selectOption()" ng-if="queryBuilder">Query Builder</button>'+
                               // '<button class="btn btn-default btn-lg btn-primary" ng-click="tableData()">Table Data</button>'+
                               // '<button class="btn btn-default btn-lg btn-primary" ng-click="fieldData()">Field data</button>'+
                                '</div>';

                var $message = $('<div></div>');
                $message.append($compile(template)(scope));
                return $message;
            },
            draggable: true,
            closable : false,
            onshown: function(dialogRef)
            {
                //$log.log(scope.dbtype+" " +scope.dbuser)
                if(mode=='sql')
                    mode = 'text/x-sql'
                editor = CodeMirror.fromTextArea(document.getElementById("codedata"), {
                    lineNumbers: true,
                    mode: mode
                });

                $log.log("query builder");
            },
            buttons: [{
                id: 'btn-ok',
                label: 'Ok',
                action: function(dialogItself){
                    var valid = true;
                    if(valid)
                    {
                        dialogItself.close();
                        //$log.log(editor.getValue());
                        onOk(editor.getValue());
                    }
                    else
                    {
                        $("#errorMsg").show();
                    }
                },
                cssClass: 'btn-default btn-lg btn-primary'
            },
                {
                    label: 'Cancel',
                    action: function(dialogItself){
                        dialogItself.close();
                        onCancel();
                    },
                    cssClass: 'btn-default btn-lg btn-danger'
                }]
        });
    }


    this.notif = function(text,position,type,delay,callback){
        var n = noty(
            {
                text: text,
                layout: position,
                type: type,
                theme : 'flexy',
                timeout : delay,
                progressBar : false,
                animation: {
                    open: {height: 'toggle'}, // or Animate.css class names like: 'animated bounceInLeft'
                    close: {height: 'toggle'}, // or Animate.css class names like: 'animated bounceOutLeft'
                    easing: 'swing',
                    speed: 500 // opening & closing animation speed
                },
                maxVisible: 2,
                callback: {
                    afterClose: callback
                },

            }

        );
    }
    

    this.safeApply=function (scope, fn){
        (scope.$$phase || scope.$root.$$phase) ? fn() : scope.$apply(fn);
    };


    this.loadjscssfile = function(filename, filetype){

        if (filetype=="js"){ //if filename is a external JavaScript file
            /*
            var message = "";
            var script = document.createElement("script");
            script.type = "text/javascript";
            script.src = filename;
            
            script.onload = function(){
                message = "loading"
                callback(message);
            }
            
            document.getElementsByTagName("head")[0].appendChild(script);

            */
            var ajaxObj;
            if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
                ajaxObj=new XMLHttpRequest();
            }
            else{// code for IE6, IE5
                ajaxObj=new ActiveXObject("Microsoft.XMLHTTP");
            }
            ajaxObj.onreadystatechange=function(){
                if (ajaxObj.readyState!=4 ) return ;
                eval(ajaxObj.responseText);   
            }
            
            ajaxObj.open("GET",filename,true);
            ajaxObj.send('');

        }
        else if (filetype=="css"){ //if filename is an external CSS file
            var fileref=document.createElement("link")
            fileref.setAttribute("rel", "stylesheet");
            fileref.setAttribute("type", "text/css");
            fileref.setAttribute("href", filename);

            document.getElementsByTagName("head")[0].appendChild(fileref);
            //var css = document.createElement("link");
            //css.rel = "stylesheet";
            //css.type = "text/css"
            //css.href = filename;
        }

        //if (typeof fileref!="undefined")
        //    document.getElementsByTagName("head")[0].appendChild(fileref)
    }
    //currently this function is not using anywhere
    this.loadComponentRes = function()
    {
        var DEFAULT_PATH ="../Assets/component/";
        var self = this;

        for(var i = 0; i < this.components.selfServiceBI.length; i++) {

            for(var j = 0; j < this.components.selfServiceBI[i].properties.files.css.length; j++) {

                var filePath = this.components.selfServiceBI[i].properties.files.css[j];
                if(filePath.substr(0,2) == ".." ||  filePath.substr(0,3) == "/.." ) // Load Relative path
                {   
                    //this.loadjscssfile(filePath,"css");
                }
                else
                {
                    this.loadjscssfile(DEFAULT_PATH+this.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath,"css")
                    filePath =DEFAULT_PATH+this.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath;
                }


                //$log.debug("\tCSS : " + filePath);
            }
            angular.forEach(this.components.selfServiceBI[i].properties.files.js , function(item,j){

                var filePath = item;
                var reply = undefined;

                if(filePath.substr(0,2) == ".." ||  filePath.substr(0,3) == "/.." ) // Load Relative path
                {
                    //self.loadjscssfile(filePath,"js");

                }
                else
                {
                    self.loadjscssfile(DEFAULT_PATH+self.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath,"js")
                    filePath = DEFAULT_PATH+self.components.selfServiceBI[i].properties.files.baseFolder + "/" + filePath;
                }
                //$log.debug("\tjs : " + filePath);
            })
        }
        //$log.log("this is finished");
    }
    
    this.setComponents = function()
    {
        this.components = this.readJSONFile('../Assets/component/components.json');
        this.loadComponentRes();
    }

    this.getIndex = function(name){
        var properties = {};
        for(i=0;i<this.components.selfServiceBI.length;i++){
            if(name == this.components.selfServiceBI[i].chartName){
                return i;
            };

        }
    }

    this.getChartType = function(input){
        var chartType;
        //$log.log(scope.chartType)
        if(input == "Saiku Analytics")
            chartType = 'Saiku';
        else if(input == "CCC Chart Library")
            chartType = 'CCC';
        else if(input == "Data Tables")
            chartType = 'Table';
        else if(input == "Label")
            chartType = 'Label'
        return chartType
    }
    this.propertiesHTMLComponent= function(pName,caption,dataType,htmlComp,defaultVal,listOfVal,advance,htmlAppend,scope,hidden)
    {
        var cssClass= '';

        //var isHidden = hidden == 0? 'hidden' : '';
        var isHidden = '';
        if(advance == 1) // 1 = Advance, 2 = Advance + Primary , 0 = Not implements but we can use as primary only
            cssClass="advance";
        else if(advance == 2)
            cssClass="primary";
        else if(advance == 0)
            isHidden = 'hidden';

        
        var comp = '<div class="form-group '+ cssClass +'" '+isHidden+'><div class="col-lg-5 col-md-5 col-sm-5 form-group-left">'+caption+'</div>';
        //var comp = '<tr '+ cssClass + isHidden+' ><td style="width:40%">'+caption+'</td>'; // this row Tr close within switch case
        //$log.log(comp);
        switch(htmlComp){
            case "textbox":
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></div>';
                //comp = comp + '<td><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></td></tr>';
                $('#'+htmlAppend).append($compile(comp)(scope));
                //$('#'+pName).val(defaultVal);
                scope[pName] = defaultVal;

                break;
            }
            case "password":
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="password" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></div>';
                //comp = comp + '<td><input type="text" id="'+pName+'" value="'+defaultVal+'" class="form-control input-sm" ng-model="'+pName+'"></td></tr>';
                $('#'+htmlAppend).append($compile(comp)(scope));
                //$('#'+pName).val(defaultVal);
                scope[pName] = defaultVal;

                break;
            }
            case "combobox" :
            {
                var possible = listOfVal;
                var options = '';
                for(j=0;j<possible.length;j++){
                    if(possible[j] == defaultVal){
                        option = '<option value="'+possible[j]+'">'+possible[j]+'</option>'
                    }
                    else{
                        option = '<option value="'+possible[j]+'">'+possible[j]+'</option>'
                    }

                    options = options.concat(option)
                }
                comp = comp +'<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><select id="'+pName+'" class="form-control input-sm" ng-model="'+pName+'">'+
                options+
                '</div></div>'
                
                $('#'+htmlAppend).append($compile(comp)(scope));

                scope[pName] = defaultVal;
                break;
            }
            case "switch" :
            case "combo" :
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="checkbox" class="form-control" id="'+pName+'" name="my-checkbox" data-size="mini" data-handle-width="42" data-on-text="True" data-off-text="False" data-on-color="success" data-off-color="danger" checked=false /></td>'+
                '</div></div>';

                $('#'+htmlAppend).append($compile(comp)(scope));

                if(defaultVal){
                    $('#'+pName).bootstrapSwitch('state',true);
                }
                else{
                    $('#'+pName).bootstrapSwitch('state',false);
                }
                break;
            }
            case "javascript" :
            case "sql" :
            {
                comp = comp + '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><div class="input-group form-inline" ng-click="openScriptDialog()"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                '<span class="input-group-addon input-sm" id="'+pName+'button" style="cursor:pointer;" ><i class="glyphicon glyphicon-pencil"></i></button>'+
                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div></div>';
                //$('#'+pName+'text').val(data.substring(0,30));
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = defaultVal;
                    if(defaultVal.length > 20 )
                        scope[pName+'text'] = defaultVal.substring(0,20)+'..(...)';
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openScriptDialog = function(){

                    var onOk = function(data) {
                        scope[pName+'text'] = data;
                        if(data.length >20)
                            scope[pName+'text'] = data.substring(0,20)+'..(...)' ;
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.codeMirrorDialog(htmlComp,currentVal,onOk,function(){},scope);
                };
                break;
            }
            /*
            case "colorDialog" :
            {
                comp = comp +   '<td><div class="input-group form-inline"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" class="form-control input-sm" size="15" />'+
                                '<span class="input-group-addon input-sm" id="'+pName+'button" style="cursor:pointer;" ><i class="glyphicon glyphicon-pencil"></i></button>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></td></tr>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = defaultVal.substring(0,30);
                    scope[pName] = defaultVal;
                }
                else{
                    scope[pName] ="";
                }

                scope[pName] = defaultVal;
                var currentVal = scope[pName];
                
                $('#'+pName+'button').on('click',function(){
                    $log.debug("color panel selected");

                    var onOk = function(data) {
                        scope[pName+'text'] = data.substring(0,15);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.colorDialog("Select Colors",currentVal,onOk,function(){},scope);
                });

                break;
            }
            */
            case "colorDialog" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><div class="form-group-right input-group form-inline"><input type="text" id="'+pName+'text" ng-click="openColorDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined")
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openColorDialog = function(){
                    $log.debug("Color Dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else if(data.length == 0)
                            scope[pName+'text'] = "";
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.safeApply(scope,function(){});
                    }
                    self.colorDialog("Select Colors",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "database" : 
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openDtsrcDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" style="cursor:text" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = defaultVal;
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openDtsrcDialog = function(){
                    $log.debug("Add Datasource Connection dialog");

                    var onOk = function(data) {
                        scope[pName+'text'] = data.name;
                        scope[pName] = data.name;
                        currentVal = data.name;
                        //var connection = self.getDBConnection(data.databaseType.shortName);
                        $log.debug(connection);
                        //$log.log(data.databaseType.extraOptionsHelpUrl.name);
                        //if(data.databaseType.name == 'MySQL')
                        //scope.driver = connection[0]
                        scope.dbtype = data.databaseType.shortName;
                        scope.dbuser = data.username;
                        scope.dbhost = data.hostname;
                        scope.dbport = data.databasePort;
                        scope.dbname = data.databaseName;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        //scope.url = connection[1]+'://'+data.hostname+':'+data.databasePort+'/'+data.databaseName;
                        self.safeApply(scope,function(){});
                    }
                    self.datasourceDialog("Select Datasource",currentVal,onOk,function(){},scope);
                }
                break;   
            }
            case "cdaparameters" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openParamDialog()" ng-model="'+pName+'text" class=" form-control input-sm readonlybg"  style="cursor:text" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openParamDialog = function(){
                    $log.debug("Add CDA Parameter dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.cdaparamDialog("Add parameters",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "outputOpt" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" ng-click="openOutputDialog()" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openOutputDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.outputOptDialog("Output Options",currentVal,onOk,function(){},scope);
                }
                break;
            }
            case "columns" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-click="openColumnDialog()" ng-model="'+pName+'text" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openColumnDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.columnsDialog("Columns Configuration",currentVal,onOk,function(){},scope);
                }
                break;
            }

            case "calcColumns" :
            {
                comp = comp +   '<div class="col-lg-7 col-md-7 col-sm-7 form-group-right"><input type="text" id="'+pName+'text" ng-model="'+pName+'text" ng-click="openCalColDialog()" class="form-control input-sm readonlybg" size="15" style="cursor:text;" readonly/>'+
                                '<input type="hidden" id="'+pName+'" ng-model="'+pName+'"/></div></div>';
                //$('#'+pName).val(defaultVal);
                $('#'+htmlAppend).append($compile(comp)(scope));

                 if (typeof defaultVal!="undefined" && defaultVal.length > 0)
                {
                    scope[pName+'text'] = JSON.stringify(defaultVal).substring(0,20);
                    scope[pName] = defaultVal;
                    $('#'+pName).val(defaultVal);
                }
                else{
                    scope[pName] ="";
                    $('#'+pName).val("");
                }

                var currentVal = scope[pName];

                scope.openCalColDialog = function(){
                    $log.debug("Output Option dialog");

                    var onOk = function(data) {
                        if(JSON.stringify(data).length > 20)
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20) + '..,(...)';
                        else
                            scope[pName+'text'] = JSON.stringify(data).substring(0,20);
                        scope[pName] = data;
                        currentVal = data;
                        self.savedFlag = false;
                        self.propertiesSaved = false;
                        self.safeApply(scope,function(){});
                    }
                    self.calcColumnsDialog("Calculated Columns",currentVal,onOk,function(){},scope);
                }
                break;
            }
        }
    }

    this.getDBConnection = function(dbname){
        var connection = [];
        switch(dbname){
            case 'MYSQL':{
                connection = ['com.mysql.jdbc.Driver','jdbc:mysql'];
                break;
            }   
            case 'ORACLE':{
                connection = ['oracle.jdbc.driver.OracleDriver','jdbc:oracle'];
                break;
            }
            case 'HIVE':{
                connection = ['org.apache.hadoop.hive.jdbc.HiveDriver','jdbc:hive'];
                break;
            }
            case 'HIVE2':{
                connection = ['org.apache.hadoop.hive.jdbc.HiveDriver','jdbc:hive2'];
                break;
            }
            case 'VERTICA5':{
                connection = ['com.vertica.jdbc.Driver','jdbc:vertica'];
                break;
            }
            case 'HYPERSONIC':{
                connection = ['org.hsqldb.jdbcDriver','jdbc:hsqldb:hsql'];
                break;
            }
            case 'POSTGRESQL':{
                connection = ['org.postgresql.Driver','jdbc:postgresql'];
                break;
            }
            case 'MSSQL':{
                connection = ['com.microsoft.sqlserver.jdbc.SQLServerDriver','jdbc:sqlserver'];
                break;   
            }
            case 'MSSQLNative':{
                connection = ['com.microsoft.sqlserver.jdbc.SQLServerDriver','jdbc:sqlserver'];
                break;   
            }
            case 'H2':{
                connection = ['org.h2.Drive','jdbc:h2'];
                break;   
            }
            case 'MONETDB':{
                connection = ['nl.cwi.monetdb.jdbc.MonetDriver','jdbc:monetdb'];
                break;
            }
            case 'IMPALA':{
                connection = ['com.cloudera.impala.jdbc.Driver','jdbc:impala'];
                break;
            }
        }
        return connection;
    }


    this.parsePropertiesDataType = function(value, dataType)
    {
        if(dataType == "boolean")
            value = JSON.parse(value);
        else if (dataType == "array")
        {
            if(value != undefined)
            {
                if(!Array.isArray(value)) {
                    if (value.length > 0)
                    {
                        value = value.split(",");
                    }
                    //$log.debug("property val: "+value);
                }
            }

        }
        return value;
    }
}]);