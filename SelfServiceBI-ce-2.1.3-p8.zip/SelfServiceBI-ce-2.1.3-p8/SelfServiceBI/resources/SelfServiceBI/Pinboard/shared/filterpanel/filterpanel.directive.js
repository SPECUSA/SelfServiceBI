angular.module('pinboard')
.directive("filterpanel",['pinboard','$log','$compile','commonUtils','translationService','$timeout',function(pinboard,$log,$compile,commonUtils,translationService,$timeout){
    return{
        restrict : 'E',
        scope : {
            'filterPanel' : '='
        },
        //transclude: true,
        //bindtoController:true,
        //controllerAs :'filterpanelctrl',
        controller : ['$scope', '$attrs','$element', function (scope, attrs,element) {
            $log.debug("This is filterPanel controller");

            $log.debug("filterPanel : "+pinboard.filterPanel);
            scope.settingVisible = commonUtils.editor;
            scope.filterPanelMinimize = false;

            scope.filterPanel.filterPanelHeight = scope.filterPanel.filterPanelHeight >99 ? scope.filterPanel.filterPanelHeight :100;
            

            scope.submitFilter = function(){
                $log.debug("this is submit filter method");
                var pinListeners = {};
                var len = scope.filterPanel.filterArray.length;
                pinboard.pinListenerArray = [];
                
                for(var i=0;i<len;i++){
                    p=scope.filterPanel.filterArray[i].listenerPins.length;
                    if(p>0){
                        for(var j=0;j<p;j++){
                            var pinId = scope.filterPanel.filterArray[i].listenerPins[j].pinId;
                            var cdaParam = scope.filterPanel.filterArray[i].listenerPins[j].param
                            var paramval = scope.filterPanel.filterArray[i].filterVal;

                            if(cdaParam!=undefined){
                                if(pinListeners[pinId]==void 0){
                                    pinListeners[pinId] = {};
                                } 
                                pinListeners[pinId][cdaParam] = paramval;    
                            }
                        }
                    }
                }


                for(var key in pinListeners){
                    for(var m=0;m<pinboard.pinLists.length;m++){
                        if(key==pinboard.pinLists[m].pin[0].pinId){
                            pinboard.pinLists[m].pin[0].paramStr = pinListeners[key] ;    
                            pinboard.pinLists[m].pin[0].render(pinListeners[key]);
                        }
                    }
                }

                commonUtils.savedFlag = false;
                $log.debug("Pinboard Json data : ");
                $log.debug(pinboard.getJson());

                
            };
            scope.resetFilters = function(){
 
                for(i=0;i<scope.filterPanel.filterArray.length;i++){
                    if(scope.filterPanel.filterArray[i].filterType == "multiSelect"){
                        var temp = [];
                        temp= scope.filterPanel.filterArray[i].defaultVal;
                        scope.filterPanel.filterArray[i].filterVal = [];
                        for(j=0;j<temp.length;j++){
                            scope.filterPanel.filterArray[i].filterVal.push(temp[j]);    
                        }
                    }
                    else{
                        scope.filterPanel.filterArray[i].filterVal = scope.filterPanel.filterArray[i].defaultVal;
                    } 
                }
                
                $log.debug(scope.filterPanel.filterArray);

                
                $log.debug("Filter Panel reseted");
                scope.submitFilter();
            }

        }],
        link : function(scope,element,attrs){
            scope.init = function(){
                //$log.log($('#filterpanel').height());
                if(!$('#filterpanel').hasClass('collapse') && !$('#filterpanel').hasClass('in'))
                    scope.filterPanelMinimize = false;
            }
            scope.init();

            if(scope.filterPanel.filterPanelShow && scope.filterPanel.filterArray.length > 0){
                
                
                $('#filterpanel').collapse('show');
            }
            var html = '<div class="filterpanelWrapper font{{filterPanel.filterPanelFontColor}}"><div id="filterpanelHeader" class="filterpanelHeader panel panel-filter" >' ;
                html = html +'<div id="filterpanel" class="panel-body panel-filter-body collapse in filterpanel">'+
                            '<div  class="filterPanelBody col-md-10  col-sm-12  column " style="height:{{filterPanel.filterPanelHeight}}px;"> '+
                                "<filtercomponent ng-repeat='filter in filterPanel.filterArray' filterconfig=filter ></filtercomponent>" +
                            '</div>' +
                            '<div class="filterSettings col-md-2 col-sm-12">' ; 
                if(commonUtils.editor)
                    html = html +'<button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()">'+translationService.trans.submit+'</button><button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()">'+translationService.trans.reset+'</button>';
                else
                    html = html +'<button class="btn btn-default btn-lg btn-primary" ng-click="submitFilter()" ng-hide=filterPanelMinimize>'+translationService.trans.submit+'</button><button class="btn btn-default btn-lg btn-danger" ng-click="resetFilters()" ng-hide=filterPanelMinimize>'+translationService.trans.reset+'</button>';
                            
                html = html +'</div>'+
                        '</div>'+
                    '</div></div>';


            element.html(html);
            $compile(element.contents())(scope);
        }
    }
}]);