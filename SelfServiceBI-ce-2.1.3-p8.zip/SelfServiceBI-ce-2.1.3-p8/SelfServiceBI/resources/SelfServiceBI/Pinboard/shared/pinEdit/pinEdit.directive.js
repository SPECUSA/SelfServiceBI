angular.module('pinboard')
.directive("pinEdit",['pinboard','Pin','$log',function(pinboard,Pin,$log){
    return {
        restrict : 'E',
        scope : {
            'editor' : '@'
        },
        bindtoController:true,
        controllerAs :'databoard',
        templateUrl : 'shared/pinEdit/pinEdit.view.html',
        transclude : true,
        controller : ['$scope','$attrs','$element', function (scope,attrs,element) {
            $log.debug("This is activePin directive");
            var vm  = this;
            vm.pinboard = pinboard;
        }]
    }
}])