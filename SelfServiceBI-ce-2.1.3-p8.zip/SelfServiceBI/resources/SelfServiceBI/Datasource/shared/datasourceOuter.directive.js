angular.module('dataSourceModule').
directive('datasourceOuter',['dataSource','$log','$compile','commonUtils','$timeout',function(dataSource,$log,$compile,commonUtils,$timeout){
    return{
        restrict : 'E',
        scope:{
            pos : "@",
            datasrcobj : "="
        },
        transclude : true,
        //template:   '<div>asd</div>'
                    //'<datasrc-comp ng-repeat="datasourceCmp in datasourceOuterCtrl.dataSource.datasources" position={{datasourceCmp.position}} obj=datasourceCmp ></datasrc-comp>',
        controller : function(){
            var vm = this;
            vm.dataSource = dataSource;
            $log.debug("This is datasource directive")
        },
        link:function(scope,element){
            $log.debug("this is datasource outer");


            scope.popup = function(){
                $log.log("popup ");
                var pos = scope.datasrcobj.position
                if($('#heading'+pos).hasClass('active')){
                    $('#heading'+pos).removeClass('active');
                    $('#heading'+pos).find('.glyphicon').removeClass('glyphicon-minus').addClass('glyphicon-plus');
                }
                else{
                    $('#heading'+pos).addClass('active');
                    $('#heading'+pos).find('.glyphicon').removeClass('glyphicon-plus').addClass('glyphicon-minus');
                    //.find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');   
                }
            }

            var html='';
            //$log.log(commonUtils.isFirst)           
            //html = html+'<div class="dtsrcPanel panel-heading clearfix">asd</div>';
            html = html +   '<div class="panel-heading active" role="tab" id="heading{{datasrcobj.position}}" data-toggle="collapse" href="#datasourceContent{{datasrcobj.position}}" aria-expanded="true" aria-controls="datasourceContent{{datasrcobj.position}}" ng-click="popup()">'+
                                '<h4 class="panel-title">'+
                                    '<a role="button" ><i class="glyphicon glyphicon-minus"></i>{{datasrcobj.datasrcName}} Datasources</a>'+
                                '</h4>'+
                            '</div>'+
                            '<div id="datasourceContent{{datasrcobj.position}}" class="panel-collapse collapse in " role="tabpanel" aria-labelledby="headingOne">'+
                                '<datasrc-comp ng-repeat="datasourceCmp in datasrcobj.datasrcEntry" position={{pos}} obj=datasourceCmp ></datasrc-comp>'+
                            '</div>'  

            //$log.log(data)
            //html = html + 
            element.html(html);
            $compile(element.contents())(scope);

            var pos = scope.datasrcobj.position;
        }
    }
}])