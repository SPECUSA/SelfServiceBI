function Fusionchart(){};
Fusionchart.prototype = new SSBBaseComponent();
Fusionchart.prototype = {
    init : function(visualization,data,htmlObj,chartProperties,editor,listenerPins,cat,ser,trans){
        this.chartProp = editor;

        var fusionData =[];
        var tempArray = [];
        var category = [];
        var series = [];
        var temp = {};
        var hasSeries = false;
        var colOneProperVales = ["String","STRING","Date","date"];
        var colOneTypeCond = (colOneProperVales.indexOf(data.metadata[0].colType)) > -1 ? true : false;


        if(visualization.name=="Pie" || visualization.name=="Donut" || visualization.name=="Bar" || visualization.name=="Column" || visualization.name=="Line" || visualization.name=="Area"){
            if(data.metadata.length == 2 || data.metadata.length == 3 && colOneTypeCond){
            for(var i=0;i<data.resultset.length;i++){
                if(data.resultset[i].length == 3){
                    fusionData.push({"label": data.resultset[i][0]+"-"+data.resultset[i][1], "value":data.resultset[i][2]});
                }else if(data.resultset[i].length == 2){
                    fusionData.push({"label": data.resultset[i][0], "value":data.resultset[i][1]}) 
                }
            }
            this.chartProp.dataSource.data = fusionData;
        }
            else{
                $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
        }
        else if(visualization.name == "Bubble"){
            var xmax = 0;
            var ymax = 0;

            if(data.metadata.length == 5 && colOneTypeCond && (data.metadata[1].colType == "String" || data.metadata[1].colType == "STRING") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER") && (data.metadata[4].colType == "Numeric" || data.metadata[4].colType == "NUMBER")){
                //console.log(data);
                var s1={};
                s1.data = [];

                var temp = {};
                for(var i=0;i<data.resultset.length;i++){
                    

                    if(temp[data.resultset[i][0]]==void 0)
                        temp[data.resultset[i][0]] = [];
                    
                    if(data.resultset[i][2] > xmax)
                    {
                        xmax = data.resultset[i][2];
                    }
                    if(data.resultset[i][3] > ymax)
                    {
                        ymax = data.resultset[i][3];
                    }

                    //temp[data.resultset[i][0]][idx] = [data.resultset[i][2],data.resultset[i][3],data.resultset[i][4]];
                    var objj = {
                        x : data.resultset[i][2],
                        y : data.resultset[i][3],
                        z : data.resultset[i][4],
                        name : data.resultset[i][1]
                    }
                    //temp[data.resultset[i][0]].push([data.resultset[i][2],data.resultset[i][3],data.resultset[i][4],data.resultset[i][1]]);
                    temp[data.resultset[i][0]].push(objj);

                    hasSeries = true;
                }
                                    
                xmax = Math.round((xmax*5)/4);
                ymax = Math.round((ymax*5)/4);
                
                console.log(s1.data.length);
                var len = s1.data.length;

                var first = Math.round(xmax/len);
                for(var i=0;i<len;i++){
                    var labelObjj = {
                        label : first*(i+1),
                        x : first*(i+1)
                    }
                    category.push(labelObjj);
                }

                for(obj in temp){
                    var tempObj = {};
                    tempObj.seriesName = obj;
                    
                    temp[obj] = parseArray(temp[obj]);
                    //if(temp[obj] != null)
                    tempObj.data = temp[obj];
                    series.push(tempObj);
                }

                this.chartProp.dataSource.dataset = series;
                this.chartProp.dataSource.categories = [{
                    category : category
                }];
                this.chartProp.dataSource.chart.xAxisMaxValue = xmax;
                this.chartProp.dataSource.chart.yAxisMaxValue = ymax;

                this.chartProp.dataSource.chart.plotTooltext = "<div id='nameDiv' style='font-size: 14px; border-bottom: 1px dashed #666666; font-weight:bold; padding-bottom: 3px; margin-bottom: 5px; display: inline-block;'>$name :</div>{br}"+data.metadata[2].colName+ " : <b>$xDataValue</b>{br}"+data.metadata[3].colName+ " : <b>$yDataValue</b>{br}"+data.metadata[4].colName+ "  : <b>$zvalue</b>";

            }
            else if(data.metadata.length == 4 && colOneTypeCond && (data.metadata[1].colType == "Numeric" || data.metadata[1].colType == "NUMBER") && (data.metadata[2].colType == "Numeric" || data.metadata[2].colType == "NUMBER") && (data.metadata[3].colType == "Numeric" || data.metadata[3].colType == "NUMBER")){
                console.log(data);
                var s1={};

                s1.data = [];
                var len = data.resultset.length;
                for(var i=0;i<len;i++){
 

                    if(data.resultset[i][1] > xmax)
                    {
                        xmax = data.resultset[i][1];
                    }
                    if(data.resultset[i][2] > ymax)
                    {
                        ymax = data.resultset[i][2];
                    }

                    var objj = {
                        x : data.resultset[i][1],
                        y : data.resultset[i][2],
                        z : data.resultset[i][3],
                        name : data.resultset[i][0]
                    }
                    s1.data.push(objj);

                }

                xmax = Math.round((xmax*5)/4);
                ymax = Math.round((ymax*5)/4);
                
                console.log(s1.data.length);
                var len = s1.data.length;

                var first = Math.round(xmax/len);
                for(var i=0;i<len;i++){
                    var labelObjj = {
                        label : first*(i+1),
                        x : first*(i+1)
                    }
                }
                
                this.chartProp.dataSource.dataset = [s1];
                this.chartProp.dataSource.chart.xAxisMaxValue = xmax;
                this.chartProp.dataSource.chart.yAxisMaxValue = ymax;

                this.chartProp.dataSource.chart.plotTooltext = "<div id='nameDiv' style='font-size: 14px; border-bottom: 1px dashed #666666; font-weight:bold; padding-bottom: 3px; margin-bottom: 5px; display: inline-block;'>$name :</div>{br}"+data.metadata[1].colName+ " : <b>$xDataValue</b>{br}"+data.metadata[2].colName+ " : <b>$yDataValue</b>{br}"+data.metadata[3].colName+ "  : <b>$zvalue</b>";
            }
            else{
                $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
        }
        else{
            if(data.metadata.length == 3 && colOneTypeCond){
            for(var i=0;i<data.resultset.length;i++){
                if(data.resultset[i].length == 3){
                    if(tempArray.indexOf(data.resultset[i][1]) == -1){
                        tempArray.push(data.resultset[i][1]);
                        category.push({"label": data.resultset[i][1]})
                    }
                    var idx = tempArray.indexOf(data.resultset[i][1])

                    if(temp[data.resultset[i][0]]==void 0)
                        temp[data.resultset[i][0]] = [];
                    
                    temp[data.resultset[i][0]][idx] = {"value":data.resultset[i][2]};

                    hasSeries = true;
                }
                else{
                    category.push({label:data.resultset[i][0]});
                    fusionData.push({value:data.resultset[i][1]});
                }
            }

            if(hasSeries){
                for(obj in temp){
                    var tempObj = {};
                    tempObj.seriesname = obj;
                    tempObj.data = temp[obj];
                    fusionData.push(tempObj);
                }
                this.chartProp.dataSource.dataset = fusionData
            }
                
            else{
                this.chartProp.dataSource.dataset = [{
                    data : fusionData
                }];  
            }

            this.chartProp.dataSource.categories = [{
                category : category
            }];
        }
            else{
                $("#" + htmlObj).html(trans.error_improper_data).css('text-align', "center");
                return;
            }
        }
        

        this.chartProp.events = {
            dataPlotClick : function(eventObj,dataObj){
                chartClick(listenerPins,dataObj.categoryLabel);
            }
        }

        

        // console.log(this.chartProp);
        // console.log(category);
        this.chartProp.renderAt = htmlObj;
//        console.log(JSON.stringify(this.chartProp));
        this.render(this.chartProp);
    },
    render: function (temp) {
        FusionCharts.ready(function () {
            var fChart = new FusionCharts(temp);
            fChart.render();
        });         
        this.postExecution();        
    },     
    preExecution: function () {
        this.render();
    },
    postExecution: function () {
    } 
}
function parseArray(arr){
    // if(arr.indexOf() !== -1)
        for(var i=0;i<arr.length;i++){
            //console.log(arr[i]);
            if(arr[i] == void 0) arr[i]=null;
        }

    return arr;
}
