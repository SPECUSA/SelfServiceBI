angular.module('commonUtilModule',['messagesModule','translationModule']);

angular.module('commonUtilModule')
.config(['$logProvider',function($logProvider){
    $logProvider.debugEnabled(false);
}]);