angular.module('dataSourceModule',['commonUtilModule','messagesModule','ui.router','oc.lazyLoad']);

angular.module('dataSourceModule')
.config(['$logProvider','$ocLazyLoadProvider','$stateProvider','$urlRouterProvider',function($logProvider,$ocLazyLoadProvider,$stateProvider,$urlRouterProvider){
    $logProvider.debugEnabled(false);

    var cdaFiles = [
    				'components/datasource.controller.js',
    				'http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js',
                    'https://cdn.rawgit.com/nakupanda/bootstrap3-dialog/master/dist/js/bootstrap-dialog.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.2/js/bootstrap-switch.min.js',
    				'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css',
                    'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-switch/3.3.2/css/bootstrap3/bootstrap-switch.min.css',
                    'https://cdn.rawgit.com/nakupanda/bootstrap3-dialog/master/dist/css/bootstrap-dialog.min.css',
                    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css',
                    'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.36.0/codemirror.min.css',
                    'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.36.0/codemirror.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.36.0/mode/javascript/javascript.min.js',
                    'https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.js',
                    'https://cdn.jsdelivr.net/npm/jqueryfiletree@2.1.4/dist/jQueryFileTree.min.css',
                    'https://cdn.jsdelivr.net/npm/jqueryfiletree@2.1.4/dist/jQueryFileTree.min.js',
                    '../Assets/js/noty/jquery.noty.packaged.js',
                    '../Assets/js/jquery.xml2json.js',
                    '../Assets/css/style.css',
                    '../Assets/component/baseComponent.js'
    ];
	//Config For ocLazyLoading
    $ocLazyLoadProvider.config({
        'debug': true, // For debugging 'true/false'
        'events': true, // For Event 'true/false'
        'modules': [{ // Set modules initially
            name : 'datasource', // State1 module
            serie: true,
            files: cdaFiles
        }]
    });

    //Config/states of UI Router
    $stateProvider
        .state('datasource', {   
            url : "/cda",
            templateUrl: "components/datasource.view.html",
            controller : "datasourceCtrl",
            resolve: {
                loadMyCtrl: ['$ocLazyLoad', function($ocLazyLoad) {
                    return $ocLazyLoad.load('datasource'); // Resolve promise and load before view 
                }]
            }
        });

    $urlRouterProvider.otherwise("/cda");
}]);
