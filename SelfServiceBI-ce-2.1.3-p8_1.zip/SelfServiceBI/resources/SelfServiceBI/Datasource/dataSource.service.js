angular.module('dataSourceModule').
service('dataSource',['commonUtils','$log','datasrcOuter','datasrc', function(commonUtils,$log,datasrcOuter,datasrc){
	this.fileName = "";
	this.datasources = [];
	this.count = 0;
	this.currentCda = "";
	this.newDtsrcType = true;
	this.nullPropertyPanel = true;

	this.init = function(){
		this.fileName = "";
		this.datasources = [];
		this.count = 0;
		this.currentCda = "";
		this.newDtsrcType = true;
	};

	this.getXml = function(){
		var xml,datasources,dataAccess,columns,output,parameters,query;

		xml =	'<?xml version="1.0" encoding="UTF-8"?>'+
						'<CDADescriptor>';
		datasources = '<DataSources>';
		dataAccess = '';

        
		for(var i=0;i<this.datasources.length;i++){
            for(var z=0;z<this.datasources[i].datasrcEntry.length;z++){

            
				var isOutput = false;
                this.datasources[i].datasrcEntry[z].type = 'sql.jndi'
				datasources = datasources + '<Connection id="'+this.datasources[i].datasrcEntry[z].name+'" type="'+this.datasources[i].datasrcEntry[z].type+'">';
				dataAccess = dataAccess+"<DataAccess ";
				columns = "<Columns>";
				parameters = '<Parameters>'
				output = '';

				for(var j=0;j<this.datasources[i].datasrcEntry[z].properties.length;j++){

					switch(this.datasources[i].datasrcEntry[z].properties[j][0]){
						case "driver":{
							datasources = datasources + '<Driver>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</Driver>';
							break;
						}
						case "username":{
							datasources = datasources + '<User>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</User>';
							break;
						}
						case "url":{
							datasources = datasources + '<Url>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</Url></Connection>';
							break;
						}
                        case "database":{
                            datasources = datasources + '<DataConn>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</DataConn>';
                            break;
                        }
						case "jndi":{
							datasources = datasources + '<Jndi>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</Jndi>';
							break;
						}
                        case "password":{
                            datasources = datasources + '<pass>'+this.datasources[i].datasrcEntry[z].properties[j][3]+'</pass></Connection>';
                            break;
                        }
						case "accessLevel":{
							dataAccess = dataAccess + 'access = "'+this.datasources[i].datasrcEntry[z].properties[j][3].toLowerCase()+'" ';
							break;
						}
						case "cache":{
							dataAccess = dataAccess + 'cache = "'+this.datasources[i].datasrcEntry[z].properties[j][3]+'" ';
							break;
						}
						case "cacheDuration":{
							dataAccess = dataAccess + 'cacheDuration = "'+this.datasources[i].datasrcEntry[z].properties[j][3]+'" ';
							break;
						}
						case "columns":{
							colLen = this.datasources[i].datasrcEntry[z].properties[j][3].length;
							for(var a=0;a<colLen;a++){
								columns = columns + '<Column idx="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][0]+'">'+
													'<Name>'+this.datasources[i].datasrcEntry[z].properties[j][3][a][1]+'</Name></Column>';
							}	
							break;							
						}
						case "calcColumns":{
							colLen = this.datasources[i].datasrcEntry[z].properties[j][3].length;
							for(var a=0;a<colLen;a++){
								columns = columns + '<CalculatedColumn> <Name>'+this.datasources[i].datasrcEntry[z].properties[j][3][a][0]+'</Name>'+
													'<Formula>'+this.datasources[i].datasrcEntry[z].properties[j][3][a][1]+'</Formula></CalculatedColumn>';
							}	
							columns = columns + '</Columns>';
							break;						
						}
						case "outputOpt":{
							if(this.datasources[i].datasrcEntry[z].properties[j][3].length > 0){
								output = '<Output indexes="'+this.datasources[i].datasrcEntry[z].properties[j][3]+'" ';
								isOutput = true;
							}
							break;
						}
						case "outputMode" :{
							if(isOutput){
								output = output + 'mode="'+this.datasources[i].datasrcEntry[z].properties[j][3].toLowerCase()+'" />';	
							}
							break;
						}
						case "parameters" :{
							paramLen = this.datasources[i].datasrcEntry[z].properties[j][3].length;
							for(var a=0;a<paramLen;a++){
								var isPrivate = this.datasources[i].datasrcEntry[z].properties[j][3][a][3]=="true"? "private" : "public";
								parameters = parameters + '<Parameter access="'+isPrivate+'" default="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][1]+'" '+
												'name="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][0]+'" type="'+this.datasources[i].datasrcEntry[z].properties[j][3][a][2]+'" />';	
							}
							parameters = parameters + '</Parameters>';
							break;
						}
						case "query" :{
							query = '<Query><![CDATA['+this.datasources[i].datasrcEntry[z].properties[j][3]+']]></Query>';
							break;
						}
					}
					//columns = columns + '</Columns>';
				}				
				dataAccess = dataAccess + 'connection="'+this.datasources[i].datasrcEntry[z].name+'" id="'+this.datasources[i].datasrcEntry[z].name+'" type="sql">'+
											columns+output+parameters+query+'</DataAccess>';
            }
		}
		datasources = datasources + '</DataSources>';
		xml = xml + datasources + dataAccess +'</CDADescriptor>';
		//$log.log(xml);

		return xml;
	};

	this.saveConfigToFile = function(){
		
		var xml = this.getXml();
		xml = this.formatXml(xml);
        var param = { "file"  :  this.fileName ,
            "content"  : xml };
        var jsonData =commonUtils.synchronousJsonCall( '/pentaho/plugin/SelfServiceBI/api/saveBDDFile',"POST",param);

        if(jsonData.result =="Success.")
        {
            return true;
        }
        else
        {
            return false;
        }
	}

	this.getConfigFromFile = function(){
		var jsonData =commonUtils.synchronousJsonCall( '/pentaho/plugin/SelfServiceBI/api/getBDDFile?path='+ this.fileName,"GET",null);
        $log.debug(jsonData.result);
	    //var xml = $.parseXML(jsonData.result);
		//$log.log(xml2json(xml));
		jsonData = $.xml2json(jsonData.result);
		//$log.log(JSON.stringify(jsonData));
        $log.debug(jsonData);
		this.datasources= [];

		if(jsonData.DataSources.Connection.length== undefined){
			this.setConnection(jsonData.DataSources.Connection,jsonData.DataAccess,0)
            this.count = 1;
		}
		else{
			var l = jsonData.DataSources.Connection.length;
			for(var c=0;c<l;c++)
				this.setConnection(jsonData.DataSources.Connection[c],jsonData.DataAccess[c],c);
            this.count = l;
		}
        //$log.log(this.datasources[0].datasrcEntry[5].properties[0][3]);

		$log.debug(this.datasources);
	}

	this.setConnection = function(connection,dataAccess,indx){
	
		this.newDtsrcType = true;

        var temp;
        var len1 = this.datasources.length;

        if(indx > 0){
            for(var i=0;i<len1;i++){
                if(this.datasources[i].datasrcName == connection.type.substr(0, connection.type.indexOf('.'))){
                    this.newDtsrcType = false;
                    temp = i;
                    //$log.log(temp)
                }    
            }
        }

        var len2= '';

        if(this.newDtsrcType){
            this.datasources[len1] = new datasrcOuter();
            this.datasources[len1].datasrcName = connection.type.substr(0, connection.type.indexOf('.'));
            this.datasources[len1].datasrcEntry = [];
            this.datasources[len1].position = len1;
            //this.datasources[len]datasrcEntry.isFirst = true;
            len2 = 0;

        }
        else{
            len2 = this.datasources[temp].datasrcEntry.length;
            //this.datasources[len].isFirst = false;
            //makeDtsrcEntry(index,arryLen);      
            //len2 = arraylen
            len1 = temp;
        }       

        this.datasources[len1].datasrcEntry[len2] = new datasrc();
        this.datasources[len1].datasrcEntry[len2].id = "dtsrc"+indx;
        this.datasources[len1].datasrcEntry[len2].name = connection.id;
        this.datasources[len1].datasrcEntry[len2].type = connection.type;
		this.datasources[len1].datasrcEntry[len2].base = connection.type.substr(0, connection.type.indexOf('.'));
		this.datasources[len1].datasrcEntry[len2].properties = [];
		this.datasources[len1].datasrcEntry[len2].properties = commonUtils.readJSONFile('../Assets/component/datasource/'+connection.type+'.properties.json');
		//var self = this;
		for(var i=0;i<this.datasources[len1].datasrcEntry[len2].properties.length;i++){
			
			if(this.datasources[len1].datasrcEntry[len2].properties[i][0] == 'jndi')
				this.datasources[len1].datasrcEntry[len2].properties[i][3] = connection.Jndi;
            else if(this.datasources[len1].datasrcEntry[len2].properties[i][0] == 'password' && connection.pass != undefined){
                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = connection.pass;
            }
                
			switch(this.datasources[len1].datasrcEntry[len2].properties[i][0]){
				case "accessLevel":{
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.access.substr(0,1).toUpperCase()+dataAccess.access.slice(1);
					break;
				}
				case "query":{
					//$log.log(dataAccess.Query);
					//$log.log(JSON.parse(dataAccess.Query));
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.Query;
					break;
				}
				case "parameters":{
					if(dataAccess.Parameters == ""){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Parameters.Parameter.length == undefined){
						len = 1;
					}
					else{
						len = dataAccess.Parameters.Parameter.length;
					}

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<len;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [];
						//this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [1,2,3]
						//$log.log(this.datasources[len1].datasrcEntry[len2].properties[i][3][a])
						if(len == 1){
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Parameters.Parameter.name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Parameters.Parameter.default;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][2] = dataAccess.Parameters.Parameter.type;
							//if(dataAccess.Parameter.Parameter.access == undefined){
							//	dataAccess.Parameter.Parameter.access == 'Public'
							//}
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][3] = (dataAccess.Parameters.Parameter.access == "private" ? "true" : "false");
						}
						else{
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Parameters.Parameter[a].name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Parameters.Parameter[a].default;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][2] = dataAccess.Parameters.Parameter[a].type;
							//if(dataAccess.Parameter.Parameter.access == undefined){
							//	dataAccess.Parameter.Parameter.access == 'Public'
							//}
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][3] = (dataAccess.Parameters.Parameter[a].access == "private" ? "true" : "false");	
						}
					}
					break;
				}
				case "outputOpt":{
					if(dataAccess.Output == undefined){
						output = "";
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else
						output = dataAccess.Output.indexes.split(',');

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<output.length;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3].push(output[a]);		
					}
					break;
				}
				case "outputMode":{
					if(dataAccess.Output == undefined)
						output = 'Include';
					else
						output = dataAccess.Output.mode;

					this.datasources[len1].datasrcEntry[len2].properties[i][3] = output.substr(0,1).toUpperCase()+ output.slice(1);
					break;
				}
				case "columns":{
					//$log.log(dataAccess.Columns);
					if(dataAccess.Columns == "" || dataAccess.Columns.Column == undefined ){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Columns.Column.length == 0){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Columns.Column.length == undefined)
						len = 1;
					else
						len = dataAccess.Columns.Column.length;

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<len;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [];
						if(len == 1){
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column.idx);
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column.Name);
						}
						else{
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column[a].idx);
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a].push(dataAccess.Columns.Column[a].Name);
						}
					}
					break;
				}
				case "calcColumns":{
					if(dataAccess.Columns == "" || dataAccess.Columns.CalculatedColumn == undefined ){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;
					}
					else if(dataAccess.Columns.CalculatedColumn.length == 0){
						len = 0;
						this.datasources[len1].datasrcEntry[len2].properties[i][3] = "";
						break;	
					}
					else if(dataAccess.Columns.CalculatedColumn.length == undefined)
						len = 1;
					else
						len = dataAccess.Columns.CalculatedColumn.length;

                    this.datasources[len1].datasrcEntry[len2].properties[i][3] = [];
					for(var a=0;a<len;a++){
						this.datasources[len1].datasrcEntry[len2].properties[i][3][a] = [];
                        //$log.log(this.datasources[len1].datasrcEntry[len2].properties[i][3][a]);
            
						if(len == 1){
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Columns.CalculatedColumn.Name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Columns.CalculatedColumn.Formula;
						}
						else{
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][0] = dataAccess.Columns.CalculatedColumn[a].Name;
							this.datasources[len1].datasrcEntry[len2].properties[i][3][a][1] = dataAccess.Columns.CalculatedColumn[a].Formula;
						}
					}
                    //$log.log(this.datasources[len1].datasrcEntry[len2].properties[i][3]);
					break;
				}
				case "cache":{
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.cache;
					break;
				}
				case "cacheDuration" :{
					this.datasources[len1].datasrcEntry[len2].properties[i][3] = dataAccess.cacheDuration;
				}
			}
		}
	}

	this.formatXml = function(xml){
	    var formatted = '';
	    var reg = /(>)(<)(\/*)/g;
	    xml = xml.replace(reg, '$1\r\n$2$3');
	    var pad = 0;
	    jQuery.each(xml.split('\r\n'), function(index, node) {
	        var indent = 0;
	        if (node.match( /.+<\/\w[^>]*>$/ )) {
	            indent = 0;
	        } else if (node.match( /^<\/\w/ )) {
	            if (pad != 0) {
	                pad -= 1;
	            }
	        } else if (node.match( /^<\w[^>]*[^\/]>.*$/ )) {
	            indent = 1;
	        } else {
	            indent = 0;
	        }
	 
	        var padding = '';
	        for (var i = 0; i < pad; i++) {
	            padding += '  ';
	        }
	 
	        formatted += padding + node + '\r\n';
	        pad += indent;
	    });
	    return formatted;
	}

	this.blankPropertiesPanel = function(){
		this.nullPropertyPanel = true;
		$('#propertiesPanel').html('');
		$('#propertiesPanelSave').html('');
	}

    this.changePosition = function(index){
        //$log.log(index);
        var len = this.datasources.length-1;
        for(var i=len;i>index;i--){
            //$log.log(i);
            this.datasources[i].position = i-1;
        }
    }

}]);