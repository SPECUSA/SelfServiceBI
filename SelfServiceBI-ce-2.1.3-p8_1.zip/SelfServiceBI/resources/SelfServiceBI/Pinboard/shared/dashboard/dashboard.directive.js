angular.module('pinboard')
.directive("dashboard",['pinboard','$log',function(pinboard,$log){
    return {
        restrict : 'E',
        scope : {
            'editor' : '@'
        },
        bindtoController:true,
        controllerAs :'databoard',
        template :  "<filterpanel filter-panel='databoard.pinboard.filterPanel' ng-show=databoard.pinboard.filterPanel.filterPanelShow></filterpanel>"+
                    '<div gridstack class="grid-stack grid" options=databoard.pinboard.options>'+
                        '<div gridstack-item ng-repeat="w in databoard.pinboard.pinLists" class="grid-stack-item" gs-item-x="w.x" gs-item-y="w.y"'+
                             'gs-item-width="w.width" gs-item-height="w.height" data-gs-min-width="2" gs-item-autopos="1" on-item-added="onItemAdded(d)" on-item-removed="onItemRemoved(item)">'+
                                '<div class="grid-stack-item-content">'+
                                    '<pin ng-repeat="pin in w.pin" idd="{{w.x}}_{{w.y}}_{{w.width}}_{{w.height}}" pinobj=pin class="column"></pin>'+
                                '</div>'+
                        '</div>'+
                    '</div>',
        transclude : true,
        controller : ['$scope','$attrs','$element', function (scope,attrs,element) {
            $log.debug("This is Dashboard directive");
            var vm  = this;
            vm.pinboard = pinboard;
            scope.options = vm.pinboard.options;
        }]
    }
}])