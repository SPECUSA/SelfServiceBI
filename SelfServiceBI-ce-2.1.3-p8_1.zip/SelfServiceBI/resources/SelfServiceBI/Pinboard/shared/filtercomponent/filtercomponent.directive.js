angular.module('pinboard')
.directive("filtercomponent",['commonUtils','translationService','pinboard','$log','$compile','$timeout',function(commonUtils,translationService,pinboard,$log,$compile,$timeout){
    return{
        restrict: 'E',
        scope : {
            filterconfig : "="
        },
        bindtoController:true,
        controllerAs : 'filterComponentCtrl',
        controller : ['$scope','$attrs','$element',function(scope,attrs,element){

            scope.i18n = translationService.trans;
            var vm = this;
            scope.filterSetting = function(){
                $log.debug("Set component Width");

                scope.selectPin = "";
                scope.pinLists = [];
                scope.totalPins = [];

                $.each(pinboard.pinLists,function(i,v){
                    
                     for(a in v.pin[0].defaultParamStr){
                        scope.totalPins.push({pinId:v.pin[0].pinId,param:a,title:v.pin[0].title});
                     }
                })  
                scope.bindPins = [];
                scope.bindPins = angular.copy(scope.filterconfig.listenerPins);


                var i=0;
                while(i<scope.totalPins.length){
                    var hasEntry = false;
                    for(var j=0;j<scope.bindPins.length;j++){
                        if(scope.bindPins[j].pinId==scope.totalPins[i].pinId && scope.bindPins[j].param==scope.totalPins[i].param){
                            scope.bindPins[j].title = scope.totalPins[i].title;
                            hasEntry = true;
                            break; 
                        }
                    }
                    if(hasEntry)
                        scope.totalPins.splice(i,1);
                    else
                        i++;
                }   

                BootstrapDialog.show({
                    title : scope.i18n.filter_settings,
                    message : function(dialog) {
                        var $message = $('<div></div>');
                        var template = commonUtils.getHtmlContent('../Assets/component/templates/filter/filterSetting.html');                                     ;
                        $message.append($compile(template)(scope));
                        return $message;
                    },
                    
                    closable : false,
                    draggable : true,
                    cssClass : 'width650',
                    onshown : function(dialogRef) {

                        scope.componentWidth = scope.filterconfig.filterWidth;
                        
                        scope.addItem = function(indx){
                            scope.bindPins.push(scope.totalPins[indx])
                            scope.totalPins.splice(indx,1)
                            //updateCss();
                            commonUtils.safeApply(scope,function(){})
                        }
                        scope.removeItem = function(indx){
                            scope.totalPins.push(scope.bindPins[indx]);
                            scope.bindPins.splice(indx,1);
                        }

                        if(scope.selectPin != "")
                            scope.changePinParams();
                    },
                    buttons : [{
                        label : scope.i18n.apply,
                        action : function(dialogItself) {
                            scope.filterconfig.filterWidth = scope.componentWidth;
                            scope.filterconfig.listenerPins = angular.copy(scope.bindPins);

                            commonUtils.safeApply(scope,function(){});
                            scope.hideOption();
                            dialogItself.close();
                        },
                        cssClass : 'btn-default btn-lg btn-primary'
                    },{
                        label : scope.i18n.close,
                        action : function(dialogItself) {
                            dialogItself.close();
                        },
                        cssClass : 'btn-lg btn-danger'
                    }]
                });
            }

            scope.removeFilterComponent = function(filterId){
                $log.debug("remove filter is"+ filterId);
                var indx,temp;
                for(i=0;i<pinboard.filterPanel.filterArray.length;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                
                pinboard.filterPanel.filterArray.splice(indx,1);
                if(pinboard.filterPanel.filterArray.length == 0){
                    pinboard.filterPanel.filterPanelShow = false;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }
            scope.slideFilterLeft = function(filterId){
                var indx;
                for(i=0;i<pinboard.filterPanel.filterArray.length;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                //$log.debug("slide filter component of index :"+indx+" to new index :"+indx-1);
                if(indx!=0){
                    var temp = pinboard.filterPanel.filterArray[indx];
                    pinboard.filterPanel.filterArray[indx] =  pinboard.filterPanel.filterArray[indx-1];
                    pinboard.filterPanel.filterArray[indx-1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }

            scope.slideFilterRight = function(filterId){
                var indx;
                var len=pinboard.filterPanel.filterArray.length;
                for(i=0;i<len;i++){
                    if(filterId == pinboard.filterPanel.filterArray[i].filterId){
                        indx = i;
                    }
                }
                //$log.debug("slide filter component of index :"+indx+" to new index :"+indx+1);
                if(indx < len-1 ){
                    var temp = pinboard.filterPanel.filterArray[indx];
                    pinboard.filterPanel.filterArray[indx] =  pinboard.filterPanel.filterArray[indx+1];
                    pinboard.filterPanel.filterArray[indx+1] = temp;
                }
                commonUtils.savedFlag = false;
                $log.debug(pinboard.filterPanel.filterArray);
            }

            scope.showOption = function(){  
                //$log.log("this is clicked"+ scope.filterconfig.filterId);
                $('.'+scope.filterconfig.filterId+'-show').hide();
                $('.'+scope.filterconfig.filterId+'-hide').show();
                $('.'+scope.filterconfig.filterId+'-buttons').show('fast');   
                //$('.btn-filterComponent .'+scope.filterconfig.filterId).show('fast');
            }

            scope.hideOption = function(){
                $('.'+scope.filterconfig.filterId+'-hide').hide();
                $('.'+scope.filterconfig.filterId+'-show').show();
                $('.'+scope.filterconfig.filterId+'-buttons').hide('fast');   
            }
        }],

        link: function(scope,element,attrs){
            //pinboard.filterScope = scope;
            scope.filterconfig.filterVal = (scope.filterconfig.filterVal == null) ? scope.filterconfig.defaultVal : scope.filterconfig.filterVal;
            //scope.filterconfig.filterVal = scope.filterconfig.defaultVal; 

            if(scope.filterconfig.filterType=="combobox" || scope.filterconfig.filterType=="multiselect"){
                
                var url = location.protocol + '//' + location.host + '/pentaho/plugin/cda/api/doQuery?path=/'+encodeURIComponent(scope.filterconfig.dataSource)+'&dataAccessId='+scope.filterconfig.dataAccessId+'&outputIndexId=1';
                var datasrcVal = commonUtils.readJSONFile(url);

                if(datasrcVal!=undefined && datasrcVal.metadata.length==1){
                    scope.filterconfig.datasourceArray = [];
                    angular.forEach(datasrcVal.resultset,function(v,i){
                        scope.filterconfig.datasourceArray.push(v);
                    })
                }
                var filterType = window[scope.filterconfig.filterType];
                var addHtmlComponent = new filterType();
                scope.filterconfig.htmlComponent = addHtmlComponent.init(scope.filterconfig.datasourceArray);
            }
            if(scope.filterconfig.filterType == "datePicker"){
                    scope.opts = {
                    locale: {
                        format: "YYYY-MM-DD"
                    },
                    ranges : {
                       'Today' : [moment(),moment()],
                       'Yesterday' : [moment().subtract(1,'days'),moment().subtract(1,'days')],
                       'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                       'Current Month': [moment().startOf('month'), moment()],
                       'Previous Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
                       'Current Year' : [moment().startOf('year'),moment()]
                    }
                }
            }

            if(commonUtils.editor == true)
            {
                var inputPopoover = ""
                var html ="<div class='filterComponentOuter'>"+
                    "<div class='filterComponent btn-filterComponent form-inline pull-right {{filterconfig.filterId}}-buttons' >" +
                    "<button class='btn  btn-xs filterButton' title={{i18n.remove_filter}} ng-click='removeFilterComponent(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-remove'></i></button>" +
                    "<button class='btn  btn-xs filterButton' title={{i18n.slide_left}} ng-click='slideFilterLeft(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-arrow-left'></i></button>" +
                    "<button class='btn  btn-xs filterButton' title={{i18n.slide_right}} ng-click='slideFilterRight(\""+scope.filterconfig.filterId+"\")'><i class='glyphicon glyphicon-arrow-right'></i></button>" +
                    "<button tabindex='0' title={{i18n.filter_settings}} ng-click='filterSetting()' class='btn btn-xs filterButton filterPopover fa fa-cog'"+
                    "></button>"+
                    "</div>"+
                    "<div class='btn-show-filteroption {{filterconfig.filterId}}-show' ng-click='showOption()'><i class='fa fa-plus-square'></i></div><div class='btn-hide-filteroption {{filterconfig.filterId}}-hide' ng-click='hideOption()'><i class='fa fa-minus-square'></i></div>" ;
            }
            else
                var html = "<div class='filterComponentOuter'>";

            html = html+scope.filterconfig.htmlComponent+"</div>";
            element.html(html);
            $compile(element.contents())(scope);



            $timeout(function(){
            
                if(scope.filterconfig.filterType != 'datePicker'){
                    var d = new Date();
                    var month = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                    if(scope.filterconfig.defaultVal=="currentDay")
                        scope.filterconfig.filterVal= d.getDate().toString();

                    else if(scope.filterconfig.defaultVal=="currentMonth")
                        scope.filterconfig.filterVal= month[d.getMonth()];
                    else if(scope.filterconfig.defaultVal=="currentYear")
                        scope.filterconfig.filterVal= d.getFullYear().toString();

                }
            },0)
        }   
    }
}])