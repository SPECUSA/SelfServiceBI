angular.module('translationModule')
.service("translationService",["$window","$location",function($window,$location){

     this.locale = (navigator.language || navigator.browserLanguage ||
        navigator.systemLanguage || navigator.userLanguage).substring(0, 2).toLowerCase();
    


    if (this.locale == 'zh') {
            this.locale = 'cn';
    }
    
    
    else if ($location.search().locale) {
        this.locale = $location.search().locale;
    }

    var self = this;
    this.getTranslation = function(locale,relative_to_root){

        self.locale = locale || this.locale;
        
        $.ajax({
            url: relative_to_root+"Translation/i18n/"+self.locale+".json",
            dataType: 'json',
            async: false,
            data: null,
            success: function(data) {
                self.trans = data;
            }
        });
        return self.trans;
        
    }
}])